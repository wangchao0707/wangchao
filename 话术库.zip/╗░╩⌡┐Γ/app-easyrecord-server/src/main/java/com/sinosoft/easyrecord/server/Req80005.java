package com.sinosoft.easyrecord.server;

public interface Req80005 {

    public String req80005(String xml);
}
