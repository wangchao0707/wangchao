package com.sinosoft.easyrecord.controller;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.entity4afc.UserSession;
import com.sinosoft.easyrecord.service.TokenManager;
import com.sinosoft.easyrecord.service.UserSessionService;
import com.sinosoft.easyrecord.vo.Token;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/QcServer")
public class QcServerController {
    private static final Logger logger = LoggerFactory.getLogger(QcServerController.class);

    @Resource
    UserSessionService userSessionService;

    @Autowired
    private TokenManager tokenManager;

    /**
     * 根据质检端登陆的用户，向userSession插入数据，再根据得到publicId
     *
     * @param publicId
     */
    @RequestMapping(value = "/getUserSession", method = RequestMethod.POST)
    public RequestResult getUserssion(
            @RequestParam String publicId
    ) {
        logger.info("publicId ===>>> {}", publicId);

      List<UserSession> userList = userSessionService.getUserList(publicId);
        if (userList!=null&&userList.size() > 0) {
            //存入session中=
            // CurrentUser.setUser(userBasicInfo);
            tokenManager.delToken(publicId);
            Token token = tokenManager.createToken(publicId);
            logger.info("token ===>>>  {} ", token);
            token.setAccessToken("QC:" + token.getAccessToken());
            RequestResult result = new RequestResult(true);
            result.setData(token);
            logger.info(" result ===>>> {}",result);

            return result;
        } else {
            return new RequestResult(false, "您没有权限访问此功能");
        }

    }


}
