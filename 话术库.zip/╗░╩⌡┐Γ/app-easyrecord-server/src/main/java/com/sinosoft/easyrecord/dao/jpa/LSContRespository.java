package com.sinosoft.easyrecord.dao.jpa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSCont;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface LSContRespository extends JpaRepository<LSCont, LSCont.LSContPK> {

    List<LSCont> findByClientContNo(String clientContNo);

    List<LSCont> findByLastOneAndInteractiveOrderBySortTimeAsc(char lastOne, String interactive);

    @Query(value = "select pk from LSCont where lastOne=?1 and interactive=?2 order by sortTime asc ")
    List<LSCont.LSContPK> queryPKByLastOneAndInteractiveOrderBySortTimeAsc(char lastOne, String interactive);

    LSCont findByClientContNoAndLastOne(String clientContNo, char lastOne);

    LSCont findTop1ByComCodeAndInsurComCodeAndBusiNumAndLastOneOrderBySortTimeDesc(String comCode, String insurComCode, String busiNum, char lastOne);

    @Transactional
    @Modifying
    @Query(value = "update LSCont set ZipUrl = ?1 where contNo = ?2")
    void updateZipUrl(String zipurl, String contNo);

    @Transactional
    @Modifying
    @Query(value = "update LSCont set ZipUrlTwo = ?1 where contNo = ?2")
    void updateZipUrlTwo(String ZipUrlTwo, String contNo);

    Page<LSCont> findByOperatorAndLastOneInAndSortTimeLessThanEqualOrderByModifyDateDescModifyTimeDesc(String operator, char[] lastOne, String sortTime, Pageable pageable);

    @Transactional
    @Modifying
    @Query(value = "SELECT lc.* FROM LSCont lc LEFT JOIN lsappnt AS la ON lc.contNo = la.contNo LEFT JOIN lsinsured AS li ON la.contNo = li.contNo WHERE lc.operator=?1  AND lc.lastOne in ?2 AND lc.sortTime <=?3 AND  (lc.busiNum LIKE %?4% OR la.name LIKE %?4% OR li.name LIKE %?4%)" ,nativeQuery = true)
    public List<LSCont> findByOperatorAndLastOneInAndSortTimeLessThanEqualAndContNo(String operator, List lastOne, String sortTime, String busiNum);


    int countByOperatorAndLastOne(String operator, char lastOne);


    @Query(value = "select DISTINCT l.BUSINUM from lscont l where l.BUSINUM not in (select v.BUSINUM from videoissend v where v.VIDEOISSEND=1)",nativeQuery = true)
    List<String> findVideoIsNotSendCont();

    List<LSCont> findByBusiNumAndInteractive(String busiNum, String interactive);

    List<LSCont> findByBusiNum(String busiNum);
    List<LSCont> findByInteractiveAndIssend(String interactive, int issend);


}
