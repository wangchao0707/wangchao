package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity4afc.LSOrganization;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/19.
 */
public interface OrganizationDao {

    List<LSOrganization> getOrgList(String comCode);

    LSOrganization getOrganization(String orgCode);

    void deleteByOrgCode(String org);

    void save(LSOrganization lsorganization);

    LSOrganization findByOrgCode(String orgCode);

    List<LSOrganization> findAll(String comCode);


}
