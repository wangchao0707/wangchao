package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSComSignedOnRela;
import com.sinosoft.easyrecord.entity.LSComSignedOnRela.LSComSignedOnRelaPK;

public interface ComSignedOnRelaDao {

    void deleteByRelaComcode(LSComSignedOnRela lsComSignedOnRela);

    void save(LSComSignedOnRela lsComSignedOnRela);

    LSComSignedOnRela find(LSComSignedOnRelaPK lComSignedOnRelaPK);

}
