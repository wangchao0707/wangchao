package com.sinosoft.easyrecord.server;

import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.List;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.EsQcMain;
import com.sinosoft.easyrecord.entity.VideoIsSend;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CookieStore;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.entity.LSCont;

import javax.net.ssl.SSLContext;

@Component
public class VideoUploadTimer {
	
	@Autowired
	ContDao contDao;
	@Autowired
	ContTimeDao contTimeDao;
	@Autowired
	ComConfigDao comConfigDao;
	@Autowired
	EsQcMainDao esQcMainDao;
	@Autowired
	VideoIsSendDao videoIsSendDao;
	@Autowired
	SendVideosToCIITC sendVideosToCIITC;
	@Autowired
	DownVideoAndUnzip downVideoAndUnzip;

	private final static long MONTH = 1000 * 60 * 60 * 24 * 30L;
	@Value(value = "${videoToCIITC.localFileDir}")
	private String localFileDir;
	@Value(value = "${videoToCIITC.cloudUrl}")
	private String cloudUrl;
	@Value("${videoToCIITC.username}")
	private String username;//保险公司账号
	@Value("${videoToCIITC.password}")
	private String password;
	@Value("${videoToCIITC.ip}")
	private String ip;//中保信ip
	@Value("${videoToCIITC.port}")//中保信端口
	private int port;
	@Value("${videoToCIITC.userProxy}")
	private Boolean userProxy;
	@Value("${videoToCIITC.poxy}")
	private String poxy ;
	@Value("${videoToCIITC.httpProtocol}")
	private String httpProtocol;
	private static HttpHost target=null;
	private static Logger logger = LoggerFactory.getLogger(VideoUploadTimer.class);
	private static CloseableHttpClient httpSSlClient = null;
	private String[] Cookies = null;



	@Scheduled(cron="${videoToCIITC.corn}")
	public void startTimer(){
		logger.info("==========向中保信推送双录视频定时任务开始!==========");
		//查找所有未推给中保信的投保单号
		List<String> list = contDao.findVideoIsNotSendCont();
		logger.info("查到未推送的投保单"+list.size());
		try {
			httpSSlClient = createSSLClientDefault();
			//循环检查未推送的视频
			for (int i=0;i<list.size();i++){
				String busiNum = list.get(i);
				//查询此保单号是否有质检通过的lscont信息
				List<LSCont> contList = contDao.findByBusiNumAndInteractive(busiNum,"S");
				logger.info("质检通过的保单共有"+contList.size());
				if (contList.size()>0){//质检通过的保单
					logger.info("busiNum为"+busiNum+"下载并推送流程开始,共有"+contList.size()+"条");
					downVideosAndSendToCIITC(busiNum);
				}else{//质检不通过的保单
					logger.info("检查质检不通过的保单,busiNum:"+busiNum);
					EsQcMain esQcMain = esQcMainDao.findMinDateByBusinessNo(busiNum);
					logger.info("esqcmain获取到的数据为"+esQcMain);
					if (esQcMain!=null){
						Date date = esQcMain.getInspectDate();
						logger.info("获取到了质检日期"+date);
						if (date!=null){
							long between = new Date().getTime()-date.getTime();
							logger.info("日期差值为"+between);
							if(between>2*MONTH){//如果超过两个月
								//从腾讯云下载视频文件并推送到中保信
								downVideosAndSendToCIITC(busiNum);
							}
						}
					}
				}
			}
		} catch (KeyManagementException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}
		logger.info("==========向中保信推送双录视频定时任务结束!==========");
	}


	/**
	 * 获取受信任httpClient
	 *
	 * @return
	 */
	private CloseableHttpClient createSSLClientDefault() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		logger.info("target----------- gouzhao 是否成功"+target);
		String[] ipItem = ip.split("/");
		String ip1 = ipItem[0];
		if (target == null)
			target = new HttpHost(ip1, port, httpProtocol);
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(target), new UsernamePasswordCredentials(username, GetMD5Code(password)));
		SSLContext sslContext;
		try {
			logger.info("======target"+target.getHostName());
			sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
					return true;
				}
			}).build();
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new String[] { "TLSv1.2" },
					null, new NoopHostnameVerifier());

			logger.info("----------------------是否使用代理"+userProxy+":"+poxy);
			CookieStore cookieStore = new BasicCookieStore();
			if(userProxy){
				//HttpHost proxy = new HttpHost(proxyHost, proxyPort, httpProtocol);
				logger.info("----------------------是否使用代理"+userProxy+":"+poxy);
				HttpHost proxy = new HttpHost(poxy);
				UsernamePasswordCredentials usernamePasswordCredentials = new UsernamePasswordCredentials("fshitd28", "Abc_201909");
				credsProvider.setCredentials(new AuthScope(proxy),
						usernamePasswordCredentials);
				httpSSlClient = HttpClients.custom().setSSLSocketFactory(sslsf).setDefaultCredentialsProvider(credsProvider)
						.setProxy(proxy)
						.build();
			}else{
				httpSSlClient = HttpClients.custom().setSSLSocketFactory(sslsf).setDefaultCredentialsProvider(credsProvider)
						.setDefaultCookieStore(cookieStore)
						.build();
			}
			return httpSSlClient;
		} catch (KeyManagementException e) {
			e.printStackTrace();
			throw e;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			throw e;
		} catch (KeyStoreException e) {
			e.printStackTrace();
			throw e;
		}
	}

	private void downVideosAndSendToCIITC(String busiNum){
		List<LSCont> contList = contDao.findByBusiNum(busiNum);
		logger.info("此busiNum:"+busiNum+"下共有"+contList.size()+"条数据");
		for (int i=0;i<contList.size();i++){
			VideoIsSend videoIsSend = new VideoIsSend();
			String contNo = contList.get(i).getContNo();
			String videoFilePath = null;
			try {
				videoFilePath = downVideoAndUnzip.startTask(contNo,localFileDir,cloudUrl);
			} catch (IOException e) {
				logger.error("下载视频压缩包并解压失败");
				e.printStackTrace();
			}
			if (videoFilePath!=null){
				try {
					int serial = 0;
					if (contList.size()!=1){
						serial = i+1;
					}
					String[] Cks = sendVideosToCIITC.sendToCIITCStart(httpSSlClient,contNo,videoFilePath,serial,Cookies);
					Cookies = Cks;
					videoIsSend.setVideoIsSend('1');
				} catch (Exception e) {
					logger.error("推送流水号为"+contNo+"的视频失败 "+e.getMessage());
					videoIsSend.setVideoIsSend('0');
					videoIsSend.setErrorMessage(e.getMessage());
				}
				videoIsSend.setBatchNo(contNo);
				videoIsSend.setContNo(contNo);
				videoIsSend.setBusiNum(busiNum);
			}else{
				logger.error("从云上下载的流水号为"+contNo+"的压缩包中没有视频或下载视频失败!");
				videoIsSend.setBatchNo(contNo);
				videoIsSend.setContNo(contNo);
				videoIsSend.setBusiNum(busiNum);
				videoIsSend.setErrorMessage("从云上下载的流水号为"+contNo+"的压缩包中没有视频或下载视频失败!");
				videoIsSend.setVideoIsSend('0');
			}
			videoIsSendDao.insertOrUpdate(videoIsSend);
			try {
				String videoDir = localFileDir + contNo;
				File file = new File(videoDir);
				if (file.exists()&&file.isDirectory()){
					FileUtils.deleteDirectory(file);
				}
			} catch (IOException e) {
				logger.error("删除临时存放视频文件夹"+localFileDir+contNo+"失败! "+e.getMessage());
			}
		}
	}

	private final static String[] strDigits = { "0", "1", "2", "3", "4", "5",
			"6", "7", "8", "9", "a", "b", "c", "d", "e", "f" };

	// 返回形式为数字跟字符串
	private static String byteToArrayString(byte bByte) {
		int iRet = bByte;
		// System.out.println("iRet="+iRet);
		if (iRet < 0) {
			iRet += 256;
		}
		int iD1 = iRet / 16;
		int iD2 = iRet % 16;
		return strDigits[iD1] + strDigits[iD2];
	}

	// 转换字节数组为16进制字串
	private static String byteToString(byte[] bByte) {
		StringBuffer sBuffer = new StringBuffer();
		for (int i = 0; i < bByte.length; i++) {
			sBuffer.append(byteToArrayString(bByte[i]));
		}
		return sBuffer.toString();
	}

	public static String GetMD5Code(String strObj) {
		String resultString = null;
		try {
			resultString = new String(strObj);
			MessageDigest md = MessageDigest.getInstance("MD5");
			// md.digest() 该函数返回值为存放哈希值结果的byte数组
			resultString = byteToString(md.digest(strObj.getBytes()));
		} catch (NoSuchAlgorithmException ex) {
			ex.printStackTrace();
		}
		return resultString;
	}
	
}
