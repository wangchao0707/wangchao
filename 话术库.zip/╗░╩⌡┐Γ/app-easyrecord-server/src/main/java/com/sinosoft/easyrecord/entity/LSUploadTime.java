package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSUploadTime")
public class LSUploadTime {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "SerialNum")
    private String serialNum;
    @Column(name = "BusiNum")
    private String busiNum;
    @Column(name = "SignTime")
    private String signTime;
    @Column(name = "UploadTime")
    private String uploadTime;
    @Column(name = "Eqinfor")
    private String eqInfor;
    @Column(name = "versionNum")
    private String versionNum;
    @Column(name = "Sign")
    private String sign;
    @Column(name = "token")
    private String token;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getSignTime() {
        return signTime;
    }

    public void setSignTime(String signTime) {
        this.signTime = signTime;
    }

    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getEqInfor() {
        return eqInfor;
    }

    public void setEqInfor(String eqInfor) {
        this.eqInfor = eqInfor;
    }

    public String getVersionNum() {
        return versionNum;
    }

    public void setVersionNum(String versionNum) {
        this.versionNum = versionNum;
    }


    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "LSUploadTime [id=" + id + ", serialNum=" + serialNum + ", busiNum=" + busiNum + ", signTime=" + signTime
                + ", uploadTime=" + uploadTime + ", eqInfor=" + eqInfor + ", versionNum=" + versionNum + ", sign="
                + sign + ", token=" + token + "]";
    }


}
