//package com.sinosoft.easyrecord.controller;
//
//import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//import com.sinosoft.easyrecord.service.AcceptSaveService;
//import com.sinosoft.easyrecord.service.OkhttpService;
//import com.sinosoft.easyrecord.util.StringUtil;
//import org.apache.axis2.addressing.EndpointReference;
//import org.apache.axis2.client.Options;
//import org.apache.axis2.rpc.client.RPCServiceClient;
//import org.apache.axis2.transport.http.HTTPConstants;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.util.StringUtils;
//import org.springframework.web.bind.annotation.*;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.xml.namespace.QName;
//import java.util.HashMap;
//
//@RestController
//@RequestMapping("/accept")
//public class AcceptSaveController {
//
//    final static private Logger logger = LoggerFactory.getLogger(HeadImgController.class);
//
//    @Autowired
//    private AcceptSaveService acceptSaveService;
//
//    @Autowired
//    private OkhttpService okhttpService;
//
//    @RequestMapping(value = "/save", method = RequestMethod.POST)
//    @ResponseBody
//    public RequestResult add(@RequestParam(value = "ORI_VEDIO_NAME")String name,
//                             @RequestParam(value = "ORI_VEDIO_PATH")String path,
//                             @RequestParam(value = "BUSS_NUM")String num,
//                             @RequestParam(value = "RETURN_ADDRESS")String address,
//                             @RequestParam(value = "TIME_NODES")String[] nodes,
//                             @RequestParam(value = "TRANS_TYPE")String trans_type,
//                             HttpServletRequest request){
//        // 非空校验
//        if (StringUtils.isEmpty(name)){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("名字为空");
//            return res;
//        }
//        if (StringUtils.isEmpty(path)){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("路径为空");
//            return res;
//        }
//        if (StringUtils.isEmpty(num)){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("业务流水号为空");
//            return res;
//        }
//        if (StringUtils.isEmpty(address)){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("返回地址为空");
//            return res;
//        }
//        if (StringUtils.isEmpty(nodes)){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("时间节点为空");
//            return res;
//        }
//        if (StringUtils.isEmpty(trans_type)){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("转码类型为空");
//            return res;
//        }
//        String s = acceptSaveService.addVideo(name, path, num, address, nodes, trans_type);
//
//        if (StringUtils.isEmpty(s)){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("请求失败");
//            return res;
//        }else {
//            RequestResult res = new RequestResult(true);
//            HashMap<String,String> has = new HashMap<>();
//            has.put("success",s);
//            res.setData(has);
//            return res;
//        }
//
//
//    }
//
//    @RequestMapping(value = "/okhttp", method = RequestMethod.POST)
//    @ResponseBody
//    public RequestResult okhttp(@RequestParam(value = "ContNo")String contNo,
//                             //@RequestParam(value = "BUSS_NUM")String num,
//                             @RequestParam(value = "RETURN_ADDRESS")String address,
//                             //@RequestParam(value = "TIME_NODES")String[] nodes,
//                             @RequestParam(value = "TRANS_TYPE")String trans_type,
//                             HttpServletRequest request){
//        // 非空校验
//        if (StringUtils.isEmpty(contNo)||contNo.equals("")){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("双录流水号为空");
//            return res;
//        }
//
//        if (StringUtils.isEmpty(address)||address.equals("")){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("返回地址为空");
//            return res;
//        }
//
//        if (StringUtils.isEmpty(trans_type)||trans_type.equals("")){
//            RequestResult res = new RequestResult(false);
//            res.setMessages("转码类型为空");
//            return res;
//        }
//        //String contNo = "b6e4c964-a622-48e6-ae26-7f7bf7518a0f";
//        RequestResult res = okhttpService.addVideo(null, address, trans_type,null,null, );
//
//        return res;
//
//
//    }
//    @RequestMapping(value = "/test", method = RequestMethod.GET)
//    @ResponseBody
//    public String test() throws Exception{
//        String s = "";
//        RPCServiceClient serviceClient = new RPCServiceClient();
//        Options options = serviceClient.getOptions();
//        EndpointReference targetEPR = new EndpointReference("https://testrec.sinosofter.com.cn/GSEasyRecord/services/EasyRecord?wsdl");
//        options.setTo(targetEPR);
//        options.setAction("easyRecord");
//        options.setManageSession(true);
//        options.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, true);
//        // 在创建QName对象时，QName类的构造方法的第一个参数表示WSDL文件的命名空间名，也就是<wsdl:definitions>元素的targetNamespace属性值
//        QName opAddEntry = new QName("http://infservice.webservice.platform.sinosoft", "easyRecord");
//        // 参数，如果有多个，继续往后面增加即可，不用指定参数的名称
//        Object[] opAddEntryArgs = new Object[]{""};
//        // 返回参数类型，这个和axis1有点区别
//        // invokeBlocking方法有三个参数，其中第一个参数的类型是QName对象，表示要调用的方法名；
//        // 第二个参数表示要调用的WebService方法的参数值，参数类型为Object[]；
//        // 第三个参数表示WebService方法的返回值类型的Class对象，参数类型为Class[]。
//        // 当方法没有参数时，invokeBlocking方法的第二个参数值不能是null，而要使用new Object[]{}
//        // 如果被调用的WebService方法没有返回值，应使用RPCServiceClient类的invokeRobust方法，
//        // 该方法只有两个参数，它们的含义与invokeBlocking方法的前两个参数的含义相同
//        Class[] classes = new Class[]{String.class};
//        s = (String) serviceClient.invokeBlocking(opAddEntry, opAddEntryArgs, classes)[0];
//        logger.info("xml {}",s);
//        serviceClient.cleanupTransport();
//        return s;
//    }
//}
