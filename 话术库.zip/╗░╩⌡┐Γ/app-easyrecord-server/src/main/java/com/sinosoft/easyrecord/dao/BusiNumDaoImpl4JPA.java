package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSBusiNumRepository;
import com.sinosoft.easyrecord.entity.LSBusiNum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BusiNumDaoImpl4JPA implements BusiNumDao {

    @Autowired
    private LSBusiNumRepository busiNumRepository;


    @Override
    public List<LSBusiNum> findOneInListBusiNum(String[] busiNumArrs) {
        return busiNumRepository.findByBusiNumIn(busiNumArrs);
    }

    @Override
    public void saveBusiNum(LSBusiNum lsBusiNum) {
        busiNumRepository.saveAndFlush(lsBusiNum);
    }
}
