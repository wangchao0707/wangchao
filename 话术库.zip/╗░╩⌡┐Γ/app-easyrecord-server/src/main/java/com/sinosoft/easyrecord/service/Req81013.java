package com.sinosoft.easyrecord.service;

/**
 * Created by wh on 2018/2/27.
 */
public interface Req81013 {

    String req81013(String xml);
}
