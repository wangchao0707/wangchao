package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-21
 * Time: 19:32
 * 迁移数据 文件数据信息表
 */
@Entity
@Table(name = "LSTransferInfo")
public class LSTransferInfo {

    @Id
    @Column(name = "ContNo")
    private String contNo;

    @Column(name = "OrgCode")
    private String orgCode;

    @Column(name = "Modifydate")
    private Date modifydate;

    /**
     * 文件下载状态
     * N 未开始  H 进行中 F 完成  L 失败   A 上传中  X 完成  E 上传失败
     **/
    @Column(name = "Status")
    private String status;

    /**
     * 腾讯云存储地址
     **/
    @Column(name = "QcloudZipUrl")
    private String qcloudZipUrl;

    /**
     * 腾讯云 文件 sha值
     **/
    @Column(name = "QcloudSHA")
    private String qcloudSHA;

    /**
     * 腾讯云 文件  大小
     **/
    @Column(name = "QcloudFileSize")
    private long qcloudFileSize;

    /**
     * nas 存储文件路径
     **/
    @Column(name = "NasFilePath")
    private String nasFilePath;

    @Column(name = "NasSHA")
    private String nasSHA;

    @Column(name = "NasFileSize")
    private long nasFileSize;

    /**
     * 内容云标识
     **/
    @Column(name = "CmsId")
    private String cmsId;

    @Column(name = "BatchNode")
    private String batchNode;

    @Column(name = "MakeDate")
    private String makeDate;

    @Column(name = "MakeTime")
    private String makeTime;

    @Column(name = "NasPath")
    private String nasPath;

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getQcloudZipUrl() {
        return qcloudZipUrl;
    }

    public void setQcloudZipUrl(String qcloudZipUrl) {
        this.qcloudZipUrl = qcloudZipUrl;
    }

    public String getQcloudSHA() {
        return qcloudSHA;
    }

    public void setQcloudSHA(String qcloudSHA) {
        this.qcloudSHA = qcloudSHA;
    }

    public long getQcloudFileSize() {
        return qcloudFileSize;
    }

    public void setQcloudFileSize(long qcloudFileSize) {
        this.qcloudFileSize = qcloudFileSize;
    }

    public String getNasFilePath() {
        return nasFilePath;
    }

    public void setNasFilePath(String nasFilePath) {
        this.nasFilePath = nasFilePath;
    }

    public String getNasSHA() {
        return nasSHA;
    }

    public void setNasSHA(String nasSHA) {
        this.nasSHA = nasSHA;
    }

    public long getNasFileSize() {
        return nasFileSize;
    }

    public void setNasFileSize(long nasFileSize) {
        this.nasFileSize = nasFileSize;
    }

    public String getCmsId() {
        return cmsId;
    }

    public void setCmsId(String cmsId) {
        this.cmsId = cmsId;
    }

    public String getBatchNode() {
        return batchNode;
    }

    public void setBatchNode(String batchNode) {
        this.batchNode = batchNode;
    }

    public String getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(String makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getNasPath() {
        return nasPath;
    }

    public void setNasPath(String nasPath) {
        this.nasPath = nasPath;
    }

    @Override
    public String toString() {
        return "LSTransferInfo{" +
                "contNo='" + contNo + '\'' +
                ", orgCode='" + orgCode + '\'' +
                ", modifydate=" + modifydate +
                ", status='" + status + '\'' +
                ", qcloudZipUrl='" + qcloudZipUrl + '\'' +
                ", qcloudSHA='" + qcloudSHA + '\'' +
                ", qcloudFileSize=" + qcloudFileSize +
                ", nasFilePath='" + nasFilePath + '\'' +
                ", nasSHA='" + nasSHA + '\'' +
                ", nasFileSize=" + nasFileSize +
                ", cmsId='" + cmsId + '\'' +
                ", batchNode='" + batchNode + '\'' +
                ", makeDate='" + makeDate + '\'' +
                ", makeTime='" + makeTime + '\'' +
                ", nasPath='" + nasPath + '\'' +
                '}';
    }
}
