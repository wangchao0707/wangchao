package com.sinosoft.easyrecord.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "lsversion")
public class LSVersion implements Serializable {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "VersionId")
    private String versionId;
    @Column(name = "VersionPath")
    private String versionPath;
    @Column(name = "IsNew")
    private String isNew;
    @Column(name = "Md5")
    private String md5;
    @Column(name = "message")
    private String message;
    @Column(name = "VersionIOSPath")
    private String versionIOSPath;
    @Column(name = "VersionFile")
    private String versionFile;
    @Column(name = "VersionIOSId")
    private String versionIOSId;
    @Column(name = "ComCode")
    private String comCode;

    @Column(name = "VersionInfor")
    private String versionInfor;
    @Column(name = "VersionIosInfor")
    private String versionIosInfor;

    public String getVersionId() {
        return versionId;
    }

    public void setVersionId(String versionId) {
        this.versionId = versionId;
    }

    public String getVersionPath() {
        return versionPath;
    }

    public void setVersionPath(String versionPath) {
        this.versionPath = versionPath;
    }

    public String getIsNew() {
        return isNew;
    }

    public void setIsNew(String isNew) {
        this.isNew = isNew;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getVersionIOSPath() {
        return versionIOSPath;
    }

    public void setVersionIOSPath(String versionIOSPath) {
        this.versionIOSPath = versionIOSPath;
    }

    public String getVersionFile() {
        return versionFile;
    }

    public void setVersionFile(String versionFile) {
        this.versionFile = versionFile;
    }

    public String getVersionIOSId() {
        return versionIOSId;
    }

    public void setVersionIOSId(String versionIOSId) {
        this.versionIOSId = versionIOSId;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVersionInfor() {
        return versionInfor;
    }

    public void setVersionInfor(String versionInfor) {
        this.versionInfor = versionInfor;
    }


    public String getVersionIosInfor() {
        return versionIosInfor;
    }

    public void setVersionIosInfor(String versionIosInfor) {
        this.versionIosInfor = versionIosInfor;
    }

    @Override
    public String toString() {
        return "LSVersion [id=" + id + ", versionId=" + versionId + ", versionPath=" + versionPath + ", isNew=" + isNew
                + ", md5=" + md5 + ", message=" + message + ", versionIOSPath=" + versionIOSPath + ", versionFile="
                + versionFile + ", versionIOSId=" + versionIOSId + ", comCode=" + comCode + ", versionInfor="
                + versionInfor + ", versionIosInfor=" + versionIosInfor + "]";
    }


}
