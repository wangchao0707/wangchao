package com.sinosoft.easyrecord.server;

/**
 * Created by wds on 2018-3-20.
 */
public interface Req81016 {

    public String getReq81016(String xml);
}
