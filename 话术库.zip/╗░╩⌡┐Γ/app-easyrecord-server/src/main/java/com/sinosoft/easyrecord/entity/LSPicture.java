package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "LSPicture")
public class LSPicture implements Serializable {

    @Id
    @Column(name = "PictureId")
    private String pictureId;
    @Column(name = "PicNo")
    private String picNo;
    @Column(name = "ContNo")
    private String contNo;
    @Column(name = "ClientContNo")
    private String clientContNo;
    @Column(name = "PicName")
    private String picName;
    @Column(name = "PicType")
    private String picType;
    @Column(name = "BusiType")
    private String busiType;
    @Column(name = "TimeNode")
    private String timeNode;
    @Column(name = "URL")
    private String URL;
    @Column(name = "Operator")
    private String operator;
    @Column(name = "MakeDate")
    private Date makeDate;

    @Column(name = "MakeTime")
    private String makeTime;

    @Column(name = "ModifyDate")
    private Date modifyDate;

    @Column(name = "ModifyTime")
    private String modifyTime;
    @Column(name = "PKID")
    private String pKId;
    @Column(name = "FileSize")
    private String fileSize;
    @Column(name = "TimeNodeMillisecond")
    private String timeNodeMillisecond;
    @Column(name = "isPlay")
    private  String isPlay;         //增加是否可读

    @Column(name = "ispass")
    private  String ispass;

    public String getIspass() {
        return ispass;
    }

    public void setIspass(String ispass) {
        this.ispass = ispass;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getPictureId() {
        return pictureId;
    }

    public void setPictureId(String pictureId) {
        this.pictureId = pictureId;
    }

    public String getPicNo() {
        return picNo;
    }

    public void setPicNo(String picNo) {
        this.picNo = picNo;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getClientContNo() {
        return clientContNo;
    }

    public void setClientContNo(String clientContNo) {
        this.clientContNo = clientContNo;
    }

    public String getPicName() {
        return picName;
    }

    public void setPicName(String picName) {
        this.picName = picName;
    }

    public String getPicType() {
        return picType;
    }

    public void setPicType(String picType) {
        this.picType = picType;
    }

    public String getTimeNode() {
        return timeNode;
    }

    public void setTimeNode(String timeNode) {
        this.timeNode = timeNode;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String uRL) {
        URL = uRL;
    }


    public String getBusiType() {
        return busiType;
    }

    public void setBusiType(String busiType) {
        this.busiType = busiType;
    }

    public Date getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(Date makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getpKId() {
        return pKId;
    }

    public void setpKId(String pKId) {
        this.pKId = pKId;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public String getTimeNodeMillisecond() {
        return timeNodeMillisecond;
    }

    public void setTimeNodeMillisecond(String timeNodeMillisecond) {
        this.timeNodeMillisecond = timeNodeMillisecond;
    }

    public String getIsPlay() {
        return isPlay;
    }

    public void setIsPlay(String isPlay) {
        this.isPlay = isPlay;
    }
}
