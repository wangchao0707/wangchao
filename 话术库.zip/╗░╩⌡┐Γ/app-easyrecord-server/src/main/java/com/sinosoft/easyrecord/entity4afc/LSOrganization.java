package com.sinosoft.easyrecord.entity4afc;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by WinterLee on 2017/7/13.
 */
@Entity
@Table(name = "LSOrganization")
public class LSOrganization implements Serializable {

    public LSOrganization(String orgCode) {
        this.orgCode = orgCode;
    }


    public LSOrganization() {

    }


    @Column(name = "ComCode")
    private String comCode;
    @Id
    @Column(name = "OrgCode")
    private String orgCode;
    @Column(name = "OrgName")
    private String orgName;
    @Column(name = "UpComCode")
    private String upComCode;
    @Column(name = "UpComName")
    private String upComName;

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }


    public String getUpComCode() {
        return upComCode;
    }


    public void setUpComCode(String upComCode) {
        this.upComCode = upComCode;
    }


    public String getUpComName() {
        return upComName;
    }


    public void setUpComName(String upComName) {
        this.upComName = upComName;
    }


    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("LSOrganization{");
        sb.append("comCode='").append(comCode).append('\'');
        sb.append(", orgCode='").append(orgCode).append('\'');
        sb.append(", orgName='").append(orgName).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
