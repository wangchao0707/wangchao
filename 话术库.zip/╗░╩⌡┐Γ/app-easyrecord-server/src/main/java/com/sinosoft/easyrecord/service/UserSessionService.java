package com.sinosoft.easyrecord.service;

import com.sinosoft.easyrecord.entity4afc.UserSession;

import java.util.List;

public interface UserSessionService {

    List<UserSession> getUserList(String publicId);
}
