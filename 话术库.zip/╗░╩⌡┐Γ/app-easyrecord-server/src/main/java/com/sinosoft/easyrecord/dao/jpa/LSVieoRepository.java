package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LsContState;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSVideo;

public interface LSVieoRepository extends JpaRepository<LSVideo, String> {

    LSVideo findByVideoNameAndContNo(String videoName, String ContNo);

    LSVideo findByContNo(String contNo);

    LSVideo findByContNoAndClientContNo(String contNo, String clientContNo);

    LSVideo findTop1ByCloudFileId(String cloudFileId);
}
