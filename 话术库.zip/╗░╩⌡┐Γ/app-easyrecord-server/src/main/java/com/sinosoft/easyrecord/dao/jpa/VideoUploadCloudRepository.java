package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.VideoUploadCloud;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @create 2020/3/1 0001
 */

public interface VideoUploadCloudRepository extends JpaRepository<VideoUploadCloud,String> {

}
