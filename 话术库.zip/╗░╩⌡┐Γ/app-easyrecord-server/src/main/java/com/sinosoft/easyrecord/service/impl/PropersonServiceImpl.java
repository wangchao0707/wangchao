package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.dao.BankNetWorkDao;
import com.sinosoft.easyrecord.entity.LSBankNetWork;
import com.sinosoft.easyrecord.service.PropersonService;
import com.sinosoft.easyrecord.vo.PropersonForm;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wds on 2018-3-20.
 */
@Service("propersonService")
public class PropersonServiceImpl implements PropersonService {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(PropersonServiceImpl.class);


    @Autowired
    private BankNetWorkDao bankNetWorkDao;

    //根据网点编码获取客户经理信息
    @Override
    public List<PropersonForm> findPropersonBybankNetWork(String bankNetWorkCode) {
        logger.info("findPropersonBybankNetWork");

        List<LSBankNetWork> list = bankNetWorkDao.findAllByBankNetWorkCode(bankNetWorkCode);
        List<PropersonForm> list1 = new ArrayList<>();
        if (list != null && list.size() != 0) {
            for (LSBankNetWork pro : list) {
                PropersonForm pf = new PropersonForm();
                pf.setPropersonCode(pro.getPropersonCode());
                pf.setPropersonName(pro.getPropersonName());
                list1.add(pf);
            }
        }

        return list1;

    }
}
