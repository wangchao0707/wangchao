package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;

public class TransbodyReq81011 implements Transbody, Serializable {

    public String TYPE;  //<!--操作类型 INSERT UPDATE DELETE-->
    public String BEFOREDOCCODE; //<!--上一次的投保单-->
    public String BEFOREDOCCODECOUNT; //<!--上一次的投保单数量-->
    public String NEWDOCCODE; //<!--新投保单-->
    public String BUSINESSNO; //<!--最新流水号-->


}
