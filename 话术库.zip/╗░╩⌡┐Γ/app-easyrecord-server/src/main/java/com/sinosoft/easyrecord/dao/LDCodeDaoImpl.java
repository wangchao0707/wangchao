package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LDCodeRepository;
import com.sinosoft.easyrecord.entity.LDCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author lijunming
 * @date 2018/7/2 下午3:24
 */
@Repository
public class LDCodeDaoImpl implements  LDCodeDao {
    @Autowired
    LDCodeRepository ldCodeRepository;
    @Override
    public LDCode findLDCodeByCodeName(String codeName) {
        return ldCodeRepository.findLDCodeByCodeName(codeName);
    }
}
