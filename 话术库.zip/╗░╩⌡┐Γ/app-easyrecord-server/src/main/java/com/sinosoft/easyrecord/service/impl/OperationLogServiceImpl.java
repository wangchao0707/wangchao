package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.dao.OperationLogDao;
import com.sinosoft.easyrecord.entity.LSOperationLog;
import com.sinosoft.easyrecord.service.OperationLogService;
import com.sinosoft.easyrecord.sso.CurrentUser;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/*
 * 操作日志
 * */
@Service
public class OperationLogServiceImpl implements OperationLogService {

    private Logger logger = LoggerFactory.getLogger(OperationLogServiceImpl.class);

    @Autowired
    private OperationLogDao operationLogDao;

    public void setOperationLogDao(OperationLogDao operationLogDao) {
        this.operationLogDao = operationLogDao;
    }

    @Value("${save.configPath}")
    private String configPath;

    @Override
    public ServiceResult<String, String[]> saveOperationLog(MultipartFile operationLog, String userId,
                                                            String equipmentInformation) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        //非空验证
        if (StringUtils.isEmpty(userId)) {
            return builder.createFailResult(new String[]{"用户ID为空"});
        }
        if (StringUtils.isEmpty(equipmentInformation)) {
            return builder.createFailResult(new String[]{"设备信息为空"});
        }

        String operator = CurrentUser.getUser().getUserId();
        logger.info("operationLog  userId {} operator {}", userId, operator);
        if (!operator.equals(userId)) {
            return builder.createFailResult(new String[]{"当前用户不正确"});
        }
        String fileName = operationLog.getOriginalFilename();
        String ext = FilenameUtils.getExtension(fileName);
//		String path = System.getProperty("user.dir");
        File dir = new File(configPath + "/upload/operatorLog/" + userId);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        String newFileName = fileName + "." + ext;
        File targetFile = new File(dir, newFileName);

        // 保存
        try {
            operationLog.transferTo(targetFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String realPath = targetFile.getAbsolutePath();
        String logPath = "/public/upload/operatorLog/" + userId + "/" + newFileName;

        //保存上传日志信息
        LSOperationLog lsOperationLog = new LSOperationLog();
        lsOperationLog.setId(UUID.randomUUID().toString());
        lsOperationLog.setUserId(userId);
        lsOperationLog.setEquipmentInformation(equipmentInformation);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:ss:mm");
        Date date = new Date();
        lsOperationLog.setUploadTime(sdf.format(date));
        lsOperationLog.setLogPath(realPath);
        operationLogDao.saveOperationLog(lsOperationLog);

        return builder.createSuccessResult(logPath);
    }
}
