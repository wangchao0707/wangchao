package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSOrganizationBackups;

import javax.transaction.Transaction;

import org.springframework.data.jpa.repository.JpaRepository;


/**
 * Created by LJW on 2017/8/9.
 */
public interface LSOrganizationBackupsRepository extends JpaRepository<LSOrganizationBackups, String> {
}
