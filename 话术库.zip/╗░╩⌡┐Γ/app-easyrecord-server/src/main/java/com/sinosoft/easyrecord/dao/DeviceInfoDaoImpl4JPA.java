package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSDeviceInfoRepository;
import com.sinosoft.easyrecord.entity.LSDeviceInfor;

@Component
public class DeviceInfoDaoImpl4JPA implements DeviceInforDao {

    private LSDeviceInfoRepository deviceInfoRepository;

    @Autowired
    public void setDeviceInfoRepository(LSDeviceInfoRepository deviceInfoRepository) {
        this.deviceInfoRepository = deviceInfoRepository;
    }

    @Override
    public void saveDeviceInfor(LSDeviceInfor lsDeviceInfor) {
        deviceInfoRepository.saveAndFlush(lsDeviceInfor);
    }

}
