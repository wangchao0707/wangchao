package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.service.AcceptSaveService;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

@Service
public class AcceptSaveServiceImpl implements AcceptSaveService {

    @Override
    public String addVideo(String name, String path, String num, String address, String[] nodes, String trans_type) {
        String url = "http://192.168.232.64:8089/stream/video/saveVideo";
        URL u = null;
        HttpURLConnection con = null;
        //构建请求参数
        StringBuffer sb = new StringBuffer();
        sb.append("ORI_VEDIO_NAME");
        sb.append("=");
        sb.append(name);
        sb.append("&");
        sb.append("ORI_VEDIO_PATH");
        sb.append("=");
        sb.append(path);
        sb.append("&");
        sb.append("BUSS_NUM");
        sb.append("=");
        sb.append(num);
        sb.append("&");
        sb.append("RETURN_ADDRESS");
        sb.append("=");
        sb.append(address);
        sb.append("&");
        sb.append("TIME_NODES");
        sb.append("=");
        sb.append(nodes);
        sb.append("&");
        sb.append("TRANS_TYPE");
        sb.append("=");
        sb.append(trans_type);
        sb.append("&");
        sb.substring(0,sb.length()-1);

         try {
            u = new URL(url);
            con = (HttpURLConnection) u.openConnection();
            //// POST 只能为大写，严格限制，post会不识别  
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setUseCaches(false);
            //con.setRequestProperty("Content-Type", "multipart/form-data");
            OutputStreamWriter osw = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
            osw.write(sb.toString());
            osw.flush();
            osw.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (con != null) {
                con.disconnect();
            }
        }

        // 读取返回内容  
        StringBuffer buffer = new StringBuffer();
        try {
            //一定要有返回值，否则无法把请求发送给server端。  
            BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            String temp;
            while ((temp = br.readLine()) != null) {
                buffer.append(temp);
                buffer.append("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        return buffer.toString();
    }
}
