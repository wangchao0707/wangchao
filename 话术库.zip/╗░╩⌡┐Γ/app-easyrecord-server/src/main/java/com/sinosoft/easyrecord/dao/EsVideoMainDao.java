package com.sinosoft.easyrecord.dao;

public interface EsVideoMainDao {

    String findUpLoadCountByDocCode(String docCode);
}
