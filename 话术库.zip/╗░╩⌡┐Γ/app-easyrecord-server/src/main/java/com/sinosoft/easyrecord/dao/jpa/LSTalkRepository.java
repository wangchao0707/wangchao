package com.sinosoft.easyrecord.dao.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.sinosoft.easyrecord.entity.LSRiskType;
import com.sinosoft.easyrecord.entity.LSTalk;
import org.springframework.transaction.annotation.Transactional;

public interface LSTalkRepository extends JpaRepository<LSTalk, String> {
    //查询对应的步骤和话术
    //  @Query("select * from LSTalk where ComCode=?1 and InsurComCode=?2 and RiskType=?3 order by OrderNum")
    List<LSTalk> findByComCodeAndInsurComCodeAndRiskTypeOrderByOrderNumAsc(String comCode, String insurComCode, String riskType);

    List<LSTalk> findByComCode(String comCode);

    //删除方法
    @Modifying
    @Transactional
    @Query(value = "delete from lstalk where ComCode=?1", nativeQuery = true)
    void deleteByComCode(String comCode);

    List<LSTalk> findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(String comCode, String insurComCode, String orgCode, String riskType);

    LSTalk findByPkid(String pkId);

    LSTalk findTop1ByTalkPointCode(String talkPointCode);
}