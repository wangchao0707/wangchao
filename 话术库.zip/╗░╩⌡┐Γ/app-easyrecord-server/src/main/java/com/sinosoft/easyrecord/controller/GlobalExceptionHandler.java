package com.sinosoft.easyrecord.controller;


import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Hashtable;

@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * 系统异常处理，比如：404,500
     *
     * @param req
     * @param e
     * @return
     * @throws Exception
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public RequestResult defaultErrorHandler(HttpServletRequest req, Exception e) throws Exception {
        logger.error(e.getMessage(), e);
        RequestResult r = new RequestResult(false);
        r.setMessage("服务异常");

        Hashtable<String, String> data = new Hashtable<>(1);

        if (e instanceof org.springframework.web.servlet.NoHandlerFoundException) {
            data.put("ErrorCode", "404"); // .setCode(404);
        }else if (e instanceof com.fasterxml.jackson.databind.exc.InvalidFormatException){
            data.put("ErrorCode","500");
        }else {
            data.put("ErrorCode", "500"); // r.setCode(500);
        }
        r.setData(data);
        return r;
    }

}
