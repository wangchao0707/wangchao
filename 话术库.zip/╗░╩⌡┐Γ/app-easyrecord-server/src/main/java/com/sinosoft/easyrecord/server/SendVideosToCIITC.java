package com.sinosoft.easyrecord.server;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.net.ssl.SSLContext;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.entity4afc.LSCom;
import com.sinosoft.easyrecord.util.MD5;
import okhttp3.Cookie;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.*;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SendVideosToCIITC {

    @Autowired
    AppntDao appntDao;
    @Autowired
    EsQcMainDao esQcMainDao;
    @Autowired
    ContDao contDao;
    @Autowired
    VideoDao videoDao;
    @Autowired
    LDCodeDao ldCodeDao;
    @Autowired
    IdTypeToCardTypeDao idTypeToCardTypeDao;
    @Autowired
    OrgCodeToCittcBankCodeDao orgCodeToCittcBankCodeDao;
    @Autowired
    LSComDao lsComDao;



    @Value("${videoToCIITC.httpProtocol}")
    private String httpProtocol;
    @Value("${videoToCIITC.ip}")
    private String ip;//中保信ip


/*    @Value("${videoToCIITC.target}")//中保信端口
    private HttpHost target ;*/

    @Value("${videoToCIITC.taskSource}")
    private int taskSource;//业务来源,1-银行，2-保险公司，3-非银行中介机构
    @Value("${videoToCIITC.taskType}")
    private String taskType;//业务类型业务类型，只能上传保险公司允许的业务类型100-承保 200-理赔 300-财务（收付） 400-产品 500-保全 999-其他
    private static Logger logger = LoggerFactory.getLogger(SendVideosToCIITC.class);
    private CloseableHttpClient httpclient;
    private String[] Cookies = null;

    /**
     * 推送视频压缩文件到中保信开始
     */
    public String[] sendToCIITCStart(CloseableHttpClient closeableHttpClient, String contNo, String videoFilePath, int serial, String[] Cks) throws Exception {
        if (Cks!=null){
            Cookies = Cks;
        }
        if (Cookies!=null&&Cookies.length==1){

        }
        httpclient = closeableHttpClient;
        UploadTask(CreateTask(videoFilePath,contNo,serial));
        return Cookies;
    }

    private Task CreateTask(String fileName,String contNo,int serial) throws Exception {
        //查询投保人信息
        LSAppnt lsAppnt = appntDao.findByContNo(contNo);
        //查询lscont表信息
        LSCont lsCont = contDao.findByContNo(contNo);
        //查询视频信息
        LSVideo lsVideo = videoDao.findByContNo(contNo);
        //查询代理人所在机构省公司
        OrgCodeToCittcBankCode toCittcBankCode = orgCodeToCittcBankCodeDao.findByAreaCode(lsCont.getOrgCode());
        String subBankCode = toCittcBankCode.getCiitcBankCode();
        //代理人所在机构
        String bankCode = findBankCode("001",lsCont.getChannel());
        File file = new File(fileName);
        if (!file.exists())
            throw new Exception(fileName+"文件不存在");
        Task task = new Task();
        task.setTaskSource(taskSource);//业务来源,1-银行，2-保险公司，3-非银行中介机构
        task.setCounterid(lsCont.getOperator());//销售人员工号
        task.setBankCode(bankCode);//销售人员所属机构编码,同方全球人寿保险有限公司
        task.setSubBankCode(subBankCode);//销售人员所属机构分行编码
        task.setSubInsurerCode(subBankCode);//(lsCont.getInsurComCode());//保险公司代码（省级分公司）
        String riskTypeItems = lsCont.getRiskType();
        if (riskTypeItems==null&&riskTypeItems.equals("")){
            logger.error("没有在lscont表中找到险种类型:"+riskTypeItems);
            throw new Exception("没有在lscont表中找到险种类型:"+riskTypeItems);
        }else {
            logger.info("查到的risktype为:"+riskTypeItems);
        }
        String riskType = "";
        if (riskTypeItems.contains(",")){
            String[] riskTypeArr = riskTypeItems.split(",");
            riskType = riskTypeArr[0];
        }else {
            riskType = riskTypeItems;
        }
        task.setProduct_code(riskType);//产品代码
        task.setBusinessType("2");//业务识别号类型,1-保单号，2-投保单号，3-其他
        String businessNo = "";
        if (serial==0){
            businessNo = lsCont.getBusiNum();
        }else {
            businessNo = lsCont.getBusiNum()+"_"+serial;
        }
        task.setBusinessNo(businessNo);//业务识别号,这里用投保单号_1  投保单号_2 ,,,,的形式区分同一个投保单下的多个视频
        task.setCustomerName(lsAppnt.getName());//客户姓名
        IdTypeToCustomerCardType customerCardType = idTypeToCardTypeDao.findByIdType(lsAppnt.getIdType());
        if (customerCardType==null||customerCardType.equals("")){
            logger.error("没有在idtype_to_customercardtype中间表中找到证件类型"+lsAppnt.getIdType()+"对应的中保信证件类型");
            throw new Exception("没有在idtype_to_customercardtype中间表中找到证件类型"+lsAppnt.getIdType()+"对应的中保信证件类型");
        }
        task.setCustomerCardType(customerCardType.getCardType());//客户证件类型
        task.setCustomerCardNo(lsAppnt.getIdNo());//客户证件号码
        Date birthday = lsAppnt.getBirthday();
        if (birthday!=null){
            String customerBirthday = new SimpleDateFormat("yyyy-MM-dd").format(birthday);
            task.setCustomerBirthday(customerBirthday);//客户出生日期
        }
        task.setVideoName(file.getName());//视频文件名
        task.setVideoType(file.getName().substring(file.getName().lastIndexOf(".")+1));//视频格式类型
        Date makeDate = lsVideo.getMakeDate();
        if (makeDate!=null){
            String batchNo = new SimpleDateFormat("yyyyMMdd").format(makeDate);
            task.setBatchNo(batchNo);//批次,转格式:yyyyMMddHH,这里使用视频的录制时间作为批次号
        }
        task.setContent_MD5(DigestUtils.md5Hex(new FileInputStream(file)));//文件签名
        task.setPayment_term(4);//交费方式=====================二期
        String record_time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(makeDate);
        task.setRecord_time(record_time);//录制时间
        task.setFile_time(Long.parseLong(lsVideo.getTimeLength()));//录制时长
        task.setFile_length(file.length() / 1024);//文件大小/kb
        task.setFileLocalPath(fileName);//本地地址
        task.setTaskType(taskType);//业务类型业务类型，只能上传保险公司允许的业务类型100-承保 200-理赔 300-财务（收付） 400-产品 500-保全 999-其他
        task.setInsuranceperiod("2");//保障期限========================二期
        logger.info("task:"+task.toString());
        return task;
    }

    private String findBankCode(String orgCode,String channel) throws Exception {
        channel = "A13";
        List<LSCom> comList = lsComDao.getAllComTree(channel);
        LSCom lsCom = null;
        for (int i=0;i<comList.size();i++){
            if (comList.get(i).getComcode().equals(orgCode)){
                lsCom = comList.get(i);
            }
        }
        if (lsCom==null){
            throw new Exception("未找到机构编码:"+orgCode);
        }
        while (lsCom.getUpcomcode()!=null&&!lsCom.getUpcomcode().equals("")){
            lsCom = findUpCom(lsCom,comList);
        }
        OrgCodeToCittcBankCode orgCodeToCittcBankCode = orgCodeToCittcBankCodeDao.findByAreaCode(lsCom.getComcode());
        return orgCodeToCittcBankCode.getCiitcBankCode();

    }

    private LSCom findUpCom(LSCom lsCom,List<LSCom> comList){
        if (lsCom.getUpcomcode()==null||lsCom.getUpcomcode().equals("")){
            return lsCom;
        }

        for (int i=0;i<comList.size();i++){

            if (comList.get(i).getComcode().equals(lsCom.getUpcomcode())){

                return comList.get(i);
            }

        }
        return lsCom;

    }

    private void UploadTask(Task task) throws Exception {

        //CloseableHttpClient httpclient = createSSLClientDefault();
        try {
            HttpPost httpPost = new HttpPost(httpProtocol + "://" + ip  + "/insurer_task");
            //HttpPost httpPost = new HttpPost(httpProtocol + "://" + poxy + "/insurer_task");
            String body = JSON.toJSONString(task);
            httpPost.setHeader("Content-Type", "application/json");
            StringEntity stringEntity = new StringEntity(body, "UTF-8");// 解决中文乱码问题
            stringEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json;charset=utf8"));
            httpPost.setEntity(stringEntity);
            logger.info("-------------------httpPost:"+httpPost.toString());
            //logger.info("-------------------localContext:"+localContext.toString());
            //CloseableHttpResponse response = httpclient.execute(target, httpPost, localContext);
            if (Cookies!=null){
                if (Cookies!=null&&Cookies.length==1){
                    httpPost.setHeader("Cookie",Cookies[0]);
                }else {
                    httpPost.setHeader("Cookie",Cookies[1]);
                }
            }
            CloseableHttpResponse response = httpclient.execute(httpPost);
            Header[] headers = response.getHeaders("Set-Cookie");
            if (headers!=null&&Cookies==null){
                String[] cs = new String[headers.length];
                for (int i=0;i<cs.length;i++){
                    cs[i] = headers[i].getValue().split(";")[0].trim();
                }
                Cookies = cs;
            }
            try {
                logger.info("------------------UpdateTask----------------------");
                StatusLine tLine = response.getStatusLine();
                logger.info("-----------------------tLine:"+tLine.toString());
                logger.info("------------------------response:"+response.toString());
                HttpEntity entity = response.getEntity();
                logger.info("------------------------entity:"+entity.toString());
                String data = IOUtils.toString(entity.getContent(), "UTF-8");
                logger.info("---------------------data:"+data);
                if (tLine.getStatusCode() == 200) {
                    JSONObject taskObject = JSON.parseObject(data);
                    logger.info(taskObject.toString());
                    //上传
                    String etag = fileUpload(task.getFileLocalPath(), taskObject.getString("bucket"), taskObject.getString("object"));
                    logger.info("------------------上传完成etag" + etag + "----------------------");
                    if (!etag.isEmpty()) {
                        //更新任务状态
                        UpdateTastStatus(etag, taskObject.getString("task_id"));// 更新任务状态
                    }else{
                        throw new Exception("上传视频失败");
                    }
                }else{
                    throw new Exception(data);
                }
            } catch (Exception e){
                logger.error("推送失败!原因:"+e.getMessage());
                throw e;
            }finally {
                response.close();
            }
        } catch (Exception ex){
            logger.error("推送失败:"+ex.getMessage());
            throw ex;
        }finally {
            //httpclient.close();
        }
    }

    /**
     * 获取授权
     *
     * @return
     * @throws IOException
     * @throws ClientProtocolException
     */
    private Map<String, String> GetInsurerGetauthor(JSONObject jsonObject)
            throws Exception {
        //CloseableHttpClient httpclient = createSSLClientDefault();
        try {
            HttpPut httpPut = new HttpPut(httpProtocol + "://" + ip + "/insurer_getauthor");
            //HttpPut httpPut = new HttpPut(httpProtocol + "://" + poxy + "/insurer_getauthor");
            String body = jsonObject.toJSONString();
            httpPut.setHeader("Content-Type", "application/json");
            StringEntity stringEntity = new StringEntity(body, "UTF-8");// 解决中文乱码问题
            stringEntity.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json;charset=utf8"));
            httpPut.setEntity(stringEntity);
            //logger.info("====----------------------==target"+target.getHostName());
            //CloseableHttpResponse response = httpclient.execute(target, httpPut, localContext);
            if (Cookies!=null){
                if (Cookies!=null&&Cookies.length==1){
                    httpPut.setHeader("Cookie",Cookies[0]);
                }else {
                    httpPut.setHeader("Cookie",Cookies[1]);
                }
            }
            CloseableHttpResponse response = httpclient.execute(httpPut);
            try {
                logger.info("------------------GetInsurerGetauthor----------------------");
                StatusLine tLine = response.getStatusLine();
                HttpEntity entity = response.getEntity();
                String data = IOUtils.toString(entity.getContent(), "UTF-8");
                logger.info(data);
                if (tLine.getStatusCode() == 200) {
                    JSONObject tmpObject = JSON.parseObject(data);
                    Map<String, String> tmpMap = new HashMap<String, String>();
                    tmpMap.put("url", tmpObject.getString("url"));
                    tmpMap.put("method", tmpObject.getString("method"));
                    tmpMap.put("host", tmpObject.getString("host"));
                    return tmpMap;
                }else {
                    throw new Exception(data);
                }
            } catch (Exception ex){
                ex.printStackTrace();
                throw ex;
            }finally {
                response.close();
            }
        } catch (Exception e){
            logger.error("获取授权时出现错误: "+e.getMessage());
            throw e;
        }
    }

    /**
     * 上传视频
     *
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    private String UploadVideo(Map<String, String> tmpMap, File file)
            throws ClientProtocolException, IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        //CloseableHttpClient httpclient = createSSLClientDefault();
        HttpPut httpPut = new HttpPut(tmpMap.get("url"));
        httpPut.setHeader("Host", tmpMap.get("host"));
        FileInputStream fInputStream = new FileInputStream(file);
        InputStreamEntity inputStreamEntity = new InputStreamEntity(fInputStream);
        httpPut.setEntity(inputStreamEntity);
        //logger.info("上传视频Cookie:"+httpPut.getFirstHeader("Cookie"));
        if (Cookies!=null){
            if (Cookies!=null&&Cookies.length==1){
                httpPut.setHeader("Cookie",Cookies[0]);
            }else {
                httpPut.setHeader("Cookie",Cookies[1]);
            }
        }
        CloseableHttpResponse response = httpclient.execute(httpPut);
        try {
            logger.info("-------------------UploadVideo---------------------");
            StatusLine tLine = response.getStatusLine();
            logger.info(response.getFirstHeader("ETag").getValue());
            if (tLine.getStatusCode() == 200) {
                String etag = response.getFirstHeader("ETag").getValue();
                return etag;
            } else {
                return "";
            }
        } catch (Exception e){
            logger.error("上传视频时出现异常: "+e.getMessage());
            throw e;
        }finally {
            response.close();
        }
    }



    /**
     * 更新任务状态
     *
     * @param etag
     * @param taskId
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    private boolean UpdateTastStatus(String etag, String taskId) throws Exception {
        //CloseableHttpClient httpclient = createSSLClientDefault();
        try {
            String enUrl = httpProtocol + "://" + ip  + "/insurer_update_task?task_id=" + taskId + "&ETag="
                   + URLEncoder.encode(etag, "UTF-8");
            HttpPost httpPost = new HttpPost(enUrl);
            //logger.info("====----------------------==target"+target.getHostName());
            //CloseableHttpResponse response = httpclient.execute(target, httpPost);
            if (Cookies!=null){
                if (Cookies!=null&&Cookies.length==1){
                    httpPost.setHeader("Cookie",Cookies[0]);
                }else {
                    httpPost.setHeader("Cookie",Cookies[1]);
                }
            }
            CloseableHttpResponse response = httpclient.execute(httpPost);
            try {
                logger.info("-------------------UpdateTastStatus---------------------");
                StatusLine tLine = response.getStatusLine();
                HttpEntity entity = response.getEntity();
                String data = IOUtils.toString(entity.getContent(), "UTF-8");
                logger.info(data);
                if (tLine.getStatusCode() == 200)
                    return true;
                else {
                    throw new Exception("上传成功,但是更新任务状态失败: "+data);
                }
            } catch (Exception ex){
                logger.error(ex.getMessage());
                throw ex;
            }finally {
                response.close();
            }
        } catch (Exception e){
            logger.error("更新任务状态时出现异常: "+e.getMessage());
            throw e;
        }finally {
            //httpclient.close();
        }
    }

    /**
     * 文件上传
     *
     * @param fileName
     *            文件名
     * @param bucket
     *            桶名称
     * @param object
     *            对象名称
     * @return etag
     * @throws Exception
     */
    private String fileUpload(String fileName, String bucket, String object) throws Exception {
        File tmpFile = new File(fileName);
        FileInputStream tmpStream = new FileInputStream(tmpFile);
        long fileLength = tmpFile.length();
        String uploadId = "";
        int fileSize =5 * 1024 * 1024;
        if (fileLength > fileSize) {// 分段上传
            JSONObject taskObject = new JSONObject();
            taskObject.put("bucket", bucket);
            taskObject.put("object", object);
            taskObject.put("method", "POST");
            taskObject.put("subresource", "uploads");
            Map<String, String> tmpMap = GetInsurerGetauthor(taskObject);// 获取分段上传初始化授权
            uploadId = InitPartUploade(tmpMap);
            long tmpValue = fileLength % fileSize;
            if (tmpValue != 0)
                tmpValue = fileLength / fileSize + 1;
            else {
                tmpValue = fileLength / fileSize;
            }
            Map<Integer, String> fileTags = new HashMap<Integer, String>();
            for (int i = 1; i <= tmpValue; i++) {
                try {
                    fileSize = (int) Math.min(fileSize, (fileLength - fileSize * (i - 1)));
                    taskObject = new JSONObject();
                    taskObject.put("bucket", bucket);
                    taskObject.put("object", object);
                    taskObject.put("method", "PUT");
                    JSONObject subObject = new JSONObject();
                    subObject.put("uploadId", uploadId);
                    subObject.put("partNumber", i);
                    taskObject.put("parameters", subObject);
                    tmpMap = GetInsurerGetauthor(taskObject);// 获取分段上传授权
                    byte[] tmpBytes = new byte[fileSize];
                    tmpStream.read(tmpBytes);
                    String etag = PartUpload(tmpMap, tmpBytes);
                    if (etag.isEmpty())
                        return "上传终止";
                    fileTags.put(i, etag);
                } catch (Exception ex) {
                    logger.error(ex.getMessage());
                }
            }
            tmpStream.close();

            taskObject = new JSONObject();
            taskObject.put("bucket", bucket);
            taskObject.put("object", object);
            taskObject.put("method", "POST");
            JSONObject subObject = new JSONObject();
            subObject.put("uploadId", uploadId);
            taskObject.put("parameters", subObject);
            // 上传完成
            tmpMap = GetInsurerGetauthor(taskObject);// 获取合并分段授权
            return CompleteUpload(tmpMap, fileTags);
        } else {// 单个上传
            JSONObject taskObject = new JSONObject();
            taskObject.put("bucket", bucket);
            taskObject.put("object", object);
            taskObject.put("method", "PUT");
            Map<String, String> tmpMap = GetInsurerGetauthor(taskObject);// 获取授权
            return UploadVideo(tmpMap, tmpFile);
        }
    }

    /**
     * 分段上传初始化
     *
     * @param tmpMap
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    private String InitPartUploade(Map<String, String> tmpMap) throws ClientProtocolException, IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        //CloseableHttpClient httpclient = createSSLClientDefault();
        HttpPost httpPost = new HttpPost(tmpMap.get("url"));
        httpPost.setHeader("Host", tmpMap.get("host"));
        if (Cookies!=null){
            if (Cookies!=null&&Cookies.length==1){
                httpPost.setHeader("Cookie",Cookies[0]);
            }else {
                httpPost.setHeader("Cookie",Cookies[1]);
            }
        }
        CloseableHttpResponse response = httpclient.execute(httpPost);
        try {
            logger.info("-------------------InitPartUploade---------------------");
            StatusLine tLine = response.getStatusLine();
            if (tLine.getStatusCode() == 200) {
                HttpEntity entity = response.getEntity();
                String data = IOUtils.toString(entity.getContent(), "UTF-8");
                Document document;
                try {
                    document = DocumentHelper.parseText(data);
                } catch (DocumentException e) {
                    return "";
                }
                Element element = document.getRootElement();
                if (element != null) {
                    Element eUploadId = element.element("UploadId");
                    String uploadId = eUploadId.getStringValue();
                    return uploadId;
                }
                return "";
            } else {
                return "";
            }
        } catch (Exception e){
            logger.error("分段上传初始化时出现异常: "+e.getMessage());
            throw e;
        }finally {
            response.close();
        }
    }

    /**
     * 分段上传视频
     *
     * @param tmpMap
     * @param tmpBytes
     *            输入字节
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    private String PartUpload(Map<String, String> tmpMap, byte[] tmpBytes)
            throws ClientProtocolException, IOException {
        try {
            InputStreamEntity inputStreamEntity = new InputStreamEntity(new ByteArrayInputStream(tmpBytes));
            //httpclient = createSSLClientDefault();
            HttpPut httpPut = new HttpPut(tmpMap.get("url"));
            httpPut.setHeader("Host", tmpMap.get("host"));
            httpPut.setEntity(inputStreamEntity);
            if (Cookies!=null){
                if (Cookies!=null&&Cookies.length==1){
                    httpPut.setHeader("Cookie",Cookies[0]);
                }else {
                    httpPut.setHeader("Cookie",Cookies[1]);
                }
            }
            CloseableHttpResponse response = httpclient.execute(httpPut);
            logger.info("-------------------PartUpload---------------------");
            StatusLine tLine = response.getStatusLine();
            logger.info(response.getFirstHeader("ETag").getValue());
            if (tLine.getStatusCode() == 200) {
                String etag = response.getFirstHeader("ETag").getValue();
                return etag;
            } else {
                return "";
            }
        } catch (Exception e) {
            return PartUpload(tmpMap, tmpBytes);
        }
    }

    /**
     * 完成分段上传视频
     *
     * @param tmpMap
     * @param fileTags
     *            上传的分片集合
     * @return
     * @throws ClientProtocolException
     * @throws IOException
     */
    private String CompleteUpload(Map<String, String> tmpMap, Map<Integer, String> fileTags)
            throws ClientProtocolException, IOException, NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
        //CloseableHttpClient httpclient = createSSLClientDefault();
        HttpPost httpPost = new HttpPost(tmpMap.get("url"));
        httpPost.setHeader("Host", tmpMap.get("host"));
        Document document = DocumentHelper.createDocument();
        Element root = DocumentHelper.createElement("CompleteMultipartUpload");
        document.setRootElement(root);
        for (int i = 1; i <= fileTags.size(); i++) {
            Element partElement = root.addElement("Part");
            Element partNumElement = partElement.addElement("PartNumber");
            partNumElement.addText(String.valueOf(i));
            Element etagElement = partElement.addElement("ETag");
            etagElement.addText(fileTags.get(i));
        }
        StringEntity sEntity = new StringEntity(document.asXML());
        httpPost.setEntity(sEntity);
        if (Cookies!=null){
            if (Cookies!=null&&Cookies.length==1){
                httpPost.setHeader("Cookie",Cookies[0]);
            }else {
                httpPost.setHeader("Cookie",Cookies[1]);
            }
        }
        CloseableHttpResponse response = httpclient.execute(httpPost);
        try {
            logger.info("-------------------CompleteUpload---------------------");
            StatusLine tLine = response.getStatusLine();
            logger.info("-------------------" + tLine.toString() + "---------------------");
            if (tLine.getStatusCode() == 200) {
                String data = IOUtils.toString(response.getEntity().getContent(), "UTF-8");
                try {
                    document = DocumentHelper.parseText(data);
                } catch (DocumentException e) {
                    return "";
                }
                Element element = document.getRootElement();
                if (element != null) {
                    Element etagEle = element.element("ETag");
                    String etag = etagEle.getStringValue();
                    return etag;
                }
                return "";
            } else {
                return "";
            }
        } catch (Exception e){
            logger.error(e.getMessage());
            throw e;
        }finally {
            response.close();
        }
    }


}
