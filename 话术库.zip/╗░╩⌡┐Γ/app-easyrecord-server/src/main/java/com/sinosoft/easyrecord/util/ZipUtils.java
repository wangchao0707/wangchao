package com.sinosoft.easyrecord.util;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

public class ZipUtils {
    private static Logger logger = LoggerFactory.getLogger(ZipUtils.class);
    private static int BUFFER_SIZE = 2048;

    public static void main(String[] args) throws Exception {

       ZipUtils.unZip("http://uploaduat-10051630.file.myqcloud.com/easyrecord/2020/1/12/24001/2810000/null-8BA6CFE7-7722-442C-BB7A-69769DDAC9E7.zip", "http://uploaduat-10051630.file.myqcloud.com/easyrecord/2020/1/12/24001/2810000/null-8BA6CFE7-7722-442C-BB7A-69769DDAC9E7");
        /*// 下载网络文件
        int bytesum = 512;
        int byteread = 512;

        URL url = new URL("http://uploaduat-10051630.file.myqcloud.com/easyrecord/2020/1/12/24001/2810000/null-8BA6CFE7-7722-442C-BB7A-69769DDAC9E7.zip");

        try {
            URLConnection conn = url.openConnection();
            InputStream inStream = conn.getInputStream();
            FileOutputStream fs = new FileOutputStream("D:/abc.zip");

            byte[] buffer = new byte[512];
            int length;
            while ((byteread = inStream.read(buffer)) != -1) {
                bytesum += byteread;
                System.out.println(bytesum);
                fs.write(buffer,1024 , byteread);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }*/

    }

    public static void unZip(String zipFilePath, String saveFileDir) {
        valiZipFile(zipFilePath);
        ZipArchiveInputStream zais = null;
        try {
            zais = new ZipArchiveInputStream(new BufferedInputStream(new FileInputStream(zipFilePath), BUFFER_SIZE));
            ArchiveEntry archiveEntry = null;

            while ((archiveEntry = zais.getNextEntry()) != null) {
                if (!archiveEntry.isDirectory()) {
                    File outFile = new File(saveFileDir, archiveEntry.getName()); // 把解压出来的文件写到指定路径
                    OutputStream os = new BufferedOutputStream(FileUtils.openOutputStream(outFile), BUFFER_SIZE);
                   IOUtils.copy(zais, os);
                    IOUtils.closeQuietly(os);
                }
            }
            logger.info("解压完成");
            //zais = null;
        } catch (IOException e) {
            logger.error("zip解压报错");
            e.printStackTrace();
        } finally {
            if (zais != null) {
                try {
                    zais.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                IOUtils.closeQuietly(zais);
            }

       }
    }

    private static void valiZipFile(String filePath) {
        if (!"zip".equalsIgnoreCase(FilenameUtils.getExtension(filePath))) {
            throw new RuntimeException("文件后缀不为zip");
        }
    }
}
