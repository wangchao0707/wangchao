//package com.sinosoft.easyrecord.controller;
//
//import com.sinosoft.almond.commons.transmit.data.ServiceResult;
//import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//import com.sinosoft.easyrecord.service.TransferVideoService;
//import com.sinosoft.easyrecord.vo.TransferVideoForm;
//import com.sinosoft.easyrecord.vo.UploadProgressForm;
//import com.sinosoft.easyrecord.vo.VideoStatusVo;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.util.StringUtils;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//
//
///**
// * @create 2020/2/28 0028
// */
//@RestController
//@RequestMapping(value = "/api")
//public class TransferVideoController {
//
//    private static final Logger LOGGER = LoggerFactory.getLogger(TransferVideoController.class);
//    @Autowired
//    private TransferVideoService transferVideoService;
//
//    @PostMapping(value = "/transferVideo")
//    public RequestResult transferVideo(@RequestBody TransferVideoForm param) {
//        ServiceResult<String, String[]> validateRes = param.validate();
//        if (!validateRes.isSuccess()) {
//            RequestResult res = new RequestResult(false);
//            res.setMessages(validateRes.getFailResult());
//            LOGGER.info("TransferVideoForm[{}] validate faild", param);
//            return res;
//        }
//        RequestResult result = new RequestResult(true);
//        transferVideoService.transferVideo(param);
//        result.setData(param.getContId());
//        return result;
//    }
//
//    @PostMapping(value = "/uploadProgress")
//    public RequestResult getUploadProgress(@RequestBody UploadProgressForm param) {
//        ServiceResult<String, String[]> validateRes = param.validate();
//        if (!validateRes.isSuccess()) {
//            RequestResult res = new RequestResult(false);
//            res.setMessages(validateRes.getFailResult());
//            LOGGER.info("UploadProgressForm[{}] validate faild", param);
//            return res;
//        }
//        RequestResult result = new RequestResult(true);
//        VideoStatusVo statusVo = transferVideoService.getUploadProgress(param.getContId());
//        if (StringUtils.isEmpty(statusVo)) {
//            RequestResult requestResult = new RequestResult(false);
//            requestResult.setData("上传状态暂无！");
//            return requestResult;
//        }
//        result.setData(statusVo);
//        return result;
//    }
//
//}
