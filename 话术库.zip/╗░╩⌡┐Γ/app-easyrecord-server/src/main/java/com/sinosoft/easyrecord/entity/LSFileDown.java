package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-08
 * Time: 16:20
 * 下载产品信息 文件 列表
 */
@Entity
@Table(name = "LSFileDown")
public class LSFileDown {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "FileName")
    private String fileName;
    @Column(name = "FliePath")
    private String filePath;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public String toString() {
        return "LSFileDown{" +
                "id='" + id + '\'' +
                ", fileName='" + fileName + '\'' +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
