package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.EsMessageSink;
import com.sinosoft.easyrecord.entity.EsQcMain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public interface EsMessageSinkRepository extends JpaRepository<EsMessageSink, String> {


    @Query(value = "select * from es_message_sink where  (CREATEDATETIME >=?1)or (MODIFYDATETIME >=?1) ",nativeQuery = true)
    public List<EsMessageSink> getAllByTime(String dateTime);
}
