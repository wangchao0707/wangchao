package com.sinosoft.easyrecord.service;

import com.sinosoft.easyrecord.vo.PropersonForm;

import java.util.List;


/**
 * Created by wds on 2018-3-20.
 */
public interface PropersonService {

    List<PropersonForm> findPropersonBybankNetWork(String bankNetWork);
}
