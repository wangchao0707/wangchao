package com.sinosoft.easyrecord.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.controller.UploadController;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.service.OkhttpService;
import com.sinosoft.easyrecord.service.PolicyService;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
//import java.net.http.HttpRequest;


@Service
public class OkhttpServiceImpl implements OkhttpService {

    private static final Logger logger = LoggerFactory.getLogger(OkhttpServiceImpl.class);

    @Autowired
    private ContDao contDao;

    @Autowired
    private TransferInfoDao transferInfoDao;

    @Autowired
    private ContStateDao contStateDao;

    @Autowired
    private ContTimeDao contTimeDao;

    @Autowired
    private PictureDao pictureDao;

    @Autowired
    private VideoDao videoDao;

    @Value("${cms.notifyUrl}")
    private String notifyUrl;

    @Value("${stream.videoProducessUrl}")
    private String streamVideoProducessUrl;

    @Override
    @Transactional
    public RequestResult addVideo(LSCont cont,String address, String trans_type,String zipUrl,String name,LsContState lsContState) {
        String contNo = cont.getContNo();
        String url = streamVideoProducessUrl;//请求的路径
        // 根据双录流水号查原文件名和原文件路径

        //LSVideo video = videoDao.findByContNo(contNo);
        //String name = video.getVideoName() + "." + video.getVideoType(); // 原文件名
        /*String path = contTimeDao.findContTime(contNo).getZipUrl(); // 原文件路径
        if (StringUtils.isEmpty(path)){
            RequestResult res = new RequestResult(false);
            res.setMessages("原文件路径查不到");
            return res;
        }*/
        // 根据双录流水号查出业务流水号
        //LSCont lsCont = contDao.findByContNo(contNo);

        String businums = cont.getBusiNum();
        if (StringUtils.isEmpty(businums)){
            RequestResult res = new RequestResult(false);
            res.setMessages("业务流水号查不到");
            return res;
        }
        String[] arrBusiNum = businums.split(",");
        String num = Arrays.asList(arrBusiNum).toString();
        // 根据双录流水号查出抽帧时间节点
        List<String> cms_extract_time = new ArrayList<>();
        List<LSPicture> pictures = pictureDao.findByContNoAndBusiType(contNo, "ScreenShoot");
        String[] nodes = new String[2];
        if (pictures != null && !pictures.isEmpty()) {
            //抽帧参数
            for (LSPicture picture : pictures) {
                cms_extract_time.add(picture.getTimeNode().split("\\.")[0]);
            }
//            nodes[0] = "抽帧时点:"+cms_extract_time; //抽帧时点
//            nodes[1] = "抽帧图片大小:600x480"; //抽帧图片大小
        } else {
            cms_extract_time.add("1");
//            nodes[0] = "抽帧时点:"+cms_extract_time; //抽帧时点
//            nodes[1] = "抽帧图片大小:600x480"; //抽帧图片大小
        }
        nodes = cms_extract_time.toArray(nodes);

        OkHttpClient client = new OkHttpClient();
        //创建一个RequestBody对象（存放待提交的参数)
        RequestBody requestBody = new FormBody.Builder()
        .add("CONT_NO",contNo)//双录流水号
        .add("ORI_VEDIO_NAME",name)//原文件名
        .add("ORI_VEDIO_PATH",zipUrl)//原文件路径
        .add("BUSS_NUM",num)//业务流水号
        .add("RETURN_ADDRESS",address)//回调地址
        .add("TIME_NODES",getToString(nodes))//抽帧时间节点
        .add("TRANS_TYPE",trans_type)//转码类型
        .build();
        //将requestBody对象传入
        Request request = new Request.Builder()
        .url(url)
        .post(requestBody)
        .build();


        try {
            Response response = client.newCall(request).execute();
            // 判断是否回调成功
            /*LSTransferInfo lsTransferInfo = transferInfoDao.findByContNo(contNo);
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println(lsTransferInfo);
            if (!lsTransferInfo.getStatus().equals("U")){
                throw new RuntimeException();
            }*/
            /*LSCont lsCont1 = contDao.findByContNo(contNo);
            LsContState contState1 = contStateDao.getContState(contNo);
            if (!lsCont1.getInteractive().equals("F")){
                throw new RuntimeException();
            }
            if (!contState1.getVideoState().equals("D")){
                throw new RuntimeException();
            }
            if (!contState1.getScreenShotState().equals("D")){
                throw new RuntimeException();
            }*/
            String string = response.body().string();
            // 用一个json串来接受返回的值
            com.alibaba.fastjson.JSONObject js = com.alibaba.fastjson.JSONObject.parseObject(string);
            RequestResult res = new RequestResult(js.getBoolean("success"));
            if (js.getBoolean("success")){
                HashMap<String,String> has = new HashMap<>();
                res.setData(has);
            } else{
                res.setMessages("请求错误");
            }
            return res;
        } catch (IOException e) {
            e.printStackTrace();
            RequestResult res = new RequestResult(false);
            res.setMessages("出现异常");
            return res;
        }

    }

    @Override
    public RequestResult updateCmsIndex(String contNo, LSCont lsCont, LsContState lsContState) {
        logger.info("抽帧批处理LSCont为 {}",lsCont);
        logger.info("抽帧批处理LsContState为 {}",lsContState);
        logger.info("抽帧批处理保单状态为 {}",lsCont.getInteractive());
        logger.info("抽帧批处理抽帧状态为 {}",lsContState.getScreenShotState());
        logger.info("抽帧批处理视频状态为 {}",lsContState.getVideoState());
        /*String[] businums = lsCont.getBusiNum().split(",");        //电子投保单单号
        List<String> cms_extract_time = new ArrayList<>();
        List<LSPicture> pictures = pictureDao.findByContNoAndBusiType(contNo, "ScreenShoot");
        String[] nodes = new String[2];
        if (pictures != null && !pictures.isEmpty()) {
            //抽帧参数
            for (LSPicture picture : pictures) {
                cms_extract_time.add(picture.getTimeNode().split("\\.")[0]);
            }
            nodes[0] = "抽帧时点:"+cms_extract_time; //抽帧时点
            nodes[1] = "抽帧图片大小:600x480"; //抽帧图片大小
        } else {
            cms_extract_time.add("1");
            nodes[0] = "抽帧时点:"+cms_extract_time; //抽帧时点
            nodes[1] = "抽帧图片大小:600x480"; //抽帧图片大小
        }*/
        //map.put("isbs_transcoding_status", UploadController.VideoTransCodingStatusEnum.TRANS_CODING); //转码状态
        logger.info("contNo {} screentShot start", contNo);
        lsContState.setScreenShotState("H");      //抽帧状态
//        lsContState.setVideoState("H");           //视频状态
        contStateDao.save(lsContState);
        // 截屏开始 时间节点
        LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
        java.util.Date date = new java.util.Date();
        SimpleDateFormat contSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
        lsContTime.setScreenShotBeginTime(contSdf.format(date));
        lsContTime.setVideoBeginTime(contSdf.format(date));
        contTimeDao.saveContTime(lsContTime);
        LSVideo video = videoDao.findByContNo(contNo);
        String name = video.getVideoName() + "." + video.getVideoType();
        String transType = "1";

        // trans_type为1代表需要转码
        RequestResult res = this.addVideo(lsCont, notifyUrl, transType,lsContTime.getZipUrl(),name, lsContState);
        //String result = this.updateIndex(cmsId, map);
        logger.info("保单状态为 {}",lsCont.getInteractive());

        return res;
    }

    @Override
    public RequestResult updateCmsIndex(String contNo, LSCont lsCont, String cmsId, LSUser lsUser) {

        return null;
    }

    private String getToString(String[] arrayData) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0 ; i < arrayData.length; i++) {
            stringBuilder.append(arrayData[i]);
            if (i < arrayData.length - 1) {
                stringBuilder.append(",");
            }
        }
        return stringBuilder.toString();
    }

}
