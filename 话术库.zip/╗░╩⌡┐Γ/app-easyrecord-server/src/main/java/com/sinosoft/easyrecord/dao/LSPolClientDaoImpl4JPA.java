package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSPolClientRepository;
import com.sinosoft.easyrecord.entity.LspolClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
public class LSPolClientDaoImpl4JPA implements LSPolClientDao {
    @Autowired
    private LSPolClientRepository lsPolClientRepository;

    public void saveAll(List<LspolClient> lspolClients){
        lsPolClientRepository.saveAll(lspolClients);
    }

    public List<LspolClient> findLspolClientByContno(String contno){
        return lsPolClientRepository.findLspolClientByContno(contno);
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteLspolClientByContno(String contno){
        lsPolClientRepository.deleteLspolClientByContno(contno);
    }

    public LspolClient findLspolClientByContnoAndRiskcode(String Contno,String Riskcode){
        return lsPolClientRepository.findByContnoAndRiskcode(Contno,Riskcode);
    }
}
