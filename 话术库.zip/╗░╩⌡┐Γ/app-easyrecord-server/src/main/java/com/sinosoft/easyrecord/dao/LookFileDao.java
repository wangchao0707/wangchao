package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSLookFile;

/**
 * Created by wh on 2018/3/3.
 */
public interface LookFileDao {

    void  saveLookFile(LSLookFile lsLookFile);
    LSLookFile findByContStateTop1(String contState);
    LSLookFile findByContStateAndContNo(String contState, String contNo);

}
