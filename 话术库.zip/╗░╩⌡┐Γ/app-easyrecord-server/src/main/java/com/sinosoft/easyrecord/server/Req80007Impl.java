package com.sinosoft.easyrecord.server;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinosoft.easyrecord.dao.ChannelBakDao;
import com.sinosoft.easyrecord.dao.ChannelDao;
import com.sinosoft.easyrecord.entity.LSChannel;
import com.sinosoft.easyrecord.entity.LSChannelBak;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transbody;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyReq80007;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyRes;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transdata;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transhead;
import com.thoughtworks.xstream.XStream;

@Service
public class Req80007Impl implements Req80007 {

    private Logger logger = LoggerFactory.getLogger(Req80007Impl.class);

    @Autowired
    private ChannelDao channelDao;

    public void setChannelDao(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    @Autowired
    private ChannelBakDao channelBakDao;

    public void setChannelBakDao(ChannelBakDao channelBakDao) {
        this.channelBakDao = channelBakDao;
    }

    @Override
    public String getReq80007(String xml) {
        logger.info("req80007 xml {}", xml);
        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq80007.class);
        xs1.alias("CHANNELS", TransbodyReq80007.CHANNELS.class);
        xs1.alias("CHANNEL", TransbodyReq80007.CHANNEL.class);
        xs1.addImplicitCollection(TransbodyReq80007.CHANNELS.class, "CHANNEL");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        Transhead head = tmp.getTranshead();
        TransbodyReq80007 body = (TransbodyReq80007) tmp.getTransbody();
        TransbodyReq80007.CHANNELS channels = body.getCHANNELS();
        List<TransbodyReq80007.CHANNEL> list = channels.CHANNEL;

        String comcode = head.getCOMPANY();

        // 全量更新
        // 备份数据
        List<LSChannel> channels2 = channelDao.findAll();
        if (channels2 != null && channels2.size() != 0) {
            for (LSChannel lsChannel : channels2) {
                LSChannelBak lsChannelBak = new LSChannelBak();
                lsChannelBak.setId(UUID.randomUUID().toString());
                lsChannelBak.setChannelCode(lsChannel.getChannelCode());
                lsChannelBak.setChannelName(lsChannel.getChannelName());
                Date date = new Date(System.currentTimeMillis());
                lsChannelBak.setModifyDate(date);
                Long makeTime = date.getTime();
                Date d = new Date(makeTime);
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                lsChannelBak.setModifyTime(sdf.format(d));
                // 保存重复数据
                channelBakDao.save(lsChannelBak);
                // 删除重复数据
                channelDao.delChannel(lsChannel);
            }
        }

        if (list != null && list.size() != 0) {
            for (TransbodyReq80007.CHANNEL channel : list) {
                LSChannel lsChannel = new LSChannel();
                lsChannel.setChannelCode(channel.CHANNELCODE);
                lsChannel.setChannelName(channel.CHANNELNAME);
                // 保存 新 数据
                channelDao.saveChannel(lsChannel);
            }
        }
        // 返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

}
