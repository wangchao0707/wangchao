package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSRiskTypeBak;

/**
 * Created by zf on 2017/8/8.
 */
public interface RiskTypeBakDao {
    //备份
    void save(LSRiskTypeBak riskTypeBak);
}
