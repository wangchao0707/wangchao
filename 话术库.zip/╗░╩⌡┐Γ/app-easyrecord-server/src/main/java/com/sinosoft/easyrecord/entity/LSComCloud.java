package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSComCloud")
public class LSComCloud {

    @Id
    @Column(name = "ComCode")
    private String comCode;
    @Column(name = "UserName")
    private String userName;
    @Column(name = "Password")
    private String password;

    @Column(name = "AxisCloud")
    private String axisCloud;

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAxisCloud() {
        return axisCloud;
    }

    public void setAxisCloud(String axisCloud) {
        this.axisCloud = axisCloud;
    }


}
