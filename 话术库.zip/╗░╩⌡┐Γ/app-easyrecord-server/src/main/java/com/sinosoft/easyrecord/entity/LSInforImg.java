package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "LSInforImg")
public class LSInforImg implements Serializable {

    @EmbeddedId
    private LSInforImgComp id;
    @Column(name = "Image")
    private String image;
    @Column(name = "ImagePath")
    private String imagePath;

    public LSInforImgComp getId() {
        return id;
    }

    public void setId(LSInforImgComp id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public LSInforImg(LSInforImgComp id, String image, String imagePath) {
        super();
        this.id = id;
        this.image = image;
        this.imagePath = imagePath;
    }

    public LSInforImg(LSInforImgComp id, String image) {
        super();
        this.id = id;
        this.image = image;
    }

    public LSInforImg() {
        super();
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("LSInforImg{");
        sb.append("contNo='").append(id.getContNo()).append('\'');
        sb.append(", type='").append(id.getType()).append('\'');
        sb.append(", image='").append(image).append('\'');
        sb.append(", imagePath='").append(imagePath).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
