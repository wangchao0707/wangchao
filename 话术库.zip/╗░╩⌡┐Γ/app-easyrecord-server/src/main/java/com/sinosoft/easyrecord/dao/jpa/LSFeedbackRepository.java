package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSFeedback;

public interface LSFeedbackRepository extends JpaRepository<LSFeedback, String> {

}
