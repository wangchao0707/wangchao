package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;




 /**
  *   新产品表   Created by Feng on   2018/9/18  13:43
  *
  **/

@Entity
@Table(name = "LsProductnew")
public class LSProductNew {
    @Id
    @Column(name = "id")
    private String id;
    /*
     * 是否发布
     *
     */
    @Column(name = "type")                    //类型  release 发布, cancelRelease 取消发布
    private String type;

    /*
     *产品类型
     */

    @Column(name = "productId")
    private String productId;

    @Column(name = "productTypeCode")
    private String productTypeCode;         //产品类型编码

    @Column(name = "productTypeName")
    private String productTypeName;          //产品类型名称
    /**
     * 产品
     */

    @Column(name = "productCode")
    private String productCode;              //产品编码

    @Column(name = "productName")
    private String productName;             //产品名称


    @Column(name = "makeDate")
    private String makeDate;                //创建日期

    @Column(name = "makeTime")
    private String makeTime;                //创建时间

    @Column(name = "isDeath")               //是否死亡
    private String isDeath;

    @Column(name = "isHealth")               //是否健康
    private String isHealth;

//    @Column(name = "MODIFYDATE")
//    private String modifyDate;              //修改日期
//
//    @Column(name = "MODIFYTIME")
//    private String modifyTime;              //修改时间


    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProductTypeCode() {
        return this.productTypeCode;
    }

    public void setProductTypeCode(String productTypeCode) {
        this.productTypeCode = productTypeCode;
    }

    public String getProductTypeName() {
        return this.productTypeName;
    }

    public void setProductTypeName(String productTypeName) {
        this.productTypeName = productTypeName;
    }

    public String getProductCode() {
        return this.productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return this.productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getMakeDate() {
        return this.makeDate;
    }

    public void setMakeDate(String makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return this.makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getIsDeath() {
        return this.isDeath;
    }

    public void setIsDeath(String isDeath) {
        this.isDeath = isDeath;
    }

    public String getIsHealth() {
        return this.isHealth;
    }

    public void setIsHealth(String isHealth) {
        this.isHealth = isHealth;
    }

    public String getProductId() {
        return this.productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    @Override
    public String toString() {
        return "LSProduct{" +
                "id='" + id + '\'' +
                ", type='" + type + '\'' +
                ", productTypeCode='" + productTypeCode + '\'' +
                ", productTypeName='" + productTypeName + '\'' +
                ", productCode='" + productCode + '\'' +
                ", productName='" + productName + '\'' +
                ", makeDate='" + makeDate + '\'' +
                ", makeTime='" + makeTime + '\'' +
                ", isDeath='" + isDeath + '\'' +
                ", productId='" + productId + '\'' +
                ", isHealth='" + isHealth + '\'' +
                '}';
    }
}
