package com.sinosoft.easyrecord.server;

public interface Req81008 {

    public String getReq81008(String xml);

}
