package com.sinosoft.easyrecord.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "lsappnt_client")
public class LsappntClient implements Serializable {
  @Id
  @Column(name = "CONTNO")
  private String contno;
  @Column(name = "APPNTNO")
  private String appntno;
  @Column(name = "APPNTNAME")
  private String appntname;
  @Column(name = "APPNTSEX")
  private String appntsex;
  @Column(name = "APPNTBIRTHDAY")
  private java.sql.Date appntbirthday;
  @Column(name = "APPNTAGE")
  private long appntage;
  @Column(name = "ADDRESS")
  private String address;
  @Column(name = "IDTYPE")
  private String idtype;
  @Column(name = "IDNO")
  private String idno;
  @Column(name = "OPERATOR")
  private String operator;
  @Column(name = "MAKEDATE")
  private java.sql.Date makedate;
  @Column(name = "MAKETIME")
  private String maketime;
  @Column(name = "MODIFYDATE")
  private java.sql.Date modifydate;
  @Column(name = "MODIFYTIME")
  private String modifytime;


  public String getContno() {
    return contno;
  }

  public void setContno(String contno) {
    this.contno = contno;
  }

  public String getAppntno() {
    return appntno;
  }

  public void setAppntno(String appntno) {
    this.appntno = appntno;
  }


  public String getAppntname() {
    return appntname;
  }

  public void setAppntname(String appntname) {
    this.appntname = appntname;
  }


  public String getAppntsex() {
    return appntsex;
  }

  public void setAppntsex(String appntsex) {
    this.appntsex = appntsex;
  }


  public java.sql.Date getAppntbirthday() {
    return appntbirthday;
  }

  public void setAppntbirthday(java.sql.Date appntbirthday) {
    this.appntbirthday = appntbirthday;
  }


  public long getAppntage() {
    return appntage;
  }

  public void setAppntage(long appntage) {
    this.appntage = appntage;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }


  public String getIdtype() {
    return idtype;
  }

  public void setIdtype(String idtype) {
    this.idtype = idtype;
  }


  public String getIdno() {
    return idno;
  }

  public void setIdno(String idno) {
    this.idno = idno;
  }


  public String getOperator() {
    return operator;
  }

  public void setOperator(String operator) {
    this.operator = operator;
  }


  public java.sql.Date getMakedate() {
    return makedate;
  }

  public void setMakedate(java.sql.Date makedate) {
    this.makedate = makedate;
  }


  public String getMaketime() {
    return maketime;
  }

  public void setMaketime(String maketime) {
    this.maketime = maketime;
  }


  public java.sql.Date getModifydate() {
    return modifydate;
  }

  public void setModifydate(java.sql.Date modifydate) {
    this.modifydate = modifydate;
  }


  public String getModifytime() {
    return modifytime;
  }

  public void setModifytime(String modifytime) {
    this.modifytime = modifytime;
  }

  @Override
  public String toString() {
    return "LsappntClient{" +
            "contno='" + contno + '\'' +
            ", appntno='" + appntno + '\'' +
            ", appntname='" + appntname + '\'' +
            ", appntsex='" + appntsex + '\'' +
            ", appntbirthday=" + appntbirthday +
            ", appntage=" + appntage +
            ", address='" + address + '\'' +
            ", idtype='" + idtype + '\'' +
            ", idno='" + idno + '\'' +
            ", operator='" + operator + '\'' +
            ", makedate=" + makedate +
            ", maketime='" + maketime + '\'' +
            ", modifydate=" + modifydate +
            ", modifytime='" + modifytime + '\'' +
            '}';
  }
}
