//package com.sinosoft.easyrecord.controller;
//
//import java.io.File;
//
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.sinosoft.almond.commons.transmit.data.ServiceResult;
//import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//import com.sinosoft.easyrecord.service.InforImgService;
//import com.sinosoft.easyrecord.vo.InforImgForm;
//
//@RestController
//@RequestMapping("api/cont/")
//public class InforImgController {
//	final static private Logger logger = LoggerFactory.getLogger(HeadImgController.class);
//
//	@Autowired
//	private InforImgService inforImgService;
//
//	@RequestMapping(value = "/inforImg", method = RequestMethod.POST)
//	@ResponseBody
//	public RequestResult uploadHeadImg( //
//			String contNo, //
//			String type, @RequestParam(value = "inforImg") MultipartFile inforImgFile) {
//
//		String fileName = inforImgFile.getOriginalFilename();
//		String path = System.getProperty("user.dir");
//		File dir = new File(path + "/src/main/webapp/upload/inforImg/" + contNo + "/" + type);
//		if (!dir.exists()) {
//			dir.mkdirs();
//		}
//
//		File targetFile = new File(dir, fileName);
//
//		// 保存
//		try {
//			inforImgFile.transferTo(targetFile);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		String image = "/upload/inforImg/" + contNo + "/" + type + "/" + targetFile.getName();
//		String imagePath = targetFile.getAbsolutePath();
//		InforImgForm imgForm = new InforImgForm();
//		imgForm.setContNo(contNo);
//		imgForm.setType(type);
//		imgForm.setImage(image);
//		imgForm.setImagePath(imagePath);
//		ServiceResult<String, String[]> validateRes = imgForm.validate();
//
//		if (validateRes.isSuccess()) {
//			validateRes = inforImgService.save(imgForm);
//		}
//
//		if (!validateRes.isSuccess()) {
//			RequestResult res = new RequestResult(false);
//			res.setMessages(validateRes.getFailResult());
//			logger.info("imgForm[{}] validate faild", imgForm);
//			return res;
//		} else {
//			RequestResult res = new RequestResult(true);
//
//			res.setData(imgForm);
//			logger.info("imgForm[{}] success [{}]", validateRes.getSuccessResult());
//			return res;
//		}
//
//	}
//
//}
