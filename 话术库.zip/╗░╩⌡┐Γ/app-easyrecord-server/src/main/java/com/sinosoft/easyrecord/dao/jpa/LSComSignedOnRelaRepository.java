package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSComSignedOnRela;


import org.springframework.data.jpa.repository.JpaRepository;

public interface LSComSignedOnRelaRepository extends JpaRepository<LSComSignedOnRela, LSComSignedOnRela.LSComSignedOnRelaPK> {


}
