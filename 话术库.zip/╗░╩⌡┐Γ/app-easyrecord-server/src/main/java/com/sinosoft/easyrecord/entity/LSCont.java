package com.sinosoft.easyrecord.entity;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.StringJoiner;

@Entity
@Table(name = "lscont")
public class LSCont implements Serializable {


    @EmbeddedId
    private LSContPK pk;
    /**/
    @Column(name = "Operator")
    private String operator;
    /*投保单号*/
    @Column(name = "BusiNum")
    private String busiNum;
    /*公司代码*/
    @Column(name = "ComCode")
    private String comCode;
    /*产品类型*/
    @Column(name = "RiskType")
    private String riskType;
    /*创建日期*/
    @Column(name = "MakeDate")
    private Date makeDate;
    /*创建的时分秒*/
    @Column(name = "MakeTime")
    private String makeTime;//
    /*数据最后一次被修改的日期*/
    @Column(name = "ModifyDate")
    private Date modifyDate;//
    /*修改时间*/
    @Column(name = "ModifyTime")
    private String modifyTime;
    /*客户端唯一标识*/
    @Column(name = "ClientContNo")
    private String clientContNo;
    /*是否重录标识*/
    @Column(name = "OperType")
    private char operType;
    /*如果 重录 关联上一次 contno*/
    @Column(name = "OrginContNo")
    private String orginContNo;
    /*是否存在标识*/
    @Column(name = "LastOne")
    private char lastOne;
    /*状态*/
    @Column(name = "Interactive")
    private String interactive;
    /*经代公司编码*/
    @Column(name = "InsurComCode")
    private String insurComCode;
    /*代理人名字*/
    @Column(name = "OperatorName")
    private String operatorName;
    /*扫描时间*/
    @Column(name = "ScanTime")
    private String scanTime;
    /*扫描日期*/
    @Column(name = "ScanDate")
    private Date scanDate;
    /*机构编码  这个是复用原来的字段（9-9）*/
    @Column(name = "OrgCode")
    private String orgCode;
    /*排序时间*/
    @Column(name = "SortTime")
    private String sortTime;
    /*渠道  这个是复用原来的字段（9-9）*/
    @Column(name = "Channel")
    private String channel;
    /*归档桶地址*/
    @Column(name = "ZipUrl")
    private String zipUrl;
    /*备份桶地址*/
    @Column(name = "ZipUrlTwo")
    private String zipUrlTwo;
    /*备份文件大小*/
    @Column(name = "ZipFileSize")
    private String zipFileSize;
    /*设备类型*/
    @Column(name = "EqInfor")
    private String eqInfor;
    /*银行编码*/
    @Column(name = "BankCode")
    private String bankCode;
    /*版本号*/
    @Column(name = "VersionNum")
    private String versionNum;
    /*登录标识*/
    @Column(name = "token")
    private String token;
    /*银行网点*/
    @Column(name = "BANKNETWORK")
    private String banknetWork;
    /*专管员*/
    @Column(name = "PROPERSON")
    private String properson;
    /*来源 业务数据来源 0是app，1是银保通前置机，2是E店--> 默认 app  这个是复用原来的字段（9-9）*/
    @Column(name = "[RESOURCE]")
    private String resource;
    /*有无双录文件 0:有 1:没有  默认为有*/
    @Column(name = "DATATYPE")
    private String dataType;
    /*质检状态 0-待质检 1-已质检 默认为0 都需要质检*/
    @Column(name = "STATUS")
    private String status;
    /*质检结论 当质检状态为  1-已质检时，需要有质检结论 0-通过  1-不通过  2-整改 */
    @Column(name = "QCCONCLUSION")
    private String qcconclusion;
    /*业务类型自营I 银保Y*/
    @Column(name = "operation")
    private String operation;
    /*整改员编码*/
    @Column(name = "repeatPerson")
    private String repeatPerson;
    /*整改员姓名*/
    @Column(name = "repertPersonName")
    private String repertPersonName;
    /*智能双录标识*/
    @Column(name = "isIntelligence")
    private String isIntelligence;
    /*是否抽中*/
    @Column(name = "ISSAMPLING")
    @org.hibernate.annotations.Type(type ="yes_no")
    private Boolean isSampling;
    /*自保件 */
    @Column(name = "isSelf")
    private String isSelf;
    /*投保场景A:投被保人皆在场  B:投被保人皆不在e店  C:被保人不在e店  D:投保人不在e店  0：暂无投保场景或者为普通投保*/
    @Column(name = "sendScene")
    private String sendScene;

    @Column(name = "orderSn")
    private String orderSn;


    @Column(name = "issend")
    private int issend;
   @Column(name = "ispass")
    private String ispass;


    /*主险名称*/
    private String mainRiskName;

    private String pictureUrl;

    private String videoSize;

    public String getIspass() {
        return ispass;
    }

    public void setIspass(String ispass) {
        this.ispass = ispass;
    }

    public int getIssend(){return issend;}

    public void setIssend(int issend){
        this.issend = issend;
    }

    public String getOrderSn(){return orderSn;}

    public void setOrderSn(String orderSn){this.orderSn=orderSn;}

    public String getVideoSize(){return videoSize;}

    public void setVideoSize(String videoSize){this.videoSize = videoSize;}

    public String getPictureUrl(){return pictureUrl;}

    public void setPictureUrl(String pictureUrl){this.pictureUrl = pictureUrl;}

    public String getMainRiskName(){return mainRiskName;}

    public void setMainRiskName(String mainRiskName){this.mainRiskName = mainRiskName;}

    public String getRepertPersonName() {
        return repertPersonName;
    }

    public void setRepertPersonName(String repertPersonName) {
        this.repertPersonName = repertPersonName;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getRepeatPerson() {
        return repeatPerson;
    }

    public void setRepeatPerson(String repeatPerson) {
        this.repeatPerson = repeatPerson;
    }


    public LSCont() {
        this.pk = new LSContPK();
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getContNo() {
        return pk.getContNo();
    }

    public void setContNo(String contNo) {
        this.pk.setContNo(contNo);
    }

    public LSContPK getPk() {
        return pk;
    }

    public void setPk(LSContPK pk) {
        this.pk = pk;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public Date getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(Date makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getClientContNo() {
        return clientContNo;
    }

    public void setClientContNo(String clientContNo) {
        this.clientContNo = clientContNo;
    }

    public char getOperType() {
        return operType;
    }

    public void setOperType(char operType) {
        this.operType = operType;
    }

    public String getOrginContNo() {
        return orginContNo;
    }

    public void setOrginContNo(String orginContNo) {
        this.orginContNo = orginContNo;
    }

    public char getLastOne() {
        return lastOne;
    }

    public void setLastOne(char lastOne) {
        this.lastOne = lastOne;
    }


    public String getInteractive() {
        return interactive;
    }

    public void setInteractive(String interactive) {
        this.interactive = interactive;
    }

    public String getInsurComCode() {
        return insurComCode;
    }

    public void setInsurComCode(String insurComCode) {
        this.insurComCode = insurComCode;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getScanTime() {
        return scanTime;
    }

    public void setScanTime(String scanTime) {
        this.scanTime = scanTime;
    }

    public Date getScanDate() {
        return scanDate;
    }

    public void setScanDate(Date scanDate) {
        this.scanDate = scanDate;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getSortTime() {
        return sortTime;
    }

    public void setSortTime(String sortTime) {
        this.sortTime = sortTime;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getZipUrl() {
        return zipUrl;
    }

    public void setZipUrl(String zipUrl) {
        this.zipUrl = zipUrl;
    }

    public String getZipUrlTwo() {
        return zipUrlTwo;
    }

    public void setZipUrlTwo(String zipUrlTwo) {
        this.zipUrlTwo = zipUrlTwo;
    }

    public String getEqInfor() {
        return eqInfor;
    }

    public void setEqInfor(String eqInfor) {
        this.eqInfor = eqInfor;
    }

    public String getZipFileSize() {
        return zipFileSize;
    }

    public void setZipFileSize(String zipFileSize) {
        this.zipFileSize = zipFileSize;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getVersionNum() {
        return versionNum;
    }

    public void setVersionNum(String versionNum) {
        this.versionNum = versionNum;
    }

    public String getBanknetWork() {
        return banknetWork;
    }

    public void setBanknetWork(String banknetWork) {
        this.banknetWork = banknetWork;
    }

    public String getProperson() {
        return properson;
    }

    public void setProperson(String properson) {
        this.properson = properson;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }


    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getQcconclusion() {
        return qcconclusion;
    }

    public void setQcconclusion(String qcconclusion) {
        this.qcconclusion = qcconclusion;
    }

    public String getIsIntelligence() {
        return isIntelligence;
    }

    public void setIsIntelligence(String isIntelligence) {
        this.isIntelligence = isIntelligence;
    }

    public Boolean getSampling() {
        return isSampling;
    }

    public void setSampling(Boolean sampling) {
        isSampling = sampling;
    }

    public String getIsSelf() {
        return isSelf;
    }

    public void setIsSelf(String isSelf) {
        this.isSelf = isSelf;
    }

    public String getSendScene() {
        return sendScene;
    }

    public void setSendScene(String sendScene) {
        this.sendScene = sendScene;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", LSCont.class.getSimpleName() + "[", "]")
                .add("pk=" + pk)
                .add("operator='" + operator + "'")
                .add("busiNum='" + busiNum + "'")
                .add("comCode='" + comCode + "'")
                .add("riskType='" + riskType + "'")
                .add("makeDate=" + makeDate)
                .add("makeTime='" + makeTime + "'")
                .add("modifyDate=" + modifyDate)
                .add("modifyTime='" + modifyTime + "'")
                .add("clientContNo='" + clientContNo + "'")
                .add("operType=" + operType)
                .add("orginContNo='" + orginContNo + "'")
                .add("lastOne=" + lastOne)
                .add("interactive='" + interactive + "'")
                .add("insurComCode='" + insurComCode + "'")
                .add("operatorName='" + operatorName + "'")
                .add("scanTime='" + scanTime + "'")
                .add("scanDate=" + scanDate)
                .add("orgCode='" + orgCode + "'")
                .add("sortTime='" + sortTime + "'")
                .add("channel='" + channel + "'")
                .add("zipUrl='" + zipUrl + "'")
                .add("zipUrlTwo='" + zipUrlTwo + "'")
                .add("zipFileSize='" + zipFileSize + "'")
                .add("eqInfor='" + eqInfor + "'")
                .add("bankCode='" + bankCode + "'")
                .add("versionNum='" + versionNum + "'")
                .add("token='" + token + "'")
                .add("banknetWork='" + banknetWork + "'")
                .add("properson='" + properson + "'")
                .add("resource='" + resource + "'")
                .add("dataType='" + dataType + "'")
                .add("status='" + status + "'")
                .add("qcconclusion='" + qcconclusion + "'")
                .add("operation='" + operation + "'")
                .add("repeatPerson='" + repeatPerson + "'")
                .add("repertPersonName='" + repertPersonName + "'")
                .add("isIntelligence='" + isIntelligence + "'")
                .add("isSampling=" + isSampling)
                .add("isSelf=" + isSelf)
                .add("sendScene='" + sendScene + "'")
                .toString();
    }

    @Embeddable
    public static class LSContPK implements Serializable {

        @Column(name = "ContNo")
        private String contNo;

        public LSContPK() {
        }

        public LSContPK(String contNo) {
            this.contNo = contNo;
        }

        public String getContNo() {
            return contNo;
        }

        public void setContNo(String contNo) {
            this.contNo = contNo;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;

            if (o == null || getClass() != o.getClass()) return false;

            LSContPK lsContPK = (LSContPK) o;

            return new EqualsBuilder()
                    .append(getContNo(), lsContPK.getContNo())
                    .isEquals();
        }

        @Override
        public int hashCode() {
            return new HashCodeBuilder(17, 37)
                    .append(getContNo())
                    .toHashCode();
        }

        @Override
        public String toString() {
            return new ToStringBuilder(this)
                    .append("contNo", contNo)
                    .toString();
        }
    }


}
