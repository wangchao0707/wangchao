package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSAuthenticationRepository;
import com.sinosoft.easyrecord.entity.LSAuthentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

/**
 * Created by WinterLee on 2017/7/14.
 */
@Component
public class AuthenticationDaoImpl4JPA implements AuthenticationDao {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationDaoImpl4JPA.class);

    @Autowired
    private LSAuthenticationRepository authenticationRepository;

    public void setAuthenticationRepository(LSAuthenticationRepository authenticationRepository) {
        this.authenticationRepository = authenticationRepository;
    }

    @Override
    public String getPassword(String userid) throws IllegalArgumentException {
        LSAuthentication authentication = getAuthentication(userid);

        if (authentication == null) {
            IllegalArgumentException ex =  new IllegalArgumentException("userid[" + userid + "] is not found LSAuthentication ！！！");
            logger.warn(ex.getMessage(), ex);
            return "";
        }

        return authentication.getPassword();
    }

    @Override
    public void save(LSAuthentication authentication) {
        if (StringUtils.isEmpty(authentication.getUserId())) {
            throw new NullPointerException("userid is empty");
        }

        authenticationRepository.saveAndFlush(authentication);
    }

    @Override
    public LSAuthentication getAuthentication(String userid) {
        Optional<LSAuthentication> res = authenticationRepository.findById(userid);
        return res.orElse(null);
    }

    @Override
    public List<LSAuthentication> findAll() {
        return authenticationRepository.findAll();
    }
}
