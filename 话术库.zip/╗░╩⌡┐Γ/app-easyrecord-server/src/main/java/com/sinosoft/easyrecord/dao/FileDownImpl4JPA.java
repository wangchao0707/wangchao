package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSFileDownRepository;
import com.sinosoft.easyrecord.entity.LSFileDown;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-08
 * Time: 16:24
 */
@Component
public class FileDownImpl4JPA implements FileDownDao{

    @Autowired
    private LSFileDownRepository fileDownRepository;

    /**
     * 查询全部 列表
     **/
    @Override
    public List<LSFileDown> findAll() {
        return fileDownRepository.findAll();
    }
}
