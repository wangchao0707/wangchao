package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSReplaceTalkRepository;
import com.sinosoft.easyrecord.entity.LSReplacetalk;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2018-06-26
 * Time: 10:40
 */
@Component
public class ReplaceTalkDaoImpl4JPA implements ReplaceTalkDao {

    @Autowired
    private LSReplaceTalkRepository lsReplaceTalkRepository;

    @Override
    public LSReplacetalk findByBusiNumAndRiskName(String busiNum, String riskName) {
        return lsReplaceTalkRepository.findByBusiNumAndRiskName(busiNum, riskName);
    }

    @Override
    public LSReplacetalk findByBusiNumAndRiskCode(String busiNum, String riskCode) {
        return lsReplaceTalkRepository.findByBusiNumAndRiskCode(busiNum, riskCode);
    }

    @Override
    public List<LSReplacetalk> findByBusiNum(String busiNum) {
        return lsReplaceTalkRepository.findByBusiNum(busiNum);
    }

/*
    @Override
    public LSReplacetalk findByBusiNum(String busiNum) {
        return lsReplaceTalkRepository.findByBusiNum(busiNum);
    }
*/

    @Override
    public void saveReplaceTalk(LSReplacetalk lsReplacetalk) {
        lsReplaceTalkRepository.save(lsReplacetalk);
    }

    @Override
    public List<LSReplacetalk> findByRiskCodeAndBusiNum(String riskType,String busiNum) {
        return lsReplaceTalkRepository.findByRiskCodeAndBusiNum(riskType,busiNum);
    }

}
