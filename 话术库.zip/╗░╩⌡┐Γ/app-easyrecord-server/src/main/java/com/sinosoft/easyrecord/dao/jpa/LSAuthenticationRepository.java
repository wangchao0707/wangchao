package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSAuthentication;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by WinterLee on 2017/7/14.
 */
public interface LSAuthenticationRepository extends JpaRepository<LSAuthentication, String> {


}
