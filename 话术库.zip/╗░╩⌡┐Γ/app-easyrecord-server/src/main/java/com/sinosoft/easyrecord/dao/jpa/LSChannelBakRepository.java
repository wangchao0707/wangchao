package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSChannelBak;

public interface LSChannelBakRepository extends JpaRepository<LSChannelBak, String> {

}
