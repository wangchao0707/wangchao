package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.dao.UserSessionDao;
import com.sinosoft.easyrecord.entity4afc.UserSession;
import com.sinosoft.easyrecord.service.UserSessionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserSessionServiceImpl implements UserSessionService {
    private static final Logger logger = LoggerFactory.getLogger(UserSessionServiceImpl.class);

    @Resource
    private UserSessionDao userSessionDao;


    @Override
    public List<UserSession> getUserList(String publicId) {
        logger.info("publicId ===>>> {}",publicId);
        return userSessionDao.getUserSession(publicId);
    }

}
