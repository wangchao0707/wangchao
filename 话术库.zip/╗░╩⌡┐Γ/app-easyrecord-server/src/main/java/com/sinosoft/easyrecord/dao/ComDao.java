package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSCom;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/19.
 */
public interface ComDao {

    List<LSCom> getComList();

    //1.保险公司
    LSCom getCom(String comCode);

    //2.代理公司(代理公司业务员，那么第一框显示的就是代理公司代理的所有保险公司)
    //查出代理公司代理了多少个保险公司
    List<LSCom> findByComCode(String comCode);

}
