package com.sinosoft.easyrecord.entity;

import javax.persistence.*;

@Entity
@Table(name = "orgcode_to_ciitcbankcode")
public class OrgCodeToCittcBankCode {

    @Id
    @Column(name = "AI_AREA_CODE")
    String areaCode;
    @Column(name = "AI_AREA_DESC")
    String areaDesc;
    @Column(name = "AI_PROVINCE")
    String province;
    @Column(name = "AI_CITY")
    String city;
    @Column(name = "CIITC_BANKCODE")
    String ciitcBankCode;
    @Column(name = "CIITC_BANKNAME")
    String ciitcBankName;

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getAreaDesc() {
        return areaDesc;
    }

    public void setAreaDesc(String areaDesc) {
        this.areaDesc = areaDesc;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCiitcBankCode() {
        return ciitcBankCode;
    }

    public void setCiitcBankCode(String ciitcBankCode) {
        this.ciitcBankCode = ciitcBankCode;
    }

    public String getCiitcBankName() {
        return ciitcBankName;
    }

    public void setCiitcBankName(String ciitcBankName) {
        this.ciitcBankName = ciitcBankName;
    }

    @Override
    public String toString() {
        return "orgCode_to_cittcBankCode{" +
                "areaCode='" + areaCode + '\'' +
                ", areaDesc='" + areaDesc + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", ciitcBankCode='" + ciitcBankCode + '\'' +
                ", ciitcBankName='" + ciitcBankName + '\'' +
                '}';
    }
}
