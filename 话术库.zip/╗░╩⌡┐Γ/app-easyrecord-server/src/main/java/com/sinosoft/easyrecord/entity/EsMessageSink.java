package com.sinosoft.easyrecord.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="es_message_sink")
public class EsMessageSink {

    @Id
    @Column(name="PRTNO")
    private String prtno;

    @Column(name="UPLOADDATE_FIRST")
    private Date uploaddateFirst;

    @Column(name="UPLOADTIME_FIRST")
    private String uploadtimeFirst;

    @Column(name="QCRECORDCOUNT")
    private String qcrecordcount;

    @Column(name="UPLOADDATE_SECOND")
    private Date uploaddateSecond;

    @Column(name="UPLOADTIME_SECOND")
    private String uploadtimeSecond;

    @Column(name="UPLOADDATE_THIRD")
    private Date uploaddateThird;

    @Column(name="UPLOADTIME_THIRD")
    private String uploadtimeThird;

    @Column(name="QCCONCLUSION")
    private String qcconclusion;

    @Column(name="RESOURCES")
    private String resources;


    @Column(name="INSPECTDATE")
    private Date inspectdate;

    @Column(name="INSPECTTIME")
    private Date inspecttime;


    @Column(name="QCVERDICT")
    private String qcverdict;


    @Column(name="MODIFYDATE")
    private Date modifydate;


    @Column(name="OPERATION")
    private String operation;


    @Column(name="CREATEDATETIME")
    private Date createDatetime;

    @Column(name="MODIFYDATETIME")
    private Date modifydateTime;





    @Column(name="RESOURCE")
    private String resource;




    @Column(name="ISUPLOAD")
    private String isupload;

    @Override
    public String toString() {
        return "EsMessageSink{" +
                "prtno='" + prtno + '\'' +
                ", uploaddateFirst=" + uploaddateFirst +
                ", uploadtimeFirst='" + uploadtimeFirst + '\'' +
                ", qcrecordcount='" + qcrecordcount + '\'' +
                ", uploaddateSecond=" + uploaddateSecond +
                ", uploadtimeSecond='" + uploadtimeSecond + '\'' +
                ", uploaddateThird=" + uploaddateThird +
                ", uploadtimeThird='" + uploadtimeThird + '\'' +
                ", qcconclusion='" + qcconclusion + '\'' +
                ", resources='" + resources + '\'' +
                ", inspectdate=" + inspectdate +
                ", inspecttime=" + inspecttime +
                ", qcverdict='" + qcverdict + '\'' +
                ", modifydate=" + modifydate +
                ", operation='" + operation + '\'' +
                ", createDatetime=" + createDatetime +
                ", modifydateTime=" + modifydateTime +
                ", resource='" + resource + '\'' +
                ", isupload='" + isupload + '\'' +
                '}';
    }

    public String getPrtno() {
        return prtno;
    }

    public void setPrtno(String prtno) {
        this.prtno = prtno;
    }

    public Date getUploaddateFirst() {
        return uploaddateFirst;
    }

    public void setUploaddateFirst(Date uploaddateFirst) {
        this.uploaddateFirst = uploaddateFirst;
    }

    public String getUploadtimeFirst() {
        return uploadtimeFirst;
    }

    public void setUploadtimeFirst(String uploadtimeFirst) {
        this.uploadtimeFirst = uploadtimeFirst;
    }

    public String getQcrecordcount() {
        return qcrecordcount;
    }

    public void setQcrecordcount(String qcrecordcount) {
        this.qcrecordcount = qcrecordcount;
    }

    public Date getUploaddateSecond() {
        return uploaddateSecond;
    }

    public void setUploaddateSecond(Date uploaddateSecond) {
        this.uploaddateSecond = uploaddateSecond;
    }

    public String getUploadtimeSecond() {
        return uploadtimeSecond;
    }

    public void setUploadtimeSecond(String uploadtimeSecond) {
        this.uploadtimeSecond = uploadtimeSecond;
    }

    public Date getUploaddateThird() {
        return uploaddateThird;
    }

    public void setUploaddateThird(Date uploaddateThird) {
        this.uploaddateThird = uploaddateThird;
    }

    public String getUploadtimeThird() {
        return uploadtimeThird;
    }

    public void setUploadtimeThird(String uploadtimeThird) {
        this.uploadtimeThird = uploadtimeThird;
    }

    public String getQcconclusion() {
        return qcconclusion;
    }

    public void setQcconclusion(String qcconclusion) {
        this.qcconclusion = qcconclusion;
    }

    public String getResources() {
        return resources;
    }

    public void setResources(String resources) {
        this.resources = resources;
    }

    public Date getInspectdate() {
        return inspectdate;
    }

    public void setInspectdate(Date inspectdate) {
        this.inspectdate = inspectdate;
    }

    public Date getInspecttime() {
        return inspecttime;
    }

    public void setInspecttime(Date inspecttime) {
        this.inspecttime = inspecttime;
    }

    public String getQcverdict() {
        return qcverdict;
    }

    public void setQcverdict(String qcverdict) {
        this.qcverdict = qcverdict;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Date getCreateDatetime() {
        return createDatetime;
    }

    public void setCreateDatetime(Date createDatetime) {
        this.createDatetime = createDatetime;
    }

    public Date getModifydateTime() {
        return modifydateTime;
    }

    public void setModifydateTime(Date modifydateTime) {
        this.modifydateTime = modifydateTime;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }

    public String getIsupload() {
        return isupload;
    }

    public void setIsupload(String isupload) {
        this.isupload = isupload;
    }
}
