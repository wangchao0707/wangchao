package com.sinosoft.easyrecord.entity;


import org.apache.shiro.SecurityUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by WinterLee on 2017/7/13.
 */
@Entity
@Table(name = "LSCom")
public class LSCom implements Serializable {

    @Id
    @Column(name = "ComCode")
    private String comCode;

    @Column(name = "ComName")
    private String comName;

    @Column(name = "ComType")
    private char comType;



    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName;
    }

    public char getComType() {
        return comType;
    }

    public void setComType(char comType) {
        this.comType = comType;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("LSCom{");
        sb.append("comCode='").append(comCode).append('\'');
        sb.append(", comName='").append(comName).append('\'');
        sb.append('}');
        return sb.toString();
    }

}
