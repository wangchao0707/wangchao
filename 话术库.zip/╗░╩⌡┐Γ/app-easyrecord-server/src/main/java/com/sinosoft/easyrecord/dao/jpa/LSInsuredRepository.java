package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSInsured;


public interface LSInsuredRepository extends JpaRepository<LSInsured, String> {

    LSInsured findByContNo(String contNo);

}
