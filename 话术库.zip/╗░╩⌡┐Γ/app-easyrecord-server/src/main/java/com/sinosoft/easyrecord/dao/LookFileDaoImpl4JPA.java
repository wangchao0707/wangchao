package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSLookFileRepository;
import com.sinosoft.easyrecord.entity.LSLookFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by wh on 2018/3/3.
 */
@Component
public class LookFileDaoImpl4JPA implements LookFileDao {


    @Autowired
    private LSLookFileRepository lsLookFileRepository;

    public void setLsLookFileRepository(LSLookFileRepository lsLookFileRepository) {
        this.lsLookFileRepository = lsLookFileRepository;
    }

    @Override
    public void saveLookFile(LSLookFile lsLookFile) {
        lsLookFileRepository.saveAndFlush(lsLookFile);
    }

    @Override
    public LSLookFile findByContStateTop1(String contState) {
        return lsLookFileRepository.findTop1ByContState(contState);
    }

    @Override
    public LSLookFile findByContStateAndContNo(String contState, String contNo) {
        return lsLookFileRepository.findTop1ByContStateAndContNo(contState,contNo);
    }
}
