package com.sinosoft.easyrecord.server;

public interface ServerService {

    public String easyScanInterface(String xml);
}
