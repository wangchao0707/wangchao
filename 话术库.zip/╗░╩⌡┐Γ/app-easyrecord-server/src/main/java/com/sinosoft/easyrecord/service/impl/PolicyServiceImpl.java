package com.sinosoft.easyrecord.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.almond.commons.transmit.vo.SelectItem;
import com.sinosoft.easyrecord.commonEnum.RiskTypeEnum;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.dao.jpa4afc.LSQuestionRepository;
import com.sinosoft.easyrecord.dao.mybatis.LsBasicOcrMapper;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.entity.LSCom;
import com.sinosoft.easyrecord.entity4afc.*;
import com.sinosoft.easyrecord.service.*;
import com.sinosoft.easyrecord.sso.CurrentUser;
import com.sinosoft.easyrecord.stroage.service.QCloudService;
import com.sinosoft.easyrecord.util.*;
import com.sinosoft.easyrecord.vo.*;
import com.tencentcloudapi.common.Credential;
import com.tencentcloudapi.common.exception.TencentCloudSDKException;
import com.tencentcloudapi.common.profile.ClientProfile;
import com.tencentcloudapi.common.profile.HttpProfile;
import com.tencentcloudapi.ocr.v20181119.OcrClient;
import com.tencentcloudapi.ocr.v20181119.models.GeneralBasicOCRRequest;
import com.tencentcloudapi.ocr.v20181119.models.GeneralBasicOCRResponse;
import com.tencentcloudapi.ocr.v20181119.models.TextDetection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.sql.Date;
import javax.transaction.Transactional;
import java.io.File;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


@Service("policyService")
public class PolicyServiceImpl implements PolicyService {
    final static private Logger logger = LoggerFactory.getLogger(PolicyServiceImpl.class);

    @Value("${save.pictureUrl}")
    private String defaultPictureUrl;

    @Value("${basesicOcr.url}")
    private String basicUrl;

    @Autowired
    private ContDao contDao;

    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }


    @Autowired
    private TalkContentDao talkContentDao;

    @Autowired
    private BankDao bankDao;

    public void setBankDao(BankDao bankDao) {
        this.bankDao = bankDao;
    }

    @Autowired
    private AppntDao appntDao;

    @Autowired
    private RiskTypeNewDao riskTypeNewDao;

    @Autowired
    private UserDao userDao;

    public void setAppnttDao(AppntDao appntDao) {
        this.appntDao = appntDao;
    }

    @Autowired
    private InsuredDao insuredDao;

    public void setInsuredDao(InsuredDao insuredDao) {
        this.insuredDao = insuredDao;
    }

    @Autowired
    private VideoDao videoDao;

    public void setVideoDao(VideoDao videoDao) {
        this.videoDao = videoDao;
    }

    @Autowired
    private PictureDao pictureDao;

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }

    @Autowired
    private ComDao comDao;

    public void setComDao(ComDao comDao) {
        this.comDao = comDao;
    }

    @Autowired
    private RiskTypeDao riskTypeDao;


    @Autowired
    private TalkNewDao talkDao;


    @Autowired
    private ContStateDao contStateDao;

    public void setContStateDao(ContStateDao contStateDao) {
        this.contStateDao = contStateDao;
    }

    @Autowired
    private ContTimeDao contTimeDao;

    public void setContTimeDao(ContTimeDao contTimeDao) {
        this.contTimeDao = contTimeDao;
    }

    @Autowired
    private QCloudService cloudService;

    public void setCloudService(QCloudService cloudService) {
        this.cloudService = cloudService;
    }

    private TalkRunTimeDao talkRunTimeDao;

    @Autowired
    public void setTalkRunTimeDao(TalkRunTimeDao talkRunTimeDao) {
        this.talkRunTimeDao = talkRunTimeDao;
    }

    private OrganizationDao organizationDao;

    @Autowired
    public void setOrganizationDao(OrganizationDao organizationDao) {
        this.organizationDao = organizationDao;
    }

    @Autowired
    private BusiNumDao busiNumDao;

    @Autowired
    private LSStateLocaDao lsStateLocaDao;

    @Autowired
    private LSComDao lsComDao;

    @Autowired
    private QueryDao queryDao;

    @Autowired
    private LSPolClientDao lsPolClientDao;

    @Autowired
    private LSQuestionRepository lsQuestionRepository;

    @Autowired

    public void setBusiNumDao(BusiNumDao busiNumDao) {
        this.busiNumDao = busiNumDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    private TokenDao tokenDao;

    @Autowired
    public void setTokenDao(TokenDao tokenDao) {
        this.tokenDao = tokenDao;
    }


    @Autowired
    private ReplaceTalkDao replaceTalkDao;

    public void setReplaceTalkDao(ReplaceTalkDao replaceTalkDao) {
        this.replaceTalkDao = replaceTalkDao;
    }

    @Autowired
    private CodeDao codeDao;

    @Autowired
    private CheckService checkService;

    @Autowired
    private RelationShipDao relationShipDao;

    @Autowired
    private NewTalkService newTalkService;

    @Autowired
    private OkhttpService okhttpService;

    @Autowired
    private SampleService sampleService;

    @Autowired
    private  LETagLinksDao leTagLinksDao;

    @Autowired
    private  LMProductDao lmProductDao;

//    @Autowired
//    private CmsService cmsService;

    @Autowired
    private MessageDao messageDao;


    @Autowired
    private ProductManagerService productManagerService;

    @Autowired
    private EsRuleMainDao esRuleMainDao;

    @Autowired
    private ComConfigDao comConfigDao;

    @Autowired
    private LsBasicOcrMapper lsBasicOcrMapper;


    @Value("${cms.notifyUrl}")
    private String notifyUrl;

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:28
     * 获取经代公司 列表
     */
    @Override
    public List<SelectItem> findInsurCom(String comCode) {
        LSCom com = comDao.getCom(comCode);
        // 如果是保险公司的话
        List<SelectItem> items = new ArrayList<SelectItem>();
        if (com.getComType() == 'I') {

            SelectItem item = new SelectItem();
            item.setDisplay(com.getComName());
            item.setValue(com.getComCode());

            items.add(item);

            return items;
        } else {
            // 代理公司
            List<LSCom> findByComCode = comDao.findByComCode(comCode);

            for (LSCom lsCom : findByComCode) {
                SelectItem item = new SelectItem();
                item.setDisplay(lsCom.getComName());
                item.setValue(lsCom.getComCode());
                items.add(item);
            }
            return items;

        }
    }

    private SimpleDateFormat contSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:28
     * 保存双录信息
     */
    @Transactional
    public RequestResult savePolcy(PolcyForm polcyForm) throws ServiceResult.ServiceResultException {



        //logger.info(polcyForm.toString());
        // 初始化时间节点
        LSContTime lsContTime = new LSContTime();
        lsContTime.setContNo(polcyForm.getContNo());
        java.util.Date date = new java.util.Date();
        lsContTime.setContBeginTime(contSdf.format(date));
        contTimeDao.saveContTime(lsContTime);

        ServiceResult<String, String[]> serviceResult = null;

        Hashtable<String, String> data = new Hashtable<>(5);
        //保存图片信息
        if (polcyForm.getPictures() != null && polcyForm.getPictures().size() != 0) {

            List<String> picList = new ArrayList<String>();
            for (PictureForm pictureForm : polcyForm.getPictures()) {
                serviceResult = this.savePictureInfo(pictureForm);
                if (!serviceResult.isSuccess()) {
                    throw new ServiceResult.ServiceResultException(serviceResult);
                }
                picList.add(serviceResult.getSuccessResult());
            }
            data.put("picNos", picList.toString());
        }

        //保存保单信息
        serviceResult = this.saveContInfo(polcyForm);
        if (!serviceResult.isSuccess()) {
            throw new ServiceResult.ServiceResultException(serviceResult);
        }
        //获取投保单信息

    /*    if(lsCont.getIspass()!=null){
            data.put("lscontIspass",lsCont.getIspass());
        }*/
        data.put("contNo", serviceResult.getSuccessResult());
        //保存投保人信息
        serviceResult = this.saveAppntInfo(polcyForm.getAppnt());
        if (!serviceResult.isSuccess()) {
            throw new ServiceResult.ServiceResultException(serviceResult);
        }
        data.put("appntNo", serviceResult.getSuccessResult());
        //保存被保人信息
        if (polcyForm.getInsured() != null) {
            logger.info("cont insured");
            serviceResult = this.saveInsuredInfo(polcyForm.getInsured());
            if (!serviceResult.isSuccess()) {
                throw new ServiceResult.ServiceResultException(serviceResult);
            }
            data.put("insuredNo", serviceResult.getSuccessResult());
        }
        //保存视频信息
        //logger.info(polcyForm.toString());
        serviceResult = this.saveVideoInfo(polcyForm.getVideo());
/*            if(!polcyForm.isSampling()){

            }*/
        if (!serviceResult.isSuccess()) {
            throw new ServiceResult.ServiceResultException(serviceResult);
        }
        data.put("videoNo", serviceResult.getSuccessResult());
       /* //保存图片信息
        if (polcyForm.getPictures() != null && polcyForm.getPictures().size() != 0) {

            List<String> picList = new ArrayList<String>();
            for (PictureForm pictureForm : polcyForm.getPictures()) {
                serviceResult = this.savePictureInfo(pictureForm);
                if (!serviceResult.isSuccess()) {
                    throw new ServiceResult.ServiceResultException(serviceResult);
                }
                picList.add(serviceResult.getSuccessResult());
            }
            data.put("picNos", picList.toString());
        }*/
        logger.info("保存话术1111111111{}",polcyForm.getTalk());
            if(polcyForm.getTalk() !=null && polcyForm.getTalk().size() != 0){
                logger.info("保存话术 {}",polcyForm.getTalk().toString());
                for (TalkSaveForm talkSaveForm : polcyForm.getTalk()) {
                    serviceResult = this.saveTalkContent(talkSaveForm,polcyForm.getContNo());
                    if (!serviceResult.isSuccess()) {
                        throw new ServiceResult.ServiceResultException(serviceResult);
                    }
                }
        }

        if(polcyForm.getRisk() !=null && polcyForm.getRisk().size() != 0){
            logger.info("保存产品 {}",polcyForm.getRisk().toString());
            for (RiskSaveForm riskSaveForm : polcyForm.getRisk()) {
                serviceResult = this.saveRiskTypeNew(riskSaveForm,polcyForm.getContNo());
                if (!serviceResult.isSuccess()) {
                    throw new ServiceResult.ServiceResultException(serviceResult);
                }
            }
        }


        //保存 cos地址
        RequestResult requestResult = saveUrlByQ(polcyForm.getContNo(), polcyForm.getZipUrl());
        if (!requestResult.isSuccess()) {
            return requestResult;
        }


        // 保存 保单结束时间节点
        LSContTime contTime = contTimeDao.findContTime(polcyForm.getContNo());
        java.util.Date date1 = new java.util.Date();
        contTime.setContEndTime(contSdf.format(date1));
        contTimeDao.saveContTime(contTime);

        RequestResult result = new RequestResult(true);
        data.put("delFile", "Y");
        result.setData(data);
        return result;
    }



    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:30
     * 保存 视频文件地址
     */
    @Transactional
    public RequestResult saveUrlByQ(String contNo, String zipUrl) {
        LSContTime contTime = contTimeDao.findContTime(contNo);
        LSCont lsCont = contDao.findByContNo(contNo);
        // 增加 下载初始状态
        LsContState lsContState = contStateDao.getContState(lsCont.getContNo());
        // 保存zip路径
        contTime.setZipUrl(zipUrl);
        contTimeDao.saveContTime(contTime);
        // 修改保单状态
        //如果没有双录文件跳过 流程
        if (lsCont.getDataType() != null && lsCont.getDataType().equals("1")) {
            lsContState.setScreenShotState("F");
            lsContState.setDownState("F");
            lsContState.setBakState("F");
        } else {

            //添加保单状态变更轨迹记录
            lsStateLocaDao.saveStateLoca(lsCont, "文件解析中");
            // 增加初始 截屏
            lsContState.setScreenShotState("N");
            lsContState.setDownState("N");
            lsContState.setBakState("F");
        }
        contStateDao.save(lsContState);
        return new RequestResult(true);
    }
    //不放状态，不抽帧
    @Transactional
    public RequestResult saveForSampling(String contNo, String zipUrl){
        LSContTime contTime = contTimeDao.findContTime(contNo);
        LSCont lsCont = contDao.findByContNo(contNo);
        // 增加 下载初始状态
        LsContState lsContState = contStateDao.getContState(lsCont.getContNo());
        // 保存zip路径
        contTime.setZipUrl(zipUrl);
        contTimeDao.saveContTime(contTime);
        // 修改保单状态
        //如果没有双录文件跳过 流程
        if (lsCont.getDataType() != null && lsCont.getDataType().equals("1")) {
            lsContState.setScreenShotState("");
            lsContState.setDownState("F");
            lsContState.setBakState("F");
        } else {
            //添加保单状态变更轨迹记录
            lsStateLocaDao.saveStateLoca(lsCont, "保单未抽中");
            // 增加初始 截屏
            lsContState.setScreenShotState("");
            lsContState.setDownState("F");
            lsContState.setBakState("F");
        }
        contStateDao.save(lsContState);
        return new RequestResult(true);
    }

    @Value(value = "${mp3.enable}")
    private boolean isMp3 = false;


    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:30
     * 保存投保单信息
     */
    @Transactional
    public ServiceResult<String, String[]> saveContInfo(PolcyForm contForm) {

        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);

        ServiceResult<String, String[]> sr = getArrayStringSortMsg(contForm.getBusiNum());
        if (!sr.isSuccess()) {
            return sr;
        }
        LSCont cont = new LSCont();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        // 获得当前时间的毫秒值 添加增加时间
        Date date = new Date(System.currentTimeMillis());
        //添加修改时间
        cont.setModifyDate(date); //修改时间
        cont.setModifyTime(sdf.format(date));
        cont.setMakeDate(date); //创建时间
        cont.setMakeTime(sdf.format(date));
        cont.setOperType('A'); //保单状态
        // 银保数据
        cont.setBankCode(contForm.getBankCode());
        cont.setBanknetWork(contForm.getBanknetWork().toUpperCase());
        cont.setProperson(contForm.getProperson());
        cont.setDataType(contForm.getDataType());
        cont.setStatus(contForm.getStatus());
        cont.setQcconclusion(contForm.getQcconclusion());
        cont.setMainRiskName(contForm.getProductName());
        //业务类型
        cont.setOperation(contForm.getOperation());
        //整改人 初次上传 整改人 为 自身
        cont.setRepeatPerson(contForm.getOperator());
        cont.setRepertPersonName(contForm.getOpeartorName());
        cont.setPictureUrl(contForm.getPictureUrl());
        cont.setVideoSize(contForm.getVideosize());
        cont.setOrderSn(contForm.getOrderSn());
        //所属人
        cont.setOperator(contForm.getOperator());
        cont.setOperatorName(contForm.getOpeartorName());
        //影像来源 0是app，1是银行-->
        if (contForm.getResource()==null || contForm.getResource().equals("")){
            cont.setResource("0");
        }else{
            cont.setResource(contForm.getResource());
        }
        if(contForm.getOrgCode()==null || contForm.getOrgCode().equals("")){
            String orgCode = CurrentUser.getUser().getOrgCode();
            cont.setOrgCode(orgCode);
        }
        cont.setOrgCode(contForm.getOrgCode());
        cont.setChannel(contForm.getChannel());
        String name = CurrentUser.getUser().getName();
        //String birthday = CurrentUser.getUser().getBrithday();
        String sex = CurrentUser.getUser().getSex();
        String idNo = CurrentUser.getUser().getIdNo();
        String self = judgeSelf(contForm.getAppnt(),name,sex,idNo);
        if(contForm.getIsSelf()==null ||contForm.getIsSelf().equals("")){
            cont.setIsSelf(self);
        }else{
            cont.setIsSelf(contForm.getIsSelf());
        }
        if(contForm.getSendScene()==null || contForm.getSendScene().equals("")){
            cont.setSendScene("0");
        }else{
            cont.setSendScene(contForm.getSendScene());
        }
        //判断图片是否通过
       if(!contForm.getIntelligentResults().equals("")&&contForm.getIntelligentResults()!=null){
            cont.setIspass(contForm.getIntelligentResults());
        }
        /*for (PictureForm pictureForm : contForm.getPictures()){
            LSPicture picNo = pictureDao.findByPicNo(pictureForm.getPicNo());
            if(picNo.getIspass()!=null){
                if(picNo.getIspass().equals("0")){
                    cont.setIspass("0");
                }else if(picNo.getIspass().equals("N")){
                    cont.setIspass("Y");

                }else if(picNo.getIspass().equals("Y")){
                    cont.setIspass("N");
                }
            }
        }*/



        /**
         * 初始化 智能双录标识
         * 查询 话术内容 表，如果有数据，智能双录，没有数据，老生产
         **/
       /* cont.setIsIntelligence("Y");
        List<LSTalkContent> talkContents = talkContentDao.findByBusiNumAndRiskType(StringSortUtil.getArrayStringSort(contForm.getBusiNum()), StringSortUtil.getArrayStringSort(contForm.getRiskType()));
        if (talkContents == null || talkContents.isEmpty()) {
            cont.setIsIntelligence("N");
        }

        LSCont lastCont = contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne(contForm.getComCode(),
                contForm.getInsurComCode(), StringSortUtil.getArrayStringSort(contForm.getBusiNum()), 'Y');
        if (lastCont != null) { // 重录操作
            // 获取最后一个修改过的lscont 并修改信息
            if (!lastCont.getOperator().equals(contForm.getOperator()) && StringUtils.isEmpty(lastCont.getBankCode())) {

                return builder.createFailResult(new String[]{"以下投保单号已经被使用:" + contForm.getBusiNum() + "，请更换投保单号重试。"});
            }
            if (lastCont.getInteractive() == null || lastCont.getInteractive().equals("")) {
                // 删除原来保单 数据 是的为 新增操作
                logger.info("old cont DELETE");
                contDao.delCont(lastCont);
            } else if (lastCont.getInteractive().equals("F")) {
                return builder.createFailResult(new String[]{"数据已上传，无法再次录制"});
            } else if (lastCont.getInteractive().equals("D")) {
                return builder.createFailResult(new String[]{"数据已上传，无法再次录制"});
            } else if (lastCont.getInteractive().equals("X")) {
                return builder.createFailResult(new String[]{"数据已上传，无法再次录制"});
            } else if (lastCont.getInteractive().equals("A")) {
                return builder.createFailResult(new String[]{"数据已提交完成，无需重录"});
            } else if (lastCont.getInteractive().equals("M")) {
                return builder.createFailResult(new String[]{"数据已提交完成，无需重录"});
            } else if (lastCont.getInteractive().equals("S")) {
                return builder.createFailResult(new String[]{"数据已审核成功，无需重录"});
            } else if (lastCont.getInteractive().equals("P")) {
                return builder.createFailResult(new String[]{"数据未抽中，无需重录"});
            } else if (lastCont.getInteractive().equals("E")) {
                return builder.createFailResult(new String[]{"数据异常，无需重录"});
            } else if (lastCont.getInteractive().equals("R")) {
                //增加判断 如果是银保业务 那么 不通过允许重录
                if (cont.getOperation().equals("Y")) {
                    logger.info("cont {} interactive R chonglu  start", cont.getContNo());
                    lastCont.setLastOne('N');
                    contDao.save(lastCont);
                    cont.setOrginContNo(lastCont.getContNo());// 保存上次的信息
                    cont.setMakeDate(lastCont.getMakeDate());// 保存注册时间
                    cont.setMakeTime(lastCont.getMakeTime());
                    //修改所属人为之前用户
                    cont.setOperator(lastCont.getOperator());
                    cont.setOperatorName(lastCont.getOperatorName());
                    //修改渠道为原有渠道
                    cont.setChannel(lastCont.getChannel());
                    cont.setOrgCode(lastCont.getOrgCode());
                    cont.setOperType('R');
                    *//**
                     * 拿回上次的智能双录状态
                     **//*
                    if (StringUtils.isEmpty(lastCont.getIsIntelligence())) {
                        cont.setIsIntelligence("N");
                    } else {
                        cont.setIsIntelligence(lastCont.getIsIntelligence());
                    }

                } else {
                    return builder.createFailResult(new String[]{"数据已审核失败，无需重录"});
                }
            } else if (lastCont.getInteractive().equals("L")) {
                logger.info("cont interactive L chonglu  start");
                lastCont.setLastOne('N');
                contDao.save(lastCont);
                cont.setOrginContNo(lastCont.getContNo());// 保存上次的信息
                cont.setMakeDate(lastCont.getMakeDate());// 保存注册时间
                cont.setMakeTime(lastCont.getMakeTime());
                //修改所属人为之前用户
                cont.setOperator(lastCont.getOperator());
                cont.setOperatorName(lastCont.getOperatorName());
                //修改渠道为原有渠道
                cont.setChannel(lastCont.getChannel());
                cont.setOrgCode(lastCont.getOrgCode());
                cont.setOperType('R');
                cont.setSampling(true);

                contForm.setSampling(true);

                *//**
                 * 拿回上次的智能双录状态
                 **//*
                if (StringUtils.isEmpty(lastCont.getIsIntelligence())) {
                    cont.setIsIntelligence("N");
                } else {
                    cont.setIsIntelligence(lastCont.getIsIntelligence());
                }
            } else if (lastCont.getInteractive().equals("Z")) {
                //文件损坏 当重录操作
                logger.info("busiNum {} cont interactive Z file spoil  start", lastCont.getBusiNum());
                lastCont.setLastOne('Z');
//				lastCont.setClientContNo(contForm.getClientContNo());
                contDao.save(lastCont);
                // 获得当前时间的毫秒值 添加修改时间
                cont.setModifyDate(date);
                cont.setModifyTime(sdf.format(date));
                cont.setOrginContNo(lastCont.getOrginContNo());// 保存上次的信息
                cont.setMakeDate(lastCont.getMakeDate());// 保存注册时间
                cont.setMakeTime(lastCont.getMakeTime());
                cont.setOperType(lastCont.getOperType());
                cont.setSampling(true);
                contForm.setSampling(true);
                if (StringUtils.isEmpty(lastCont.getIsIntelligence())) {
                    cont.setIsIntelligence("N");
                } else {
                    cont.setIsIntelligence(lastCont.getIsIntelligence());
                }
            } else {
                return builder.createFailResult(new String[]{"数据未知错误！"});
            }
        }
        //银保数据取回
        if (lastCont != null && lastCont.getBankCode() != null) {
            cont.setBankCode(lastCont.getBankCode());
            cont.setBanknetWork(lastCont.getBanknetWork());
            cont.setProperson(lastCont.getProperson());
            //影像来源 0是app，1是银行-->
            //不在获取上次银保来源
            //cont.setResource(lastCont.getResource());
            //cont.setDataType(lastCont.getDataType());
            cont.setStatus(lastCont.getStatus());
            cont.setQcconclusion(lastCont.getQcconclusion());
        }

        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
        //排序时间
        cont.setSortTime(sdf1.format(date));
        cont.setContNo(contForm.getContNo());

        cont.setBusiNum(StringSortUtil.getArrayStringSort(contForm.getBusiNum()));

        cont.setLastOne('Y');
        cont.setRiskType(StringSortUtil.getArrayStringSort(contForm.getRiskType()));
        cont.setClientContNo(contForm.getClientContNo());
        cont.setComCode(contForm.getComCode());

        if (contForm.getEqInfor() != null) {
            cont.setEqInfor(contForm.getEqInfor());
        }
        // cont.setInteractive('F'); //初始状态均为 F：文件待上传
        cont.setInsurComCode(contForm.getInsurComCode());
        if (contForm.getScanDate() != null) {
            cont.setScanDate(contForm.getScanDate());
            cont.setScanTime(contForm.getScanTime());
        }

        if (contForm.getVersionNum() != null) {
            cont.setVersionNum(contForm.getVersionNum());
        }

        // 保存保单状态
        LsContState lsContState = new LsContState();
        lsContState.setContNo(cont.getContNo());
        //添加是否开启语言转文本标识
        if (isMp3) {
            lsContState.setMp3State("N");
            lsContState.setVideoToMp3State("N");
        } else {
            lsContState.setMp3State("F");
            lsContState.setVideoToMp3State("F");
        }

        lsContState.setPicState("N");
        lsContState.setVideoState("N");
        logger.info("PolicyServiceImpl类中的saveContInfo方法将视频状态设置成N");
        //调取抽检的结果
        //增加判断前面是不是整改
        if(cont.getSampling()==null || cont.getSampling()==false){
            boolean samplingResults = this.newSamplingRule(contForm);
            contForm.setSampling(samplingResults);
            cont.setSampling(contForm.isSampling());
//            if(!samplingResults){
//                //UserBasicInfo lsUser = CurrentUser.getUser();
//                try{
//                    // trans_type为2代表不需要转码
//                    String zipUrl = contForm.getZipUrl();
//                    String videoName = contForm.getVideo().getVideoName()+"."+contForm.getVideo().getVideoType();
//
//                    okhttpService.addVideo(cont,notifyUrl,"2",zipUrl,videoName, lsContState);
//                    //cmsService.updateCmsIndex(cont.getContNo(), cont,contForm.getCloudFileId(), lsUser.toUser());
//                }catch(Exception e){
//                    UserActionUtil.info("cms", "Update index", cont.getContNo()+"||"+cont+"||"+contForm.getCloudFileId(),e);
//                    logger.error("cont.getContNo {}, cont {},contForm.getCloudFileId {}, lsUser.toUser {}",cont.getContNo(), cont,contForm.getCloudFileId(),e);
//                }
//
//            }else {
//                try{
//                    // trans_type为1代表需要转码
//                    String zipUrl = contForm.getZipUrl();
//                    String videoName = contForm.getVideo().getVideoName()+"."+contForm.getVideo().getVideoType();
//
//                    okhttpService.addVideo(cont,notifyUrl,"1",zipUrl,videoName, lsContState);
//                    //cmsService.updateCmsIndex(cont.getContNo(), cont,contForm.getCloudFileId(), lsUser.toUser());
//                }catch(Exception e){
//                    UserActionUtil.info("cms", "Update index", cont.getContNo()+"||"+cont+"||"+contForm.getCloudFileId(),e);
//                    logger.error("cont.getContNo {}, cont {},contForm.getCloudFileId {}, lsUser.toUser {}",cont.getContNo(), cont,contForm.getCloudFileId(),e);
//                }
//            }
        }
        //如果没有双录文件 则直接跳过所有流程
        if ("1".equals(cont.getDataType()) || !contForm.isSampling()) {
            lsContState.setVideoState("F");
            lsContState.setPicState("F");
            lsContState.setMp3State("F");
            lsContState.setVideoToMp3State("F");
            //设置投保单初始状态为 F
            cont.setInteractive("F");
            //添加保单记录变更表
            lsStateLocaDao.saveStateLoca(cont, "上传中");
        }
        contStateDao.save(lsContState);
*/

        /**
         * Date:2020/03/17
         * Time:14:28
         * 泛华双录自动抽检
         * Create by zbl
         */

        //1.首先判断是否为整改单，若是整改则去抽检
        LSCont lastCont = contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne(contForm.getComCode(),
                contForm.getInsurComCode(), StringSortUtil.getArrayStringSort(contForm.getBusiNum()), 'Y');
        if (lastCont != null) { // 重录操作
            // 获取最后一个修改过的lscont 并修改信息
            if (!lastCont.getOperator().equals(contForm.getOperator()) && StringUtils.isEmpty(lastCont.getBankCode())) {

                return builder.createFailResult(new String[]{"以下投保单号已经被使用:" + contForm.getBusiNum() + "，请更换投保单号重试。"});
            }
            if (lastCont.getInteractive() == null || lastCont.getInteractive().equals("")) {
                // 删除原来保单 数据 是的为 新增操作
                logger.info("old cont DELETE");
                contDao.delCont(lastCont);
            } else if (lastCont.getInteractive().equals("F")) {
                return builder.createFailResult(new String[]{"数据已上传，无法再次录制"});
            } else if (lastCont.getInteractive().equals("D")) {
                return builder.createFailResult(new String[]{"数据已上传，无法再次录制"});
            } else if (lastCont.getInteractive().equals("X")) {
                return builder.createFailResult(new String[]{"数据已上传，无法再次录制"});
            } else if (lastCont.getInteractive().equals("A")) {
                return builder.createFailResult(new String[]{"数据已提交完成，无需重录"});
            } else if (lastCont.getInteractive().equals("M")) {
                return builder.createFailResult(new String[]{"数据已提交完成，无需重录"});
            } else if (lastCont.getInteractive().equals("S")) {
                return builder.createFailResult(new String[]{"数据已审核成功，无需重录"});
            } else if (lastCont.getInteractive().equals("P")) {
                return builder.createFailResult(new String[]{"数据未抽中，无需重录"});
            } else if (lastCont.getInteractive().equals("E")) {
                return builder.createFailResult(new String[]{"数据异常，无需重录"});
            }else if (lastCont.getInteractive().equals("R")) {
                //增加判断 如果是银保业务 那么 不通过允许重录
                if (cont.getOperation().equals("Y")) {
                    logger.info("cont {} interactive R chonglu  start", cont.getContNo());
                    lastCont.setLastOne('N');
                    contDao.save(lastCont);
                    cont.setOrginContNo(lastCont.getContNo());// 保存上次的信息
                    cont.setMakeDate(lastCont.getMakeDate());// 保存注册时间
                    cont.setMakeTime(lastCont.getMakeTime());
                    //修改所属人为之前用户
                    cont.setOperator(lastCont.getOperator());
                    cont.setOperatorName(lastCont.getOperatorName());
                    //修改渠道为原有渠道
                    cont.setChannel(lastCont.getChannel());
                    cont.setOrgCode(lastCont.getOrgCode());
                    cont.setOperType('R');

                    if (StringUtils.isEmpty(lastCont.getIsIntelligence())) {
                        cont.setIsIntelligence("N");
                    } else {
                        cont.setIsIntelligence(lastCont.getIsIntelligence());
                    }

                } else {
                    return builder.createFailResult(new String[]{"数据已审核失败，无需重录"});
                }
            } else if (lastCont.getInteractive().equals("L")) {
                logger.info("cont interactive L chonglu  start");
                lastCont.setLastOne('N');
                contDao.save(lastCont);
                cont.setOrginContNo(lastCont.getContNo());// 保存上次的信息
                cont.setMakeDate(lastCont.getMakeDate());// 保存注册时间
                cont.setMakeTime(lastCont.getMakeTime());
                //修改所属人为之前用户
                cont.setOperator(lastCont.getOperator());
                cont.setOperatorName(lastCont.getOperatorName());
                //修改渠道为原有渠道
                cont.setChannel(lastCont.getChannel());
                cont.setOrgCode(lastCont.getOrgCode());
                cont.setOperType('R');
                cont.setSampling(true);

                contForm.setSampling(true);

                if (StringUtils.isEmpty(lastCont.getIsIntelligence())) {
                    cont.setIsIntelligence("N");
                } else {
                    cont.setIsIntelligence(lastCont.getIsIntelligence());
                }
            } else if (lastCont.getInteractive().equals("Z")) {
                //文件损坏 当重录操作
                logger.info("busiNum {} cont interactive Z file spoil  start", lastCont.getBusiNum());
                lastCont.setLastOne('Z');
//				lastCont.setClientContNo(contForm.getClientContNo());
                contDao.save(lastCont);
                // 获得当前时间的毫秒值 添加修改时间
                cont.setModifyDate(date);
                cont.setModifyTime(sdf.format(date));
                cont.setOrginContNo(lastCont.getOrginContNo());// 保存上次的信息
                cont.setMakeDate(lastCont.getMakeDate());// 保存注册时间
                cont.setMakeTime(lastCont.getMakeTime());
                cont.setOperType(lastCont.getOperType());
                cont.setSampling(true);
                contForm.setSampling(true);
                if (StringUtils.isEmpty(lastCont.getIsIntelligence())) {
                    cont.setIsIntelligence("N");
                } else {
                    cont.setIsIntelligence(lastCont.getIsIntelligence());
                }
            } else {
                return builder.createFailResult(new String[]{"数据未知错误！"});
            }
        }
        else{
            //1.如果是新单首先获取新单的渠道和地区和被保人年龄

            String contChannel = contForm.getChannel();
            String contOrgCode = contForm.getOrgCode();
            String contAge = contForm.getInsured().getAge();

            com.sinosoft.easyrecord.entity4afc.LSCom lsCom = lsComDao.findByInComCode(contOrgCode);

            if(lsCom == null){
                return builder.createFailResult(new String[]{"机构不存在，请核对机构数据"});
            }

            String comName = lsCom.getComname();


           if(!contForm.getIntelligentResults().equals("N")&&!contForm.getIntelligentResults().equals("0")){
               //优先匹配险种规则
               List<String> risktypeList = new ArrayList<String>();
               List<EsRuleMain> esRuleMainList =new ArrayList<EsRuleMain>();
               if(contForm.getRisk() !=null && contForm.getRisk().size() != 0){
                   for (RiskSaveForm riskSaveForm : contForm.getRisk()) {
                       if(riskSaveForm.getRiskTypeType() != null && !riskSaveForm.getRiskTypeType().equals("")){
                           risktypeList.add(riskSaveForm.getRiskTypeType());
                       }
                   }
               }
               if(risktypeList.size() != 0){
                   esRuleMainList = esRuleMainDao.findByChannelAndRiskTypeCodeIn(contChannel,risktypeList);
               }else {
                   esRuleMainList = esRuleMainDao.findByChannel(contChannel);
               }

               if(esRuleMainList.size() == 0){
                   esRuleMainList = esRuleMainDao.findByChannel(contChannel);
               }







               //用于保存匹配地区的集合
               List<EsRuleMain> esRuleMainList1 = new ArrayList<EsRuleMain>();

               //用于保存匹配年龄的集合

               List<EsRuleMain> esRuleMainList2 = new ArrayList<EsRuleMain>();

               //用户于保存匹配险种的集合
               List<EsRuleMain> esRuleMainList3 = new ArrayList<EsRuleMain>();

               //用于保存最终符合时间的集合
               List<EsRuleMain> esRuleMainList4 = new ArrayList<EsRuleMain>();



               //判断符合地区的规则

               for(EsRuleMain esRuleMain :esRuleMainList){
                   if(esRuleMain.getProvince() == null || esRuleMain.getProvince().equals("") || esRuleMain.getProvince().equals("请选择")){
                       esRuleMainList1.add(esRuleMain);
                   }else {
                       if(comName.contains(esRuleMain.getProvince())){
                           if(comName.contains(esRuleMain.getCity()) || esRuleMain.getCity().equals("") || esRuleMain.getCity().equals("请选择")) {
                               esRuleMainList1.add(esRuleMain);
                           }


                       }else {
                           if(comName.contains(esRuleMain.getCity())) {
                               esRuleMainList1.add(esRuleMain);
                           }
                       }
                   }
               }

               //匹配符合年龄的规则

               for(EsRuleMain esRuleMain: esRuleMainList1){
                   String age = esRuleMain.getAppntage();
                   if(age == null || age.equals("")){
                       esRuleMainList2.add(esRuleMain);
                   }else {
                       int point = age.lastIndexOf("_");
                       String ageStart = age.substring(0,point);
                       String ageEnd = age.substring(point+1,age.length());

                       if(!ageStart.equals("")){
                           if(!ageEnd.equals("")){
                               if(Integer.valueOf(ageStart) <= Integer.valueOf(contAge) && Integer.valueOf(ageEnd) >= Integer.valueOf(contAge)){
                                   esRuleMainList2.add(esRuleMain);
                               }else {
                                   continue;
                               }
                           }else {
                               if(Integer.valueOf(ageStart) <= Integer.valueOf(contAge)){
                                   esRuleMainList2.add(esRuleMain);
                               }else {
                                   continue;
                               }
                           }


                       }else {
                           if(!ageEnd.equals("")){
                               if(Integer.valueOf(ageEnd) >= Integer.valueOf(contAge)){
                                   esRuleMainList2.add(esRuleMain);
                               }else {
                                   continue;
                               }
                           }else {
                               esRuleMainList2.add(esRuleMain);
                           }
                       }
                   }
               }


               //匹配险种的逻辑


               java.util.Date nowDate = new java.util.Date();
               long nowTime = nowDate.getTime();

               SimpleDateFormat utilDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               try {
                   for(EsRuleMain esRuleMain : esRuleMainList2){
                       if(esRuleMain.getEffectbegintime() == null || esRuleMain.getEffectEndTime().equals("")){
                           if(esRuleMain.getEffectEndTime() == null || esRuleMain.getEffectEndTime().equals("") ){
                               esRuleMainList4.add(esRuleMain);
                           }else{
                               java.util.Date endTime = utilDate.parse(esRuleMain.getEffectEndTime());
                               long endTime1 = endTime.getTime();
                               if(endTime1 > nowTime){
                                   esRuleMainList4.add(esRuleMain);
                               }
                           }
                       }else {
                           if(esRuleMain.getEffectEndTime() == null || esRuleMain.getEffectEndTime().equals("") ){
                               java.util.Date beginTime = utilDate.parse(esRuleMain.getEffectbegintime());
                               long beginTimeTime = beginTime.getTime();
                               if(beginTimeTime < nowTime){
                                   esRuleMainList4.add(esRuleMain);
                               }
                           }else{
                               java.util.Date endTime = utilDate.parse(esRuleMain.getEffectEndTime());
                               long endTime1 = endTime.getTime();
                               java.util.Date beginTime = utilDate.parse(esRuleMain.getEffectbegintime());
                               long beginTimeTime = beginTime.getTime();
                               if(endTime1 > nowTime && beginTimeTime < nowTime){
                                   esRuleMainList4.add(esRuleMain);
                               }
                           }
                       }
                   }
               }catch (Exception e){
                   e.printStackTrace();

               }

               int comFlag = 0;
               int cityFlag = 0;
               int provinceFlag = 0;
               int countryFlag = 0;



               for(int i = 0; i< esRuleMainList4.size();i++) {
                   if (esRuleMainList4.get(i).getComCode() != null && !esRuleMainList4.get(i).getComCode().equals("") && esRuleMainList4.get(i).getComCode().equals(contOrgCode)) {
                       comFlag = i;
                   } else {
                       if (esRuleMainList4.get(i).getComCode() != null && !esRuleMainList4.get(i).getComCode().equals("")) {
                           String pattern = "^" + esRuleMainList4.get(i).getComCode();
                           Pattern r = Pattern.compile(pattern);
                           Matcher m = r.matcher(contOrgCode);
                           if (m.find()) {
                               comFlag = i;
                           }
                       }
                   }

                   if (esRuleMainList4.get(i).getCity() != null && !esRuleMainList4.get(i).getCity().equals("") && !esRuleMainList4.get(i).getCity().equals("请选择")) {
                       cityFlag = i;
                   }
                   if (esRuleMainList4.get(i).getProvince() != null && !esRuleMainList4.get(i).getProvince().equals("") && !esRuleMainList4.get(i).getProvince().equals("请选择")) {
                       provinceFlag = i;
                   }
               }
               if(comFlag != 0){
                   EsRuleMain esRuleMain = esRuleMainList4.get(comFlag);
                   String scale = esRuleMain.getScale();
                   int scaleNum = Integer.valueOf(scale);

                   String count = esRuleMain.getCount();

                   if(count != null && !count.equals("")){
                       String []countArray = count.split(",");
                       if(countArray.length == 99){
                           esRuleMain.setCount("");
                           esRuleMainDao.save(esRuleMain);
                       }
                       for(int ii= 0; ii<100;ii++){
                           int random = (int)(Math.random()*100);
                           int kk = 0;
                           for(int jj =0; jj < countArray.length;jj++){
                               if(random == Integer.valueOf(countArray[jj])){
                                   kk ++;
                               }
                           }
                           if(kk == 0){
                               if(random <= scaleNum){
                                   cont.setInteractive("A");
                               }else {
                                   cont.setInteractive("P");
                               }
                               StringBuffer stringBuffer = new StringBuffer(count);
                               stringBuffer.append(","+Integer.toString(random));
                               esRuleMain.setCount(stringBuffer.toString());
                               esRuleMainDao.save(esRuleMain);
                           }
                       }
                   }else{
                       int random = (int)(Math.random()*100);

                       if(random <= scaleNum){
                           cont.setInteractive("A");
                       }else {
                           cont.setInteractive("P");
                       }
                       count = Integer.toString(random);
                       esRuleMain.setCount(count);
                       esRuleMainDao.save(esRuleMain);
                   }



               }

               else if(cityFlag != 0){
                   EsRuleMain esRuleMain = esRuleMainList4.get(cityFlag);
                   String scale = esRuleMain.getScale();
                   int scaleNum = Integer.valueOf(scale);

                   String count = esRuleMain.getCount();

                   if(count != null && !count.equals("")){
                       String []countArray = count.split(",");
                       if(countArray.length == 99){
                           esRuleMain.setCount("");
                           esRuleMainDao.save(esRuleMain);
                       }
                       for(int ii= 0; ii<100;ii++){
                           int random = (int)(Math.random()*100);
                           int kk = 0;
                           for(int jj =0; jj < countArray.length;jj++){
                               if(random == Integer.valueOf(countArray[jj])){
                                   kk ++;
                               }
                           }
                           if(kk == 0){
                               if(random <= scaleNum){
                                   cont.setInteractive("A");
                               }else {
                                   cont.setInteractive("P");
                               }
                               StringBuffer stringBuffer = new StringBuffer(count);
                               stringBuffer.append(","+Integer.toString(random));
                               esRuleMain.setCount(stringBuffer.toString());
                               esRuleMainDao.save(esRuleMain);
                           }
                       }
                   }else{
                       int random = (int)(Math.random()*100);

                       if(random <= scaleNum){
                           cont.setInteractive("A");
                       }else {
                           cont.setInteractive("P");
                       }
                       count = Integer.toString(random);
                       esRuleMain.setCount(count);
                       esRuleMainDao.save(esRuleMain);
                   }

               }else if(provinceFlag != 0){
                   EsRuleMain esRuleMain = esRuleMainList4.get(provinceFlag);
                   String scale = esRuleMain.getScale();
                   int scaleNum = Integer.valueOf(scale);

                   String count = esRuleMain.getCount();

                   if(count != null && !count.equals("")){
                       String []countArray = count.split(",");
                       if(countArray.length == 99){
                           esRuleMain.setCount("");
                           esRuleMainDao.save(esRuleMain);
                       }
                       for(int ii= 0; ii<100;ii++){
                           int random = (int)(Math.random()*100);
                           int kk = 0;
                           for(int jj =0; jj < countArray.length;jj++){
                               if(random == Integer.valueOf(countArray[jj])){
                                   kk ++;
                               }
                           }
                           if(kk == 0){
                               if(random <= scaleNum){
                                   cont.setInteractive("A");
                               }else {
                                   cont.setInteractive("P");
                               }
                               StringBuffer stringBuffer = new StringBuffer(count);
                               stringBuffer.append(","+Integer.toString(random));
                               esRuleMain.setCount(stringBuffer.toString());
                               esRuleMainDao.save(esRuleMain);
                           }
                       }
                   }else{
                       int random = (int)(Math.random()*100);

                       if(random <= scaleNum){
                           cont.setInteractive("A");
                       }else {
                           cont.setInteractive("P");
                       }
                       count = Integer.toString(random);
                       esRuleMain.setCount(count);
                       esRuleMainDao.save(esRuleMain);
                   }


               }else if(esRuleMainList4.size() != 0){
                   EsRuleMain esRuleMain = esRuleMainList4.get(0);
                   String scale = esRuleMain.getScale();
                   int scaleNum = Integer.valueOf(scale);

                   String count = esRuleMain.getCount();

                   if(count != null && !count.equals("")){
                       String []countArray = count.split(",");
                       if(countArray.length == 99){
                           esRuleMain.setCount("");
                           esRuleMainDao.save(esRuleMain);
                       }
                       for(int ii= 0; ii<100;ii++){
                           int random = (int)(Math.random()*100);
                           int kk = 0;
                           for(int jj =0; jj < countArray.length;jj++){
                               if(random == Integer.valueOf(countArray[jj])){
                                   kk ++;
                               }
                           }
                           if(kk == 0){
                               if(random <= scaleNum){
                                   cont.setInteractive("A");
                               }else {
                                   cont.setInteractive("P");
                               }
                               StringBuffer stringBuffer = new StringBuffer(count);
                               stringBuffer.append(","+Integer.toString(random));
                               esRuleMain.setCount(stringBuffer.toString());
                               esRuleMainDao.save(esRuleMain);
                           }
                       }
                   }else{
                       int random = (int)(Math.random()*100);

                       if(random <= scaleNum){
                           cont.setInteractive("A");
                       }else {
                           cont.setInteractive("P");
                       }
                       count = Integer.toString(random);
                       esRuleMain.setCount(count);
                       esRuleMainDao.save(esRuleMain);
                   }

               }else {
                   cont.setInteractive("X");
               }

           }


        }







        //在投保单中保存token
        LDToken ldToken = tokenDao.getTokenByUserId(contForm.getOperator());
        String accessToken;
        if (ldToken == null) {
            accessToken = "Front-end machine";
        } else {
            accessToken = ldToken.getAccessToken();
        }
        cont.setToken(accessToken);
        if(cont.getInteractive() == null || cont.getInteractive().equals("")){
            cont.setInteractive("X");
        }
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
        cont.setSortTime(sdf1.format(date));
        cont.setContNo(contForm.getContNo());

        cont.setBusiNum(StringSortUtil.getArrayStringSort(contForm.getBusiNum()));

        cont.setLastOne('Y');
        cont.setRiskType(StringSortUtil.getArrayStringSort(contForm.getRiskType()));
        cont.setClientContNo(contForm.getClientContNo());
        cont.setComCode(contForm.getComCode());

        if (contForm.getEqInfor() != null) {
            cont.setEqInfor(contForm.getEqInfor());
        }
        // cont.setInteractive('F'); //初始状态均为 F：文件待上传
        cont.setInsurComCode(contForm.getInsurComCode());
        if (contForm.getScanDate() != null) {
            cont.setScanDate(contForm.getScanDate());
            cont.setScanTime(contForm.getScanTime());
        }

        if (contForm.getVersionNum() != null) {
            cont.setVersionNum(contForm.getVersionNum());
        }


        // 保存保单状态
        LsContState lsContState = new LsContState();
        lsContState.setContNo(cont.getContNo());
        //添加是否开启语言转文本标识
        if (isMp3) {
            lsContState.setMp3State("N");
            lsContState.setVideoToMp3State("N");
        } else {
            lsContState.setMp3State("F");
            lsContState.setVideoToMp3State("F");
        }

        lsContState.setPicState("N");
        lsContState.setVideoState("F");
        logger.info("PolicyServiceImpl类中的saveContInfo方法将视频状态设置成N");
        //调取抽检的结果
        //增加判断前面是不是整改
        if(cont.getSampling()==null || cont.getSampling()==false){

            boolean samplingResults = true;

            if(cont.getInteractive().equals("P")){
                samplingResults = false;
            }
            contForm.setSampling(samplingResults);
            cont.setSampling(contForm.isSampling());

            /*if(!samplingResults){
            }else {
                try{
                    // trans_type为1代表需要转码
                    String zipUrl = contForm.getZipUrl();
                    String videoName = contForm.getVideo().getVideoName()+"."+contForm.getVideo().getVideoType();

                    okhttpService.addVideo(cont,notifyUrl,"1",zipUrl,videoName, lsContState);
                    //cmsService.updateCmsIndex(cont.getContNo(), cont,contForm.getCloudFileId(), lsUser.toUser());
                }catch(Exception e){
                    UserActionUtil.info("cms", "Update index", cont.getContNo()+"||"+cont+"||"+contForm.getCloudFileId(),e);
                   logger.error("cont.getContNo {}, cont {},contForm.getCloudFileId {}, lsUser.toUser {}",cont.getContNo(), cont,contForm.getCloudFileId(),e);
                }
            }*/
        }
        //如果没有双录文件 则直接跳过所有流程
        /*if ("1".equals(cont.getDataType()) || !contForm.isSampling()) {
            lsContState.setVideoState("F");
            lsContState.setPicState("F");
            lsContState.setMp3State("F");
            lsContState.setVideoToMp3State("F");
            //设置投保单初始状态为 F
            cont.setInteractive("F");
            //添加保单记录变更表
            lsStateLocaDao.saveStateLoca(cont, "上传中");
        }*/
        contDao.save(cont);
        contStateDao.save(lsContState);
        return builder.createSuccessResult(cont.getClientContNo());
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:30
     * 保存投保人信息
     */
    @Transactional
    public ServiceResult<String, String[]> saveAppntInfo(AppntForm appntForm) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        LSAppnt appnt = new LSAppnt();
        appnt.setAppntNo(appntForm.getAppntNo());
        Date date = new Date(System.currentTimeMillis());
        appnt.setMakeDate(date);
        Long makeTime = date.getTime();
        Date d = new Date(makeTime);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        appnt.setMakeTime(sdf.format(d));
        appnt.setName(appntForm.getName());
        appnt.setSex(appntForm.getSex());
        appnt.setBirthday(appntForm.getBirthday());
        appnt.setAddress(appntForm.getAddress());
        appnt.setIdType(appntForm.getIdType());
        appnt.setIdNo(appntForm.getIdNo());
        appnt.setContNo(appntForm.getContNo());
        appnt.setOperator(appntForm.getOperator());
        appnt.setClientContNo(appntForm.getClientContNo());
        Date date1 = new Date(System.currentTimeMillis());
        appnt.setModifyDate(date1);
        Long makeTime1 = date.getTime();
        Date d1 = new Date(makeTime1);
        appnt.setModifyTime(sdf.format(d1));
        appnt.setAge(appntForm.getAge());

        appntDao.save(appnt);

        return builder.createSuccessResult(appnt.getAppntNo());
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:30
     * 保存被保人信息
     */
    @Transactional
    public ServiceResult<String, String[]> saveInsuredInfo(InsuredForm insuredForm) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        LSInsured insured = new LSInsured();
        insured.setInsuredNo(insuredForm.getInsuredNo());
        Date date = new Date(System.currentTimeMillis());
        insured.setMakeDate(date);

        Long makeTime = date.getTime();
        // System.out.println(makeTime);

        Date d = new Date(makeTime);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        insured.setMakeTime(sdf.format(d));
        Date date1 = new Date(System.currentTimeMillis());
        Long makeTime1 = date.getTime();
        Date d1 = new Date(makeTime1);
        insured.setModifyDate(date1);
        insured.setModifyTime(sdf.format(d1));
        insured.setName(insuredForm.getName());
        insured.setSex(insuredForm.getSex());
        insured.setBirthday(insuredForm.getBirthday());
        insured.setAddress(insuredForm.getAddress());
        insured.setIdType(insuredForm.getIdType());
        insured.setIdNo(insuredForm.getIdNo());
        insured.setContNo(insuredForm.getContNo());
        insured.setAppntNo(insuredForm.getAppntNo());
        insured.setOperator(insuredForm.getOperator());
        insured.setClientContNo(insuredForm.getClientContNo());
        insured.setAge(insuredForm.getAge());
        insured.setLDRelationshipCode(insuredForm.getInsuredRelationship());

        insuredDao.save(insured);

        return builder.createSuccessResult(insured.getInsuredNo());
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:31
     * 保存视频信息
     */
    @Transactional
    public ServiceResult<String, String[]> saveVideoInfo(VideoForm videoForm) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        LSVideo video = new LSVideo();
        video.setVideoNo(videoForm.getVideoNo());
        Date date = new Date(System.currentTimeMillis());
        video.setMakeDate(date);

        Long makeTime = date.getTime();
        // System.out.println(makeTime);

        Date d = new Date(makeTime);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        video.setMakeTime(sdf.format(d));
        Date date1 = new Date(System.currentTimeMillis());
        Long makeTime1 = date.getTime();
        Date d1 = new Date(makeTime1);
        video.setModifyDate(date1);
        video.setModifyTime(sdf.format(d1));
        video.setClientContNo(videoForm.getClientContNo());
        video.setContNo(videoForm.getContNo());
        video.setVideoName(videoForm.getVideoName());
        video.setVideoType(videoForm.getVideoType());
        video.setStorageType(videoForm.getStorageType().charAt(0));
        video.setURL(videoForm.getURL());
        video.setCloudFileId(videoForm.getCloudFileId());
        video.setOperator(videoForm.getOperator());
        video.setTimeLength(videoForm.getTimeLength());

        //添加是否可以拷贝标识 -- 默认值为NO 不能copy
        video.setIsCopy("NO");
        String date2 = videoForm.getBeginTime();
        String[] dates = date2.split(" ");
        video.setBeginTime(dates[1]);
        sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            video.setBeginDate(sdf.parse(dates[0]));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //添加摄像头版本号
        if (videoForm.getCameraVersion() != null) {
            video.setCameraVersion(videoForm.getCameraVersion());
        }
        videoDao.save(video);

        return builder.createSuccessResult(video.getVideoNo());
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:31
     * 保存图片信息
     */
    @Transactional
    public ServiceResult<String, String[]> savePictureInfo(PictureForm pictureForm) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        LSPicture picture = new LSPicture();

        picture.setPictureId(UUID.randomUUID().toString());

        picture.setPicNo(pictureForm.getPicNo());
        Date date = new Date(System.currentTimeMillis());
        picture.setMakeDate(date);

        Long makeTime = date.getTime();
        // System.out.println(makeTime);

        Date d = new Date(makeTime);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        picture.setMakeTime(sdf.format(d));
        Date date1 = new Date(System.currentTimeMillis());
        Long makeTime1 = date.getTime();
        Date d1 = new Date(makeTime1);
        picture.setModifyDate(date1);
        picture.setModifyTime(sdf.format(d1));
        picture.setBusiType(pictureForm.getBusiType());
        picture.setClientContNo(pictureForm.getClientContNo());
        picture.setContNo(pictureForm.getContNo());
        picture.setOperator(pictureForm.getOperator());
        //picture.setPicName(UUID.randomUUID().toString());
        picture.setPicName(pictureForm.getPicName());
        picture.setPicType("jpg");
        picture.setTimeNode(pictureForm.getTimeNode());
        picture.setIspass(pictureForm.getIspass());
        String pkid = pictureForm.getpKID();
        String isplay = "";
        if (pkid.contains("---")) {
            String[] pkids = pkid.split("---");
            pkid = pkids[0];
            isplay = pkids[1];
        }

        picture.setpKId(pkid);
        picture.setIsPlay(isplay);
        pictureDao.save(picture);

        return builder.createSuccessResult(picture.getPicNo());

    }


    /**
     * 保存话术信息
     * Create by zbl
     * Date:2020/02/25
     */
    @Transactional
    public ServiceResult<String, String[]> saveTalkContent(TalkSaveForm talkSaveForm,String contNo) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        LSTalkContent lsTalkContent = new LSTalkContent();
        lsTalkContent.setId(UUID.randomUUID().toString());
        lsTalkContent.setBusiNum(talkSaveForm.getBusiNum());
        lsTalkContent.setRiskType(talkSaveForm.getRiskType());
        lsTalkContent.setPkid(talkSaveForm.getPkId());
        lsTalkContent.setOrderNum(talkSaveForm.getOrderNum());
        lsTalkContent.setTalkContent(talkSaveForm.getTalkContent());
        lsTalkContent.setTalkTitle(talkSaveForm.getTalkTitle());
        lsTalkContent.setContNo(contNo);
        talkContentDao.saveTalkContent(lsTalkContent);


        return builder.createSuccessResult(talkSaveForm.getOrderNum());

    }


    /**
     * 保存产品信息
     * Create by zbl
     * Date:2020/03/06
     */
    @Transactional
    public ServiceResult<String, String[]> saveRiskTypeNew(RiskSaveForm riskSaveForm,String contNo) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        LsRiskTypeNew lsRiskTypeNew = new LsRiskTypeNew();
        lsRiskTypeNew.setRisktypeId(UUID.randomUUID().toString());
        lsRiskTypeNew.setContNo(contNo);
        lsRiskTypeNew.setRiskTypeCode(riskSaveForm.getRiskTypeCode());
        lsRiskTypeNew.setRiskTypeName(riskSaveForm.getRiskTypeName());
        lsRiskTypeNew.setRiskTypeType(riskSaveForm.getRiskTypeType());
        lsRiskTypeNew.setIsHealth(riskSaveForm.getIsHealth());
        lsRiskTypeNew.setIsDeath(riskSaveForm.getIsDeath());
        lsRiskTypeNew.setIsSale(riskSaveForm.getIsSale());
        lsRiskTypeNew.setRiskTime(riskSaveForm.getRiskTime());
        lsRiskTypeNew.setPrice(riskSaveForm.getPrice());
        lsRiskTypeNew.setCount(riskSaveForm.getCount());
        lsRiskTypeNew.setPaymentMethod(riskSaveForm.getPaymentMethod());
        lsRiskTypeNew.setPaymentTime(riskSaveForm.getPaymentTime());
        lsRiskTypeNew.setSumPrice(riskSaveForm.getSumPrice());
        riskTypeNewDao.saveRiskTypeNew(lsRiskTypeNew);


        return builder.createSuccessResult(riskSaveForm.getRiskTypeCode());

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:33
     * 检查经代公司是否正确
     */
    private boolean isExistInsurComCode(QueryTypeForm queryTypeForm) {

        List<SelectItem> comList = findInsurCom(queryTypeForm.getComCode());
        for (SelectItem s : comList) {
            if (queryTypeForm.getInsurComCode().equals(s.getValue())) {
                return true;
            }
        }
        return false;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:33
     * 检查险种是否正确
     */
//    private boolean isExistRiskType(QueryTalkForm queryTalkForm) {
//
//        // List<SelectItem> comList=findInsurCom(queryTalkForm.getComCode());
//        List<LSRiskType> risktypeList = findRiskTypeByComCodeAndOrgCodeAndInsurCinCode(queryTalkForm.getComCode(), queryTalkForm.getOrgCode(), queryTalkForm.getInsurComCode()); // riskTypeDao.findByComCodeAndInsurComCode(queryTalkForm.getComCode(),queryTalkForm.getInsurComCode(),CurrentUser.getUser().getOrgCode());
//
//        for (LSRiskType s : risktypeList) {
//            if (queryTalkForm.getRiskType().equals(s.getRiskType())) {
//                return true;
//            }
//        }
//        return false;
//
//    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:33
     * 查询险种
     */
    public ServiceResult<RiskForm[], String> showTypeName(QueryTypeForm queryTypeForm) {
        // 调用查询conName的方法
        ServiceResult.Builder<RiskForm[], String> resBuilder = ServiceResult.build(RiskForm[].class, String.class);

        // List<SelectItem> typeList = null;
        if (!isExistInsurComCode(queryTypeForm)) {
            // 提示，如果insurComCode有问题，那么就提示输入的有问题：请输入正确的保险公司
            logger.warn("Please enter the correct insurance company. {}", queryTypeForm);// 是不是要用英文提示
            return resBuilder.createFailResult("请输入正确的保险公司");
        }

        String findMessage = queryTypeForm.getFindMessage();
        //获取 保险类型 集合
//        List<LDCode> codes = codeDao.findByCodeType("productType");
        List<String> codes = leTagLinksDao.findByCode();
        logger.info("leTagLinksDao.findByCode() >> {}", codes);
        // 查询到数据，转换数据格式
        RiskForm[] typeSelectItemArray = new RiskForm[codes.size() + 3];

        //组织保险类型数据
        if (codes != null && !codes.isEmpty()) {
            logger.info("codes != null && !codes.isEmpty() >> true");
            for (int i = 0; i < codes.size(); i++) {
                List<LMProduct> productNewAll = new ArrayList<>();
                LMProduct lmProduct=null;
                if (StringUtils.isEmpty(findMessage)) {
                    productNewAll = lmProductDao.findByCharacter(codes.get(i));
                } else {
                    findMessage = "%" + findMessage + "%";
                    productNewAll = lmProductDao.findByCharacterAndProductCodeLikeOrProductNameLike(codes.get(i), findMessage, findMessage);
                }
                RiskForm riskFormCode = new RiskForm();
                String producttype=codes.get(i);
                if(producttype!=null&&!("".equals(producttype))){
                    if(producttype.equals(RiskTypeEnum.RISK_TYPE_N.getValue())){
                        riskFormCode.setProductName("普通型");
                        riskFormCode.setProductCode("01");
                    }else if(producttype.equals(RiskTypeEnum.RISK_TYPE_B.getValue())){
                        riskFormCode.setProductName("分红型");
                        riskFormCode.setProductCode("03");

                    }else{
                        riskFormCode.setProductName("万能型");
                        riskFormCode.setProductCode("02");
                    }
                }
                /*riskFormCode.setProductName(codes.get(i)[1].toString());
                riskFormCode.setProductCode(codes.get(i)[0].toString());*/
                List<Map> codeList = new ArrayList<>();
                if (!productNewAll.isEmpty() && productNewAll != null) {
                    for (LMProduct lmProduct1 : productNewAll) {
                        Map<String, Object> map = new HashMap<>();
                        map.put("riskType", lmProduct1.getProductCode());
                        map.put("riskName", lmProduct1.getProductName());
                        codeList.add(map);
                    }
                }
                riskFormCode.setRiskList(codeList);
                logger.info("typeSelectItemArray[{}] = {} ", i + 1, riskFormCode);
                typeSelectItemArray[i + 1] = riskFormCode;
            }
        } else {
            logger.info("codes != null && !codes.isEmpty() >> false");
        }

        //首先组织全部数据
        List<LMProduct> productNewAll = null;
        if (StringUtils.isEmpty(findMessage)) {
            productNewAll = lmProductDao.findAll();
        } else {
            findMessage = "%" + findMessage + "%";
            productNewAll = lmProductDao.findByProductCodeLikeOrProductNameLike(findMessage);
        }
        RiskForm riskForm = new RiskForm();
        riskForm.setProductName("全部");
        riskForm.setProductCode("all");
        List<Map> riskList = new ArrayList<>();
        if (!productNewAll.isEmpty() && productNewAll != null) {
            for (LMProduct lmProduct : productNewAll) {
                Map<String, Object> map = new HashMap<>();
                map.put("riskType", lmProduct.getProductCode());
                map.put("riskName", lmProduct.getProductName());
                riskList.add(map);
            }
        }
        riskForm.setRiskList(riskList);
        typeSelectItemArray[0] = riskForm;

        //组织健康产品
        List<LMProduct> isHealths = null;
        if (StringUtils.isEmpty(findMessage)) {
            isHealths = lmProductDao.findByCharacter(RiskTypeEnum.RISK_TYPE_H.getValue());
        } else {
            findMessage = "%" + findMessage + "%";
            isHealths = lmProductDao.findByCharacterAndProductCodeLikeOrProductNameLike(RiskTypeEnum.RISK_TYPE_H.getValue(), findMessage, findMessage);
        }
        RiskForm riskFormIsHealth = new RiskForm();
        riskFormIsHealth.setProductName("健康型产品");
        riskFormIsHealth.setProductCode("isHealth");
        List<Map> isHealthList = new ArrayList<>();
        if (!isHealths.isEmpty() && isHealths != null) {
            for (LMProduct lmProduct : isHealths) {
                Map<String, Object> map = new HashMap<>();
                map.put("riskType", lmProduct.getProductCode());
                map.put("riskName", lmProduct.getProductName());
                isHealthList.add(map);
            }
        }
        riskFormIsHealth.setRiskList(isHealthList);
        typeSelectItemArray[codes.size() + 1] = riskFormIsHealth;

        //组织  死亡给付产品
        List<LMProduct> isDeath = null;
        if (StringUtils.isEmpty(findMessage)) {
            isDeath = lmProductDao.findByCharacter(RiskTypeEnum.RISK_TYPE_D.getValue());
        } else {
            findMessage = "%" + findMessage + "%";
            isDeath = lmProductDao.findByCharacterAndProductCodeLikeOrProductNameLike(RiskTypeEnum.RISK_TYPE_D.getValue(), findMessage, findMessage);
        }
        RiskForm riskFormIsDeath = new RiskForm();
        riskFormIsDeath.setProductName("是否死亡给付");
        riskFormIsDeath.setProductCode("isDeath");
        List<Map> isDeathList = new ArrayList<>();
        if (!isDeath.isEmpty() && isDeath != null) {
            for (LMProduct lmProduct: isDeath) {
                Map<String, Object> map = new HashMap<>();
                map.put("riskType", lmProduct.getProductCode());
                map.put("riskName", lmProduct.getProductName());
                isDeathList.add(map);
            }
        }
        riskFormIsDeath.setRiskList(isDeathList);
        typeSelectItemArray[codes.size() + 2] = riskFormIsDeath;

        return resBuilder.createSuccessResult(typeSelectItemArray);

    }

    // 话述支持机构 递归查询 话述
    public List<LSTalkNew> findTalksByOrgCode(String comCode, String insurComCode, String orgCode, String riskType) {
        // 查询自己
        List<LSTalkNew> talks = talkDao.findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(comCode,
                insurComCode, orgCode, riskType);
        // 自己如果为空 则 去查询上一级
        if (talks == null || talks.size() == 0) {
            LSOrganization lsOrganization = organizationDao.findByOrgCode(orgCode);
            if (lsOrganization.getOrgCode().equals(lsOrganization.getUpComCode())) {
                return talks;
            }
            talks = findTalksByOrgCode(comCode, insurComCode, lsOrganization.getUpComCode(), riskType);
        }
        return talks;
    }

    //  险种支持机构  单险种
//    public LSRiskType getLsRiskTypeByComCodeAndOrgCodeAndRiskType(String comCode, String orgCode, String riskType) {
//        LSRiskType lsRiskType = riskTypeDao.findByComCodeAndRiskType(comCode, riskType, orgCode);
//        if (lsRiskType == null) {
//            LSOrganization lsOrganization = organizationDao.findByOrgCode(orgCode);
//            if (lsOrganization.getOrgCode().equals(lsOrganization.getUpComCode())) {
//                return lsRiskType;
//            }
//            lsRiskType = getLsRiskTypeByComCodeAndOrgCodeAndRiskType(comCode, lsOrganization.getUpComCode(), riskType); //riskTypeDao.findByComCodeAndRiskType(comCode, riskType,lsOrganization.getUpComCode());
//        }
//        return lsRiskType;
//    }

    // 多险种
//    public List<LSRiskType> findRiskTypeByComCodeAndOrgCodeAndInsurCinCode(String comCode, String orgCode, String insurComCode) {
//        List<LSRiskType> list = riskTypeDao.findByComCodeAndInsurComCode(comCode, insurComCode, orgCode);
//        if (list == null || list.size() == 0) {
//            LSOrganization lsOrganization = organizationDao.findByOrgCode(orgCode);
//            if (lsOrganization.getOrgCode().equals(lsOrganization.getUpComCode())) {
//                return list;
//            }
//            list = findRiskTypeByComCodeAndOrgCodeAndInsurCinCode(comCode, lsOrganization.getUpComCode(), insurComCode); //riskTypeDao.findByComCodeAndInsurComCode(comCode, insurComCode, lsOrganization.getUpComCode());
//        }
//        return list;
//    }

    // 查询话述
    @Override
    public ServiceResult<TalkForm[], String> showStepTalk(QueryTalkForm queryTalkForm) {

        // 创建一个ServiceResult 成功返回对象数组 ，失败返回字符串1
        ServiceResult.Builder<TalkForm[], String> res = ServiceResult.build(TalkForm[].class, String.class);

        // 第一个框可选的结果,验证 InusrComCode
        boolean isContains = this.isExistInsurComCode(queryTalkForm);
        // 第二个框可选的结果 验证RiskType
//        boolean isRiskTypeContains = this.isExistRiskType(queryTalkForm);
//
//        if (!isRiskTypeContains) {
//            return res.createFailResult("risk参数非法");
//        }
        if (!isContains) {
            return res.createFailResult("com参数非法");
        }
        // 验证通过
        // 第三步所需话术返回的结果

        List<LSTalkNew> talks = findTalksByOrgCode(queryTalkForm.getComCode(), queryTalkForm.getInsurComCode(),
                queryTalkForm.getOrgCode(), queryTalkForm.getRiskType());

        // 查询分公司 没有 则去查询 总公司 话述
        // 加向下继承
        if (talks.size() != 0) {
            TalkForm[] talkForms = new TalkForm[talks.size()];
            Integer order = 0;
            for (LSTalkNew talk : talks) {
                // 封装对象数组
                TalkForm talkForm = new TalkForm();
                talkForm.setId(talk.getPkid());
                talkForm.setStep(talk.getStep());
                talkForm.setOrdernum(order + "");
                talkForm.setTalkContent(talk.getTalkContent());
                talkForm.setIsRead(talk.getIsRead());
                talkForms[order] = talkForm;
                order++;
            }
            return res.createSuccessResult(talkForms);
        }

        return res.createFailResult("无结果");
    }

    // 查询 实时话述
    @Override
    public RequestResult showTalkRunTime(TalkRunTimeForm talkRunTimeForm) {

        String busiNum = talkRunTimeForm.getBusiNum();
        String operator = CurrentUser.getUser().getUserId();
        String comCode = CurrentUser.getUser().getComCode();
        String insurComCode = talkRunTimeForm.getInsurComCode();
        String orgCode = CurrentUser.getUser().getOrgCode();
        String riskType = talkRunTimeForm.getRiskType();
        List<LSTalkRunTime> talkRunTimes = null;
        if (busiNum == null || busiNum.equals("")) {
        } else {
            // 根据投保单号查询是否有整改记录
            talkRunTimes = talkRunTimeDao.findByBusiNumAndOperatorAndComCodeAndInsurComCode(busiNum, operator, comCode,
                    insurComCode);
        }
        String comcode = CurrentUser.getUser().getOrgCode();
        String channel = CurrentUser.getUser().getChannel();
        // 判断是否有记录
        if (talkRunTimes != null && talkRunTimes.size() != 0) {
            if (!talkRunTimes.get(0).getRiskType().equals(talkRunTimeForm.getRiskType())) {
//                LSRiskType lsRiskType = getLsRiskTypeByComCodeAndOrgCodeAndRiskType(comCode, orgCode, talkRunTimes.get(0).getRiskType());
                LMProduct lsProductNew = productManagerService.getProduct(talkRunTimes.get(0).getRiskType(), comCode, channel);
                RequestResult requestResult = new RequestResult(false);
                requestResult.setMessage("险种选择错误,请选择：" + lsProductNew.getProductName());
                return requestResult;
            }
            // 封装对象数组
            TalkForm[] talkForms = new TalkForm[talkRunTimes.size()];
            Integer order = 0;
            // 整改次数
            String updateTime = "";
            // 整改状态
            String isFlag = "";
            for (LSTalkRunTime lsTalkRunTime : talkRunTimes) {
                // 封装对象数组
                TalkForm talkForm = new TalkForm();
                talkForm.setId(lsTalkRunTime.getPkId());
                talkForm.setStep(lsTalkRunTime.getStep());
                talkForm.setOrdernum(order + "");
                talkForm.setTalkContent(lsTalkRunTime.getTaleConent());
                talkForms[order] = talkForm;
                order++;
                // 获取 整改次数
                updateTime = lsTalkRunTime.getUpdateTime();
                isFlag = lsTalkRunTime.getIsFlag();
            }
            RequestResult requestResult = new RequestResult(true);
            requestResult.setResult(talkForms);
            Hashtable<String, String> data = new Hashtable<>();
            data.put("updateTime", updateTime);
            data.put("isFlag", isFlag);
            requestResult.setData(data);
            return requestResult;

        } else {
            // 没有找到 则 去 查询 lstalk 表 将 查询到的 属于这个机构的 这个 险种的 话述 在添加到 talkruntime 表里
            // 在递归调用该方法
            List<LSTalkNew> talks = findTalksByOrgCode(comCode, insurComCode, orgCode, riskType);

            if (talks.size() != 0) {
                TalkForm[] talkForms = new TalkForm[talks.size()];
                Integer order = 0;
                // 整改次数
                String updateTime = "";
                // 整改状态
                String isFlag = "";
                for (LSTalkNew talk : talks) {
                    // 封装对象数组
                    TalkForm talkForm = new TalkForm();
                    talkForm.setId(talk.getPkid());
                    talkForm.setStep(talk.getStep());
                    talkForm.setOrdernum(order + "");
                    talkForm.setTalkContent(talk.getTalkContent());
                    talkForms[order] = talkForm;
                    order++;
                }
                RequestResult requestResult = new RequestResult(true);
                requestResult.setResult(talkForms);
                Hashtable<String, String> data = new Hashtable<>();
                data.put("updateTime", updateTime);
                data.put("isFlag", isFlag);
                requestResult.setData(data);
                return requestResult;
            } else {
                RequestResult requestResult = new RequestResult(false);
                requestResult.setMessage("话术无结果");
                return requestResult;
            }

        }

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:35
     * 更新投保单号
     */
    @Override
    public ServiceResult<String, String[]> updateBusiNum(String operator, String clientContNo, String busiNum) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        if (clientContNo == null) {
            return builder.createFailResult(new String[]{"请输入投保单标识"});
        }
        if (busiNum == null) {
            return builder.createFailResult(new String[]{"请输入投保单号"});
        }
        LSCont lsCont = null;
        List<LSCont> list = contDao.findByClientContNO(clientContNo);
        if (list.size() == 0) {
            return builder.createFailResult(new String[]{"没有保单信息"});
        }
        for (LSCont lsCont2 : list) {
            if (lsCont2.getLastOne() == 'Y') {
                lsCont = lsCont2;
            }
        }
        if (lsCont != null && lsCont.getOperator() != null && operator != null && !lsCont.getOperator().equals(operator)) {
            return builder.createFailResult(new String[]{"该用户没有修改保单的权限"});
        }
        if (lsCont != null) {
            lsCont.setBusiNum(busiNum);
            contDao.save(lsCont);
            return builder.createSuccessResult(lsCont.getClientContNo());
        } else {
            return builder.createFailResult(new String[]{"没有找到数据"});
        }

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:35
     * 查询状态
     */
    @Override
    public RequestResult showState(StateForm stateForm) {
        List<String> clientContNos = stateForm.getContNos();
        RequestResult result = null;
        List<StateReqForm> list = new ArrayList<StateReqForm>();
        for (String clientContNo : clientContNos) {
            StateReqForm stateReqForm = new StateReqForm();
            //查找是否有删除单子
            LSCont delLsCont = contDao.findByClientContNoAndLastOne(clientContNo, 'C');
            if (delLsCont != null) {

                stateReqForm.setBusiNum(delLsCont.getBusiNum());
                stateReqForm.setContNo(clientContNo);
                stateReqForm.setDelFile("Y");
                stateReqForm.setIsDel("true");
                stateReqForm.setStateFlag("");
                stateReqForm.setStateName("");
                stateReqForm.setUrl("");
                stateReqForm.setIsCopy("");
                stateReqForm.setMakeDate("");
                list.add(stateReqForm);


            }


            LSCont cont = contDao.findByClientContNoAndLastOne(clientContNo, 'Y');
            if (cont != null && !"Y".equals(cont.getOperation())) {
                if (cont == null || !cont.getOperator().equals(CurrentUser.getUser().getUserId())) {
                    continue;
                }
            }


            if (!StringUtils.isEmpty(cont)) {
                String stateFlag = cont.getInteractive();
                String stateName = "";
                String delFile = "N";
                if ("F".equals(stateFlag)) {
                    stateName = "后台处理中";
                } else if ("A".equals(stateFlag)) {
                    stateName = "后台处理中";
                } else if ("L".equals(stateFlag)) {
                    stateName = "整改";
                } else if ("S".equals(stateFlag)) {
                    stateName = "通过";
                    delFile = "Y";
                } else if ("M".equals(stateFlag)) {
                    stateName = "数据审核中";
                    delFile = "Y";
                } else if (stateFlag.equals("")) {
                    stateName = "后台处理中";
                } else if ("X".equals(stateFlag)) {
                    stateName = "后台处理中";
                } else if ("R".equals(stateFlag)) {
                    stateName = "不通过";

                    if (!"Y".equals(cont.getOperation())) {
                        delFile = "Y";
                    }
                } else if (stateFlag.equals("D")) {
                    //增加点播中间态
                    stateName = "后台处理中";
                } else if (stateFlag.equals("Z")) {
                    stateName = "视频录制异常";
                } else if (stateFlag.equals("B")) {
                    stateName = "数据待审核";
                } else if (stateFlag.equals("P")){
                    stateName = "数据未抽中";
                } else if (stateFlag.equals("E")){
                    stateName = "数据异常";
                }

                stateReqForm.setContNo(clientContNo);
                if (stateFlag.equals("M")) {
                    stateFlag = "A";
                } else if (stateFlag.equals("D")) {
                    stateFlag = "F";
                } else if (stateFlag.equals("B")) {
                    stateFlag = "A";
                }
                //增加投保单号
                stateReqForm.setBusiNum(cont.getBusiNum());
                stateReqForm.setDelFile(delFile);
                stateReqForm.setStateFlag(stateFlag);
                stateReqForm.setStateName(stateName);
                logger.info("stateNamestateName:"+stateName);
                //增加是否删除投保单号标识
                stateReqForm.setIsDel("false");
                String contNo = cont.getContNo();
                LSVideo videa = videoDao.findByContNo(contNo);
                if (!"F".equals(stateFlag)) {
                    if(null == videa || org.apache.commons.lang3.StringUtils.isBlank(videa.getURL())){
                        stateReqForm.setUrl("");
                    }else{
                        stateReqForm.setUrl(videa.getURL());
                    }

                } else {
                    stateReqForm.setUrl("");
                }
                //添加是否copy标识
                if (videa != null) {
                    String isCopy = "NO";
                    if (videa.getIsCopy() != null && !videa.getIsCopy().equals("")) {
                        isCopy = videa.getIsCopy();
                    }
                    stateReqForm.setIsCopy(isCopy);
                }
                //添加上传时间
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                stateReqForm.setMakeDate(simpleDateFormat.format(cont.getMakeDate()));
                //增加返回业务类型
                stateReqForm.setOperation(cont.getOperation());


                if(cont.getPictureUrl() != null && !cont.getPictureUrl().equals("")){
                    stateReqForm.setPictureUrl("http://uploaduat-10051630.file.myqcloud.com"+cont.getPictureUrl());
                }else{
                    stateReqForm.setPictureUrl(defaultPictureUrl);
                }


                if(cont.getVideoSize() != null && !cont.getVideoSize().equals("")){
                    stateReqForm.setVideoSize(cont.getVideoSize());
                }else{
                    stateReqForm.setVideoSize("0.00");
                }

                LSInsured lsInsured = insuredDao.findByContNo(contNo);
                if(lsInsured != null){
                    stateReqForm.setInsuredName(lsInsured.getName());
                }

                LSAppnt lsAppnt = appntDao.findByContNo(contNo);
                if(lsAppnt != null){
                    stateReqForm.setAppntName(lsAppnt.getName());
                }


                if(cont.getMainRiskName() != null && !cont.getMainRiskName().equals("")){
                    stateReqForm.setRiskName(cont.getMainRiskName());
                }else{
                    stateReqForm.setRiskName("暂无主险名称");
                }
                //新添两个字段返回：产品名称、投保人姓名；
                ShowStateVo showStateVo = new ShowStateVo();
                showStateVo = queryDao.selectForStateByContNo(contNo);
                if(null == showStateVo || org.apache.commons.lang3.StringUtils.isBlank(showStateVo.getName())){
                    stateReqForm.setName("");
                }else{
                    stateReqForm.setName(showStateVo.getName());
                }
                String riskType = null;
                if(null == showStateVo){
                    riskType = "";
                    stateReqForm.setProductName("");
                }else{
                    riskType = showStateVo.getRiskType();
                    List<String> listRisk = new ArrayList<>();
                    listRisk = Arrays.asList(riskType.split(","));
                    List<String> productNames = queryDao.selectProductNameByCode(listRisk);
                    String productName = null;
                    StringBuffer sb = new StringBuffer();
                    if(null == productNames || productNames.size() < 1){
                        productName = "";
                        stateReqForm.setProductName(productName);
                    }else{
                        productName = org.apache.commons.lang3.StringUtils.join(productNames,',');
                        stateReqForm.setProductName(productName);
                    }
                }
                list.add(stateReqForm);

            }
        }
        result = new RequestResult(true);
        result.setResult(list);
        return result;
    }


    @Override
    public RequestResult showStateReject(StateForm stateForm) {
        List<String> clientContNos = stateForm.getContNos();
        RequestResult result = null;
        List<StateReqForm> list = new ArrayList<StateReqForm>();
        for (String clientContNo : clientContNos) {
            StateReqForm stateReqForm = new StateReqForm();
            //查找是否有删除单子
            LSCont delLsCont = contDao.findByClientContNoAndLastOne(clientContNo, 'C');
            if (delLsCont != null) {

                stateReqForm.setBusiNum(delLsCont.getBusiNum());
                stateReqForm.setContNo(clientContNo);
                stateReqForm.setDelFile("Y");
                stateReqForm.setIsDel("true");
                stateReqForm.setStateFlag("");
                stateReqForm.setStateName("");
                stateReqForm.setUrl("");
                stateReqForm.setIsCopy("");
                stateReqForm.setMakeDate("");
                list.add(stateReqForm);


            }


            LSCont cont = contDao.findByClientContNoAndLastOne(clientContNo, 'Y');
            if (cont != null && !"Y".equals(cont.getOperation())) {
                if (cont == null || !cont.getOperator().equals(CurrentUser.getUser().getUserId())) {
                    continue;
                }
            }


            if (!StringUtils.isEmpty(cont)) {
                String stateFlag = cont.getInteractive();
                String stateName = "";
                String delFile = "N";
                if ("F".equals(stateFlag)) {
                    stateName = "后台处理中";
                    continue;
                } else if ("A".equals(stateFlag)) {
                    stateName = "后台处理中";
                    continue;
                } else if ("L".equals(stateFlag)) {
                    stateName = "整改";
                } else if ("S".equals(stateFlag)) {
                    stateName = "通过";

                    delFile = "Y";
                    continue;
                } else if ("M".equals(stateFlag)) {
                    stateName = "数据审核中";
                    delFile = "Y";
                    continue;
                } else if (stateFlag.equals("")) {
                    stateName = "后台处理中";
                    continue;
                } else if ("X".equals(stateFlag)) {
                    stateName = "后台处理中";
                    continue;
                } else if ("R".equals(stateFlag)) {
                    stateName = "不通过";
                    if (!"Y".equals(cont.getOperation())) {
                        delFile = "Y";
                    }
                } else if (stateFlag.equals("D")) {
                    //增加点播中间态
                    stateName = "后台处理中";
                    continue;
                } else if (stateFlag.equals("Z")) {
                    stateName = "视频录制异常";
                    continue;
                } else if (stateFlag.equals("B")) {
                    stateName = "数据待审核";
                    continue;
                } else if (stateFlag.equals("P")){
                    stateName = "数据未抽中";
                    continue;
                } else if (stateFlag.equals("E")){
                    stateName = "数据异常";
                    continue;
                }

                stateReqForm.setContNo(clientContNo);
                if (stateFlag.equals("M")) {
                    stateFlag = "A";
                } else if (stateFlag.equals("D")) {
                    stateFlag = "F";
                } else if (stateFlag.equals("B")) {
                    stateFlag = "A";
                }
                //增加投保单号
                List<LSMessage> message = messageDao.findByBusinum(cont.getBusiNum());
                if(message != null){
                    StringBuffer stringBuffer = new StringBuffer();
                    for(int i = 0;i < message.size();i++){
                        if(message.get(i).getTitle() != null && !message.get(i).getTitle().equals("")){
                            if(i == (message.size()-1)){
                                stringBuffer.append(message.get(i).getTitle());
                            }else {
                                stringBuffer.append(message.get(i).getTitle()+",");
                            }
                        }
                    }
                    stateReqForm.setRejectReason(stringBuffer.toString());
                }

                LSInsured lsInsured = insuredDao.findByContNo(cont.getContNo());
                if(lsInsured != null){
                    stateReqForm.setInsuredName(lsInsured.getName());
                }

                LSAppnt lsAppnt = appntDao.findByContNo(cont.getContNo());
                if(lsAppnt != null){
                    stateReqForm.setAppntName(lsAppnt.getName());
                }


                stateReqForm.setBusiNum(cont.getBusiNum());
                stateReqForm.setDelFile(delFile);
                stateReqForm.setStateFlag(stateFlag);
                stateReqForm.setStateName(stateName);
                logger.info("stateNamestateName:"+stateName);
                //增加是否删除投保单号标识
                stateReqForm.setIsDel("false");
                String contNo = cont.getContNo();
                LSVideo videa = videoDao.findByContNo(contNo);
                if (!"F".equals(stateFlag)) {
                    stateReqForm.setUrl(videa.getURL());
                } else {
                    stateReqForm.setUrl("");
                }
                //添加是否copy标识
                if (videa != null) {
                    String isCopy = "NO";
                    if (videa.getIsCopy() != null && !videa.getIsCopy().equals("")) {
                        isCopy = videa.getIsCopy();
                    }
                    stateReqForm.setIsCopy(isCopy);
                }
                //添加上传时间
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                stateReqForm.setMakeDate(simpleDateFormat.format(cont.getMakeDate()));
                //增加返回业务类型
                stateReqForm.setOperation(cont.getOperation());


                if(cont.getPictureUrl() != null && !cont.getPictureUrl().equals("")){
                    stateReqForm.setPictureUrl("http://uploaduat-10051630.file.myqcloud.com"+cont.getPictureUrl());
                }else{
                    stateReqForm.setPictureUrl(defaultPictureUrl);
                }


                if(cont.getVideoSize() != null && !cont.getVideoSize().equals("")){
                    stateReqForm.setVideoSize(cont.getVideoSize());
                }else{
                    stateReqForm.setVideoSize("0.00");
                }

                if(cont.getMainRiskName() != null && !cont.getMainRiskName().equals("")){
                    stateReqForm.setRiskName(cont.getMainRiskName());
                }else{
                    stateReqForm.setRiskName("暂无主险名称");
                }
                list.add(stateReqForm);

            }

        }
        result = new RequestResult(true);
        result.setResult(list);
        return result;
    }

    //递归查询最初的流水单号
    public String findOrginContNo(String contNo) {
        LSCont lsCont = contDao.findByContNo(contNo);
        if (lsCont != null) {
            if ((lsCont.getOperType() + "").equals("R")) {
                contNo = lsCont.getOrginContNo();
                return findOrginContNo(contNo);
            }
        }
        return contNo;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:35
     * 查询保单详情
     */
    @Override
    public ServiceResult<PolcyForm, String[]> showPolicy(String contNo) {
        ServiceResult.Builder<PolcyForm, String[]> res = ServiceResult.build(PolcyForm.class, String[].class);

        LSCont lsCont = contDao.findByClientContNoAndLastOne(contNo, 'Y');
        if (lsCont == null) {
            return res.createFailResult(new String[]{"没有保单数据"});
        }
        String orginContNo = lsCont.getContNo();
        //查询最初的流水单号
        if (lsCont.getOrginContNo() != null && !lsCont.getOrginContNo().trim().equals("")) {
            orginContNo = findOrginContNo(lsCont.getOrginContNo());
        }

        PolcyForm polcyForm = new PolcyForm();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        LSAppnt lsAppnt = appntDao.findByContNo(lsCont.getContNo());
        LSInsured lsInsured = insuredDao.findByContNo(lsCont.getContNo());
        LSVideo lsVideo = videoDao.findByContNo(lsCont.getContNo());
        List<LSPicture> lsPictures = pictureDao.findByContNo(orginContNo);
        Iterator it = lsPictures.iterator();
        while (it.hasNext()) {
            LSPicture lp = (LSPicture) it.next();
            if (lp.getBusiType().equals("ScreenShoot")) {
                it.remove();
            }
        }

        // 保存保单
        polcyForm.setBusiNum(lsCont.getBusiNum());
        polcyForm.setContNo(lsCont.getClientContNo());
        polcyForm.setComCode(lsCont.getInsurComCode());
        polcyForm.setRiskType(lsCont.getRiskType());
        polcyForm.setOperator(lsCont.getOperator());
        polcyForm.setScanDate(lsCont.getScanDate());
        polcyForm.setScanTime(lsCont.getScanTime());
        polcyForm.setMakeDate(sdf.format(lsCont.getMakeDate()) + " " + lsCont.getMakeTime());
        polcyForm.setChannel(lsCont.getChannel());
        polcyForm.setOrgCode(lsCont.getOrgCode());
        if(lsCont.getSendScene()==null || lsCont.getSendScene().equals("")){
            polcyForm.setSendScene("0");
        }
        polcyForm.setSendScene(lsCont.getSendScene());
        polcyForm.setIsSelf(lsCont.getIsSelf());
        polcyForm.setResource(lsCont.getResource());
        if ("Y".equals(lsCont.getOperation())) {
            polcyForm.setOperation(lsCont.getOperation());
            //添加返回银行名称
            LSBank lsBank = bankDao.findByBankCode(lsCont.getBankCode());
            polcyForm.setBankName(lsBank.getBankName());
            polcyForm.setBankCode(lsCont.getBankCode());
            polcyForm.setBanknetWork(lsCont.getBanknetWork());
            polcyForm.setProperson(lsCont.getProperson());
        } else {
            //历史数据默认给 自营业务
            polcyForm.setOperation("I");
            polcyForm.setBankCode("");
            polcyForm.setBankName("");
            polcyForm.setBanknetWork("");
            polcyForm.setProperson("");
        }

        // 保存投保人
        AppntForm appnt = new AppntForm();
        appnt.setAppntNo(lsAppnt.getAppntNo());
        appnt.setName(lsAppnt.getName());
        appnt.setSex(lsAppnt.getSex());
        appnt.setBirthday(lsAppnt.getBirthday());
        appnt.setAddress(lsAppnt.getAddress());
        appnt.setIdNo(lsAppnt.getIdNo());
        appnt.setIdType(lsAppnt.getIdType());
        appnt.setAge(lsAppnt.getAge());
        polcyForm.setAppnt(appnt);

        // 保存被保人

        if (lsInsured != null) {
            InsuredForm insered = new InsuredForm();
            insered.setAddress(lsInsured.getAddress());
            insered.setAge(lsInsured.getAge());
            insered.setBirthday(lsInsured.getBirthday());
            insered.setIdNo(lsInsured.getIdNo());
            insered.setIdType(lsInsured.getIdType());
            insered.setInsuredNo(lsInsured.getInsuredNo());
            insered.setName(lsInsured.getName());
            insered.setSex(lsInsured.getSex());
            polcyForm.setInsured(insered);
        }

        // 保存视频
        VideoForm video = new VideoForm();
        video.setVideoNo(lsVideo.getVideoNo());
        video.setBeginTime(sdf.format(lsVideo.getBeginDate()) + " " + lsVideo.getBeginTime());
        video.setTimeLength(lsVideo.getTimeLength());
        video.setVideoName(lsVideo.getVideoName());
        video.setVideoType(lsVideo.getVideoType());
        video.setStorageType(lsVideo.getStorageType() + "");
        video.setURL(lsVideo.getURL());
        polcyForm.setVideo(video);

        // 保存图片
        List<PictureForm> pictureForms = new ArrayList<PictureForm>();
        for (LSPicture lsPicture : lsPictures) {
            PictureForm pictureForm = new PictureForm();
            pictureForm.setPicNo(lsPicture.getPicNo());
            pictureForm.setPicName(lsPicture.getPicName());
            pictureForm.setPicType(lsPicture.getPicType());
            pictureForm.setpKID(lsPicture.getpKId());
            pictureForm.setBusiType(lsPicture.getBusiType() + "");
            pictureForm.setTimeNode(lsPicture.getTimeNode());
            pictureForm.setPicUrl(lsPicture.getURL());
            pictureForms.add(pictureForm);
        }
        polcyForm.setPictures(pictureForms);
        return res.createSuccessResult(polcyForm);
    }

    @Override
    public List<LSCont> findAllCont() {
        return contDao.findAll();
    }

    @Override
    public LSPicture findByPicNameAndContNo(String picName, String contNo) {
        return pictureDao.findByPicNameAndContNo(picName, contNo);
    }

    @Override
    public void saveVideo(LSVideo lsVideo) {
        videoDao.save(lsVideo);
    }

    @Override
    public void savePicture(LSPicture lsPicture) {
        pictureDao.save(lsPicture);
    }

    @Override
    public LSCont findContByClientContNoAndLastOne(String clientContNo) {
        return contDao.findByClientContNoAndLastOne(clientContNo, 'Y');
    }

    @Override
    public List<LSCont> findByLastOneAndInteractive(char lastOne, String interactive) {
        return contDao.findByLastOneAndInteractive(lastOne, interactive);
    }

    @Override
    public void saveCont(LSCont lsCont) {
        contDao.save(lsCont);
    }

    @Override
    public LSVideo findVideoByContNo(String contNo) {
        return videoDao.findByContNo(contNo);
    }

    @Override
    public List<LSPicture> findPictureByContNo(String contNo) {
        return pictureDao.findByContNo(contNo);
    }

    @Override
    public LSAppnt findAppntByContNo(String contNo) {
        return appntDao.findByContNo(contNo);
    }

    @Override
    public LSInsured findInsuredByContNo(String contNo) {
        return insuredDao.findByContNo(contNo);
    }

    @Override
    public LSCont findByContNo(String contNo) {
        return contDao.findByContNo(contNo);
    }

    @Override
    public LSUser findUserByUserId(String userId) {
        return userDao.getUser(userId);
    }

    final private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:35
     * h5 上传
     */
    @Override
    @Transactional
    public RequestResult uploadZip(MultipartFile zipFile, String contNo, String clientMD5) {

        LSCont lsCont = contDao.findByClientContNoAndLastOne(contNo, 'Y');
        if (lsCont == null || !lsCont.getOperator().equals(CurrentUser.getUser().getUserId())) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessage("文件与数据不符");
            return requestResult;
        }
        // 文件保存开始 时间节点
        LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
        java.util.Date date = new java.util.Date();
        lsContTime.setFileBeginTime(contSdf.format(date));
        contTimeDao.saveContTime(lsContTime);

        File dir = _createTmpDir();
        File file = _saveFile(zipFile, dir, contNo);

        String serverMD5 = Md5Util.getMD5(file);
        logger.info("client file md5::{}, server file md5::{}", clientMD5, serverMD5);
        String finish = null;
        if (clientMD5.equalsIgnoreCase(serverMD5)) {
            logger.info("Cont[{}] file md5 check success", contNo);

            finish = "Y";

            File dealDir = _createDealDir(lsCont.getContNo());

            lsCont.setInteractive("F");
            contDao.save(lsCont);

            // 文件 解压缩 开始时间节点
            java.util.Date date3 = new java.util.Date();
            lsContTime.setZipBeginTime(contSdf.format(date3));
            contTimeDao.saveContTime(lsContTime);
            ZipUtils.unZip(file.getAbsolutePath(), dealDir.getAbsolutePath());
            // 保存 解压缩 结束时间 节点
            java.util.Date date2 = new java.util.Date();
            lsContTime.setZipEndTime(contSdf.format(date2));
            contTimeDao.saveContTime(lsContTime);
            logger.info("Cont[{}] zip接收文件解压完成", contNo);
        } else {
            logger.error("Cont[{}] file md5 check failed", contNo);
            finish = "N";
        }
        logger.info("finish {}", finish);
        // 删除文件
        Boolean boolean1 = file.delete();
        logger.info("Cont[{}]  file delete {}", contNo, boolean1);
        // 文件保存结束 时间节点
        java.util.Date date1 = new java.util.Date();
        lsContTime.setFileEndTime(contSdf.format(date1));
        contTimeDao.saveContTime(lsContTime);

        RequestResult result = new RequestResult(true);
        Hashtable<String, String> data = new Hashtable<>(1);
        data.put("finish", finish);
        result.setData(data);
        return result;
    }

    private File _createDir(String savepath) {
        File dir = new File(savepath);
        if (!dir.exists()) {
            logger.info("dir is not exists!!! path={}", savepath);
            dir.mkdirs();
        } else {
            logger.info("dir is exists!!! path={}", savepath);
        }
        return dir;
    }

    private File _createTmpDir() {
//		String path = System.getProperty("user.dir");
//		logger.info("base path: {}", path);
        String dateString = sdf.format(new java.util.Date());
        String pathDate = dateString;
        String uuid = UUID.randomUUID().toString();
        String savepath = zipPath + "/" + pathDate + "/" + uuid;
        File dir = _createDir(savepath);
        return dir;
    }

    @Value("${save.filePath}")
    private String filePath;
    @Value("${save.zipPath}")
    private String zipPath;

    private File _createDealDir(String contNo) {
//		String path = System.getProperty("user.dir");
//		logger.info("base path: {}", path);
        String dealPath = filePath + "/" + contNo + "/";
        File dir = _createDir(dealPath);
        return dir;
    }

    private File _saveFile(MultipartFile inputFile, File toDir, String contNo) {

        String fileName = inputFile.getOriginalFilename();
        if (logger.isInfoEnabled()) {
            logger.info("Cont[{}], save file [filename={}, savepath={}] ", contNo, fileName, toDir.getAbsolutePath());
        }

        File file = new File(toDir, fileName);
        // 保存
        try {
            inputFile.transferTo(file);
        } catch (Exception e) {
            // e.printStackTrace();
            RuntimeException ex = new RuntimeException("Cont[" + contNo + "] upload file save failed！！！！ filename="
                    + fileName + ", savepath=" + toDir.getAbsolutePath(), e);
            logger.error(ex.getMessage(), ex);
            throw ex;
        }

        if (logger.isInfoEnabled()) {
            logger.info("cont[{}] files save to disk, savepath={}", contNo, file.getAbsolutePath());
        }
        return file;
    }

    @Override
    public RequestResult cosZip(String contNo, String zipUrl) {

        LSCont lsCont = contDao.findByClientContNoAndLastOne(contNo, 'Y');
        if (lsCont == null || !lsCont.getOperator().equals(CurrentUser.getUser().getUserId())) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessage("文件与数据不符");
            return requestResult;
        }

        // 文件保存开始 时间节点
        LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
        java.util.Date date = new java.util.Date();
        lsContTime.setFileBeginTime(contSdf.format(date));
        lsContTime.setZipUrl(zipUrl);
        contTimeDao.saveContTime(lsContTime);

        // 压缩包目录
        File dir = _createTmpDir();
        File file = new File(dir, contNo + ".zip");
        String result = cloudService.download(lsCont.getComCode(), zipUrl, file.getAbsolutePath(), "down");
        logger.info("contNo {} cos zip result {}", lsCont.getContNo(), result);

        // 文件目录
        File dealDir = _createDealDir(lsCont.getContNo());
        lsCont.setInteractive("F");
        contDao.save(lsCont);


        // 文件 解压缩 开始时间节点
        java.util.Date date3 = new java.util.Date();
        lsContTime.setZipBeginTime(contSdf.format(date3));
        contTimeDao.saveContTime(lsContTime);
        ZipUtils.unZip(file.getAbsolutePath(), dealDir.getAbsolutePath());
        // 保存 解压缩 结束时间 节点
        java.util.Date date2 = new java.util.Date();
        lsContTime.setZipEndTime(contSdf.format(date2));
        contTimeDao.saveContTime(lsContTime);
        logger.info("Cont[{}] zip接收文件解压完成", contNo);
        // 删除文件
        Boolean boolean1 = file.delete();
        logger.info("Cont[{}]  file delete {}", contNo, boolean1);
        // 文件保存结束 时间节点
        java.util.Date date1 = new java.util.Date();
        lsContTime.setFileEndTime(contSdf.format(date1));
        contTimeDao.saveContTime(lsContTime);

        RequestResult requestResult = new RequestResult(true);
        Hashtable<String, String> data = new Hashtable<>(1);
        data.put("finish", "Y");
        requestResult.setData(data);
        return requestResult;
    }

    //替换实时话术
    public TalkForm[] replaceMergeTalkRunTime(TalkForm[] talkForms, String busiNum, String riskName) {
        LSReplacetalk lsReplacetalk = null;
        if (!StringUtils.isEmpty(busiNum)) {
            lsReplacetalk = replaceTalkDao.findByBusiNumAndRiskName(busiNum, riskName);
        }
        String str = "";
        if (lsReplacetalk != null) {
            for (int i = 0; i < talkForms.length; i++) {
                str = talkForms[i].getTalkContent();
                str = StringUtil.replace(str, "?appntName?", lsReplacetalk.getAppntName());
                str = StringUtil.replace(str, "?insuredName?", lsReplacetalk.getInsuredName());
                str = StringUtil.replace(str, "?comName?", lsReplacetalk.getComName());
                str = StringUtil.replace(str, "?userName?", lsReplacetalk.getUserName());
                str = StringUtil.replace(str, "?riskName?", lsReplacetalk.getRiskName());
                str = StringUtil.replace(str, "?intersectionPayIntv?", lsReplacetalk.getIntersectionPayInty());
                str = StringUtil.replace(str, "?intersectionPrem?", lsReplacetalk.getIntersectionPrem());
                str = StringUtil.replace(str, "?intersectionPayEndYear?", lsReplacetalk.getIntersectionPayEndYead());
                str = StringUtil.replace(str, "?intersectionInsuYear?", lsReplacetalk.getIntersectionInsuYear());
                str = StringUtil.replace(str, "?wholesalePrem?", lsReplacetalk.getWholesalePrem());
                str = StringUtil.replace(str, "?wholesaleInsuYear?", lsReplacetalk.getWholesaleInsuYear());
                str = StringUtil.replace(str, "?wholesaleHesitation?", lsReplacetalk.getWholesaleHesitation());
                talkForms[i].setTalkContent(str);
            }
        } else {
            for (int i = 0; i < talkForms.length; i++) {
                str = talkForms[i].getTalkContent();
                str = StringUtil.replace(str, "?appntName?", "XX");
                str = StringUtil.replace(str, "?insuredName?", "XX");
                str = StringUtil.replace(str, "?comName?", "XX");
                str = StringUtil.replace(str, "?userName?", "XX");
                str = StringUtil.replace(str, "?riskName?", "XX");
                str = StringUtil.replace(str, "?intersectionPayIntv?", "XX");
                str = StringUtil.replace(str, "?intersectionPrem?", "XX");
                str = StringUtil.replace(str, "?intersectionPayEndYear?", "XX");
                str = StringUtil.replace(str, "?intersectionInsuYear?", "XX");
                str = StringUtil.replace(str, "?wholesalePrem?", "XX");
                str = StringUtil.replace(str, "?wholesaleInsuYear?", "XX");
                str = StringUtil.replace(str, "?wholesaleHesitation?", "XX");
                talkForms[i].setTalkContent(str);
            }
        }

        return talkForms;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:36
     * 查询实时话术
     */
    @Override
    public RequestResult  showMergeTalkRunTime(TalkRunTimeForm talkRunTimeForm) {
        DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        logger.info("talkruntimeform {}", talkRunTimeForm);
        String busiNum = null;
        String busNum = null;//未排序的Businum
        ServiceResult<String, String[]> serviceResult = null;
        if (talkRunTimeForm.getBusiNum() != null) {
            ServiceResult<String, String[]> sr = getArrayStringSortMsg(talkRunTimeForm.getBusiNum());
            if (sr.isSuccess()) {
                busiNum = sr.getSuccessResult();
            } else {
                RequestResult requestResult = new RequestResult(false);
                requestResult.setMessages(sr.getFailResult());
                return requestResult;
            }
        }
        //1.businum
        busNum = talkRunTimeForm.getBusiNum();
        busiNum = StringSortUtil.getArrayStringSort(talkRunTimeForm.getBusiNum());
        talkRunTimeForm.setBusiNum(busiNum);//准备talkRunTimeForm数据：busiNum
        //2.operator
        String operator = CurrentUser.getUser().getUserId();
        talkRunTimeForm.setOperator(operator);//准备talkRunTimeForm数据：operator
        //3.代理人证件号
        String idNo = CurrentUser.getUser().getIdNo();
        talkRunTimeForm.setIdNo(idNo);
        //4.代理人证件类型
        String idType = CurrentUser.getUser().getIdType();
        talkRunTimeForm.setIdType(idType);
        //5.机构码，国寿：24001
        String comCode = CurrentUser.getUser().getComCode();
        String insurComCode = talkRunTimeForm.getInsurComCode();
        //6.机构 orgCode eg:321200
        String orgCode = talkRunTimeForm.getOrgCode();
        if(StringUtils.isEmpty(talkRunTimeForm.getOrgCode())){
            orgCode = CurrentUser.getUser().getOrgCode();
        }
        talkRunTimeForm.setOrgCode(orgCode);//准备talkRunTimeForm数据：comCode
        //7.渠道
        String channel = talkRunTimeForm.getChannel();
        if(StringUtils.isEmpty(talkRunTimeForm.getChannel())){
            channel = CurrentUser.getUser().getChannel();
        }
        talkRunTimeForm.setChannel(channel);
        //8.代理人编号
        String agentCode = CurrentUser.getUser().getAgentCode();
        talkRunTimeForm.setAgentCode(agentCode);//准备talkRunTimeForm数据：agentCode
        //9.代理人姓名
        String userName = CurrentUser.getUser().getName();
        talkRunTimeForm.setName(userName);
        //10.异地和来源
        try{
            if(StringUtils.isEmpty(talkRunTimeForm.getSendScene())){
                talkRunTimeForm.setSendScene("0");
            }
        }catch(Exception e){
            logger.info(e.getMessage(),e);
        }
        String riskName = "";
        String riskType = StringSortUtil.getArrayStringSort(talkRunTimeForm.getRiskType());
        String insuredName = talkRunTimeForm.getInsured().getName();
        String appntName = talkRunTimeForm.getAppnt().getName();
        String appntBirthday = format1.format(talkRunTimeForm.getAppnt().getBirthday());
        String insuredBirthday = format1.format(talkRunTimeForm.getInsured().getBirthday());
        String insuredRelationship = talkRunTimeForm.getInsured().getInsuredRelationship();
        LSUser lsUser = userDao.getUser(operator);
        talkRunTimeForm.setBrithday(lsUser.getBrithday());
        talkRunTimeForm.setSex(lsUser.getSex());
        talkRunTimeForm.setPhoneNo(lsUser.getPhoneNo());
        talkRunTimeForm.setIdNo(lsUser.getIdNo());
        logger.info("check  busiNum  start{}");

        //11.自保件
        if(StringUtils.isEmpty(talkRunTimeForm.getIsSelf())){
            String self = judgeIsSelf(talkRunTimeForm.getAppnt(),lsUser);
            talkRunTimeForm.setIsSelf(self);
        }
        //验证投保单号
        serviceResult = checkService.checkBusiNum(comCode, busiNum, agentCode, riskType);
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            logger.info("businum {}  fileresult {}", busiNum, serviceResult.getFailResult());
            Hashtable<String, String> data = new Hashtable<>();
            data.put("isMove", "false");
            requestResult.setData(data);
            return requestResult;
        }
        List<NewTalkRiskForm> message = talkRunTimeForm.getNewTalkRiskForm();
        if (message == null || message.size() == 0 ){
            String clientContNo = talkRunTimeForm.getClientContNo();
            if (!StringUtils.isEmpty(clientContNo)){
                for (String str : StringSortUtil.getArrayStringSort(riskType).split(",")) {
                    LspolClient lspolClient = lsPolClientDao.findLspolClientByContnoAndRiskcode(clientContNo, str);
                    if(null!=lspolClient && !"".equals(lspolClient)){
                        NewTalkRiskForm risk = new NewTalkRiskForm();
                        risk.setRiskCode(lspolClient.getRiskcode());
                        risk.setRiskName(lspolClient.getRiskname());
                        if (lspolClient.getPayendyear().equals("趸交")){
                            risk.setWholesalePrem(String.valueOf(lspolClient.getPrem()));
                            risk.setWholesaleInsuYear(lspolClient.getInsuyear());
                        }else{
                            risk.setIntersectionPayEndYear(lspolClient.getPayendyear());
                            risk.setIntersectionPayInty(lspolClient.getPayintv());
                            risk.setIntersectionPrem(String.valueOf(lspolClient.getPrem()));
                            risk.setIntersectionInsuYear(lspolClient.getInsuyear());
                        }
                        message.add(risk);
                    }else{
                        break;
                    }
                }
            }
        }
        //准备talkRunTimeForm数据：准备根据businum查询risk信息

        /*if(busiNum != null && ! "".equals(busiNum)){
            for (String rt : (StringSortUtil.getArrayStringSort(riskType).split(","))){
                List<LSReplacetalk> lsReplacetalks = replaceTalkDao.findByRiskCodeAndBusiNum(rt,busiNum);
                if(lsReplacetalks != null && !lsReplacetalks.isEmpty()){
                    for(LSReplacetalk lsReplacetalk : lsReplacetalks){
                        NewTalkRiskForm risk = new NewTalkRiskForm();
                        risk.setRiskCode(lsReplacetalk.getRiskCode());
                        risk.setRiskName(lsReplacetalk.getRiskName());
                        risk.setWholesaleInsuYear(lsReplacetalk.getWholesaleInsuYear());
                        risk.setWholesaleInsuYearFlag(lsReplacetalk.getWholesaleInsuYearFlag());
                        risk.setWholesalePrem(lsReplacetalk.getWholesalePrem());
                        risk.setWholesaleHesitation(lsReplacetalk.getWholesaleHesitation());
                        risk.setIntersectionInsuYear(lsReplacetalk.getIntersectionInsuYear());
                        risk.setIntersectionInsuYearFlag(lsReplacetalk.getIntersectionInsuYearFlag());
                        risk.setIntersectionPrem(lsReplacetalk.getIntersectionPrem());
                        risk.setIntersectionPayInty(lsReplacetalk.getIntersectionPayInty());
                        risk.setIntersectionPayEndYearFlag(lsReplacetalk.getIntersectionPayEndYearFlag());
                        risk.setIntersectionPayEndYear(lsReplacetalk.getIntersectionPayEndYead());
                        message.add(risk);
                    }
                }
            }
        }*/

        for (String rt : (StringSortUtil.getArrayStringSort(riskType).split(","))) {
            logger.info(rt+"     "+orgCode+"     "+channel);
            LMProduct lsProductNew  = productManagerService.getProduct(rt,orgCode,channel);
            if (lsProductNew == null) {
                continue;
            }
            if (!riskName.equals(""))
                riskName += " 和 ";
            riskName += lsProductNew.getProductName();
        }
        //判断投保人姓名是否为空，如果为空去数据库中查询
        if (talkRunTimeForm.getAppnt().getName() == null) {
            String contNo = (contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne(comCode, insurComCode, busiNum, 'Y')).getContNo();
            LSAppnt lsAppnt = appntDao.findByContNo(contNo);
            talkRunTimeForm.getAppnt().setName(lsAppnt.getName());
            talkRunTimeForm.getAppnt().setSex(lsAppnt.getSex());
        }
        List<LSTalkRunTime> talkRunTimes = null;
        if (busiNum == null || busiNum.isEmpty()) {
        } else {
            // 根据投保单号查询是否有整改记录
            LSCont lsCont = contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne(comCode, insurComCode, busiNum, 'Y');
            if (lsCont != null) {
                if ("Y".equals(lsCont.getOperation())) {
                    talkRunTimes = talkRunTimeDao.findByBusiNum(busiNum);
                } else {
                    //简化查询
                    //talkRunTimes = talkRunTimeDao.findByBusiNumAndOperatorAndComCodeAndInsurComCode(busiNum, operator, comCode, insurComCode);
                    talkRunTimes=talkRunTimeDao.findByBusiNum(busiNum);
                }
            }
        }

        // 判断是否有记录
        if (talkRunTimes != null && talkRunTimes.size() != 0) {
            //合并话术
            //getRuntimeTalk(talkRunTimes);
            //排序
            talkRunTimes.sort(new Comparator<LSTalkRunTime>() {
                @Override
                public int compare(LSTalkRunTime o1, LSTalkRunTime o2) {
                    return o1.getOrderNum() - o2.getOrderNum();
                }
            });
            if (talkRunTimes.get(0).getRiskType()!=null&&!StringSortUtil.getArrayStringSort(talkRunTimes.get(0).getRiskType()).equals(riskType)) {
                String riskNameList = "";
                for (String rt : (StringSortUtil.getArrayStringSort(talkRunTimes.get(0).getRiskType())).split(",")) {
//                    LSRiskType lsRiskType = getLsRiskTypeByComCodeAndOrgCodeAndRiskType(comCode, orgCode, rt);
                    LMProduct lsProductNew  = productManagerService.getProduct(rt,comCode,channel);
                    if (!riskNameList.equals(""))
                        riskNameList += " 和 ";
                    riskNameList += lsProductNew.getProductName();
                }
                RequestResult requestResult = new RequestResult(false);
                requestResult.setMessage("险种选择错误,请选择：" + riskNameList);
                return requestResult;
            }
            // 封装对象数组
            TalkForm[] talkForms = new TalkForm[talkRunTimes.size()];
            Integer order = 0;
            // 整改次数
            String updateTime = "";
            // 整改状态
            String isFlag = "";

            // 删除历史数据
            List<LSTalkContent> talkContents = talkContentDao.findByBusiNumAndRiskType(busiNum, riskType);
            if (talkContents != null && !talkContents.isEmpty()) {
                for (LSTalkContent ls : talkContents
                ) {
                    talkContentDao.delTalkContent(ls);
                }
            }
            for (LSTalkRunTime lsTalkRunTime : talkRunTimes) {
                // 封装对象数组
                TalkForm talkForm = new TalkForm();
                talkForm.setId(lsTalkRunTime.getTalkPointCode());
                talkForm.setStep(lsTalkRunTime.getStep());
                //整改的时候新增智能质检和身份证OCR，单证识别
                LSQuestion lsQuestion = lsQuestionRepository.findByQid(lsTalkRunTime.getTalkPointCode());
                if (!StringUtils.isEmpty(lsQuestion.getQuestion())){
                    talkForm.setQuestion(lsQuestion.getQuestion());
                    talkForm.setKeys(lsQuestion.getKeys().split(","));
                }
                if (lsTalkRunTime.getStep().contains("投保人身份确认") || lsTalkRunTime.getStep().contains("投保人身份")){
                    talkForm.setIsUseIDCardOCR("Y");
                }else{
                    talkForm.setIsUseIDCardOCR("N");
                }
                if (lsTalkRunTime.getStep().contains("出示投保提示书") || lsTalkRunTime.getStep().contains("投保提示书")){
                    talkForm.setIsUseBasicOCR("Y");
                }else if (lsTalkRunTime.getStep().contains("出示产品说明书") || lsTalkRunTime.getStep().contains("产品说明书")){
                    talkForm.setIsUseBasicOCR("Y");
                }else if (lsTalkRunTime.getStep().contains("出示并阅读免除保险人责任条款") || lsTalkRunTime.getStep().contains("免除保险人责任条款")){
                    talkForm.setIsUseBasicOCR("Y");
                }else if (lsTalkRunTime.getStep().contains("出示保险条款和投保单") || lsTalkRunTime.getStep().contains("保险条款和投保单")){
                    talkForm.setIsUseBasicOCR("Y");
                }else{
                    talkForm.setIsUseBasicOCR("N");
                }
                talkForm.setOrdernum(order + "");
                //将整改话术设置为可读
                if("322".equals(lsTalkRunTime.getTalkPointCode())){
                    talkForm.setIsRead("Y");
                }else{
                    /*talkForm.setIsRead(lsTalkRunTime.getIsRead());*/
                    talkForm.setIsRead("Y");
                }

                String talkContent = lsTalkRunTime.getTaleConent();
                if (talkContent.contains("[趸交]") || talkContent.contains("[期交]")) {
                    talkForm.setIsRead("N");
                }
                if (talkForm.getIsRead().equals("N")) {
                    talkForm.setStep(lsTalkRunTime.getStep() + ",请代理人自行阅读！");
                } else {
                    talkForm.setStep(lsTalkRunTime.getStep());
                }

                talkForm.setTalkContent(talkContent);
                talkForms[order] = talkForm;
                order++;
                // 获取 整改次数
                updateTime = lsTalkRunTime.getUpdateTime();
                isFlag = lsTalkRunTime.getIsFlag();

                //保存替换话术
                LSTalkContent lsTalkContent = new LSTalkContent();
                lsTalkContent.setId(UUID.randomUUID().toString());
                lsTalkContent.setBusiNum(busiNum);
                lsTalkContent.setRiskType(riskType);
                lsTalkContent.setPkid(talkForm.getId());
                lsTalkContent.setTalkContent(talkForm.getTalkContent());
                lsTalkContent.setOrderNum(order + "");
                talkContentDao.saveTalkContent(lsTalkContent);
                logger.info("talkcont save {}", lsTalkContent);
            }
            // talkForms = replaceMergeTalkRunTime(talkForms, busiNum,riskName);
            RequestResult requestResult = new RequestResult(true);
            requestResult.setResult(talkForms);
            Hashtable<String, String> data = new Hashtable<>();
            data.put("updateTime", updateTime);
            data.put("isFlag", isFlag);
            requestResult.setData(data);
            logger.info("mearge talkruntime {}", requestResult);
            return requestResult;
        }
        //于9月19日14：38分决定拆除挡板，全部走新的话术
        if (false) {
//            // 没有找到 则 去 查询 lstalk 表 将 查询到的 属于这个机构的 这个 险种的 话述 在添加到 talkruntime 表里
//            // 在递归调用该方法
//            List<LSTalkNew> talks = new ArrayList<LSTalkNew>();
//
//            //添加险种排序
//            String riskTypeNew = getRiskSort(riskType);
//
//            logger.info("险种 {}", riskTypeNew);
//            for (String rt : riskTypeNew.split(",")) {
//                if (rt == null || rt.equals(""))
//                    continue;
//                List<LSTalkNew> t = findTalksByOrgCode(comCode, insurComCode, orgCode, rt);//所有话术
//                logger.info("{}", t);
//
//
//                List<LSTalkNew> replaceTalk = new ArrayList<>();
//                if (t != null && !t.isEmpty()) {
//
//                    //替换话术
//                    for (LSTalkNew lstalk : t) {
//
//                        //如果投被保人为同一人，则去掉 死亡给付 话术
//                        if (!StringUtils.isEmpty(insuredName) && appntName.equalsIgnoreCase(insuredName)) {
//                            if (lstalk.getStep().contains("死亡")) {
//                                continue;
//                            }
//                        }
//
//                        if (AgeUtil.calAgeFromBirthday(talkRunTimeForm.getInsured().getBirthday()) >= 18) {
//                            if (lstalk.getStep().contains("未成年人限额介绍")) {
//                                continue;
//                            }
//                        }
////                    LSRiskType lsRiskType = getLsRiskTypeByComCodeAndOrgCodeAndRiskType(comCode, orgCode, rt);
//                        com.sinosoft.easyrecord.entity.LMProduct lsProductNew  = productManagerService.getProduct(rt,comCode,channel);
//                        if (lsProductNew == null) {
//                            RequestResult requestResult = new RequestResult(false);
//                            requestResult.setMessage("险种选择错误，系统无信息，险种编码" + rt);
//                            return requestResult;
//                        }
//                        LSOrganization lsOrganization = organizationDao.findByOrgCode(orgCode);
//                        String talkContent = lstalk.getTalkContent();
//
//                        //获取免责条款
//                        LDCode ldCode = codeDao.findByCode(new LDCode.LDCodePk("disclaimer", rt));
//                        String disclaimer = "";
//                        if (ldCode != null) {
//                            disclaimer = ldCode.getCodeName();
//                        } else {
//                            disclaimer = "系统无配置信息，请联系管理员";
//                        }
//                        //获取万能比例
//                        LDCode wannengCode = codeDao.findByCode(new LDCode.LDCodePk("universal", rt));
//                        String universal = "";
//                        if (wannengCode != null) {
//                            universal = wannengCode.getCodeName();
//                        } else {
//                            universal = "系统无配置信息，请联系管理员";
//                        }
//                        //获取犹豫期
//                        String hesitation = "系统无配置信息，请联系管理员";
//                        LDCode hesitationCode = codeDao.findByCode(new LDCode.LDCodePk("hesitation" + orgCode, rt));
//                        if (hesitationCode == null) {
//                            hesitationCode = codeDao.findByCode(new LDCode.LDCodePk("hesitation", rt));
//                        }
//
//
//                        if (hesitationCode != null) {
//                            //获取渠道
//                            if (orgCode.equals("440200")) {
//                               // String channel = CurrentUser.getUser().getChannel();
//                                if (channel.equals("A11") || channel.equals("A16")) {
//                                    String hesitation1 = hesitationCode.getCodeRiskType();
//                                    if (StringUtils.isEmpty(hesitation1)) {
//                                        hesitation = hesitationCode.getCodeNameEn();
//                                    } else {
//                                        hesitation = hesitation1;
//                                    }
//                                } else {
//                                    hesitation = hesitationCode.getCodeNameEn();
//                                }
//                            } else {
//                                hesitation = hesitationCode.getCodeName();
//                            }
//                        }
//                        //获取产品提示书
//                        LDCode productTipsCode = codeDao.findByCode(new LDCode.LDCodePk("productTips", orgCode));
//                        if (productTipsCode == null) {
//                            productTipsCode = codeDao.findByCode(new LDCode.LDCodePk("productTips", "86"));
//                        }
//                        String productTips = productTipsCode.getCodeName();
//                        //获取产品责任
//                        LDCode responsibilityCode = codeDao.findByCode(new LDCode.LDCodePk("responsibility", rt));
//                        String responsibility = "";
//                        if (responsibilityCode != null) {
//                            responsibility = responsibilityCode.getCodeName();
//                        } else {
//                            responsibility = "系统无配置信息，请联系管理员";
//                        }
//
//                        //判断是否为 新型产品
//                        String riskCue = "";
//                        if (!lsProductNew.getProductTypeCode().equals("01")) {
//                            riskCue = "【人身保险新型产品】请将客户签字和抄录风险提示语句的在镜头前停留至少3秒保证清晰显示签名。";
//                        }
//
//                        //增加深圳清单
//                        //增加深圳清单
//                        LDCode detailedListCode = codeDao.findByCode(new LDCode.LDCodePk("detailedlist", orgCode));
//                        String detailedList = "";
//                        if (detailedListCode != null) {
//                            detailedList = detailedListCode.getCodeName();
//                        }
//                        //是否万能型产品
//                        String productTypeCode = lsProductNew.getProductTypeCode();
//                        String productCode = lsProductNew.getProductCode();
//                        //替换话术
//                        talkContent = replaceTalk(talkContent, lsProductNew.getProductName(), appntName, insuredName, talkRunTimeForm.getAppnt().getSex(), lsOrganization.getOrgName(), userName, disclaimer, universal, hesitation, productTips, responsibility, riskCue, detailedList, busNum, productTypeCode, productCode, appntBirthday, insuredBirthday, insuredRelationship);
//                        //切断序列化操作
//                        logger.info("替换话术后话术内容为 talkContent {}", talkContent);
//                        LSTalkNew lsTalkone = new LSTalkNew();
//                        lsTalkone = gettalk(lstalk, talkContent);
//                        logger.info("替换序列化后话术为 {}", lsTalkone);
//                        replaceTalk.add(lsTalkone);
//                    }
//                    talks.addAll(replaceTalk);
//                    logger.info("全部替换之后话术为 talks {}", talks);
//                }
//
//            }
//            getTalks(talks);
//            if (talks.size() != 0) {
//
//                TalkForm[] talkForms = new TalkForm[talks.size()];
//                Integer order = 0;
//                // 整改次数
//                String updateTime = "";
//                // 整改状态
//                String isFlag = "";
//
//                // 删除历史数据
//                List<LSTalkContent> talkContents = talkContentDao.findByBusiNumAndRiskType(busiNum, riskType);
//
//                if (talkContents != null && !talkContents.isEmpty()) {
//                    for (LSTalkContent ls : talkContents) {
//                        talkContentDao.delTalkContent(ls);
//                    }
//                }
//                logger.info("遍历对象之前话术为 talks {}", talks);
//                for (LSTalkNew talk : talks) {
//                    // 封装对象数组
//                    TalkForm talkForm = new TalkForm();
//                    String talkContent = talk.getTalkContent();
//                    logger.info("输出话术：{}", talk.getTalkContent());
//                    // 组合话术
//                    talkContent = groupTalk(talkContent);
//                    logger.info("组合话术之后话术为 {}", talkContent);
//                    talkForm.setIsRead(talk.getIsRead());
//                    if (talkContent.contains("[趸交]") || talkContent.contains("[期交]")) {
//                        talkForm.setIsRead("N");
//                    }
//                    talkForm.setId(talk.getTalkPointCode());
//                    if (talkForm.getIsRead().equals("N")) {
//                        talkForm.setStep(talk.getStep() + ",请代理人自行阅读！");
//                    } else {
//                        talkForm.setStep(talk.getStep());
//                    }
//                    talkForm.setOrdernum(order + "");
//                    talkForm.setTalkContent(talkContent);
//                    talkForms[order] = talkForm;
//                    order++;
//
//                    //保存替换话术
//                    LSTalkContent lsTalkContent = new LSTalkContent();
//                    lsTalkContent.setId(UUID.randomUUID().toString());
//                    lsTalkContent.setBusiNum(busiNum);
//                    lsTalkContent.setRiskType(riskType);
//                    lsTalkContent.setPkid(talkForm.getId());
//                    lsTalkContent.setTalkContent(talkForm.getTalkContent());
//                    lsTalkContent.setOrderNum(order + "");
//                    logger.info("save lstalk talk {}", talkForm.getTalkContent());
//                    talkContentDao.saveTalkContent(lsTalkContent);
//                }
//                //查询保单号是否存在于要替换话术的名单中,存在替换为对象属性，不存在替换为XX
//                RequestResult requestResult = new RequestResult(true);
//                requestResult.setResult(talkForms);
//                Hashtable<String, String> data = new Hashtable<>();
//                data.put("updateTime", updateTime);
//                data.put("isFlag", isFlag);
//                requestResult.setData(data);
//                return requestResult;
//
//            } else {
//                RequestResult requestResult = new RequestResult(false);
//                requestResult.setMessage("无结果");
//                return requestResult;
//            }
        }else{
            NewTalkDTO newTalkDTO = new NewTalkDTO();
            newTalkDTO.setNewTalkRiskForm(message);
            newTalkDTO.setAppnt(talkRunTimeForm.getAppnt());
            newTalkDTO.setInsured(talkRunTimeForm.getInsured());
            newTalkDTO.setAgentCode(talkRunTimeForm.getAgentCode());
            newTalkDTO.setAgentOrgCode(talkRunTimeForm.getOrgCode());
            newTalkDTO.setBankCode(talkRunTimeForm.getBankCode());
            newTalkDTO.setBankName(talkRunTimeForm.getBankName());
            newTalkDTO.setBanknetWork(talkRunTimeForm.getBanknetWork());
            newTalkDTO.setBrithday(talkRunTimeForm.getBrithday());
            newTalkDTO.setBusiNum(talkRunTimeForm.getBusiNum());
            newTalkDTO.setChannel(talkRunTimeForm.getChannel());
            newTalkDTO.setClientContNo(talkRunTimeForm.getClientContNo());
            newTalkDTO.setEqInfor(talkRunTimeForm.getEqInfor());
            newTalkDTO.setIdNo(talkRunTimeForm.getIdNo());
            newTalkDTO.setIdType(talkRunTimeForm.getIdType());
            newTalkDTO.setInsurComCode(talkRunTimeForm.getInsurComCode());
            newTalkDTO.setIsChange(talkRunTimeForm.getIsChange());
            newTalkDTO.setIsDone(talkRunTimeForm.getIsDone());
            newTalkDTO.setName(userName);
            newTalkDTO.setOperation(talkRunTimeForm.getOperation());
            newTalkDTO.setOperator(talkRunTimeForm.getOperator());
            newTalkDTO.setPhoneNo(talkRunTimeForm.getPhoneNo());
            newTalkDTO.setPractice(talkRunTimeForm.getPractice());
            newTalkDTO.setProperson(talkRunTimeForm.getProperson());
            newTalkDTO.setRiskType(talkRunTimeForm.getRiskType());
            newTalkDTO.setBusiNum(talkRunTimeForm.getBusiNum());
            newTalkDTO.setScanDate(talkRunTimeForm.getScanDate());
            newTalkDTO.setScanTime(talkRunTimeForm.getScanTime());
            newTalkDTO.setSendScene(talkRunTimeForm.getSendScene());
            newTalkDTO.setIsSelf(talkRunTimeForm.getIsSelf());
            newTalkDTO.setResource(talkRunTimeForm.getResource());
            List<PointTalkDescribe> talkContents = newTalkService.getTalks(newTalkDTO);
            TalkForm[] talkForms = new TalkForm[talkContents.size()];

            talkContents = talkContents.stream().sorted(Comparator.comparingInt(PointTalkDescribe::getSortnum))
                    .collect(Collectors.toList());


            // 删除历史数据
            List<LSTalkContent> talkContentLst = talkContentDao.findByBusiNumAndRiskType(busiNum, riskType);
            if (talkContentLst != null && !talkContentLst.isEmpty()) {
                for (LSTalkContent _ls : talkContentLst) {
                    talkContentDao.delTalkContent(_ls);
                }
            }

            for (int i=0;i<talkContents.size();i++){
                TalkForm talkForm = new TalkForm();
                talkForm.setStep(talkContents.get(i).getPointcontent());
                talkForm.setTalkContent(talkContents.get(i).getDescribecontent());
                talkForm.setId(talkContents.get(i).getPointid());
                talkForm.setIsRead(talkContents.get(i).getIsvoicebroadcast());
                talkForm.setOrdernum(String.valueOf(i));
                //添加问题跟keys
                talkForm.setQuestion(talkContents.get(i).getQuestion());
                talkForm.setKeys(talkContents.get(i).getKeys());
                talkForm.setIsUseIDCardOCR(talkContents.get(i).getIsUseIDCardOCR());
                talkForm.setIsUseBasicOCR(talkContents.get(i).getIsUseBasicOCR());
                talkForms[i] = talkForm;
                //保存替换话术
                LSTalkContent lsTalkContent = new LSTalkContent();
                lsTalkContent.setId(UUID.randomUUID().toString());
                lsTalkContent.setBusiNum(busiNum);
                lsTalkContent.setRiskType(riskType);
                lsTalkContent.setPkid(talkForm.getId());
                lsTalkContent.setTalkContent(talkForm.getTalkContent());
                lsTalkContent.setOrderNum(talkForm.getOrdernum());
                //添加问题跟keys
                lsTalkContent.setQuestion(talkForm.getQuestion());
                lsTalkContent.setIsKey(talkForm.getKeys().toString());
                logger.info("save lstalk talk {}", talkForm.getTalkContent());
                talkContentDao.saveTalkContent(lsTalkContent);
            }

            RequestResult requestResult = new RequestResult(false);
            System.out.println(talkForms);
            requestResult.setResult(talkForms);
            requestResult.setMessage("新流程");
            requestResult.setSuccess(true);
            return requestResult;
        }
        RequestResult requestResult = new RequestResult(false);
        requestResult.setMessage("无结果");
        return requestResult;
    }

    /**
     * 组合话术
     **/
    public String groupTalk(String talkContent) {
        logger.info("组合话术前话术为 {}",talkContent);
        if (!talkContent.contains("##replace##")) {
            return talkContent;
        } else {
            String[] talks = talkContent.split("##replace##");
            String begin = talks[0];
            if (StringUtils.isEmpty(begin)) {
                begin = "begin";
            }
            String end = talks[talks.length - 1];
            String home = "";
            for (String talk : talks) {
                logger.info("组合前所有话术 {}",talks);
                logger.info("组合话术前的话术 {}",home);

                if (talk.contains(begin) || talk.contains(end)) {

                } else {
                    if(!home.contains(talk)){
                        home += talk;
                    }else
                    {
                        logger.info("------话术重复   不做操作------");
                    }
                    logger.info("组合中 home {}",home);
                }
                logger.info("组合话术后的话术 {}",home);
            }
            if (begin.equals("begin")) {
                begin = "";
            }
            /**
             * 合并免责
             **/
            home = hebinghome(home);
            String str = begin + home + end;
            logger.info("组合完成 话术为(finished话术为) {}",str);
            return str;
        }
    }

    private String hebinghome(String home) {
        if (!home.contains("&&hebing&&")) {
            return home;
        }
        logger.info("合并免责 {}", home);
        String[] homes = home.split("&&hebing&&");
        if (homes.length <= 3) {
            home = StringUtil.replace(home, "&&hebing&&", "");
            home = StringUtil.replace(home, "&&caifen&&", "");
            return home;
        }
        String str = "";
        Map<String, Object> risk = new HashMap();
        for (String a : homes
        ) {
            if (a.contains("&&caifen&&")) {
                String[] as = a.split("&&caifen&&");
                String riskName = as[0];
                String mianze = as[1];
                if (risk.containsKey(mianze)) {
                    String riskNameold = (String) risk.get(mianze);
                    risk.put(mianze, riskName + "和" + riskNameold);
                } else {
                    risk.put(mianze, riskName);
                }
            }
        }
        String res = "";
        for (Map.Entry<String, Object> entry : risk.entrySet()) {
            res += entry.getValue();
            res += entry.getKey();
        }
        logger.info("合并后 {}", res);
        return res;
    }

//    /**
//     * 排序 险种顺序
//     **/
//    public String getRiskSort(String riskType) {
//        if (StringUtils.isEmpty(riskType)) {
//            return riskType;
//        }
//        if (!riskType.contains(",")) {
//            return riskType;
//        }
//
//        String[] risks = riskType.split(",");
//        String fenhong = "";
//        String wanneng = "";
//        String putong = "";
//        String toulian = "";
//        String other = "";
//        for (String str : risks) {
//            com.sinosoft.easyrecord.entity.LMProduct lsProductNew  = productManagerService.getProduct(str,comCode,channel);
//            if (lsProductNew != null && lsProductNew.getProductTypeName().contains("万能")) {
//                if (StringUtils.isEmpty(wanneng)) {
//                    wanneng += lsProductNew.getProductCode();
//                } else {
//                    wanneng += ",";
//                    wanneng += lsProductNew.getProductCode();
//                }
//            } else if (lsProductNew != null && lsProductNew.getProductTypeName().contains("分红")) {
//                if (StringUtils.isEmpty(fenhong)) {
//                    fenhong += lsProductNew.getProductCode();
//                } else {
//                    fenhong += ",";
//                    fenhong += lsProductNew.getProductCode();
//                }
//            } else if (lsProductNew != null && lsProductNew.getProductTypeName().contains("投连")) {
//                if (StringUtils.isEmpty(toulian)) {
//                    toulian += lsProductNew.getProductCode();
//                } else {
//                    toulian += ",";
//                    toulian += lsProductNew.getProductCode();
//                }
//            } else if (lsProductNew != null && lsProductNew.getProductTypeName().contains("普通")) {
//                if (StringUtils.isEmpty(putong)) {
//                    putong += lsProductNew.getProductCode();
//                } else {
//                    putong += ",";
//                    putong += lsProductNew.getProductCode();
//                }
//            } else {
//                if (StringUtils.isEmpty(other)) {
//                    other += lsProductNew.getProductCode();
//                } else {
//                    other += ",";
//                    other += lsProductNew.getProductCode();
//                }
//            }
//
//        }
//        String riskTypeNew = "";
//        riskTypeNew += putong;
//        if (!StringUtils.isEmpty(riskTypeNew)) {
//            riskTypeNew += ",";
//        }
//        riskTypeNew += fenhong;
//        if (!StringUtils.isEmpty(riskTypeNew)) {
//            riskTypeNew += ",";
//        }
//        riskTypeNew += wanneng;
//        if (!StringUtils.isEmpty(riskTypeNew)) {
//            riskTypeNew += ",";
//        }
//        riskTypeNew += toulian;
//        if (!StringUtils.isEmpty(riskTypeNew)) {
//            riskTypeNew += ",";
//        }
//        riskTypeNew += other;
//        return riskTypeNew;
//    }

    /**
     * 替换序列化
     **/
    public LSTalkNew gettalk(LSTalkNew lsTalk, String content) {
        LSTalkNew talk = new LSTalkNew();
        talk.setTalkContent(content);
        talk.setIsMerge(lsTalk.getIsMerge());
        talk.setComCode(lsTalk.getComCode());
        talk.setInsurComCode(lsTalk.getInsurComCode());
        talk.setIsRead(lsTalk.getIsRead());
        talk.setOrderNum(lsTalk.getOrderNum());
        talk.setOrgCode(lsTalk.getOrgCode());
        talk.setPkid(lsTalk.getPkid());
        talk.setRiskType(lsTalk.getRiskType());
        talk.setStep(lsTalk.getStep());
        talk.setTalkPkId(lsTalk.getTalkPkId());
        talk.setTalkPointCode(lsTalk.getTalkPointCode());

        return talk;
    }

    /**
     * 替换话术内容
     */
    private String replaceTalk(String talkContent, String riskName, String appntName, String insuredName,String gender, String orgName, String userName, String disclaimer, String universal, String hesitation, String productTips, String responsibility, String riskCue, String detailedList, String busiNum, String productTypeCode, String productCode,String appntBirthday,String insuredBirthday,String insuredRelationship) {
        /**
         * 如果是万能险，需要添加替换内容
         **/
//        if (productTypeCode.equals("02")){
//            talkContent = StringUtil.replace(talkContent, "?WANGNENG?", "这份保险您在一次性交纳保险费?PREM?元后，可以选择转入保险费和申请追加保险费，转入保险费由您与本公司约定，申请追加保险费须符合申请当时本公司的规定。");
//        } else {
        logger.info("现在的话术里有 {}",talkContent);
        talkContent = StringUtil.replace(talkContent, "?WANGNENG?", "");
//        }
        talkContent = StringUtil.replace(talkContent,"?INSUREDNAME?",insuredName);
        talkContent = StringUtil.replace(talkContent, "?RISKNAME?", riskName);
        talkContent = StringUtil.replace(talkContent, "?APPNTNAME?", appntName);
        if (gender.equals("男") || gender.equals("1")) {
            gender = "先生";
        } else if (gender.equals("女") || gender.equals("2")) {
            gender = "女士";
        }
        talkContent = StringUtil.replace(talkContent, "?APPNTSEX?", gender);
        LSReplacetalk lsReplacetalk = replaceTalkDao.findByBusiNumAndRiskCode(busiNum, productCode);
        if (lsReplacetalk != null) {
            String repText = "";//多余的话术内容
            String prem = "";//保费
            if (productTypeCode.equals("02") && talkContent.indexOf("?INTERSECTION?") != -1) {
                repText = talkContent.substring(talkContent.indexOf("?INTERSECTION?"), talkContent.lastIndexOf("?WHOLESALE?") + 11);
                LDCode ldCode = codeDao.findByCode(new LDCode.LDCodePk("payment", productCode));
                //talkContent = StringUtil.replace(talkContent, repText, "保险期间为本合同生效之日起至本合同终止之日止。这份保险您在一次性交纳保险费?PREM?元后，可以选择转入保险费和申请追加保险费，转入保险费由您与本公司约定，申请追加保险费须符合申请当时本公司的规定");
                talkContent = StringUtil.replace(talkContent, repText, ldCode.getCodeName());
                prem = lsReplacetalk.getIntersectionPrem();
            } else {
                if (lsReplacetalk.getIntersectionInsuYear().equals("XX")) {//趸交类型
                    if (talkContent.indexOf("?INTERSECTION?") != -1) {
                        repText = talkContent.substring(talkContent.indexOf("?INTERSECTION?"), talkContent.lastIndexOf("?INTERSECTION?") + 14);
                        talkContent = StringUtil.replace(talkContent, repText, " ");
                    }
                    prem = lsReplacetalk.getWholesalePrem();
                    talkContent = StringUtil.replace(talkContent, "?WHOLESALE?", "");
                    String insuyear = lsReplacetalk.getWholesaleInsuYear();
                    String insuyearflag = lsReplacetalk.getWholesaleInsuYearFlag();
                    if (insuyearflag.equals("A")) {
                        if (insuyear.equals("105")) {
                            insuyear = "终身";
                            LDCode code = codeDao.findByCode(new LDCode.LDCodePk("INSUYEAR", productCode));
                            if (code!=null){
                                insuyear = code.getCodeName();
                            }
                        } else {
                            insuyear = "为本合同生效之日起至被保险人" + insuyear + "周岁的年生效对应日止";
                        }
                    } else {
                        insuyear = "为" + insuyear + "年";
                    }
                    talkContent = StringUtil.replace(talkContent, "?INSUYEAR?", insuyear);
                } else {
                    if (talkContent.indexOf("?WHOLESALE?") != -1) {
                        repText = talkContent.substring(talkContent.indexOf("?WHOLESALE?"), talkContent.lastIndexOf("?WHOLESALE?") + 11);
                        talkContent = StringUtil.replace(talkContent, repText, " ");
                    }
                    String payendyear = lsReplacetalk.getIntersectionPayEndYead();
                    String payEndYearFlag = lsReplacetalk.getIntersectionPayEndYearFlag();
                    if (payendyear.equals("1000")) {
                        payendyear = "一次性交清";
                    } else if (payendyear.equals("0")) {
                        payendyear = "";
                    } else {
                        if (payEndYearFlag.equals("A")) {
                            payendyear = "交到" + payendyear + "周岁的年生效对应日止";
                        } else {
                            payendyear = "交" + payendyear + "年";
                        }
                    }
                    String insuyear = lsReplacetalk.getIntersectionInsuYear();
                    String insuyearflag = lsReplacetalk.getIntersectionInsuYearFlag();
                    if (insuyearflag.equals("A")) {
                        if (insuyear.equals("105")) {
                            insuyear = "终身";
                            LDCode code = codeDao.findByCode(new LDCode.LDCodePk("INSUYEAR", productCode));
                            if (code!=null){
                                insuyear = code.getCodeName();
                            }
                        } else {
                            insuyear = "为本合同生效之日起至被保险人" + insuyear + "周岁的年生效对应日止";
                        }
                    } else {
                        insuyear = "为" + insuyear + "年";
                    }
                    String payIntv = lsReplacetalk.getIntersectionPayInty();
                    if (payIntv.equals("1")) {
                        payIntv = "每月";
                    } else if (payIntv.equals("12")) {
                        payIntv = "每年";
                    } else if (payIntv.equals("36")) {
                        payIntv = "每三年";
                    } else if (payIntv.equals("0") || payIntv.equals("1000")) {
                        payIntv = "一次性";
                    }
                    if (productTypeCode.equals("02")) {
                        payIntv = "一次性";
                        insuyear = "终身";
                        payendyear = "一次性交清";
                    }
                    prem = lsReplacetalk.getIntersectionPrem();
                    talkContent = StringUtil.replace(talkContent, "?INTERSECTION?", "");
                    talkContent = StringUtil.replace(talkContent, "?INSUYEAR?", insuyear);
                    talkContent = StringUtil.replace(talkContent, "?PAYINTV?", payIntv);
                    talkContent = StringUtil.replace(talkContent, "?PAYENDYEAR?", payendyear);
                }
            }
            talkContent = StringUtil.replace(talkContent, "?PREM?", prem);
        } else {
            talkContent = StringUtil.replace(talkContent, "?APPNTSEX?", gender);
            talkContent = StringUtil.replace(talkContent, "?INTERSECTION?", "[期交]");
            talkContent = StringUtil.replace(talkContent, "?WHOLESALE?", "[趸交]");
            talkContent = StringUtil.replace(talkContent, "?PAYINTV?", "XX");
            talkContent = StringUtil.replace(talkContent, "?PREM?", "XX");
            talkContent = StringUtil.replace(talkContent, "?PAYENDYEAR?", "XX");
            talkContent = StringUtil.replace(talkContent, "?INSUYEAR?", "XX");
        }
        //替换终身
//        talkContent = StringUtil.replace(talkContent, "105  年   ", "终身");

        //替换投被保人关系

        if(insuredRelationship != null && !insuredRelationship.equals("") ){
            LDRelationship LDRelationship = relationShipDao.findByCode(insuredRelationship);
            if(LDRelationship != null) {
                String codeName = LDRelationship.getCodeName();
                if(lsReplacetalk!=null) {
                    lsReplacetalk.setInsuredRelationship(codeName);
                }
                talkContent = StringUtil.replace(talkContent,"?INSUREDRELATIONSHIP?",codeName);
            }
        }


        talkContent = StringUtil.replace(talkContent, "?ORGCODE?", orgName);
        talkContent = StringUtil.replace(talkContent, "?USERNAME?", userName);
        //替换免责条款
        talkContent = StringUtil.replace(talkContent, "?DISCLAIMER?", disclaimer);
        //替换万能比例
        talkContent = StringUtil.replace(talkContent, "?UNIVERSAL?", universal);
        //替换犹豫期
        talkContent = StringUtil.replace(talkContent, "?HESITATION?", hesitation);
        //替换产品提示书
        talkContent = StringUtil.replace(talkContent, "?PRODUCTTIPS?", productTips);
        //替换产品责任
        talkContent = StringUtil.replace(talkContent, "?RESPONSIBILITY?", responsibility);
        //替换风险提示语
        talkContent = StringUtil.replace(talkContent, "?RISKCUE?", riskCue);
        //替换深圳 医疗说明书
        talkContent = StringUtil.replace(talkContent, "?DETAILEDLIST?", detailedList);
        logger.info("替换后的话术内容为:{}", talkContent);
        return talkContent;
    }


    private Set<String> getRuntimeTalk(List<LSTalkRunTime> target) {

        if (target == null || target.isEmpty())
            return null;
        Set<String> riskTypSet = new HashSet<String>();
        List<LSTalkRunTime> removeTalkList = new ArrayList<LSTalkRunTime>();
        Map<String, LSTalkRunTime> tMap = new HashMap<String, LSTalkRunTime>();
        for (LSTalkRunTime t : target) {
            if (t == null)
                continue;
            riskTypSet.add(t.getRiskType());
            String tpc = t.getTalkPointCode();
            String tpid = t.getPkId();

            if (tpc == null || tpc.isEmpty() || tpid == null || tpid.isEmpty())
                continue;
            if (tMap.containsKey(tpc)) {
                if (tMap.get(tpc) != null &&
                        tMap.get(tpc).getTalkPointCode() != null &&
                        tMap.get(tpc).getTalkPointCode().compareTo(tpid) <= 0)
                    removeTalkList.add(t);
                else {
                    removeTalkList.add(tMap.get(tpc));
                    tMap.put(tpc, t);
                }
            } else
                tMap.put(tpc, t);
        }

        if (!target.isEmpty() && !removeTalkList.isEmpty())
            target.removeAll(removeTalkList);
        target.sort(new Comparator<LSTalkRunTime>() {
            @Override
            public int compare(LSTalkRunTime o1, LSTalkRunTime o2) {
                return o1.getOrderNum() - o2.getOrderNum();
            }
        });
        return riskTypSet;
    }

    /**
     * 合并话术
     **/
    private List<LSTalkNew> removeTalk(List<LSTalkNew> target) {
        List<LSTalkNew> removeTalkList = new ArrayList<LSTalkNew>();
        Map<String, LSTalkNew> tMap = new HashMap<String, LSTalkNew>();
        //首先合并需要合并的话术
        for (LSTalkNew t : target) {
            if (t.getIsMerge().equals("N")) {
                if (tMap.containsKey(t.getTalkPointCode())) {
                    LSTalkNew talk = tMap.get(t.getTalkPointCode());
                    talk.setTalkContent(talk.getTalkContent() + t.getTalkContent());
                    tMap.put(t.getTalkPointCode(), talk);

                } else {
                    tMap.put(t.getTalkPointCode(), t);

                }
                removeTalkList.add(t);
            }
        }
        target.removeAll(removeTalkList);
        removeTalkList.clear();
        target.addAll(tMap.values());

        return target;
    }


    private void getTalks(List<LSTalkNew> target) {

        target = removeTalk(target);

        if (target == null || target.isEmpty())
            return;
        List<LSTalkNew> removeTalkList = new ArrayList<LSTalkNew>();
        Map<String, LSTalkNew> tMap = new HashMap<String, LSTalkNew>();
        for (LSTalkNew t : target) {
            if (t == null)
                continue;
            String tpc = t.getTalkPointCode();
            String tpid = t.getPkid();
            if (tpc == null || tpc.isEmpty() || tpid == null || tpid.isEmpty())
                continue;
            if (tMap.containsKey(tpc)) {
                if (tMap.get(tpc) != null &&
                        tMap.get(tpc).getTalkPointCode() != null &&
                        tMap.get(tpc).getTalkPointCode().compareTo(tpid) <= 0)
                    removeTalkList.add(t);
                else {
                    removeTalkList.add(tMap.get(tpc));
                    tMap.put(tpc, t);
                }
            } else
                tMap.put(tpc, t);
        }

        //删除重复话术
        if (!target.isEmpty() && !removeTalkList.isEmpty())
            target.removeAll(removeTalkList);
        //根据话术id排序
        target.sort(new Comparator<LSTalkNew>() {
            @Override
            public int compare(LSTalkNew o1, LSTalkNew o2) {
                return o1.getOrderNum() - o2.getOrderNum();
            }
        });

    }


    private ServiceResult<String, String[]> getArrayStringSortMsg(String str) {
        ServiceResult.Builder<String, String[]> rb = ServiceResult.build(String.class, String[].class);
        if (str == null || str.isEmpty())
            return rb.createFailResult(new String[]{"投保单号不能为空"});
        if (!str.contains(",") || str.replaceAll(",", "").trim().isEmpty())
            return rb.createSuccessResult(str);
        if (str.endsWith(","))
            str = str.substring(0, str.length() - 1);
        String[] arrStr = str.split(",");
        int arrLength = arrStr.length;
        int eNum = new HashSet<String>(Arrays.asList(arrStr)).size();

        if (arrLength != eNum)
            return rb.createFailResult(new String[]{"投保单号不能重复"});
        Arrays.sort(arrStr);
        StringBuilder res = new StringBuilder("");
        for (String s : arrStr) {
            if (s != null && !s.isEmpty()) {
                if (res.length() < 1)
                    res.append(s);
                else {
                    res.append(",");
                    res.append(s);
                }
            }
        }
        return rb.createSuccessResult(res.toString());
    }

    @Override
    public void saveUser(LSUser lsUser) {
        userDao.save(lsUser);
    }


    @Override
    public List<LSCont.LSContPK> queryPKByLastOneAndInteractive(char lastOne, String interactive) {
        return contDao.queryPKByLastOneAndInteractive(lastOne, interactive);
    }

    //已上传列表获取
    @Override
    public RequestResult getPageUpload(int pageNo, String sortTime, String busiNum) {
        String operator = CurrentUser.getUser().getUserId();

        List<LSCont> conts = new ArrayList<>();
        Page<LSCont> pages = null;

        if(busiNum == null || busiNum.isEmpty()){
            char[] lastOne = new char[]{'Y', 'C'};
            pages = contDao.findByOperatorAndLastOneInAndSortTimeLessThanEqualOrderByMakeDateDescMakeTimeDesc(operator, lastOne, sortTime, pageNo);
            conts = pages.getContent();
        }else{
            List lastOne = new ArrayList();
            lastOne.add('Y');
            lastOne.add('C');
            conts = contDao.findByOperatorAndLastOneInAndSortTimeLessThanEqualAndBusiNum(operator, lastOne, sortTime, busiNum);
        }


        RequestResult requestResult = new RequestResult(true);

        //添加当前用户上传总条数
        Hashtable<String, Integer> data = new Hashtable<>(1);
        int count = contDao.countByOperatorAndLastOne(operator, 'Y');
        data.put("count", count);
        requestResult.setData(data);

        if (conts == null || conts.size() == 0) {
            //requestResult.setMessage("我是有底线的");
            return requestResult;
        }
        List<String> contNos = new ArrayList<String>();
        for (LSCont lscont : conts
        ) {
            contNos.add(lscont.getClientContNo());
        }

        StateForm stateform = new StateForm();
        stateform.setContNos(contNos);
        RequestResult result = showState(stateform);
        requestResult.setResult(result.getResult());
        return requestResult;
    }


    //被驳回列表获取
    @Override
    public RequestResult getPageReject(int pageNo, String sortTime, String busiNum) {
        String operator = CurrentUser.getUser().getUserId();

        Page<LSCont> pages = null;
        List<LSCont> conts = new ArrayList<>();
        if(busiNum == null || busiNum.isEmpty()){
            char[] lastOne = new char[]{'Y', 'C'};
            pages = contDao.findByOperatorAndLastOneInAndSortTimeLessThanEqualOrderByMakeDateDescMakeTimeDesc(operator, lastOne, sortTime, pageNo);
            conts = pages.getContent();
        }else{
            List lastOne = new ArrayList();
            lastOne.add('Y');
            lastOne.add('C');
            conts = contDao.findByOperatorAndLastOneInAndSortTimeLessThanEqualAndBusiNum(operator, lastOne, sortTime, busiNum);
        }

        RequestResult requestResult = new RequestResult(true);

        //添加当前用户上传总条数
        Hashtable<String, Integer> data = new Hashtable<>(1);
        int count = contDao.countByOperatorAndLastOne(operator, 'Y');
        data.put("count", count);
        requestResult.setData(data);

        if (conts == null || conts.size() == 0) {
            //requestResult.setMessage("我是有底线的");
            return requestResult;
        }
        List<String> contNos = new ArrayList<String>();
        for (LSCont lscont : conts
        ) {
            contNos.add(lscont.getClientContNo());
        }
        StateForm stateform = new StateForm();
        stateform.setContNos(contNos);
        RequestResult result = showStateReject(stateform);
        requestResult.setResult(result.getResult());
        return requestResult;
    }




//    /**
//     * User: FL
//     * Date: 2018/8/27
//     * Time: 16:25
//     * 获取险种列表
//     */
//    public ServiceResult<RiskForm[], String> showProductTypeCode(QueryTypeForm queryTypeForm) {
//        ServiceResult.Builder<RiskForm[], String> resBuilder = ServiceResult.build(RiskForm[].class, String.class);
//
//        if (!isExistInsurComCode(queryTypeForm)) {
//            // 提示，如果insurComCode有问题，那么就提示输入的有问题：请输入正确的保险公司
//            logger.warn("Please enter the correct insurance company. {}", queryTypeForm);// 是不是要用英文提示
//            return resBuilder.createFailResult("请输入正确的保险公司");
//        }
//        List<LSProductNew> risktypeList = null;
//        //判断是否有 查询条件
//        String findMessage = queryTypeForm.getFindMessage();
//        if (StringUtils.isEmpty(findMessage)) {
//            risktypeList = productDaoNew.findAll();
//        } else {
//            findMessage = "%" + findMessage + "%";
//            risktypeList = productDaoNew.findByProductCodeLikeOrProductNameLike(findMessage);
//        }
//        if (risktypeList == null || risktypeList.isEmpty()) {
//            // 没有查到数据。应该是数据错误。
//            logger.warn("LSProductNew Data failed. {}", queryTypeForm);// 是不是要用英文提示
//            return resBuilder.createFailResult("未找到有该关键字的产品，请确认后查询");
//        }
//
//        // 查询到数据，转换数据格式
//        RiskForm[] riskForms = new RiskForm[risktypeList.size()];
//        for (int i = 0; i < risktypeList.size(); i++) {
//            LSProductNew type = risktypeList.get(i);           //产品
//            RiskForm riskForm = new RiskForm();
//
//            riskForm.setProductTypeCode(type.getProductTypeCode());
//            riskForm.setProductTypeName(type.getProductTypeName());
//            riskForm.setProductCode(type.getProductCode());
//            riskForm.setProductName(type.getProductName());
//            riskForm.setIsDeath(type.getIsDeath());
//            riskForm.setIsHealth(type.getIsHealth());
//            riskForms[i] = riskForm;
//        }
//
//        return resBuilder.createSuccessResult(riskForms);
//
//    }

    /**
     * Created by Feng on   2018/9/18  14:27
     * * 根据 产品编码 获取 保险类型和 业务类型
     **/
    @Override
    public RequestResult showProductTypeCode(Map reqMap) {
        logger.info("查询产品类型{}", reqMap);
        RequestResult requestResult = new RequestResult(false);
        //查询产品表所有字段为productType的

        if (!reqMap.containsKey("riskType")) {
            requestResult.setMessage("参数不能为空");
            return requestResult;
        }

        String riskType = (String) reqMap.get("riskType");

        //查找到  保险类型 集合
        List<String> codes = leTagLinksDao.findByCode();

        List<Map> listmap = new ArrayList<>();
        //遍历查询到的产品类型结合
        for (String productTypeCodeNew: codes) {
            String productTypeCode = null;
            String productTypeName = null;
            if(productTypeCodeNew!=null&&!("".equals(productTypeCodeNew))){
                if(productTypeCodeNew.equals(RiskTypeEnum.RISK_TYPE_N.getValue())){
                    productTypeName = "普通型";
                    productTypeCode = "01";
                }else if(productTypeCodeNew.equals(RiskTypeEnum.RISK_TYPE_B.getValue())){
                    productTypeName = "分红型";
                    productTypeCode = "03";
                }else{
                    productTypeName = "万能型";
                    productTypeCode = "02";
                }
            }

            Map map1 = new HashMap();//存放产品类型
            map1.put("productTypeCode", productTypeCode);
            map1.put("productTypeName", productTypeName);

            String comCode = CurrentUser.getUser().getOrgCode();
            String channel = CurrentUser.getUser().getChannel();
            //查找对应产品
            List<TagLinks> productlist= leTagLinksDao.findByProductType(productTypeCodeNew);

            Map<String, String> map = new HashMap();//存放产品集合
            if (productlist == null || productlist.size() == 0) {
                requestResult.setMessage("没有找到数据！");
            } else {
                logger.info("查询产品{}", productlist);
                List<LMProduct>  lsProductTypeList=new ArrayList<>();
                //否则遍历
                for (TagLinks tag : productlist) {

                    String productid = tag.getLeTagLinksPk().getRefId();
                    LMProduct lmProduct = lmProductDao.findByProductId(productid);
                    lsProductTypeList.add(lmProduct);
                    map.put("productCode", lmProduct.getProductCode());
                    map.put("productName", lmProduct.getProductName());

                    List<TagLinks> _tags = leTagLinksDao.findByObj("Prod", lmProduct.getProductId());
                    List<String> _tagsArray = _tags.stream().map(t -> t.getLeTagLinksPk().getTagCode() ).collect(Collectors.toList());
                    if (_tagsArray.contains(RiskTypeEnum.RISK_TYPE_D.getValue())) {
                        map1.put("productTypeCode", "isDeath");
                        map1.put("productTypeName", "是否死亡给付");
                    }

                    if (_tagsArray.contains(RiskTypeEnum.RISK_TYPE_H.getValue())) {
                        map1.put("productTypeCode", "isHealth");
                        map1.put("productTypeName", "健康型产品");
                    }

                }
                map1.put("lsProductList", lsProductTypeList);//写在lsProductTypeList中不管有无发布产品，值要code表存在，就会显示
                listmap.add(map1);
            }
            logger.info("执行结束，正在返回 {}", requestResult);
            requestResult.setSuccess(true);
            requestResult.setData((Serializable) listmap);
        }
        return requestResult;
    }


    /**
     * 根据产品信息获取 提示语
     **/
    @Override
    public Map getHint(Map reqMap) {
        Map<String, Object> resMap = new HashMap<>();
        //解析参数
        String[] productList = ((String) reqMap.get("products")).split(",");
        if (productList == null) {
            resMap.put("success", false);
            resMap.put("message", "参数不能为空");
            return resMap;
        }
        String comcode = String.valueOf(reqMap.get("orgCode"));
        if(StringUtils.isEmpty(comcode)){
            comcode = CurrentUser.getUser().getOrgCode();
        }
        String channel = String.valueOf(reqMap.get("channel"));
        if (StringUtils.isEmpty(channel)){
            channel = CurrentUser.getUser().getChannel();
        }
        //组织返回数据
        List<String> resList = new ArrayList<>();
        resList.add("销售人员身份证件");
        for (String product : productList) {
            LMProduct lmProduct = productManagerService.getProduct(product, comcode, channel);
            if (lmProduct != null) {
                List<TagLinks> tags = leTagLinksDao.findByObj("Prod", lmProduct.getProductId());
                List<String> tagsArray = tags.stream().map(t -> t.getLeTagLinksPk().getTagCode()).collect(Collectors.toList());
                if(
                        tagsArray.contains(RiskTypeEnum.RISK_TYPE_U.getValue()) // 万能型
                                || tagsArray.contains(RiskTypeEnum.RISK_TYPE_B.getValue()) // 分红型
                                || tagsArray.contains("RiskType:I") // 投连
                ){
                    resList.add("产品说明书（限新型产品）");
                    break;
                }

            }
        }
        for (String product : productList) {
            LMProduct lmProduct = productManagerService.getProduct(product, comcode, channel);
            if (lmProduct != null) {
                List<TagLinks> tags = leTagLinksDao.findByObj("Prod", lmProduct.getProductId());
                List<String> tagsArray = tags.stream().map(t -> t.getLeTagLinksPk().getTagCode()).collect(Collectors.toList());
                if(
                        tagsArray.contains(RiskTypeEnum.RISK_TYPE_H.getValue()) // 健康型产品
                ){
                    resList.add("投/被保人身份证件");
                    break;
                }
            }
        }
        resList.add("《人身保险投保提示书》");
        resList.add("《免除保险人责任说明书》");
        resList.add("产品条款");
        resList.add("电子投保确认单/人身保险投保单（纸质投保）");

        List<LDCode> codes = codeDao.findAllByCodeTypeAndCodeRiskType("file_message", comcode);
        if (codes == null || codes.isEmpty()) {
//            resList.add("各分公司地方性监管所需资料（如有）。");
        } else {
            for (LDCode code : codes) {
                resList.add(code.getCodeNameEn());
            }
        }


        resMap.put("success", true);
        resMap.put("hintInfo", resList);
        return resMap;
    }

    @Override
    public Map getFileInfo() {

        Map<String, Object> resMap = new HashMap();

        List<LDCode> codes = codeDao.findByCodeType("zip_file");
        List<Map> resList = new ArrayList<>();
        if (codes != null && !codes.isEmpty()) {
            for (LDCode code : codes) {
                Map map = new HashMap();
                map.put("fileName", code.getCode());
                map.put("filePath", code.getCodeName());
                resList.add(map);
            }
        } else {
            resMap.put("success", false);
            resMap.put("message", "无结果");
            return resMap;
        }
        resMap.put("success", true);
        resMap.put("result", resList);

        return resMap;
    }

    //修改投保单号，存库，并刷新 话术内容 表
    @Override
    public Map changeBusi(Map map) {
        logger.info("changebusi req map {}", map);
        String newBusi = (String) map.get("newBusi");
        newBusi = StringSortUtil.getArrayStringSort(newBusi);
        String oldBusi = (String) map.get("oldBusi");
        oldBusi = StringSortUtil.getArrayStringSort(oldBusi);
        //初始化返回值
        Map<String, Object> resMap = new HashMap();
        //修改保单号
        List<LSTalkContent> talkContents = talkContentDao.findByBusiNum(oldBusi);
        if (talkContents != null && !talkContents.isEmpty()) {
            for (LSTalkContent talkcontent : talkContents
            ) {
                talkcontent.setBusiNum(newBusi);
                talkContentDao.saveTalkContent(talkcontent);
            }
        } else {
            resMap.put("success", false);
            resMap.put("message", "保单号没有找到对应记录");
            return resMap;
        }
        resMap.put("success", true);
        resMap.put("message", "ok");

        return resMap;
    }
    //组织数据调用新抽检方法
    private boolean newSamplingRule(PolcyForm contForm) {
        NewTalkDTO newTalkDTO = new NewTalkDTO();
        String agentCode = CurrentUser.getUser().getAgentCode();
        String phoneNo = CurrentUser.getUser().getPhoneNo();
        String OrgCode =  CurrentUser.getUser().getOrgCode();
        String birthday = CurrentUser.getUser().getBrithday();
        String name = CurrentUser.getUser().getName();
        String sex = CurrentUser.getUser().getSex();
        String idNo = CurrentUser.getUser().getIdNo();
        String channel = CurrentUser.getUser().getChannel();
        //代理人信息
        newTalkDTO.setPhoneNo(phoneNo);
        newTalkDTO.setAgentCode(agentCode);
        if(!StringUtils.isEmpty(contForm.getOrgCode())){
            newTalkDTO.setAgentOrgCode(contForm.getOrgCode());
        }else{
            newTalkDTO.setAgentOrgCode(OrgCode);
        }
        newTalkDTO.setBrithday(birthday);
        newTalkDTO.setName(name);
        newTalkDTO.setSex(sex);
        newTalkDTO.setIdNo(idNo);
        newTalkDTO.setChannel(channel);
        //bank信息
        newTalkDTO.setBanknetWork(contForm.getBanknetWork());
        newTalkDTO.setBankCode(contForm.getBankCode());
        newTalkDTO.setBankName(contForm.getBankName());
        newTalkDTO.setOperator(contForm.getOperator());
        newTalkDTO.setOperation(contForm.getOperation());
        //主键信息
        newTalkDTO.setContNo(contForm.getContNo());
        newTalkDTO.setClientContNo(contForm.getClientContNo());
        //comCode,通过AllByQ接口获取到
        newTalkDTO.setInsurComCode(contForm.getComCode());
        //险种类型、产品类型
        newTalkDTO.setRiskType(contForm.getRiskType());
        //投保单号
        newTalkDTO.setBusiNum(contForm.getBusiNum());
        //投保人信息
        newTalkDTO.setAppnt(contForm.getAppnt());
        //被保人信息
        newTalkDTO.setInsured(contForm.getInsured());
        //创建日期
        newTalkDTO.setScanTime(contForm.getScanTime());
        newTalkDTO.setScanDate(contForm.getMakeDate());
        newTalkDTO.setProperson(contForm.getProperson());
        newTalkDTO.setResource(contForm.getResource());
        newTalkDTO.setSendScene(contForm.getSendScene());
        String self = judgeSelf(contForm.getAppnt(),name,sex,idNo);
        newTalkDTO.setIsSelf(self);
        //E店产品信息
        List<NewTalkRiskForm> message = new ArrayList<>();
        for (String rt : (StringSortUtil.getArrayStringSort(newTalkDTO.getRiskType()).split(","))) {
            List<LSReplacetalk> lsReplacetalks = replaceTalkDao.findByRiskCodeAndBusiNum(rt, newTalkDTO.getBusiNum());
            if (lsReplacetalks != null && !lsReplacetalks.isEmpty()) {
                for (LSReplacetalk lsReplacetalk : lsReplacetalks) {
                    NewTalkRiskForm risk = new NewTalkRiskForm();
                    risk.setRiskCode(lsReplacetalk.getRiskCode());
                    risk.setRiskName(lsReplacetalk.getRiskName());
                    risk.setWholesaleInsuYear(lsReplacetalk.getWholesaleInsuYear());
                    risk.setWholesaleInsuYearFlag(lsReplacetalk.getWholesaleInsuYearFlag());
                    risk.setWholesalePrem(lsReplacetalk.getWholesalePrem());
                    risk.setWholesaleHesitation(lsReplacetalk.getWholesaleHesitation());
                    risk.setIntersectionInsuYear(lsReplacetalk.getIntersectionInsuYear());
                    risk.setIntersectionInsuYearFlag(lsReplacetalk.getIntersectionInsuYearFlag());
                    risk.setIntersectionPrem(lsReplacetalk.getIntersectionPrem());
                    risk.setIntersectionPayInty(lsReplacetalk.getIntersectionPayInty());
                    risk.setIntersectionPayEndYearFlag(lsReplacetalk.getIntersectionPayEndYearFlag());
                    risk.setIntersectionPayEndYear(lsReplacetalk.getIntersectionPayEndYead());
                    message.add(risk);
                }
                newTalkDTO.setNewTalkRiskForm(message);
            }
        }
        //调用接口判断doSample
        return sampleService.doSample(newTalkDTO);

    }

    public String judgeIsSelf(AppntForm appnt, LSUser user){
       /* SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String userName = user.getName();
        String userSex = user.getSex();
        if ("1".equals(userSex)){
            userSex = "女";
        }
        if ("2".equals(userSex)){
            userSex = "男";
        }
        *//*if("1".equals(userSex)){
            userSex = "男";
        }else {
            userSex = "女";
        }*/
        String userIdNo= user.getIdNo();
       /* String appntName = appnt.getName();
        String appntSex = appnt.getSex();*/
        String appntIdNo = appnt.getIdNo();
        if(userIdNo.equals(appntIdNo)){
        /*if(userName.equals(appntName)&&userSex.equals(appntSex)&&userIdNo.equals(appntIdNo)){*/
            return "Y";
        }else{
            return "N";
        }
    }
    public String judgeSelf(AppntForm appnt,String name,String sex,String idNo){
       /* SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        if("1".equals(sex)){
            sex = "男";
        }else {
            sex = "女";
        }*/
        /*String appntName = appnt.getName();
        String appntSex = appnt.getSex();*/
        String appntIdNo = appnt.getIdNo();
        if (idNo.equals(appntIdNo)){
       /* if(name.equals(appntName) && sex.equals(appntSex) && idNo.equals(appntIdNo)){*/
            return "Y";
        }else{
            return "N";
        }
    }

    @Override
    public RequestResult generalBasicOce(BasicOCRForm basicOCRForm) {
        RequestResult requestResult = new RequestResult(false);
        String compareString = new String();
        String compareStringSecond = new String();
        String compareStringThird = new String();
        LDComConfig ldComConfig = comConfigDao.findByComCode("24001");
        if (!StringUtils.isEmpty(basicOCRForm.getStepText())){
            if (basicOCRForm.getStepText().contains("出示投保提示书")){
                compareString = "投保提示书";
            }else if (basicOCRForm.getStepText().contains("出示产品说明书")){
                compareString = "产品说明书";
            }else if (basicOCRForm.getStepText().contains("出示并阅读免除保险人责任条款")){
                compareString = "免除保险人责任条款";
            }else if (basicOCRForm.getStepText().contains("出示保险条款和投保单")){
                compareString = "保险条款";
                compareStringSecond = "投保单";
                compareStringThird = "寿险条款";
            }
        }
        logger.info("当前节点匹配的信息为"+basicOCRForm.getStepText());
        Credential cred = new Credential(ldComConfig.getCloudSecretId(), ldComConfig.getCloudSecretKey());
        HttpProfile httpProfile = new HttpProfile();
//        httpProfile.setEndpoint("ocr.tencentcloudapi.com");
        httpProfile.setEndpoint(basicUrl);
        ClientProfile clientProfile = new ClientProfile();
        clientProfile.setHttpProfile(httpProfile);
        Map map=new HashMap();
        if(!StringUtils.isEmpty(basicOCRForm.getImageUrl())){
            map.put("ImageUrl",basicOCRForm.getImageUrl());
        }
        if(!StringUtils.isEmpty(basicOCRForm.getImageBase64())){
            map.put("ImageBase64",basicOCRForm.getImageBase64());
        }
        map.put("LanguageType","zh");
        String params = JSONObject.toJSONString(map);
        OcrClient client = new OcrClient(cred, "ap-shanghai", clientProfile);

        GeneralBasicOCRRequest req = GeneralBasicOCRRequest.fromJsonString(params, GeneralBasicOCRRequest.class);

        GeneralBasicOCRResponse resp = null;
        try {
            resp = client.GeneralBasicOCR(req);
            logger.info("basicOCR resMap{}", resp);
            TextDetection[] textDetections = resp.getTextDetections();
            String[] results = new String[textDetections.length];
            String saveResult = textDetections[0].getDetectedText()+",";
            for (int i=0;i<textDetections.length;i++){
                results[i] = textDetections[i].getDetectedText();
            }
            for (int i=1;i<textDetections.length-1;i++){
                saveResult += textDetections[i].getDetectedText()+"||";
            }
            saveResult = saveResult+textDetections[textDetections.length-1].getDetectedText();
            LsBasicOcr lsBasicOcr = new LsBasicOcr();
            lsBasicOcr.setId(UUID.randomUUID().toString());
            lsBasicOcr.setBusinum(basicOCRForm.getBusiNum());
            lsBasicOcr.setSteptext(basicOCRForm.getStepText());
            lsBasicOcr.setIdentifyresult(saveResult);
            lsBasicOcr.setIdentifytime(new java.util.Date());
            lsBasicOcrMapper.saveLsBasicOcr(lsBasicOcr);
            if (!StringUtils.isEmpty(textDetections) && textDetections.length!=0){
                for (int i=0;i<textDetections.length;i++){
                    if (basicOCRForm.getStepText().contains("出示保险条款和投保单")){
                        if ((textDetections[i].getDetectedText().contains(compareString) || textDetections[i].getDetectedText().contains(compareStringSecond))
                                || textDetections[i].getDetectedText().contains(compareStringThird)){
                            logger.info(textDetections[i].getDetectedText());
                            requestResult.setSuccess(true);
                            requestResult.setData(results);
                            requestResult.setMessage("识别成功");
                            break;
                        }else{
                            requestResult.setSuccess(false);
                            requestResult.setData(results);
                            requestResult.setMessage("识别失败");
                        }
                    }else{
                        if (textDetections[i].getDetectedText().contains(compareString)){
                            logger.info(textDetections[i].getDetectedText());
                            requestResult.setData(1);
                            requestResult.setSuccess(true);
                            requestResult.setMessage("识别成功");
                            break;
                        }else{
                            requestResult.setData(0);
                            requestResult.setSuccess(false);
                            requestResult.setMessage("识别失败");
                        }
                    }

                }
            }else{
                requestResult.setData(0);
                requestResult.setSuccess(false);
                requestResult.setMessage("识别失败");
            }
        } catch (TencentCloudSDKException e) {
            e.printStackTrace();
        }
        return requestResult;
    }
}
