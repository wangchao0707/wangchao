package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * Created by WinterLee on 2017/7/14.
 */
@Entity
@Table(name = "LSAuthentication")
public class LSAuthentication implements Serializable {

    @Id
    @Column(name = "UserId")
    private String userId;

    @Column(name = "Password")
    private String password;

    @Column(name = "CipherText")
    private String cipherText;

    @Column(name = "ISDEFAULTPWD")
    private String IsDefaultPWD;


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getCipherText() {
        return cipherText;
    }

    public void setCipherText(String cipherText) {
        this.cipherText = cipherText;
    }

    public String getIsDefaultPWD() {
        return IsDefaultPWD;
    }

    public void setIsDefaultPWD(String isDefaultPWD) {
        IsDefaultPWD = isDefaultPWD;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("LSAuthentication{");
        sb.append("userId='").append(userId).append('\'');
        sb.append(", password='").append(password).append('\'');
        sb.append(", cipherText='").append(cipherText).append('\'');
        sb.append(", IsDefaultPWD='").append(IsDefaultPWD).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
