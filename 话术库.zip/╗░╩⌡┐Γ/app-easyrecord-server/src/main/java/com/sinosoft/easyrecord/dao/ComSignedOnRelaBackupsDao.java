package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSComSignedOnRelaBackups;

public interface ComSignedOnRelaBackupsDao {


    void save(LSComSignedOnRelaBackups lsComSignedOnRelaBackups);
}
