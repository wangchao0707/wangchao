package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSStateLoca;

import java.util.List;

public interface LSStateLocaDao {

    /**
     * 保存保单状态变更轨迹记录
     * @param
     */
    void saveStateLoca(LSCont lsCont, String stateName);

    /**
     * 查询保单状态为Y的记录
     * @return
     */
    List<LSStateLoca> findByIsSend(String isSend);

    /**
     * 修改保单状态
     * @param lsStateLoca
     */
    void  editStateLoca(LSStateLoca lsStateLoca);
}
