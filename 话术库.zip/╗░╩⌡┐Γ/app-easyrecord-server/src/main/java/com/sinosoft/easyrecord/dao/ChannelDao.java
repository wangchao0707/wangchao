package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSChannel;

import java.util.List;

public interface ChannelDao {

    void saveChannel(LSChannel lsChannel);

    LSChannel findChannel(String channelCode);

    List<LSChannel> findAll();

    void delChannel(LSChannel lsChannel);

    LSChannel findByChannelName(String channer);
}
