package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.SelectItem;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/19.
 */
public interface ComManager {

    SelectItem[] getComList();

    SelectItem[] getChannelList();

    ServiceResult<SelectItem[], String> getOrgList(String comCode);

    ServiceResult<SelectItem[], String> getOrgListByNew(String comCode);

    ServiceResult<SelectItem[], String> getCurrentComList();

}
