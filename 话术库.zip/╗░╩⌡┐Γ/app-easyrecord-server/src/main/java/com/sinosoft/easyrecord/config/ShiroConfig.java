package com.sinosoft.easyrecord.config;

import com.sinosoft.easyrecord.sso.UserPwdAuthorizingRealm;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by WinterLee on 2017/7/14.
 */
@Configuration
public class ShiroConfig {

    final static private Logger logger = LoggerFactory.getLogger(ShiroConfig.class);

    public ShiroConfig() {
        logger.info("load ShiroConfig");
    }

    @Bean(name = "securityManager")
    public DefaultWebSecurityManager getDefaultWebSecurityManager(
            @Qualifier(value = "UserPwdAuthorizingRealm") UserPwdAuthorizingRealm userPwdAuthorizingRealm) {
        DefaultWebSecurityManager dwsm = new DefaultWebSecurityManager();
        // dwsm.setRealm();

        dwsm.setRealm(userPwdAuthorizingRealm);
//      <!-- 用户授权/认证信息Cache, 采用EhCache 缓存 -->
//         dwsm.setCacheManager(getEhCacheManager());
        return dwsm;
    }


    @Bean(name = "shiroFilter")
    public ShiroFilterFactoryBean getShiroFilterFactoryBean(DefaultWebSecurityManager securityManager) {

        ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
        // 必须设置 SecurityManager
        shiroFilterFactoryBean.setSecurityManager(securityManager);

        return shiroFilterFactoryBean;
    }


}
