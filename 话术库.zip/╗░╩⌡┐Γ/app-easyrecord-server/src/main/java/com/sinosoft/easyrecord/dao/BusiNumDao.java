package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSBusiNum;

import java.util.List;

public interface BusiNumDao {

    List<LSBusiNum> findOneInListBusiNum(String[] busiNumArrs);

    void saveBusiNum(LSBusiNum lsBusiNum);
}
