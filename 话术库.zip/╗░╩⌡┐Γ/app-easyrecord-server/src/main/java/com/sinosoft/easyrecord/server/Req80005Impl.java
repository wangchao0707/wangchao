package com.sinosoft.easyrecord.server;

import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sinosoft.easyrecord.dao.CodeDao;
import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.dao.MessageBukDao;
import com.sinosoft.easyrecord.dao.MessageDao;
import com.sinosoft.easyrecord.entity.LDCode;
import com.sinosoft.easyrecord.entity.LDCode.LDCodePk;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSMessage;
import com.sinosoft.easyrecord.entity.LSMessageBuk;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransBodyReq80005;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transbody;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyRes;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transdata;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transhead;
import com.thoughtworks.xstream.XStream;

@Service
public class Req80005Impl implements Req80005 {

    private Logger logger = LoggerFactory.getLogger(Req80005Impl.class);

    private MessageDao messageDao;

    @Autowired
    public void setMessageDao(MessageDao messageDao) {
        this.messageDao = messageDao;
    }

    private CodeDao codeDao;

    @Autowired
    public void setCodeDao(CodeDao codeDao) {
        this.codeDao = codeDao;
    }

    private ContDao contDao;

    @Autowired
    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }

    private MessageBukDao messageBukDao;

    @Autowired
    public void setMessageBukDao(MessageBukDao messageBukDao) {
        this.messageBukDao = messageBukDao;
    }

    @Value("${save.filePath}")
    private String filePath;

    @Override
    public String req80005(String xml) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransBodyReq80005.class);
        xs1.alias("QCFEEDBACKS", TransBodyReq80005.QCFEEDBACKS.class);
        xs1.alias("QCFEEDBACK", TransBodyReq80005.QCFEEDBACK.class);
        xs1.addImplicitCollection(TransBodyReq80005.QCFEEDBACKS.class, "QCFEEDBACK");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        TransBodyReq80005 body = (TransBodyReq80005) tmp.getTransbody();
        Transhead head = tmp.getTranshead();
        TransBodyReq80005.QCFEEDBACKS QCFEEDBACKS = body.getQCFEEDBACKS();

        //获取业务流水号
        String contNo = QCFEEDBACKS.BUSINESSNO;
//		String comCode = head.getCOMPANY();
        List<TransBodyReq80005.QCFEEDBACK> list = QCFEEDBACKS.QCFEEDBACK;

        //删除mp3文件
        // 删除文件
        String path = filePath + "/" + contNo;
        File dir = new File(path);
        if (dir.exists()) {
            File[] fileList = dir.listFiles();
            for (File file : fileList) {
                String ext = FilenameUtils.getExtension(file.getName());
                if (ext.equals("mp3")) {
                    Boolean boolean1 = file.delete();
                    logger.info("core success file delete result {}", boolean1);
                }

            }
        }

        // 备份 删除
        //根据业务流水号查询 保单 clientcontNo
        LSCont lsCont = contDao.findByContNo(contNo);
        if (lsCont.getOrginContNo() != null) {
            LSCont lastCont = contDao.findByContNo(lsCont.getOrginContNo());
            if (lastCont != null) {
                List<LSMessage> lsMessages = messageDao.findByContNo(lastCont.getClientContNo());

                if (lsMessages != null && lsMessages.size() != 0) {
                    logger.info("messagebak start");
                    for (LSMessage lsMessage : lsMessages) {
                        LSMessageBuk lsMessageBuk = new LSMessageBuk(UUID.randomUUID().toString(), lsMessage,
                                new Date(System.currentTimeMillis()), sdf.format(new java.util.Date()));
                        messageBukDao.save(lsMessageBuk);
                        messageDao.del(lsMessage);
                    }
                }
            }
        }
        //获取质检结果
        //根据字典表 查询类型
        String ISFLAG = QCFEEDBACKS.ISFLAG;
        LDCode ldCode = codeDao.findByCode(new LDCodePk("message_type", ISFLAG));
        String riskType = ldCode.getCodeRiskType();

        for (TransBodyReq80005.QCFEEDBACK back : list) {

            LSMessage lsMessage2 = new LSMessage();
            lsMessage2.setMessageNo(UUID.randomUUID().toString());
            lsMessage2.setUserNo(back.AGENTID);
            lsMessage2.setTitle(back.ISSUETYPES);

            lsMessage2.setType(riskType);
            //修改 保单 状态
            if (lsCont != null) {
                lsMessage2.setContNo(lsCont.getClientContNo());
                lsCont.setInteractive(ldCode.getCodeRiskType());
                contDao.save(lsCont);
            } else {
                lsMessage2.setContNo("");
            }

            lsMessage2.setMessage(back.ISSUEDESC);

            lsMessage2.setBusiNum(back.DOCCODE);
            lsMessage2.setOcopertor(back.QCOPERATOR);
            lsMessage2.setMakeDate(new Date(System.currentTimeMillis()));
            lsMessage2.setMakeTime(sdf.format(new java.util.Date()));
            lsMessage2.setIssueDate(back.ISSUEDATE);
            lsMessage2.setSource("core");
            lsMessage2.setState('N');
            messageDao.save(lsMessage2);
        }

        // 返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

}
