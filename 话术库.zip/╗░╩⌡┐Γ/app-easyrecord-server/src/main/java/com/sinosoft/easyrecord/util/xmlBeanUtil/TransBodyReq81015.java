package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by wds on 2018-3-17.
 */
public class TransBodyReq81015 implements Transbody, Serializable {

    private BANKS BANKS;


    public BANKS getBANKS() {
        return BANKS;
    }

    public void setBANKS(BANKS BANKS) {
        BANKS = BANKS;
    }


    public static class BANKS {
        public String BANKCOUNT;//
        public List<BANK> BANK = new ArrayList<BANK>();
    }

    public static class BANK {
        public String BANKCODE;//<!-- 银行编码-->
        public String BANKNAME;//<!-- 银行名称 -->
    }
}
