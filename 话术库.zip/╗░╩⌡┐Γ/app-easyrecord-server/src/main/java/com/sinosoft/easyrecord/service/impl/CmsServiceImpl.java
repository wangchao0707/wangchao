//package com.sinosoft.easyrecord.service.impl;
//
//import com.google.gson.Gson;
//import com.sinosoft.easyrecord.controller.UploadController;
//import com.sinosoft.easyrecord.dao.ContStateDao;
//import com.sinosoft.easyrecord.dao.ContTimeDao;
//import com.sinosoft.easyrecord.dao.PictureDao;
//import com.sinosoft.easyrecord.entity.*;
//import com.sinosoft.easyrecord.service.CmsService;
//import com.sinosoft.easyrecord.sso.CurrentUser;
//import com.sinosoft.easyrecord.util.Md5Util;
//import com.yuancore.cms.client.CmsClient;
//import com.yuancore.cms.client.ObjectMetadata;
//import com.yuancore.cms.client.exception.CMSException;
//import org.apache.commons.lang3.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.text.SimpleDateFormat;
//import java.util.*;
//
///**
// * @author SunYu
// * @date 2019/3/13 16:27
// */
//@Service
//public class CmsServiceImpl implements CmsService {
//
//    private static final Logger logger = LoggerFactory.getLogger(CmsServiceImpl.class);
//
//    @Autowired
//    private ContStateDao contStateDao;
//
//    @Autowired
//    private ContTimeDao contTimeDao;
//
//    @Autowired
//    private PictureDao pictureDao;
//
//
//    @Value("${cms.serviceURL}")
//    private String serviceURL;
//    @Value("${cms.acckey}")
//    private String accKey;
//    @Value("${cms.secretkey}")
//    private String secretKey;
//    @Value("${cms.bucketName}")
//    private String bucketName;  //源文件桶
//    @Value("${cms.resBucket}")
//    private String resBucket;  //抽帧+分片桶
//
//    @Value("${cms.notifyUrl}")
//    private String notifyUrl;
//
//    private CmsClient getCmsClient() {
//        CmsClient cmsClient = new CmsClient(serviceURL, accKey, secretKey);
//        return cmsClient;
//    }
//
//    public enum VideoTransCodingStatusEnum {
//        TRANS_CODING, NO_TRANS_CODING
//    }
//
//    //获取token
//    public String getToken() {
//        CmsClient client = getCmsClient();
//        String token = "error";
//        try {
//            token = client.genToken();
//        } catch (CMSException e) {
//            logger.info("获取token失败: {}", e);
//        }
//        return token;
//    }
//
//    //获取图片外链地址
//    public String getPicture(String objectId, String type,int time) {
//        CmsClient cmsClient = getCmsClient();
//        Calendar calendar = Calendar.getInstance();
//        calendar.add(Calendar.MONTH, time);
//        String cmslink = "";
//        try {
//            if ("0".equals(type)) {
//                //获取上传的图片
//                if(!StringUtils.isEmpty(objectId)) {
//                    cmslink = cmsClient.generateImageUrl(bucketName, objectId, null, String.valueOf(calendar.getTimeInMillis()));
//                }
//            } else if ("1".equals(type)) {
//                //获取抽帧的图片
//                if(!StringUtils.isEmpty(objectId)) {
//                    cmslink = cmsClient.generateImageUrl(resBucket, objectId, null, String.valueOf(calendar.getTimeInMillis()));
//                }
//            }
//        } catch (Exception e) {
//            logger.info("getPicture exception :{}, objectId : {}", e, objectId);
//            throw new RuntimeException(e.getMessage());
//        }
//        return cmslink;
//    }
//
//    public String updateIndex(String objectId, Map<String, Object> meta) {
//        CmsClient cmsClient = getCmsClient();
//        String result = "";
//        try {
//            if(logger.isInfoEnabled()){
//                logger.info("cmsClient.updateMetaInfo(bucketName: {}, objectId: {}, meta: {})",
//                        bucketName, objectId, new Gson().toJson( meta));
//            }
//            result = cmsClient.updateMetaInfo(bucketName, objectId, meta);
//            logger.info("cms返回的内容是：{}",result);
//        } catch (CMSException e) {
//            logger.info("update index filed objectId : {}, exception : {}", objectId, e);
//            throw new RuntimeException(e.getMessage());
//        }
//        return result;
//    }
//
//    //获取m3u8地址
//    public String getM3u8(String objectId) {
//        CmsClient cmsClient = getCmsClient();
//        Calendar calendar = Calendar.getInstance();
//        calendar.add(Calendar.MONTH, 3);
//        String m3u8 = "";
//        try {
//            m3u8 = cmsClient.generateM3u8Url(resBucket, objectId, "600x480", calendar.getTimeInMillis());
//        } catch (IOException e) {
//            logger.info("getM3u8 exception : {}, objectId : {}", e, objectId);
//            throw new RuntimeException(e.getMessage());
//        }
//        return m3u8;
//    }
//
//
//    @Override
//    public Map testUploadVideo(String path) {
//        System.out.println("\n=== 断点续传文件上传 ===\n");
//        FileInputStream fileInputStream = null;
//        try {
//            Map<String, Object> map = new HashMap<>();
//            //转码+切割参数
//            map.put("isbs_res_bucket", "b-isbs-shard");
//            map.put("isbs_hls_time", "5");
//            List<String> cms_hls_resolution = new ArrayList<>();
//            cms_hls_resolution.add("ORIGIN");
//            map.put("isbs_hls_resolution", cms_hls_resolution);
//            //抽帧参数
//            List<String> cms_extract_time = new ArrayList<>();
//            cms_extract_time.add("00:00:01");
//            cms_extract_time.add("00:00:11");
//            cms_extract_time.add("00:00:21");
//            map.put("isbs_extract_time", cms_extract_time);
//            map.put("isbs_extract_size", "600x480");
//            map.put("isbs_transcoding_status", VideoTransCodingStatusEnum.TRANS_CODING);
//            map.put("clerk_no", UUID.randomUUID().toString());
//            map.put("phone_no", "15648484848");
//            map.put("branch_no", "dfsdsdf");
//            map.put("isbs_version", "dsfsdfsd");
//            map.put("file_business_type", "ID");
//            map.put("sys_source", "0");
//            map.put("operate_timestamp", System.currentTimeMillis());
//            logger.info("map {}", map);
//            ObjectMetadata md = new ObjectMetadata();
//            File file = new File(path);
//            fileInputStream = new FileInputStream(file);
//            System.out.println(file.exists());
//            md.setContentLength(file.length());
//            md.setUserMetadata(map);
//            CmsClient client = new CmsClient(serviceURL, accKey, secretKey);
//            client.initRBU();
//            Map<String, String> result = client.putObjectViaRBU(bucketName, null, fileInputStream, md, 5 * 1024 * 1024L, true);
//            //fileInputStream.close();
//            System.out.println("断点续传上传成功");
//            logger.info("cms result {}", result);
//            return result;
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                fileInputStream.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return null;
//    }
//
//    @Override
//    public Map getIndex(String objectId) throws CMSException {
//        CmsClient cmsClient = new CmsClient(serviceURL, accKey, secretKey);
//        Map map = cmsClient.getMetaInfo(bucketName, objectId);
//        return map;
//    }
//
//    /**
//     * 上传头像信息
//     **/
//    @Override
//    public Map uploadPicture(String filePath, String userId) {
//        logger.info("headimg req filepath {} userid {}",filePath,userId);
//        Map resMap = new HashMap();
//        Boolean success = true;
//        File imgFile = new File(filePath);
//        String md5 = Md5Util.getMD5(imgFile);
//        Map<String, Object> map = getMessage();
//        logger.info("upload headimg meta : {}", map);
//        CmsClient client = new CmsClient(serviceURL, accKey, secretKey);
//        client.initRBU();
//        FileInputStream fileInputStream = null;
//        String cmsId = "";
//        try {
//            fileInputStream = new FileInputStream(imgFile);
//            Map<String, Object> result = client.simpleUpload(bucketName,
//                    false, md5, fileInputStream, map);
//            logger.info("upload picture result :{}", result);
//            cmsId = (String) result.get("id");
//            String cmsMd5 = (String) result.get("md5");
//            if (!cmsMd5.equals(md5)){
//                success = false;
//            }
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//            success = false;
//        } catch (CMSException e) {
//            success = false;
//            e.printStackTrace();
//        } finally {
//            if (fileInputStream != null) {
//                try {
//                    fileInputStream.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//
//        resMap.put("success",success);
//        resMap.put("objectId",cmsId);
//        logger.info("headimg res Map {}",resMap);
//        return resMap;
//
//    }
//
//
//    private Map<String, Object> getMessage() {
//        String userId = CurrentUser.getUser().getUserId();
//        String orgCode = CurrentUser.getUser().getOrgCode();
//        Map<String, Object> map = new HashMap<>();
//        map.put("branch_no", orgCode);        //机构号
//        map.put("isbs_version", "2.0.0");  //版本号
//        map.put("file_business_type", "O_ID");              //文件类型  其他
//        map.put("operate_timestamp", System.currentTimeMillis());   //当前时间时间戳
//        map.put("isbs_rec_no", userId);     //双录流水号
//        map.put("sys_source", "ISBS");     //系统来源
//        String[] businums = CurrentUser.getUser().getAgentCode().split(",");
//        map.put("e_appl_no", Arrays.asList(businums));                 //电子投保单单号
//        String[] riskTypes = CurrentUser.getUser().getAgentCode().split(",");
//        map.put("pro_code", Arrays.asList(riskTypes));                //产品编码
//        map.put("isbs_transcoding_status", VideoTransCodingStatusEnum.NO_TRANS_CODING);
//        return map;
//    }
//
//
//    public String updateCmsIndex(String contNo, LSCont lsCont, LsContState lsContState, String cmsId, LSUser lsUser) {
//        logger.info("抽帧批处理LSCont为 {}",lsCont);
//        logger.info("抽帧批处理LsContState为 {}",lsContState);
//        logger.info("抽帧批处理保单状态为 {}",lsCont.getInteractive());
//        logger.info("抽帧批处理抽帧状态为 {}",lsContState.getScreenShotState());
//        logger.info("抽帧批处理视频状态为 {}",lsContState.getVideoState());
//        Map<String, Object> map = new HashMap<>();
//        map.put("clerk_no", lsUser.getAgentCode());   //agentcode
//        map.put("phone_no", org.springframework.util.StringUtils.isEmpty(lsUser.getPhoneNo()) ? "18888888888" : lsUser.getPhoneNo());     //手机号
//        map.put("branch_no", lsCont.getOrgCode());        //机构号
//        map.put("isbs_version", "2.0.0");  //版本号
//        map.put("file_business_type", "S_V");              //文件类型  S_V 视频  S_V_F 抽帧文件
//        map.put("operate_timestamp", System.currentTimeMillis());   //当前时间时间戳
//        map.put("isbs_rec_no", lsCont.getContNo());     //双录流水号
//        map.put("sys_source", "ISBS");     //系统来源
//        String[] businums = lsCont.getBusiNum().split(",");
//        map.put("e_appl_no", Arrays.asList(businums));                 //电子投保单单号
//        String[] riskTypes = lsCont.getRiskType().split(",");
//        map.put("pro_code", Arrays.asList(riskTypes));                //产品编码
//        map.put("isbs_notify_url", notifyUrl);          //回调地址
//        //转码+切割参数
//        map.put("isbs_res_bucket", resBucket);        //抽帧+分片桶名
//        map.put("isbs_hls_time", "15");               //分片时间建个
//        List<String> cms_hls_resolution = new ArrayList<>();
//        cms_hls_resolution.add("600x480");           //分片分辨率
//        map.put("isbs_hls_resolution", cms_hls_resolution);
//        List<String> cms_extract_time = new ArrayList<>();
//        List<LSPicture> pictures = pictureDao.findByContNoAndBusiType(contNo, "ScreenShoot");
//        if (pictures != null && !pictures.isEmpty()) {
//            //抽帧参数
//            for (LSPicture picture : pictures) {
//                cms_extract_time.add(picture.getTimeNode().split("\\.")[0]);
//            }
//            map.put("isbs_extract_time", cms_extract_time);    //抽帧时点
//            map.put("isbs_extract_size", "600x480");          //抽帧图片大小
//        } else {
//            cms_extract_time.add("1");
//            map.put("isbs_extract_time", cms_extract_time);    //抽帧时点
//            map.put("isbs_extract_size", "600x480");
//        }
//        map.put("isbs_transcoding_status", UploadController.VideoTransCodingStatusEnum.TRANS_CODING); //转码状态
//        logger.info("contNo {} screentShot start", contNo);
//        lsContState.setScreenShotState("H");      //抽帧状态
//        lsContState.setVideoState("H");           //视频状态
//        contStateDao.save(lsContState);
//        logger.info("contNo {} lsContState change !!! \n {}, \n CMSID: {}",lsContState, cmsId);
//        // 截屏开始 时间节点
//        LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
//        java.util.Date date = new java.util.Date();
//        SimpleDateFormat contSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
//        lsContTime.setScreenShotBeginTime(contSdf.format(date));
//        lsContTime.setVideoBeginTime(contSdf.format(date));
//        contTimeDao.saveContTime(lsContTime);
//        String result = this.updateIndex(cmsId, map);
//        logger.info("保单状态为 {}",lsCont.getInteractive());
//        return result;
//    }
//
//    @Override
//    public String updateCmsIndex(String contNo, LSCont lsCont, String cmsId, LSUser lsUser) {
//        logger.info("抽帧批处理LSCont为 {}",lsCont);
//        logger.info("抽帧批处理保单状态为 {}",lsCont.getInteractive());
//        Map<String, Object> map = new HashMap<>();
//        map.put("clerk_no", lsUser.getAgentCode());   //agentcode
//        map.put("phone_no", org.springframework.util.StringUtils.isEmpty(lsUser.getPhoneNo()) ? "18888888888" : lsUser.getPhoneNo());     //手机号
//        map.put("branch_no", lsCont.getOrgCode());        //机构号
//        map.put("isbs_version", "2.0.0");  //版本号
//        map.put("file_business_type", "S_V");              //文件类型  S_V 视频  S_V_F 抽帧文件
//        map.put("operate_timestamp", System.currentTimeMillis());   //当前时间时间戳
//        map.put("isbs_rec_no", lsCont.getContNo());     //双录流水号
//        map.put("sys_source", "ISBS");     //系统来源
//        String[] businums = lsCont.getBusiNum().split(",");
//        map.put("e_appl_no", Arrays.asList(businums));                 //电子投保单单号
//        String[] riskTypes = lsCont.getRiskType().split(",");
//        map.put("pro_code", Arrays.asList(riskTypes));                //产品编码
//        map.put("isbs_notify_url", notifyUrl);          //回调地址
//        //转码+切割参数
//        map.put("isbs_res_bucket", resBucket);        //抽帧+分片桶名
//        map.put("isbs_hls_time", "15");               //分片时间建个
//        List<String> cms_hls_resolution = new ArrayList<>();
//        cms_hls_resolution.add("600x480");           //分片分辨率
//        map.put("isbs_hls_resolution", cms_hls_resolution);
//
//        map.put("isbs_transcoding_status", UploadController.VideoTransCodingStatusEnum.NO_TRANS_CODING); //转码状态
//
//        logger.info("保单状态为 {}",lsCont.getInteractive());
//        String result = this.updateIndex(cmsId, map);
//        return result;
//    }
//
//
//    public static void main(String[] args) {
//        String path = "https://nry.e-chinalife.com";
//        CmsClient cmsClient = new CmsClient(path, "33110a7a2d6eec0bb4258e7254a4c86c", "rFmix1kSv8DqMgAtGwIjSzBH4nq01jqOk72K7ghn2HXNdfZu08nmWtNjr3SsCwDz");
//        Map map = null;
//        try {
////            map = cmsClient.getMetaInfo("b-isbs-original", "af5d15942e124aaa95dba62487137107");
//            try {
//                String  cmslink = cmsClient.privateDownloadUrl("b-isbs-original", "d14e64f662ab42a9ab61a29404a08cee","1577844554689");
//                System.out.println(path+cmslink);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        } catch (CMSException e) {
//            e.printStackTrace();
//        }
//        System.out.println(map);
//    }
//}
