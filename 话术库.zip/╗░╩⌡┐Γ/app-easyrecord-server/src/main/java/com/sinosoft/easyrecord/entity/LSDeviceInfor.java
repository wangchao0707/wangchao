package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSDeviceInfor")
public class LSDeviceInfor {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "UserId")
    private String userId;
    @Column(name = "UploadTime")
    private String uploadTime;
    @Column(name = "DeviceInfor")
    private String deviceInfor;
    @Column(name = "token")
    private String token;


    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getDeviceInfor() {
        return deviceInfor;
    }

    public void setDeviceInfor(String deviceInfor) {
        this.deviceInfor = deviceInfor;
    }

    @Override
    public String toString() {
        return "LSDeviceInfor [id=" + id + ", userId=" + userId + ", uploadTime=" + uploadTime + ", deviceInfor="
                + deviceInfor + ", token=" + token + "]";
    }


}
