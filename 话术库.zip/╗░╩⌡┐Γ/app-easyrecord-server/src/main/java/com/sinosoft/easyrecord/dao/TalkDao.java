package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSTalk;

import java.util.List;

/**
 * Created by zf on 2017/7/27.
 */
public interface TalkDao {
    List<LSTalk> findTalkList(String comCode, String insurComCode, String riskType);

    List<LSTalk> findByComCode(String comCode);

    void deleteByComCode(String comCode);

    void save(LSTalk lsTalk);

    LSTalk findOneByPkId(String pkId);

    List<LSTalk> findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(String comCode, String insurComCode, String orgCode, String riskType);


    LSTalk findTop1ByTalkPointCode(String talkPointCode);
}
