package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.vo.QueryOrgForm;
import com.sinosoft.easyrecord.vo.ShowStateVo;

import java.util.List;

public interface QueryDao {

    List<QueryOrgForm> selectQueryStatus(List<String> list);

    List<String> isExit(List<String> list);

    ShowStateVo selectForStateByContNo(String contNo);

    List<String> selectProductNameByCode(List<String> listRisk);
}
