package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSInsuredRepository;
import com.sinosoft.easyrecord.entity.LSInsured;

import java.util.Optional;

@Component
public class InsuredDaoImpl4JPA implements InsuredDao {
    @Autowired
    private LSInsuredRepository insuredRepository;

    public void setInsuredRepository(LSInsuredRepository insuredRepository) {
        this.insuredRepository = insuredRepository;
    }

    @Override
    public void save(LSInsured insured) {
        insuredRepository.saveAndFlush(insured);
    }

    @Override
    public LSInsured findByInsuredNo(String insuredNo) {
        Optional<LSInsured> res = insuredRepository.findById(insuredNo);
        return res.orElse(null);
    }

    @Override
    public LSInsured findByContNo(String contNo) {
        return insuredRepository.findByContNo(contNo);
    }

}
