package com.sinosoft.easyrecord.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sinosoft.easyrecord.service.QuaCheckAndQryPolicyInter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/qcqp")
public class QuaCheckAndQryPolicyInfoController {

    @Autowired
    private QuaCheckAndQryPolicyInter quaCheckAndQryPolicyInter;

    @RequestMapping(value = "/quacheck",method = {RequestMethod.POST,RequestMethod.GET})
    public String quaCheck1(@RequestBody String data){
        return quaCheckAndQryPolicyInter.doQuaCheck(data);
    }

    @RequestMapping(value = "/qryPolicy",method = {RequestMethod.POST})
    public String qryPolicyInfo1(@RequestBody String data){
        return quaCheckAndQryPolicyInter.doQryPolicyInfo(data);
    }

    @RequestMapping(value = "/message",method = {RequestMethod.POST})
    public String messageRequest(@RequestBody String data){
        return quaCheckAndQryPolicyInter.doMessageRequest(data);
    }
}
