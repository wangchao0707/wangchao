package com.sinosoft.easyrecord.server;

public interface Req81019 {
    String getReq81019(String xml);
}
