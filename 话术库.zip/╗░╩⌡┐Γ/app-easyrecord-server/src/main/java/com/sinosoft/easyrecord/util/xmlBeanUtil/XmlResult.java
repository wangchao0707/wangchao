package com.sinosoft.easyrecord.util.xmlBeanUtil;

import com.thoughtworks.xstream.XStream;

/**
 * Created by wh on 2018/2/27.
 */
public class XmlResult {

    // 返回xml
    public static String result(Transhead head, String returnCode, String message) {
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = returnCode;
        result.MESSAGE = message;

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }
}
