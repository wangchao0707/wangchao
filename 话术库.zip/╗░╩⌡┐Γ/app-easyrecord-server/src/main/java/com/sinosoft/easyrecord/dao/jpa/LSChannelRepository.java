package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSChannel;

public interface LSChannelRepository extends JpaRepository<LSChannel, String> {
    LSChannel findByChannelName(String channer);
}
