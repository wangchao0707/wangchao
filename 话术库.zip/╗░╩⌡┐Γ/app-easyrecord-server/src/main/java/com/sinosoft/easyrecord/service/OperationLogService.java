package com.sinosoft.easyrecord.service;

import org.springframework.web.multipart.MultipartFile;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;

public interface OperationLogService {

    ServiceResult<String, String[]> saveOperationLog(MultipartFile operationLog, String userId, String equipmentInformation);

}
