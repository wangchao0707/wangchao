package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSTransferControl;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-22
 * Time: 10:18
 */

public interface TransferControlDao {


    LSTransferControl findByOrgCodeAndModifyDate(LSTransferControl.TransferControlId transferControlId);

    void saveTransControl(LSTransferControl lsTransferControl);

    LSTransferControl findByEnable(char enable);

}
