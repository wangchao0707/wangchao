package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSTransferInfo;

import java.util.Date;
import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-21
 * Time: 19:39
 */
public interface TransferInfoDao {

    void  saveTransferInfo(LSTransferInfo lsTransferInfo);

    LSTransferInfo findByStatus(String status);

    int findByStatusAndBatchNode(String status, String batchNode);

    List<LSTransferInfo> findByOrgCodeAndModifydateAndAndStatus(String orgCode, Date modifyDate, String status);
    List<LSTransferInfo> findByOrgCodeAndModifydate(String orgCode, Date modifyDate);

    LSTransferInfo findByContNo(String contNo);

    LSTransferInfo findByStatusAndOrgCode(String status, String[] orgCode);

    List<LSTransferInfo> find10ByStatusAndOrgCode(String status, String[] orgCode);
}
