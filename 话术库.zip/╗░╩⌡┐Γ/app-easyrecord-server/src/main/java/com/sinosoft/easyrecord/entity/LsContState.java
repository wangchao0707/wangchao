package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LsContState")
public class LsContState {

    @Id
    @Column(name = "ContNo")
    private String contNo;

    @Column(name = "PicState")
    private String picState;

    @Column(name = "VideoState")
    private String videoState;

    @Column(name = "Mp3State")
    private String mp3State;

    @Column(name = "VideoToMp3State")
    private String videoToMp3State;

    @Column(name = "ProdusId")
    private String produsId;

    @Column(name = "PicTime")
    private Long picTime;
    @Column(name = "Mp3Time")
    private Long mp3Time;
    @Column(name = "VideoTime")
    private Long videoTime;
    @Column(name = "VideoToMp3Time")
    private Long videoToMp3Time;

    @Column(name = "downState")
    private String downState;
    @Column(name = "downTime")
    private Long downTime;

    @Column(name = "ScreenShotState")
    private String screenShotState;
    @Column(name = "ScreenShotTime")
    private Long screenShotTime;

    @Column(name = "ZipUploadState")
    private String zipUploadState;
    @Column(name = "ZipTime")
    private Long zipTime;


    @Column(name = "BakState")
    private String bakState;
    @Column(name = "BakTime")
    private Long bakTime;
    @Column(name = "ZipFile")
    private String zipFile;


    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getPicState() {
        return picState;
    }

    public void setPicState(String picState) {
        this.picState = picState;
    }

    public String getVideoState() {
        return videoState;
    }

    public void setVideoState(String videoState) {
        this.videoState = videoState;
    }

    public String getMp3State() {
        return mp3State;
    }

    public void setMp3State(String mp3State) {
        this.mp3State = mp3State;
    }

    public String getVideoToMp3State() {
        return videoToMp3State;
    }

    public void setVideoToMp3State(String videoToMp3State) {
        this.videoToMp3State = videoToMp3State;
    }

    public String getProdusId() {
        return produsId;
    }

    public void setProdusId(String produsId) {
        this.produsId = produsId;
    }

    public Long getPicTime() {
        return picTime;
    }

    public void setPicTime(Long picTime) {
        this.picTime = picTime;
    }

    public Long getMp3Time() {
        return mp3Time;
    }

    public void setMp3Time(Long mp3Time) {
        this.mp3Time = mp3Time;
    }

    public Long getVideoTime() {
        return videoTime;
    }

    public void setVideoTime(Long videoTime) {
        this.videoTime = videoTime;
    }

    public Long getVideoToMp3Time() {
        return videoToMp3Time;
    }

    public void setVideoToMp3Time(Long videoToMp3Time) {
        this.videoToMp3Time = videoToMp3Time;
    }

    public String getDownState() {
        return downState;
    }

    public void setDownState(String downState) {
        this.downState = downState;
    }

    public Long getDownTime() {
        return downTime;
    }

    public void setDownTime(Long downTime) {
        this.downTime = downTime;
    }

    public String getScreenShotState() {
        return screenShotState;
    }

    public void setScreenShotState(String screenShotState) {
        this.screenShotState = screenShotState;
    }

    public Long getScreenShotTime() {
        return screenShotTime;
    }

    public void setScreenShotTime(Long screenShotTime) {
        this.screenShotTime = screenShotTime;
    }

    public String getZipUploadState() {
        return zipUploadState;
    }

    public void setZipUploadState(String zipUploadState) {
        this.zipUploadState = zipUploadState;
    }

    public Long getZipTime() {
        return zipTime;
    }

    public void setZipTime(Long zipTime) {
        this.zipTime = zipTime;
    }

    public String getBakState() {
        return bakState;
    }

    public void setBakState(String bakState) {
        this.bakState = bakState;
    }

    public Long getBakTime() {
        return bakTime;
    }

    public void setBakTime(Long bakTime) {
        this.bakTime = bakTime;
    }

    public String getZipFile() {
        return zipFile;
    }

    public void setZipFile(String zipFile) {
        this.zipFile = zipFile;
    }

    @Override
    public String toString() {
        return "LsContState [contNo=" + contNo + ", picState=" + picState + ", videoState=" + videoState + ", mp3State="
                + mp3State + ", videoToMp3State=" + videoToMp3State + ", produsId=" + produsId + ", picTime=" + picTime
                + ", mp3Time=" + mp3Time + ", videoTime=" + videoTime + ", videoToMp3Time=" + videoToMp3Time
                + ", downState=" + downState + ", downTime=" + downTime + ", screenShotState=" + screenShotState
                + ", screenShotTime=" + screenShotTime + ", zipUploadState=" + zipUploadState + ", zipTime=" + zipTime
                + ", bakState=" + bakState + ", bakTime=" + bakTime + ", zipFile=" + zipFile + "]";
    }


}
