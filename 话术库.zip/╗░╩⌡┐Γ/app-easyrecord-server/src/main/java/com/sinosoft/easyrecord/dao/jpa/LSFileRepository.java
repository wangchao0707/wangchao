package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSFile;

public interface LSFileRepository extends JpaRepository<LSFile, String> {


    public LSFile findTop1ByContNo(String contNo);
}
