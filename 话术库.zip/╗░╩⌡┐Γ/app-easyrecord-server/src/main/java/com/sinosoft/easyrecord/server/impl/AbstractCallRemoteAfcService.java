package com.sinosoft.easyrecord.server.impl;

import com.sinosoft.easyrecord.server.CallRemoteAfcService;
import com.sinosoft.easyrecord.server.CallRemoteAfcServiceUtilFactory;
import com.sinosoft.easyrecord.server.CallRemoteAfcServiceUtilImpl;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;

public abstract class AbstractCallRemoteAfcService<R, Q> implements CallRemoteAfcService<R, Q>, InitializingBean {

    private static final Logger logger = LoggerFactory.getLogger(CallRemoteAfcServiceUtilImpl.class);


    private CallRemoteAfcServiceUtilFactory callAfcServiceFactory;

    private String serviceNo;

    private XStream requestConverter;

    private XStream responseConverter;


    protected AbstractCallRemoteAfcService(String serviceNo, CallRemoteAfcServiceUtilFactory callAfcServiceFactory) {
        this.serviceNo = serviceNo;
        this.callAfcServiceFactory = callAfcServiceFactory;
    }

    @Override
    public void afterPropertiesSet() throws Exception {

        requestConverter = buildRequestConverter();

        responseConverter = buildResponseConverter();

    }

    abstract XStream buildRequestConverter();

    abstract XStream buildResponseConverter();

    @Override
    public Q callService(R requestData, String comCode) {

        try {

            String requestXml = requestConverter.toXML(requestData);
            logger.info("request AFC service [c:{},s:{}], request XML: \n {}", comCode, serviceNo, requestXml);

            String responseXml = callAfcServiceFactory.getInstance(comCode).sendService(requestXml);

            logger.info("request AFC service [c:{},s:{}], response XML: \n {}", comCode, serviceNo, responseXml);

            Q responseData = (Q) responseConverter.fromXML(responseXml);

            return responseData;

        } catch (Exception ex) {
            throw new RuntimeException(ex.getMessage(), ex);
        }
    }
}
