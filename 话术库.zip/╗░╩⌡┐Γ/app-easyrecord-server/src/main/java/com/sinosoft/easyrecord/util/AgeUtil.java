package com.sinosoft.easyrecord.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * User: weihao
 * Date: 2018/5/17
 * Time: 9:37
 *  计算年龄
 */

public class AgeUtil {

    private static Logger logger = LoggerFactory.getLogger(AgeUtil.class);


    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    /**
     *
     * @Description: 根据年龄字符串计算年龄
     * @param @param birthday yyyy-MM-dd格式
     * @param @return
     * @return int
     * @throws
     * @author zhenghr
     * @date 2016-8-23
     */
    public static int calAgeFromBirthday(String birthday) {
        int age = -1;
        if (!StringUtils.isEmpty(birthday)) {
            Date birthdayDate;
            try {
                birthdayDate = sdf.parse(birthday);
                age = calInterval(birthdayDate, new Date(), "Y");
            } catch (ParseException e) {
                logger.error("计算年龄出错：" + e.getMessage());
                e.printStackTrace();
            }
        }
        return age;
    }

    /**
     *
     * @Description: 根据出生日期计算年龄
     * @param @param birthday
     * @param @return
     * @return int
     * @throws
     * @author zhenghr
     * @date 2016-8-23
     */
    public static int calAgeFromBirthday(Date birthday) {
        return calInterval(birthday, new Date(), "Y");
    }

    /**
     * 通过起始日期和终止日期计算以时间间隔单位为计量标准的时间间隔 author: HST
     * <p><b>Example: </b><p>
     * <p>参照calInterval(String  cstartDate, String  cendDate, String unit)，前两个变量改为日期型即可<p>
     * @param startDate 起始日期，Date变量
     * @param endDate 终止日期，Date变量
     * @param unit 时间间隔单位，可用值("Y"--年 "M"--月 "D"--日)
     * @return 时间间隔,整形变量int
     */
    public static int calInterval(Date startDate, Date endDate, String unit) {
        int interval = 0;

        GregorianCalendar sCalendar = new GregorianCalendar();
        sCalendar.setTime(startDate);
        int sYears = sCalendar.get(Calendar.YEAR);
        int sMonths = sCalendar.get(Calendar.MONTH);
        int sDays = sCalendar.get(Calendar.DAY_OF_MONTH);
        int sDaysOfYear = sCalendar.get(Calendar.DAY_OF_YEAR);

        GregorianCalendar eCalendar = new GregorianCalendar();
        eCalendar.setTime(endDate);
        int eYears = eCalendar.get(Calendar.YEAR);
        int eMonths = eCalendar.get(Calendar.MONTH);
        int eDays = eCalendar.get(Calendar.DAY_OF_MONTH);
        int eDaysOfYear = eCalendar.get(Calendar.DAY_OF_YEAR);

        if (unit.equals("Y")) {
            interval = eYears - sYears;
            if (eMonths < sMonths) {
                interval--;
            }
            else {
                if (eMonths == sMonths && eDays < sDays) {
                    interval--;
                    if (eMonths == 1) { //如果同是2月，校验润年问题
                        if ( (sYears % 4) == 0 && (eYears % 4) != 0) { //如果起始年是润年，终止年不是润年
                            if (eDays == 28) { //如果终止年不是润年，且2月的最后一天28日，那么补一
                                interval++;
                            }
                        }
                    }
                }
            }
        }
        if (unit.equals("M")) {
            interval = eYears - sYears;
            interval = interval * 12;

            interval = eMonths - sMonths + interval;
            if (eDays < sDays) {
                interval--;
                //eDays如果是月末，则认为是满一个月
                int maxDate = eCalendar.getActualMaximum(Calendar.DATE);
                if (eDays == maxDate) {
                    interval++;
                }
            }
        }
        if (unit.equals("D")) {
            interval = eYears - sYears;
            interval = interval * 365;
            interval = eDaysOfYear - sDaysOfYear + interval;

            // 处理润年
            int n = 0;
            eYears--;
            if (eYears > sYears) {
                int i = sYears % 4;
                if (i == 0) {
                    sYears++;
                    n++;
                }
                int j = (eYears) % 4;
                if (j == 0) {
                    eYears--;
                    n++;
                }
                n += (eYears - sYears) / 4;
            }
            if (eYears == sYears) {
                int i = sYears % 4;
                if (i == 0)
                    n++;
            }
            interval += n;
        }
        return interval;
    }


	public static void main(String[] args) {
		String bir = "1957-02-26";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date date = null;
		try {
			date = sdf.parse(bir);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		int age = calAgeFromBirthday(date);
		System.out.println(age);
	}
}
