package com.sinosoft.easyrecord.server;

public interface Req81003 {

    String getReq81003(String xml);
}
