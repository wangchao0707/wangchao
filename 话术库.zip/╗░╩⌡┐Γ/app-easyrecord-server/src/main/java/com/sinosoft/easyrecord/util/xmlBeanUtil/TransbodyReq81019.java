package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


//产品报文处理接口
/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: FengLei
 * Date: 2018-09-17
 * Time: 14：48
*/

public class TransbodyReq81019 implements Transbody,Serializable {

    private static final long serialVersionUID = -6043904177435693250L;
    private PRODUCTMANAGEMENT PRODUCTMANAGEMENT;


    public PRODUCTMANAGEMENT getPRODUCTMANAGEMENT() {
        return PRODUCTMANAGEMENT;
    }

    public void setPRODUCTMANAGEMENT(PRODUCTMANAGEMENT PRODUCTMANAGEMENT) {
        this.PRODUCTMANAGEMENT = PRODUCTMANAGEMENT;
    }

    //多个产品
    public static class PRODUCTMANAGEMENTS {
        public List<PRODUCTMANAGEMENT> PRODUCTMANAGEMENT = new ArrayList<>();
    }

    //单个产品
    public static class PRODUCTMANAGEMENT {

        private String TYPE;                      //类型  release 发布, cancelRelease 取消发布
        private String PRODUCTID;                 //产品主键ID
        private String PRODUCTCODE;               //产品编码
        private String PRODUCTNAME;               //产品名称
        private String PRODUCTTYPECODE;           //产品类型编码
        private String PRODUCTTYPENAME;                //产品类型名称
        private String ISDEATH;                   //是否死亡
        private String ISHEALTH;                  //是否健康

            //以下可以设置为空
        private String BUSINESSTYPECODE;        //业务类型编码
        private String BUSINESSTYPENAME;        //业务类型名称
        private String PRODUCTRISKLEVELS;       //风险等级
        private String PRODUCTTERM;             //产品期限
        private String COMPANYNAME;             //产品公司名称
        private String GREATNUMBERLIMIT;        //高额限制
//        private String OLDAGELIMIT;             //高龄限制

//        public String getOLDAGELIMIT() {
//            return OLDAGELIMIT;
//        }
//
//        public void setOLDAGELIMIT(String OLDAGELIMIT) {
//            this.OLDAGELIMIT = OLDAGELIMIT;
//        }


        public String getTYPE() {
            return this.TYPE;
        }

        public void setTYPE(String TYPE) {
            this.TYPE = TYPE;
        }

        public String getPRODUCTID() {
            return this.PRODUCTID;
        }

        public void setPRODUCTID(String PRODUCTID) {
            this.PRODUCTID = PRODUCTID;
        }

        public String getPRODUCTCODE() {
            return this.PRODUCTCODE;
        }

        public void setPRODUCTCODE(String PRODUCTCODE) {
            this.PRODUCTCODE = PRODUCTCODE;
        }

        public String getPRODUCTNAME() {
            return this.PRODUCTNAME;
        }

        public void setPRODUCTNAME(String PRODUCTNAME) {
            this.PRODUCTNAME = PRODUCTNAME;
        }

        public String getPRODUCTTYPECODE() {
            return this.PRODUCTTYPECODE;
        }

        public void setPRODUCTTYPECODE(String PRODUCTTYPECODE) {
            this.PRODUCTTYPECODE = PRODUCTTYPECODE;
        }

        public String getPRODUCTTYPENAME() {
            return this.PRODUCTTYPENAME;
        }

        public void setPRODUCTTYPENAME(String PRODUCTTYPENAME) {
            this.PRODUCTTYPENAME = PRODUCTTYPENAME;
        }

        public String getISDEATH() {
            return this.ISDEATH;
        }

        public void setISDEATH(String ISDEATH) {
            this.ISDEATH = ISDEATH;
        }

        public String getISHEALTH() {
            return this.ISHEALTH;
        }

        public void setISHEALTH(String ISHEALTH) {
            this.ISHEALTH = ISHEALTH;
        }

        public String getBUSINESSTYPECODE() {
            return this.BUSINESSTYPECODE;
        }

        public void setBUSINESSTYPECODE(String BUSINESSTYPECODE) {
            this.BUSINESSTYPECODE = BUSINESSTYPECODE;
        }

        public String getBUSINESSTYPENAME() {
            return this.BUSINESSTYPENAME;
        }

        public void setBUSINESSTYPENAME(String BUSINESSTYPENAME) {
            this.BUSINESSTYPENAME = BUSINESSTYPENAME;
        }

        public String getPRODUCTRISKLEVELS() {
            return this.PRODUCTRISKLEVELS;
        }

        public void setPRODUCTRISKLEVELS(String PRODUCTRISKLEVELS) {
            this.PRODUCTRISKLEVELS = PRODUCTRISKLEVELS;
        }

        public String getPRODUCTTERM() {
            return this.PRODUCTTERM;
        }

        public void setPRODUCTTERM(String PRODUCTTERM) {
            this.PRODUCTTERM = PRODUCTTERM;
        }

        public String getCOMPANYNAME() {
            return this.COMPANYNAME;
        }

        public void setCOMPANYNAME(String COMPANYNAME) {
            this.COMPANYNAME = COMPANYNAME;
        }

        public String getGREATNUMBERLIMIT() {
            return this.GREATNUMBERLIMIT;
        }

        public void setGREATNUMBERLIMIT(String GREATNUMBERLIMIT) {
            this.GREATNUMBERLIMIT = GREATNUMBERLIMIT;
        }
    }
 }