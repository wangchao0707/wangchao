package com.sinosoft.easyrecord.server;

public interface Req80008 {

    public String getReq80008(String xml);

}
