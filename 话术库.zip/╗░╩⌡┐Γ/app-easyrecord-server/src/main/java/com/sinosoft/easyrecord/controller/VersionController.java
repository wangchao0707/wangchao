package com.sinosoft.easyrecord.controller;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.entity.LSVersion;
import com.sinosoft.easyrecord.service.VersionService;
import com.sinosoft.easyrecord.vo.VersionForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.annotation.RequestScope;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/upload")
public class VersionController {

    private Logger logger = LoggerFactory.getLogger(VersionController.class);

    @Autowired
    private VersionService versionService;

    @RequestMapping(value = "/version", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @RequestScope
    public RequestResult updateVersion(@RequestParam String versionId, String type, String comCode) {
        VersionForm versionForm = new VersionForm();
        versionForm.setVersionId(versionId);
        versionForm.setType(type);
        versionForm.setComCode(comCode);
        return updateVision(versionForm);
        
    }


    @RequestMapping(value = "/version", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult updateVision(@RequestBody VersionForm versionForm) {

        ServiceResult<String, String[]> build = versionForm.validate();
        if (!build.isSuccess()) {
            RequestResult result = new RequestResult(false);
            result.setMessages(build.getFailResult());
            return result;
        }

        ServiceResult<LSVersion, String[]> result = versionService.saveVersion(versionForm.getVersionId(), versionForm.getType(), versionForm.getComCode());
        if (result.isSuccess()) {
            RequestResult res = new RequestResult(true);
            logger.info("version info {}", result.getSuccessResult());
            res.setData(result.getSuccessResult());
            return res;
        } else {
            RequestResult res = new RequestResult(false);
            res.setMessages(result.getFailResult());
            return res;
        }

    }

    @RequestMapping(value = "/updateMd5", method = RequestMethod.POST,consumes = "application/x-www-form-urlencoded")

    public RequestResult updateMd5(@RequestParam String versionId,String type,String comCode,String md5){
        Map<String,Object> reqMap = new HashMap<>();
        reqMap.put("versionId",versionId);
        reqMap.put("type",type);
        reqMap.put("comCode",comCode);
        reqMap.put("md5",md5);
        return updateMd5(reqMap);
    }

    @RequestMapping(value = "/updateMd5" , method = RequestMethod.POST,consumes = "application/json")
    public RequestResult updateMd5(@RequestBody Map reqMap){
        return versionService.updateMd5(reqMap);
    }
}
