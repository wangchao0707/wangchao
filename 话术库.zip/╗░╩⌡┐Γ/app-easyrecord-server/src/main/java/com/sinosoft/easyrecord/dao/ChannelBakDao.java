package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSChannelBak;

public interface ChannelBakDao {

    void save(LSChannelBak lsChannelBak);
}
