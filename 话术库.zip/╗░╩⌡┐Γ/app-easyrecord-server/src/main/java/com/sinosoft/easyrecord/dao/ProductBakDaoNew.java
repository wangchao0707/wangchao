package com.sinosoft.easyrecord.dao;


import com.sinosoft.easyrecord.entity.LSProductNewBak;

public interface ProductBakDaoNew {

    void saveLSProductBakNew(LSProductNewBak lsProductNewBak);               //保存主编数据做更新
}
