package com.sinosoft.easyrecord.service.impl;


import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.server.Req800011;
import com.sinosoft.easyrecord.service.UserActionLogService;
import com.sinosoft.easyrecord.service.UserService;
import com.sinosoft.easyrecord.sso.CurrentUser;
import com.sinosoft.easyrecord.util.MD5;
import com.sinosoft.easyrecord.util.ShowStarUtils;
import com.sinosoft.easyrecord.vo.*;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.transaction.Transactional;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

//import com.sinosoft.easyrecord.util.SMSUtil;

/**
 * Created by WinterLee on 2017/7/15.
 */
@Service
public class UserServiceImpl implements UserService {

    private Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserActionLogService userActionLogService;

    @Autowired
    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Autowired
    private VersionDao versionDao;

    @Autowired
    private AuthenticationDao authenticationDao;

    public void setAuthenticationDao(AuthenticationDao authenticationDao) {
        this.authenticationDao = authenticationDao;
    }


    @Autowired
    private ComDao comDao;

    public void setComDao(ComDao comDao) {
        this.comDao = comDao;
    }

    @Autowired
    private OrganizationDao organizationDao;

    public void setOrganizationDao(OrganizationDao organizationDao) {
        this.organizationDao = organizationDao;
    }

    private DeviceInforDao deviceDao;

    @Autowired
    public void setDeviceDao(DeviceInforDao deviceDao) {
        this.deviceDao = deviceDao;
    }

    @Autowired
    private VerificationCodeDao verificationCodeDao;

    public void setVerificationCodeDao(VerificationCodeDao verificationCodeDao) {
        this.verificationCodeDao = verificationCodeDao;
    }

    @Autowired
    private BankNetWorkDao bankNetWorkDao;

    public void setBankNetWorkDao(BankNetWorkDao bankNetWorkDao) {
        this.bankNetWorkDao = bankNetWorkDao;
    }

    @Autowired
    private FeedbackDao feedbackDao;

    public void setFeedbackDao(FeedbackDao feedbackDao) {
        this.feedbackDao = feedbackDao;
    }

    @Autowired
    private Req800011 req800011;

    public void setReq800011(Req800011 req800011) {
        this.req800011 = req800011;
    }

    @Autowired
    private ChannelDao channelDao;

    public void setChannelDao(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    public ServiceResult<LSUser, String[]> saveRegisterInfo(RegisterForm registerForm) {

        ServiceResult.Builder<LSUser, String[]> builder = ServiceResult.build(LSUser.class, String[].class);

        ServiceResult<LSUser, String[]> x = null;
        LSVerificationCode lsVerificationCode = verificationCodeDao.findByPhoneNum(registerForm.getPhoneNo());
//        if (lsVerificationCode == null || !lsVerificationCode.getVerificationCode().equals(registerForm.getVcode())) {
//            x = builder.createFailResult(new String[]{"您的验证码输入错误，请再次确认"});
//        } else {
            if (lsVerificationCode != null) {
                String createtime = lsVerificationCode.getVerificationTime();
                try {
                    Date date = sdf.parse(createtime);
                    long time = date.getTime();
                    if (System.currentTimeMillis() - time > 120 * 1000) {
                        x = builder.createFailResult(new String[]{"超过时间，请重新发送"});
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
//        }
        if (x != null) return x;

        //添加银保数据虚拟账号判断
        LSUser user = userDao.getByComInfo(registerForm.getComCode(), registerForm.getAgentCode());
        if (user != null && user.getState() != 'Y') {
            return builder.createFailResult(new String[]{"您的代理人工号已经注册过了。请再次确认"});
        }
        //判断 是否有 网点与客户经理对应 关系 只在用户角色为 银行员工时判断
        if (registerForm.getRole().equals("B")) {
            List<LSBankNetWork> bankNetWorks = bankNetWorkDao.findAllByBankNetWorkCode(registerForm.getDotCode());
            if (bankNetWorks == null || bankNetWorks.size() == 0) {
                return builder.createFailResult(new String[]{"录入网点不存在。请再次确认或联系系统管理员进行网点维护"});
            }
        }

        user = userDao.getByIDNo(registerForm.getIdNo());
        if (user != null && user.getState() != 'Y') {
            return builder.createFailResult(new String[]{"您的证件号已经注册过了。请再次确认"});
        }

        user = userDao.getByPhoneNo(registerForm.getPhoneNo());
        if (user != null && user.getState() != 'Y') {
            return builder.createFailResult(new String[]{"您的手机号已经注册过"});
        }

        return saveRegisterInfoOutCheckVerCode(registerForm);
    }

    // registMod  手工注册    系统导入
    public ServiceResult<LSUser, String[]> saveRegisterInfoOutCheckVerCode(RegisterForm registerForm) {
        ServiceResult.Builder<LSUser, String[]> builder = ServiceResult.build(LSUser.class, String[].class);

        LSUser user = null;

        user = _saveRegisterInfo(registerForm);

        return builder.createSuccessResult(user);
    }

    private static SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

    @Transactional
    public LSUser _saveRegisterInfo(RegisterForm registerForm) {
        java.sql.Date currDate = new java.sql.Date(System.currentTimeMillis());
        String currTime = format.format(currDate);

        boolean isUpdate = false;

        //银保数据覆盖
        LSUser userFromDB = userDao.getByComInfo(registerForm.getComCode(), registerForm.getAgentCode());
        if (userFromDB != null) {
            // 查到了
            isUpdate = true;
        } else {
            // 没有查到
            userFromDB = new LSUser();
            userFromDB.setUserId(UUID.randomUUID().toString());
            userFromDB.setMakeDate(currDate);
            userFromDB.setMakeTime(currTime);
            userFromDB.setState('1');   // state 为1 代表 app 注册用户
            userFromDB.setWorkFlag("0");
            userFromDB.setUseFalg("0");
        }
        userFromDB.setComCode(registerForm.getComCode());
        userFromDB.setOrgCode(registerForm.getOrgCode());
        userFromDB.setAgentCode(registerForm.getAgentCode());
        userFromDB.setName(registerForm.getName());
        userFromDB.setSex(registerForm.getSex());
        userFromDB.setBrithday(registerForm.getBrithday());
        userFromDB.setIdNo(registerForm.getIdNo());
        userFromDB.setPhoneNo(registerForm.getPhoneNo() );
        userFromDB.setDotCode(registerForm.user().getDotCode());
        userFromDB.setIsecDate(registerForm.user().getIsecDate());
        userFromDB.setIsecNo(registerForm.user().getIsecNo());
        userFromDB.setHeadImg(registerForm.user().getHeadImg());
        userFromDB.setCloudURL(registerForm.user().getCloudURL());
        userFromDB.setChannel(registerForm.getChannel());
        userFromDB.setSaleComCode(registerForm.user().getSaleComCode());
        if ((null!=registerForm.user().getSaleComName()) && (registerForm.user().getSaleComName().contains(":"))){
            userFromDB.setSaleComName(registerForm.user().getSaleComName().split(":")[1].trim());
        }else{
            userFromDB.setSaleComName(registerForm.user().getSaleComName());
        }
        userFromDB.setRole(registerForm.getRole());
        userFromDB.setBankCode(registerForm.getBankCode());
        userFromDB.setCciaNo(registerForm.user().getCciaNo());
        userFromDB.setIdType(registerForm.user().getIdType());
        userFromDB.setIsPush("Y");
        userFromDB.setModifyDate(currDate);
        userFromDB.setModifyTime(currTime);
        userFromDB.setDistributor(registerForm.getDistributor());
        userDao.save(userFromDB);

        if(isUpdate) {
            // 老用户，不需要修改密码。
            return userFromDB;
        }

        if(StringUtils.isEmpty(registerForm.getPassword())){
            String agentCode = registerForm.getAgentCode();
            String password =  agentCode.substring(agentCode.length()-6,agentCode.length());
            logger.info("agentCode ::{},password :: {}",agentCode,password);
            password = MD5.stringToMD5(password);
            registerForm.setPassword(password);
            //将数据导入数据库（密码是工号后六位）
            logger.info("agentCode ::{},password :: {}",agentCode,password);
            changePasswd(registerForm, userFromDB, "Y");
        } else {
            changePasswd(registerForm, userFromDB, "N");
        }

        return userFromDB;
    }

    private void changePasswd(RegisterForm registerForm, LSUser inputUser, String isDefaultPwd) {
        LSAuthentication authentication = new LSAuthentication();
        authentication.setUserId(inputUser.getUserId());
        // 加密保存
        String password = registerForm.getPassword();
        authentication.setIsDefaultPWD(isDefaultPwd);
        authentication.setPassword(password);
        authenticationDao.save(authentication);
    }

    @Override
    public ServiceResult<UserBasicInfo, String> getUserInfo(String userId) {

        ServiceResult.Builder<UserBasicInfo, String> builder = ServiceResult.build(UserBasicInfo.class, String.class);

        LSUser user = userDao.getUser(userId);

        if(user == null){
            logger.error("find user failed!!!!!  userDao.getUser(userId: {}) >> NULL ", userId);
            return builder.createFailResult("用户信息有误！UE-0001");
        }

        UserBasicInfo userInfo = new UserBasicInfo(user);

        ServiceResult<String, String[]> validateinfo = userInfo.validate();

        if (validateinfo.isSuccess()) {
            return builder.createSuccessResult(userInfo);
        } else {
            return builder.createFailResult(validateinfo.getFailResult()[0]);
        }

    }

    public ServiceResult<UserInfo, String> basicInfo2UserInfo(UserBasicInfo basicInfo) {

        ServiceResult.Builder<UserInfo, String> builder = ServiceResult.build(UserInfo.class, String.class);

        //历史用户统一改为营销员
        if (StringUtils.isEmpty(basicInfo.getRole())) {
            basicInfo.setRole("S");
        }
        UserInfo userInfo = new UserInfo(basicInfo);

        userInfo.setComInfo(comDao.getCom(userInfo.getComCode()));
        userInfo.setOrgInfo(organizationDao.getOrganization(userInfo.getOrgCode()));
        if (StringUtils.isEmpty(organizationDao.getOrganization(userInfo.getOrgCode()))){
            throw new RuntimeException("系统中没有渠道为："+userInfo.getChannel()+",机构为："+userInfo.getOrgCode()+"的数据,请联系信息部门提工单处理");
        }

        ServiceResult<String, String[]> validateinfo = userInfo.validate();

        if (validateinfo.isSuccess()) {
            //改
            LSUser user = userDao.getUser(userInfo.getUserId());
            String phoneNom = ShowStarUtils.showPhoneStar(user.getPhoneNo());
            user.setPhoneNo(phoneNom);
            if(user.getIdNo()!=null && !user.getIdNo().equals("")){
                user.setIdNo(ShowStarUtils.showIdStar(user.getIdNo()));
            }
            userInfo.setUserInfo(user);
            return builder.createSuccessResult(userInfo);
        } else {
            return builder.createFailResult(validateinfo.getFailResult()[0]);
        }
    }

    @Override
    public ServiceResult<String, String[]> saveExtended(UserExtendedForm userExtendedForm) {

        LSUser user = null;
        if (!StringUtils.isEmpty(userExtendedForm.getUserId())) {
            user = userDao.getUser(userExtendedForm.getUserId());
        } else {
            return ServiceResult.BUILDER_Validate.createFailResult("用户ID为空");
        }

        if (user == null) {
            return ServiceResult.BUILDER_Validate.createFailResult("用户名或密码错误");
        }

        logger.info("extended user userform {}",userExtendedForm);

        user.setCciaNo(userExtendedForm.getCciaNo());
        user.setIsecDate(userExtendedForm.getIsecDate());
        user.setIsecNo(userExtendedForm.getIsecNo());
        user.setName(userExtendedForm.getName());
        user.setSex(userExtendedForm.getSex());
        user.setChannel(userExtendedForm.getChannel());
        user.setIsPush("N");
        user.setRole(userExtendedForm.getRole());

        if (userExtendedForm.getOrgCode() != null) {
            user.setOrgCode(userExtendedForm.getOrgCode());
        }


        userDao.save(user);

        return ServiceResult.BUILDER_Validate.createSuccessResult("OK");
    }

    @Override
    public ServiceResult<String, String[]> updatePassword(String oldPassword, String newPassword, String randomCode) {

        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        String userId = CurrentUser.getUser().getUserId();
        LSAuthentication lsAuthentication = authenticationDao.getAuthentication(userId);

        String passWord0 = (lsAuthentication.getPassword()) + randomCode;
        String oldPassword2 = MD5.stringToMD5(passWord0);
        if (!oldPassword2.equalsIgnoreCase(oldPassword)) {
            return builder.createFailResult(new String[]{"旧密码错误"});
        }
        LSUser lsUser = userDao.getUser(userId);
        lsUser.setIsPush("N");

        userDao.save(lsUser);
        lsAuthentication.setPassword(newPassword);
        lsAuthentication.setIsDefaultPWD("N");
        authenticationDao.save(lsAuthentication);

        return builder.createSuccessResult("OK");
    }

    @Override
    public ServiceResult<String, String[]> foreignPassword(String phoneNo, String newPassword, String valicode,
                                                           String randomCode) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);

        LSUser lsUser = userDao.getByPhoneNo(phoneNo);
        if (lsUser == null) {
            return builder.createFailResult(new String[]{"用户电话号码不存在！"});
        }
/*        LSVerificationCode lsVerificationCode = verificationCodeDao.findByPhoneNum(phoneNo);
        if (lsVerificationCode!= null){
            String createtime = lsVerificationCode.getVerificationTime();
            try {
                Date date = sdf.parse(createtime);
                long time = date.getTime();
                if (System.currentTimeMillis()-time>120*1000){
                    return builder.createFailResult(new String[]{"超过时间，请重新发送"});
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }
        if (!valicode.equals(lsVerificationCode.getVerificationCode())) {
            return builder.createFailResult(new String[]{"用户校验码错误"});
        }*/
        LSAuthentication lsAuthentication = authenticationDao.getAuthentication(lsUser.getUserId());
        if(lsAuthentication == null){
            lsAuthentication = new LSAuthentication();
            lsAuthentication.setUserId(lsUser.getUserId());
        }
        lsAuthentication.setPassword(newPassword);
        lsAuthentication.setIsDefaultPWD("N");
        authenticationDao.save(lsAuthentication);

        lsUser.setIsPush("N");
        userDao.save(lsUser);

        return builder.createSuccessResult("OK");
    }

    @Override
    public void saveDeviceInfor(String userId, String deviceInfor, String token) {
//        LSUser lsUser = userDao.getByPhoneNo(userId);
        LSDeviceInfor lsDeviceInfor = new LSDeviceInfor();
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        lsDeviceInfor.setId(UUID.randomUUID().toString());
        lsDeviceInfor.setDeviceInfor(deviceInfor);
        lsDeviceInfor.setUploadTime(sdf.format(date));
        lsDeviceInfor.setUserId(userId);

        //保存token
        lsDeviceInfor.setToken(token);

        deviceDao.saveDeviceInfor(lsDeviceInfor);
    }

    @Value(value = "${com.code}")
    private String comcode;
    @Value(value = "${com.enable}")
    private boolean enable;


    @Value(value = "${self.verification.url}")
    private String verificationURL;

    public ServiceResult<String, String[]> forwordMessage(String phoneNum, String comCode) {
        ServiceResult.Builder<String, String[]> build = ServiceResult.build(String.class, String[].class);
        //设置转发的url
        String url = verificationURL;
        //转发收到的短信信息
        logger.info("forword message phoneNum {} comCode {}", phoneNum, comCode);

        OkHttpClient okHttpClient = new OkHttpClient();
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("phoneNum", phoneNum);
        builder.add("comCode", comCode);
        FormBody formBody = builder.build();
        Request request = new Request.Builder() //
                .url(url) //
                .post(formBody) //
                .build();
        String body = "";
        Response response = null;
        try {
            response = okHttpClient.newCall(request).execute();
            body = response.body().string();
//			response.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (response != null) {
                response.close();
            }
        }
        logger.info("phonenum {} response body {}", phoneNum, body);
        JSONObject jsonObject = null;
        //添加异常标识
        Boolean isFailed = false;
        try {
            jsonObject = new JSONObject(body);
        } catch (Exception e) {
            isFailed = true;
            logger.error("phoneNum {} json error {}", phoneNum, e);
        }
        if (isFailed) {
            return build.createFailResult(new String[]{"系统繁忙，请稍后在试"});
        }
        boolean success = jsonObject.getBoolean("success");
        if (!success) {
            JSONArray jsonArray = jsonObject.getJSONArray("messages");
            StringBuffer message = new StringBuffer();
            for (int i = 0; i < jsonArray.length(); i++) {
                String message1 = (String) jsonArray.get(i);
                message.append(message1);
            }
            logger.warn("phonenum {}  failed message {}", phoneNum, message);
            return build.createFailResult(new String[]{message.toString()});
        } else {
            return build.createSuccessResult("ok");
        }
    }


    //发送短信验证码
    @Override
    public ServiceResult<String, String[]> getVerification(String phoneNum, String comCode) {
        ServiceResult.Builder<String, String[]> build = ServiceResult.build(String.class, String[].class);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        // 短信平台没有下来 暂时统一用 1234
        String code = UUID.randomUUID().toString().substring(0, 6);  //(int)(Math.ceil((Math.random() * 9 + 1) * 1000))+"";
        logger.info("phoneNum {} verificationCode {}", phoneNum, code);

        phoneNum = phoneNum.trim();

        /**
         * 添加时间校验，统一手机 一分钟就能发送 一次
         **/
        LSVerificationCode lsVerificationCode = verificationCodeDao.findByPhoneNum(phoneNum);
        if (lsVerificationCode!= null){
            String createtime = lsVerificationCode.getVerificationTime();
            try {
                Date date = sdf.parse(createtime);
                long time = date.getTime();
                if (System.currentTimeMillis()-time<60*1000){
                    return build.createFailResult(new String[]{"验证码发送失败,请勿短时间内重复发送！"});
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }

        // 发送短信
        String result = req800011.getReq800011(phoneNum, "您的短信验证码是：" + code);
        logger.info("phoneNum {} sms result {}", phoneNum, result);
        if (!result.equals("100")) {
            return build.createFailResult(new String[]{"验证码发送失败"});
        }

        //保存保存内容
        lsVerificationCode = new LSVerificationCode();
        lsVerificationCode.setId(UUID.randomUUID().toString());
        lsVerificationCode.setPhoneNum(phoneNum);
        lsVerificationCode.setVerificationCode(code);
        Date date = new Date();

        lsVerificationCode.setVerificationTime(sdf.format(date));
        verificationCodeDao.saveVerificationCode(lsVerificationCode);
        logger.info("短信验证码 {}",lsVerificationCode);
        return build.createSuccessResult("ok");
    }

    @Override
    public ServiceResult<String, String[]> getPhoneNumVerification(String phoneNum, String comCode) {
        ServiceResult.Builder<String, String[]> build = ServiceResult.build(String.class, String[].class);

        LSUser lsUser = userDao.getByPhoneNo(phoneNum);
        if (lsUser != null) {
            return build.createFailResult(new String[]{"该手机号已经注册，无法再次注册"});
        }

        return forwordMessage(phoneNum, comCode);
    }

    @Override
    public ServiceResult<String, String[]> loginVerification(String phoneNum, String comCode) {
        ServiceResult.Builder<String, String[]> build = ServiceResult.build(String.class, String[].class);

        LSUser lsUser = userDao.getByPhoneNo(phoneNum);
        if (lsUser != null) {
            return build.createFailResult(new String[]{"该手机号已经注册，无法再次注册"});
        }

        return forwordMessage(phoneNum, comCode);

    }

    @Override
    public ServiceResult<String, String[]> foreignVerification(String phoneNum, String comCode) {
        ServiceResult.Builder<String, String[]> build = ServiceResult.build(String.class, String[].class);

        LSUser lsUser = userDao.getByPhoneNo(phoneNum);
        if (lsUser == null) {
            return build.createFailResult(new String[]{"该手机号没有注册过，无法修改密码"});
        }

        return forwordMessage(phoneNum, comCode);
    }

    @Override
    public ServiceResult<String, String[]> saveFeedback(FeedbackForm feedbackForm) {
        ServiceResult.Builder<String, String[]> build = ServiceResult.build(String.class, String[].class);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        LSFeedback lsFeedback = new LSFeedback();

        lsFeedback.setId(UUID.randomUUID().toString());
        lsFeedback.setTitle(feedbackForm.getTitle());
        lsFeedback.setContent(feedbackForm.getContent());
        lsFeedback.setPriority(feedbackForm.getPriority());
        lsFeedback.setComCode(CurrentUser.getUser().getComCode());
        lsFeedback.setBeginTime(sdf.format(new Date()));
        feedbackDao.saveFeedback(lsFeedback);

        return build.createSuccessResult("OK");
    }

    @Override
    public ServiceResult<String, String[]> changePhoneNo(String password, String newPhoneNum, String valicode,
                                                         String randomCode) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        String userId = CurrentUser.getUser().getUserId();
        LSAuthentication lsAuthentication = authenticationDao.getAuthentication(userId);
        LSUser lsUser = userDao.getByPhoneNo(newPhoneNum);
        if (lsUser != null) {
            return builder.createFailResult(new String[]{"您的手机号已经注册过！！！"});
        }

        String passWord0 = (lsAuthentication.getPassword()) + randomCode;
        String passWord2 =MD5.stringToMD5(passWord0);
        if (!passWord2.equalsIgnoreCase(password)) {
            return builder.createFailResult(new String[]{"用户密码输入错误"});
        }
        LSVerificationCode lsVerificationCode = verificationCodeDao.findByPhoneNum(newPhoneNum);
        if (lsVerificationCode!= null){
            String createtime = lsVerificationCode.getVerificationTime();
            try {
                Date date = sdf.parse(createtime);
                long time = date.getTime();
                if (System.currentTimeMillis()-time>120*1000){
                    return builder.createFailResult(new String[]{"超过时间，请重新发送"});
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }

        }
        //TODO 前台校验 后台不做校验
/*        if (lsVerificationCode == null || !valicode.equals(lsVerificationCode.getVerificationCode())) {
            return builder.createFailResult(new String[]{"用户校验码错误"});
        }*/

        lsUser = userDao.getUser(userId);
        lsUser.setPhoneNo(newPhoneNum);
        lsUser.setIsPush("N");
        userDao.save(lsUser);
        return builder.createSuccessResult("OK");
    }

    // 银保通 没有注册过手工注册 添加虚拟数据
    @Transactional
    @Override
    public LSUser saveUserByBank(PolicyCoreForm polcyForm) {
        LSUser lsUser = new LSUser();
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        lsUser.setUserId(UUID.randomUUID().toString());
        lsUser.setAgentCode(polcyForm.getAgentCode());
        lsUser.setChannel(polcyForm.getChannel());
        lsUser.setComCode(polcyForm.getComCode());
        lsUser.setIdNo(polcyForm.getAgentCode());
        lsUser.setIsPush("N");
        java.sql.Date currDate = new java.sql.Date(System.currentTimeMillis());
        String currTime = format.format(currDate);
        lsUser.setMakeDate(currDate);
        lsUser.setMakeTime(currTime);
        lsUser.setModifyDate(currDate);
        lsUser.setModifyTime(currTime);
        lsUser.setBrithday("2018-01-01");
        lsUser.setUseFalg("1");
        lsUser.setWorkFlag("0");
        lsUser.setName(polcyForm.getAgentCode());
        lsUser.setOrgCode(polcyForm.getOrgCode());
        lsUser.setSex("0");
        lsUser.setPhoneNo("");
        //通过state字段的值区分银保注册虚拟账号  Y 为银保数据 1 为 app数据
        lsUser.setState('Y');
        //给的客户经理工号，所以将角色设置为 客户经理
        lsUser.setRole("M");
        //保存代理人
        userActionLogService.info("SYSTEM", "create_lsuser", "UserServiceImpl > saveUserByBank \n user: " + lsUser, new Exception());
        userDao.save(lsUser);
        //为代理人创建一个密码 默认密码为 111111
        LSAuthentication lsAuthentication = new LSAuthentication();
        lsAuthentication.setUserId(lsUser.getUserId());
        lsAuthentication.setPassword(MD5.stringToMD5("111111"));
        authenticationDao.save(lsAuthentication);

        return lsUser;
    }


//	// 客户经理 虚拟注册
//	public void saveUserByXuNi(String agentCode,String comCode,String orgCode){
//	    logger.info("ManageCode {} regist ",agentCode);
//	    logger.info("虚拟注册");
//		LSUser lsUser = new LSUser();
//		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
//		lsUser.setUserId(UUID.randomUUID().toString());
//		lsUser.setAgentCode(agentCode);
//		LSChannel channelName = channelDao.findByChannelName("银代");
//		if(channelName!=null){
//			lsUser.setChannel(channelName.getChannelCode());
//		}
//		lsUser.setComCode(comCode);
//		lsUser.setIdNo(agentCode);
//		lsUser.setIsPush("N");
//		java.sql.Date currDate = new java.sql.Date(System.currentTimeMillis());
//		String currTime = format.format(currDate);
//		lsUser.setMakeDate(currDate);
//		lsUser.setMakeTime(currTime);
//		lsUser.setModifyDate(currDate);
//		lsUser.setModifyTime(currTime);
//		lsUser.setBrithday("2018-01-01");
//		lsUser.setUseFalg("1");
//		lsUser.setWorkFlag("0");
//		lsUser.setName(agentCode);
//		lsUser.setOrgCode(orgCode);
//		lsUser.setSex("0");
//		lsUser.setPhoneNo("");
//		//通过state字段的值区分银保注册虚拟账号  Y 为银保数据 1 为 app数据
//		lsUser.setState('Y');
//		//设置角色为客户经理
//		lsUser.setRole("M");
//		//保存代理人
//		userDao.save(lsUser);
//		//为代理人创建一个密码 默认密码为 111111
//		LSAuthentication lsAuthentication = new LSAuthentication();
//		lsAuthentication.setUserId(lsUser.getUserId());
//		lsAuthentication.setPassword(MD5.stringToMD5("111111"));
//		authenticationDao.save(lsAuthentication);
//
//	}


    /**
     * 登录后 根据 用户工号
     **/
    @Override
    public ServiceResult<LSVersion, String[]> userVerSion(String versionId, String type) {
        ServiceResult.Builder<LSVersion, String[]> result = ServiceResult.build(LSVersion.class, String[].class);

        String orgCode = CurrentUser.getUser().getOrgCode();

        LSVersion lsVersion = versionDao.findByIsNewAndComCode("Y", orgCode);
        logger.info("client agentcode versionNum {} server versionnum android {} ios {}",orgCode, versionId, lsVersion.getVersionId(), lsVersion.getVersionIOSId());
        logger.info("version {}", lsVersion);
        if (lsVersion == null) {
            lsVersion = new LSVersion();
            lsVersion.setMessage("2");
            return result.createSuccessResult(lsVersion);
        }
        if (type.equalsIgnoreCase("ios")) {
            if (!versionId.equals(lsVersion.getVersionIOSId())) {
                lsVersion.setMessage("1");
                lsVersion.setVersionPath(lsVersion.getVersionIOSPath());
                lsVersion.setVersionId(lsVersion.getVersionIOSId());
                lsVersion.setVersionFile("");
                lsVersion.setVersionIOSPath("");
                lsVersion.setIsNew("");
                lsVersion.setVersionIOSId("");
                lsVersion.setVersionInfor(lsVersion.getVersionIosInfor());
                return result.createSuccessResult(lsVersion);
            } else {
                lsVersion = new LSVersion();
                lsVersion.setMessage("2");
                return result.createSuccessResult(lsVersion);
            }
        } else if (type.equals("android")) {

            if ((!lsVersion.getVersionId().equals(versionId))) {
//                String path = lsVersion.getVersionFile();
//                File file = new File(path);
//                String md5 = Md5Util.getMD5(file);
                lsVersion.setMessage("1");
                lsVersion.setMd5("123");
                lsVersion.setVersionFile("");
                lsVersion.setVersionIOSPath("");
                lsVersion.setIsNew("");
                lsVersion.setVersionIOSId("");
                return result.createSuccessResult(lsVersion);
            } else {
                lsVersion = new LSVersion();
                lsVersion.setMessage("2");
                return result.createSuccessResult(lsVersion);
            }
        } else {
            return result.createFailResult(new String[]{"设备类型编号错误！"});
        }
    }

    @Override
    public LSUser findByPhoneNo(String phoneNo) {
        return userDao.getByPhoneNo(phoneNo);
    }
}
