package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author SunYu
 * @date 2019/3/8 18:30
 */
@Entity
@Table(name = "LSCMSPICTURE")
public class LSCmsPicture {
    @Id
    @Column(name = "CMSID")
    private String cmsId;
    @Column(name = "CONTNO")
    private String contNo;
    @Column(name = "PICNAME")
    private String picName;
    @Column(name = "PICTYPE")
    private String picType;
    @Column(name = "MAKEDATE")
    private String makeDate;
    @Column(name = "MAKETIME")
    private String makeTime;
    @Column(name = "MODIFYDATE")
    private Date modifyDate;

    public String getCmsId() {
        return cmsId;
    }

    public void setCmsId(String cmsId) {
        this.cmsId = cmsId;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getPicName() {
        return picName;
    }

    public void setPicName(String picName) {
        this.picName = picName;
    }

    public String getPicType() {
        return picType;
    }

    public void setPicType(String picType) {
        this.picType = picType;
    }

    public String getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(String makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    @Override
    public String toString() {
        return "LSCmsPicture{" +
                "cmsId='" + cmsId + '\'' +
                ", contNo='" + contNo + '\'' +
                ", picName='" + picName + '\'' +
                ", picType='" + picType + '\'' +
                ", makeDate='" + makeDate + '\'' +
                ", makeTime='" + makeTime + '\'' +
                ", modifyDate=" + modifyDate +
                '}';
    }
}
