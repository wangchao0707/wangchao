package com.sinosoft.easyrecord.server;

import com.alibaba.fastjson.JSONArray;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.service.PolicyService;
import com.sinosoft.easyrecord.util.HttpUtil;
import com.sinosoft.easyrecord.util.StringUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class BatchStrat {

    private static final Logger logger = LoggerFactory.getLogger(BatchStrat.class);

    @Value(value = "${com.code}")
    private String comCode;

    @Autowired
    private CoreInteractiveFactory coreInteractiveFactory;


    @Autowired
    private PolicyService policyService;

    @Autowired
    private PictureDao pictureDao;

    @Autowired
    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Autowired
    private ContStateDao contStateDao;

    @Value(value = "${message.enable}")
    private boolean messageEnable = false;
    @Value(value = "${message.url}")
    private String messageUrl;

    @Autowired
    private TalkRunTimeDao talkRunTimeDao;

    @Autowired
    private LSStateLocaDao lsStateLocadao;

    @Value(value = "${self.downIsRunable}")
    private boolean downIsRunable;

    @Value(value = "${self.uploadIsRunable}")
    private boolean uploadIsRunable;

    @Value(value = "${self.messageIsRunable}")
    private boolean messageIsRunable = false;

    @Value(value = "${self.userIsRunable}")
    private boolean userIsRunable;

    @Value(value = "${self.sendContStateIsRunable}")
    private boolean sendContStateIsRunable;

    @Value(value = "${self.downSize}")
    private int downSize = 4;

    @Value(value = "${self.uploadSize}")
    private int uploadSize = 4;

    @Value(value = "${self.userSize}")
    private int userSize = 100;

    @Value(value = "${self.messageSize}")
    private int messageSize = 100;

    @Value(value = "${self.sendContStateSize}")
    private int sendContStateSize = 100;

    @Value(value = "${sino-system.nodename}")
    private String nodename;

//    @Value(value = "${cms.updateIsRunable}")
//    private boolean updateIsRunable;


    @Autowired
    private VideoDao videoDao;

    @Autowired
    private ContDao contDao;

    @Autowired
    private MessageDao messageDao;

    @Autowired
    private AppntDao appntDao;


    // 第一次延迟1分钟执行，当执行完后1分钟再执行
    // 下载 定时函数
    @Scheduled(initialDelay = 30000, fixedDelay = 60000)
    public void timerInitDown() {
        logger.info("nodename: {}", nodename);
        if (!downIsRunable) {
            logger.info("downIsRunable::: {},break!!!!!", downIsRunable);
            return;
        }
        // 保单信息
        coreDown();
    }

    /**
     * User: weihao
     * Date: 2019/2/25
     * Time: 14:14
     * 发送消息给E 店
     */
    @Scheduled(initialDelay = 30000, fixedDelay = 60000)
    public void sendMessageStart() {
        logger.info("messageEnable: {}", messageEnable);
        if (!messageEnable) {
            logger.info("messageEnable::: {},break!!!!!", messageEnable);
            return;
        }
        //主体方法
        sendMessage();
    }


    //推送保单最新状态定时函数,5秒执行一次
    @Scheduled(initialDelay = 30000, fixedDelay = 5000)
    public void timeInitContState() {
        if (!sendContStateIsRunable) {
            logger.info("sendContStateIsRunable::: {},break!!!!!", sendContStateIsRunable);
            return;
        }
        //推送保单状态信息
        coreContState();
    }


    // 上传定时函数
    @Scheduled(initialDelay = 30000, fixedDelay = 60000)
    public void timerInitUpload() {
        if (!uploadIsRunable) {
            logger.info("uploadIsRunable::: {},break!!!!!", uploadIsRunable);
            return;
        }
        // 保单信息
        coreUpload();
    }

//    // 超时，获取索引，判断转码是否完成
//    @Scheduled(initialDelay = 30000, fixedDelay = 30000)
//    public void updateVideoState() {
//        if (!updateIsRunable) {
//            logger.info("updateIsRunable::: {},break!!!!!", updateIsRunable);
//            return;
//        }
//        updateVideo();
//    }

    //核心报文定时函数
    @Scheduled(initialDelay = 30000, fixedDelay = 60000)
    public void timerInitMessage() {
        if (!messageIsRunable) {
            logger.info("messageIsRunable::: {},break!!!!!", messageIsRunable);
            return;
        }
        // 保单信息
        coreMeaasge();
    }

    @Scheduled(initialDelay = 60000, fixedDelay = 60000)
    public void timerInitUser() {
        if (!userIsRunable) {
            logger.info("userIsRunable::: {},break!!!!!", userIsRunable);
            return;
        }
        // 代理人信息
        logger.info("进入userIsN的批处理");
        coreUser();
    }

//    /*
//     * 修改保单状态
//     * */
//    public void updateVideo() {
//        List<LSCont.LSContPK> lsContPKS = policyService.queryPKByLastOneAndInteractive('Y', "D");
//        //D状态超时的单子
//        for(LSCont.LSContPK lsContPK : lsContPKS){
//            try{
//                logger.info("D timeout : {}", lsContPK);
//                coreInteractiveFactory.getInstance(comCode).updateVideo(lsContPK);
//            }catch (Exception e){
//                logger.info("bastch updateVideo:{}",e);
//            }
//        }
//    }

    public void coreMeaasge() {
        // 类型为A 为 上传核心报文
        int a = 1;
        List<LSCont.LSContPK> conts2 = policyService.queryPKByLastOneAndInteractive('Y', "A");
        for (LSCont.LSContPK lsContPK : conts2) {
            logger.info("conNo {} submit ", lsContPK.getContNo());
            try {
                coreInteractiveFactory.getInstance(comCode).submitCont(lsContPK);
            } catch (Exception e) {
                logger.info(e.getMessage(), e);
            }
            a++;
            if (a > messageSize) {
                break;
            }
        }
    }

    public void coreUpload() {
        // 类型为 F 为 文件没有上传 去上传文件
        List<LSCont.LSContPK> conts2 = policyService.queryPKByLastOneAndInteractive('Y', "F");
        //增加限制上传个数
        int f = 1;
        for (LSCont.LSContPK lsContPK : conts2) {
            logger.info("contNo {} uploadCloud", lsContPK.getContNo());
            try {
                coreInteractiveFactory.getInstance(comCode).uploadCloud(lsContPK);
            } catch (Exception e) {
                logger.info(e.getMessage(), e);
            }
            f++;
            if (f > uploadSize) {
                break;
            }
        }
    }

    public void coreDown() {
        // 类型为X 为 cos 拉取文件
        int x = 1;
        List<LSCont.LSContPK> conts2 = policyService.queryPKByLastOneAndInteractive('Y', "X");
        for (LSCont.LSContPK lsContPK : conts2) {
            logger.info("conNo {} download ", lsContPK.getContNo());
            try {
                coreInteractiveFactory.getInstance(comCode).downCloud(lsContPK);
            } catch (Exception e) {
                logger.info(e.getMessage(), e);
            }
            x++;
            if (x > downSize) {
                break;
            }
        }

    }

    // 同步 代理人信息
    public void coreUser() {
        List<LSUser> list = userDao.findByIsPush("N");
        if (list != null && list.size() != 0) {
            int u = 1;
            for (LSUser lsUser : list) {
                try {
                    logger.info("批处理同步人员信息查询ispush为N的信息：{}+{}"+lsUser.getUserId(),lsUser.getName());
                    coreInteractiveFactory.getInstance(comCode).dealOneUser(lsUser);
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
                u++;
                if (u > userSize) {
                    break;
                }
            }
        }
    }

    private void coreContState() {
        //类型为N的则推送保单信息
        int cs = 1;
        List<LSStateLoca> list = lsStateLocadao.findByIsSend("N");
        /**
         * 增加 非空判断
         **/
        if (list == null || list.isEmpty()) {
//            logger.info("contstate don't exist");
            return;
        }
        List<LSStateLoca> resList = new ArrayList<>();
        for (LSStateLoca lsStateLocat : list) {
            lsStateLocat.setIsSend("H");//添加中间态
            lsStateLocadao.editStateLoca(lsStateLocat);
            resList.add(lsStateLocat);
            cs++;
            if (cs > sendContStateSize) {
                break;
            }
        }
        coreInteractiveFactory.getInstance(comCode).sendContState(resList, comCode);
    }

    /**
     * e店发送的主体方法
     **/
    public void sendMessage() {
        //查询需要发送消息
        List<LSMessage> messageList = messageDao.findByStatus('H');
        if (messageList!=null && !messageList.isEmpty()){
            for (LSMessage lsMessage:messageList){
                if (lsMessage.getType().equals("S")){
                }else{
                    String clientcontno = lsMessage.getContNo();
                    String busiNum = lsMessage.getBusiNum();
                    LSCont lsCont = contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne("24001","24001",busiNum,'Y');
                    if (lsCont == null){
                        continue;
                    }
                    LSUser lsUser = userDao.getUser(lsCont.getOperator());
                    if (lsUser ==  null){
                        continue;
                    }
                    String agentCode = lsUser.getAgentCode() == null?"1234":lsUser.getAgentCode();
                    LSAppnt lsAppnt = appntDao.findByContNo(lsCont.getContNo());
                    sendMessageInfo(agentCode,busiNum,lsAppnt.getName(),lsMessage.getType());
                }
                //修改保单状态
                lsMessage.setState('F');
                messageDao.save(lsMessage);

            }
        } else {
            logger.info("sendMessage is null");
        }
    }

    private void sendMessageInfo(String agentCode, String busiNum, String appntName,String type) {
        //组织封装数据
        JSONObject sendMap = new JSONObject();
        sendMap.put("sendType", "1");
        sendMap.put("sendTo", agentCode);
        sendMap.put("dataSource", "sl");
        sendMap.put("title", "质检消息");
        sendMap.put("msgType", "sl01");
        sendMap.put("topMsgType", "01");
        if (type.equals("L")) {
            sendMap.put("message", "亲爱的销售伙伴，您的客户" + appntName + "编号为" + busiNum + "投保单需要重新进行双录，请前往【全部订单】【问题件】模块进行操作。");
        } else if (type.equals("R")) {
            sendMap.put("message", "亲爱的销售伙伴，您的客户" + appntName + "编号为" + busiNum + "投保单录音录像文件质检不通过，请您及时联系客户。");
        } else if (type.equals("Z")){
            sendMap.put("message","亲爱的销售伙伴，您的客户"+appntName+"编号为"+busiNum+"投保单需要重新进行双录，请前往【全部订单】【问题件】模块进行操作。");
        }
        logger.info("sendMessage jsonObject {}",sendMap);
        //把质检消息发送给e店
        //多线程跑
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    HttpUtil.doPost(messageUrl, sendMap.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        thread.start();

    }

    //@Scheduled(initialDelay = 30000, fixedDelay = 60000)
    public void toSendZhengGai() {
        List<LSCont> contList = contDao.findByInteractiveAndIssend("L",0);
        List<LSCont> contList1 = contDao.findByInteractiveAndIssend("S",0);
        List<LSCont> contList2 = contDao.findByInteractiveAndIssend("R",0);
        List<LSCont> contList3 = contDao.findByInteractiveAndIssend("P",0);

        for(LSCont lsCont1:contList){
            List<LSMessage> list = messageDao.findByContNo(lsCont1.getContNo());
            List<LSTalkRunTime> talkRunTimes = talkRunTimeDao.findByContNo(lsCont1.getContNo());
            String time = "";
            if(talkRunTimes == null || talkRunTimes.size() == 0){
                time = "0";
            }else {
                time = talkRunTimes.get(0).getUpdateTime();
            }
            if(list.size() == 0){
                com.alibaba.fastjson.JSONObject jsonObject = sendMessage(lsCont1,new LSMessage(),talkRunTimes,time);
                String status = jsonObject.getString("status");
                if(status.equals("SUCCESS")){
                    lsCont1.setIssend(1);
                    contDao.save(lsCont1);
                }
            }else {
                com.alibaba.fastjson.JSONObject jsonObject = sendMessage(lsCont1,list.get(0),talkRunTimes,time);
                String status = jsonObject.getString("status");
                if(status.equals("SUCCESS")){
                    lsCont1.setIssend(1);
                    contDao.save(lsCont1);
                }
            }

        }
        for(LSCont lsCont1:contList1){
            List<LSMessage> list = messageDao.findByContNo(lsCont1.getContNo());
            List<LSTalkRunTime> talkRunTimes = talkRunTimeDao.findByContNo(lsCont1.getContNo());
            String time = "";
            if(talkRunTimes == null || talkRunTimes.size() == 0){
                time = "0";
            }else {
                time = talkRunTimes.get(0).getUpdateTime();
            }
            if(list.size() == 0){
                com.alibaba.fastjson.JSONObject jsonObject = sendMessage(lsCont1,new LSMessage(),talkRunTimes,time);
                String status = jsonObject.getString("status");
                if(status.equals("SUCCESS")){
                    lsCont1.setIssend(1);
                    contDao.save(lsCont1);
                }
            }else {
                com.alibaba.fastjson.JSONObject jsonObject = sendMessage(lsCont1,list.get(0),talkRunTimes,time);
                String status = jsonObject.getString("status");
                if(status.equals("SUCCESS")){
                    lsCont1.setIssend(1);
                    contDao.save(lsCont1);
                }
            }
        }
        for(LSCont lsCont1:contList2){
            List<LSMessage> list = messageDao.findByContNo(lsCont1.getContNo());
            List<LSTalkRunTime> talkRunTimes = talkRunTimeDao.findByContNo(lsCont1.getContNo());
            String time = "";
            if(talkRunTimes == null || talkRunTimes.size() == 0){
                time = "0";
            }else {
                time = talkRunTimes.get(0).getUpdateTime();
            }
            if(list.size() == 0){
                sendMessage(lsCont1,new LSMessage(),talkRunTimes,time);
            }else {
                sendMessage(lsCont1,list.get(0),talkRunTimes,time);
            }
            if(list.size() == 0){
                com.alibaba.fastjson.JSONObject jsonObject = sendMessage(lsCont1,new LSMessage(),talkRunTimes,time);
                String status = jsonObject.getString("status");
                if(status.equals("SUCCESS")){
                    lsCont1.setIssend(1);
                    contDao.save(lsCont1);
                }
            }else {
                com.alibaba.fastjson.JSONObject jsonObject = sendMessage(lsCont1,list.get(0),talkRunTimes,time);
                String status = jsonObject.getString("status");
                if(status.equals("SUCCESS")){
                    lsCont1.setIssend(1);
                    contDao.save(lsCont1);
                }
            }
        }
        for(LSCont lsCont1:contList3){
            com.alibaba.fastjson.JSONObject json = new com.alibaba.fastjson.JSONObject();
            try {
                json.put("orderSn", lsCont1.getOrderSn());
                json.put("bussNo",lsCont1.getClientContNo());
                json.put("reTryTimes","");
                json.put("operator","system");
                json.put("qcTime", "");

                json.put("qcStatus",lsCont1.getInteractive());

                json.put("qcMsg", "");
                json.put("source", "");
                JSONArray jsonArray = new JSONArray();

                json.put("nodeList", jsonArray);
                String url="";
                String result = HttpUtil.doPost(url, json.toJSONString());
                logger.info("质检结果推送=》{}",result);
                com.alibaba.fastjson.JSONObject resultJson = com.alibaba.fastjson.JSONObject.parseObject(result);
                json = new com.alibaba.fastjson.JSONObject();
                json.put("status", resultJson.getString("status"));
                json.put("message", resultJson.getString("message"));
                if( resultJson.getString("status").equals("SUCCESS")){
                    lsCont1.setIssend(1);
                    contDao.save(lsCont1);
                }

            }catch (Exception e) {
                logger.error("发送请求出现异常",e);
                json = new com.alibaba.fastjson.JSONObject();
                json.put("status", "FAILED");
                json.put("message","请求异常:"+e.getMessage());
            }
        }
        // 保单信息
    }

    private com.alibaba.fastjson.JSONObject sendMessage(LSCont lscont,LSMessage lsmessage,List<LSTalkRunTime>lstalktime,String reTryTimes){
        com.alibaba.fastjson.JSONObject json = new com.alibaba.fastjson.JSONObject();
        try {
            json.put("orderSn", lscont.getOrderSn());
            json.put("bussNo",lscont.getClientContNo());
            json.put("reTryTimes",reTryTimes);
            if(lsmessage.getOcopertor() == null || lsmessage.getOcopertor().equals("")){
                json.put("operator","005");
            }else {
                json.put("operator", lsmessage.getOcopertor());
            }

            if(lsmessage.getIssueDate() == null || lsmessage.getIssueDate().equals("")){
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                json.put("qcTime", simpleDateFormat.format(new Date()));
            }else {
                json.put("qcTime", lsmessage.getIssueDate());
            }


            json.put("qcStatus",lscont.getInteractive());

            json.put("qcMsg", lsmessage.getTitle());
            json.put("source", lsmessage.getSource());
            JSONArray jsonArray = new JSONArray();
            for(LSTalkRunTime ls:lstalktime) {
                JSONObject jsona = new JSONObject();
                jsona.put("stepNo", ls.getTalkPointCode());
                LSPicture lspictrue=pictureDao.findByPkIdAndContNo(ls.getTalkPointCode(), lscont.getContNo());
                jsona.put("rectifyOpinions",lsmessage.getTitle());
                jsona.put("rectifyStatus","0");
                if(lspictrue != null){
                    jsona.put("url", lspictrue.getURL());
                }else{
                    jsona.put("url","");
                }

                jsonArray.add(jsona);
            }
            json.put("nodeList", jsonArray);
            String url="";
            String result = HttpUtil.doPost(url, json.toJSONString());
            logger.info("质检结果推送=》{}",result);
            com.alibaba.fastjson.JSONObject resultJson = com.alibaba.fastjson.JSONObject.parseObject(result);
            json = new com.alibaba.fastjson.JSONObject();
            json.put("status", resultJson.getString("status"));
            json.put("message", resultJson.getString("message"));
        }catch (Exception e) {
            logger.error("发送请求出现异常",e);
            json = new com.alibaba.fastjson.JSONObject();
            json.put("status", "FAILED");
            json.put("message","请求异常:"+e.getMessage());
        }
        return json;
    }
}
