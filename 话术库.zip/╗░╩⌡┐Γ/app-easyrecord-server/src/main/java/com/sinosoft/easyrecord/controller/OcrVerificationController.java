package com.sinosoft.easyrecord.controller;

import java.io.IOException;

import javax.annotation.Resource;
//import net.minidev.json.JSONObject;
import com.alibaba.fastjson.JSONObject;
import com.sinosoft.easyrecord.utils.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.codec.binary.Base64;
import com.aegonthtf.wzeus.util.Base64ForImg;
import com.aegonthtf.wzeus.util.EncryptDESUtils;
//import com.qcloud.Utilities.Json.JSONObject;
import com.sinosoft.easyrecord.service.OcrVerificationService;
/**
 * Created by  yulong
 * on  date 2020-05-11
 * time 12:00
 */
@RestController
@RequestMapping("/Ocr")
public class OcrVerificationController {
	 @Resource
	    private OcrVerificationService ocrVerificationService;
	/**
     * ocr证件照扫描
     *
	 * @return*/
	  @RequestMapping(value = "/Verification", method = RequestMethod.POST)
	  @ResponseBody
	  public JSONObject OcrVerification(@RequestParam(value = "Verification") MultipartFile IdImgFile){
		JSONObject reqObject = new JSONObject();
		JSONObject header = new JSONObject();
		header.put("Source","easyRecord");
		header.put("ServerName", "FaceRecognize_GETIDCARDINFO");
		JSONObject body= new JSONObject();
        //对字节数组Base64编码
		  String pic = null;
		Base64ForImg encoder = new Base64ForImg();
		  if(!IdImgFile.isEmpty()) {
			  try {
				  pic = Base64.encodeBase64String(IdImgFile.getBytes());
			  } catch (IOException e) {
				  // TODO Auto-generated catch block
				  e.printStackTrace();
			  }
		  }
		body.put("Image",pic);//base64编码照片流字符串
		JSONObject object = new JSONObject();
		object.put("header",header);
		object.put("body",body);
		String enctyptStr = EncryptDESUtils.encryptBasedDes(object.toString(),"2Bqv9fuXaSWnDY91fFTlClsK7DEfPnEFkd0xjBOkqZ8ODItC9lJ5U0");
		reqObject.put("request", enctyptStr);
		JSONObject jsonObject = ocrVerificationService.httpClientPost(reqObject);
		JSONObject info = jsonObject.getJSONObject("info");
		if (!StringUtils.isEmpty(info)){
			Object number = info.get("number");
			if (!StringUtils.isEmpty(number)){ //识别正面
				info.put("authority",null);
				info.put("timelimit",null);
				jsonObject.getJSONObject("validity").put("authority",false);
				jsonObject.getJSONObject("validity").put("timelimit",false);
			}else{
				if (!StringUtils.isEmpty("authority")){ //识别反面
					jsonObject.put("state","2");
					jsonObject.put("message","身份证服务失败，当前不能识别反面");
					jsonObject.remove("validity");
					jsonObject.remove("info");
					jsonObject.remove("type");
				}
			}
		}else{

		}
		return jsonObject;
	  }
  

	
}
