package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyReq81019.PRODUCTMANAGEMENT;
import com.thoughtworks.xstream.XStream;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.List;

public class ClientTest {

    public static void main(String[] args) {

        String inputXml ="<TRANSDATA>" + "  <TRANSHEAD>" + "    <VERSION>1.0</VERSION>"
                + "    <SYSCODE>002</SYSCODE>" + "    <TRANUSER>admin</TRANUSER>"
                + "    <TRANPASSWD>111111</TRANPASSWD>" + "    <COMPANY>24001</COMPANY>"
                + "    <TRANSCODE>81001</TRANSCODE>"
                + "    <BUSINESSNO>e827cf58-f6bd-4c3b-9dc0-4df850ec2e19</BUSINESSNO>" + "  </TRANSHEAD>"
                + "  <TRANSBODY>" + "    <VIDEO>" + "      <DOCCODE>1132321011554119</DOCCODE>"
                + "      <TYPE>A</TYPE>" + "      <HOSTNAME>COS</HOSTNAME>"
                + "      <BUSINESSNO>e827cf58-f6bd-4c3b-9dc0-iiiiii19</BUSINESSNO>"
                + "      <BEFOREBUSINESSNO></BEFOREBUSINESSNO>" + "      <BUSSTYPE>DB</BUSSTYPE>"
                + "      <SUBTYPE>DB001</SUBTYPE>" + "      <CHANNEL>A16</CHANNEL>"
                + "      <NUMPAGES>15</NUMPAGES>" + "      <AGENTID>32062681000095</AGENTID>"
                + "      <AGENTNAME>姚舜菊</AGENTNAME>" + "      <COMPANY>24001</COMPANY>"
                + "      <RISKTYPE>0</RISKTYPE>" + "      <RISKTYPECODE>SA2</RISKTYPECODE>"
                + "      <COMCODE>321200</COMCODE>" + "      <APPNTNAME>张建平</APPNTNAME>"
                + "      <APPNTIDTYPE>4</APPNTIDTYPE>" + "      <APPNTIDNO>320626195305206629</APPNTIDNO>"
                + "      <APPNTIDIMG>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/7c8a415b-c2d4-443f-885f-aaddf51891e9.jpg</APPNTIDIMG>"
                + "      <APPNTBIRTHDAY>1953-05-20</APPNTBIRTHDAY>"
                + "      <APPNTADRESS>江苏省启东市东元镇三圩村二十三组108号</APPNTADRESS>" + "      <APPNTSEX>1</APPNTSEX>"
                + "      <APPNTAGE>55</APPNTAGE>" + "      <INSURDENAME></INSURDENAME>"
                + "      <INSUREDIDTYPE></INSUREDIDTYPE>" + "      <INSUREDIDIMG></INSUREDIDIMG>"
                + "      <INSUREDIDNO></INSUREDIDNO>" + "      <INSUREDBIRTHDAY></INSUREDBIRTHDAY>"
                + "      <INSUREDADRESS></INSUREDADRESS>" + "      <INSUREDSEX></INSUREDSEX>"
                + "      <INSUREDAGE></INSUREDAGE>" + "      <POLAPPLYDATE>2018-04-27 10:05:10</POLAPPLYDATE>"
                + "      <RECDATE>2018-04-27</RECDATE>" + "      <RECTIME>09:44:16</RECTIME>"
                + "      <UPLOADDATE>2018-04-27</UPLOADDATE>" + "      <UPLOADTIME>10:05:10</UPLOADTIME>"
                + "      <BANKCODE></BANKCODE>" + "      <BANKNETWORK></BANKNETWORK>"
                + "      <PROPERSON></PROPERSON>" + "      <RESOURCE>0</RESOURCE>"
                + "      <DATATYPE>0</DATATYPE>" + "      <STATUS>0</STATUS>"
                + "      <QCCONCLUSION></QCCONCLUSION>" + "      <OPERATION>0</OPERATION>"
                + "      <REPEATPERSON>姚舜菊</REPEATPERSON>"
                + "      <REPEATPERSONCODE>32062681000095</REPEATPERSONCODE>" + "  <TALK>"
                + "<APPNTNAME></APPNTNAME><!--投保人姓名 -->                                   "
                + "<INSUREDNAME></INSUREDNAME><!--被保人姓名 --> " + "<COMNAME></COMNAME><!--销售人员所属公司名称--> "
                + "<USERNAME></USERNAME><!--销售人员姓名--> " + "<RISKNAME></RISKNAME><!--保险产品全称—多个产品以逗号隔开--> "
                + "<INTERSECTIONPAYINTV></INTERSECTIONPAYINTV><!--期交产品缴费方式--> "
                + "<INTERSECTIONPREM></INTERSECTIONPREM><!--期交产品保费--> "
                + "<INTERSECTIONPAYENDYEAR></INTERSECTIONPAYENDYEAR><!--期交产品缴费期间--> "
                + "<INTERSECTIONINSUYEAR></INTERSECTIONINSUYEAR><!--期交产品保险期间--> "
                + "<WHOLESALEPREM></WHOLESALEPREM><!--趸交产品保费--> "
                + "<WHOLESALEINSUYEAR></WHOLESALEINSUYEAR><!--趸交产品保险期间--> "
                + "<WHOLESALEHESITATION></WHOLESALEHESITATION><!--趸交产品犹豫期--> " + "  </TALK>"
                + "      <PAGES>" + "        <PAGECOUNT>14</PAGECOUNT>" + "        <PAGE>"
                + "          <FILETYPE>0</FILETYPE>"
                + "          <PAGENAME>a063f340-f601-484f-9e9a-592f6cf16dac</PAGENAME>"
                + "          <PAGESUFFIX>mp4</PAGESUFFIX>"
                + "          <URL>http://1254603590.vod2.myqcloud.com/24324cf4vodtranssh1254603590/4fc9c2ce7447398155721535445/v.f220.m3u8</URL>"
                + "          <RECORDER></RECORDER>" + "          <IMGTIMEPOINT></IMGTIMEPOINT>"
                + "          <DESCRIBEID></DESCRIBEID>" + "          <RECDATE>2018-04-27</RECDATE>"
                + "          <RECTIME>09:44:16</RECTIME>" + "          <RECDURATION>661</RECDURATION>"
                + "          <FILESIZE>191013293</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>832bfc62-bced-497b-89c5-d54acc55f6e6</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/832bfc62-bced-497b-89c5-d54acc55f6e6.jpg</URL>"
                + "          <RECORDER>1</RECORDER>" + "          <IMGTIMEPOINT>112</IMGTIMEPOINT>"
                + "          <DESCRIBEID>5</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>364424</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>87c3aa98-45eb-4e3c-be86-cfa122d49ed0</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/87c3aa98-45eb-4e3c-be86-cfa122d49ed0.jpg</URL>"
                + "          <RECORDER>2</RECORDER>" + "          <IMGTIMEPOINT>123</IMGTIMEPOINT>"
                + "          <DESCRIBEID>6</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>343817</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>a22fd465-acc5-42bd-afa2-50a22baaaa33</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/a22fd465-acc5-42bd-afa2-50a22baaaa33.jpg</URL>"
                + "          <RECORDER>3</RECORDER>" + "          <IMGTIMEPOINT>141</IMGTIMEPOINT>"
                + "          <DESCRIBEID>7</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>351554</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>0ce21741-aa34-4961-a121-5affc3b601e8</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/0ce21741-aa34-4961-a121-5affc3b601e8.jpg</URL>"
                + "          <RECORDER>4</RECORDER>" + "          <IMGTIMEPOINT>157</IMGTIMEPOINT>"
                + "          <DESCRIBEID>8</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>352001</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>311dec50-7401-4d81-a385-d721912848fd</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/311dec50-7401-4d81-a385-d721912848fd.jpg</URL>"
                + "          <RECORDER>5</RECORDER>" + "          <IMGTIMEPOINT>168</IMGTIMEPOINT>"
                + "          <DESCRIBEID>12</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>345394</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>35497777-bb8d-4254-b195-d0c063fab5c3</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/35497777-bb8d-4254-b195-d0c063fab5c3.jpg</URL>"
                + "          <RECORDER>6</RECORDER>" + "          <IMGTIMEPOINT>20</IMGTIMEPOINT>"
                + "          <DESCRIBEID>1</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>353514</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>88e30717-c465-4cba-8713-593a3685ec4c</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/88e30717-c465-4cba-8713-593a3685ec4c.jpg</URL>"
                + "          <RECORDER>7</RECORDER>" + "          <IMGTIMEPOINT>211</IMGTIMEPOINT>"
                + "          <DESCRIBEID>13</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>362977</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>45dd436c-cbe2-4c57-8d6d-187e90c54ae5</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/45dd436c-cbe2-4c57-8d6d-187e90c54ae5.jpg</URL>"
                + "          <RECORDER>8</RECORDER>" + "          <IMGTIMEPOINT>237</IMGTIMEPOINT>"
                + "          <DESCRIBEID>14</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>383866</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>5a512a2e-8cac-47ff-9ebe-de2044b6139d</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/5a512a2e-8cac-47ff-9ebe-de2044b6139d.jpg</URL>"
                + "          <RECORDER>9</RECORDER>" + "          <IMGTIMEPOINT>408</IMGTIMEPOINT>"
                + "          <DESCRIBEID>15</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>327191</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>3a0ab7a1-41c0-4ae5-b4eb-bee642b4555d</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/3a0ab7a1-41c0-4ae5-b4eb-bee642b4555d.jpg</URL>"
                + "          <RECORDER>10</RECORDER>" + "          <IMGTIMEPOINT>41</IMGTIMEPOINT>"
                + "          <DESCRIBEID>2</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>355974</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>36b91a3c-3676-4cab-aa1b-5cd3acdc346c</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/36b91a3c-3676-4cab-aa1b-5cd3acdc346c.jpg</URL>"
                + "          <RECORDER>11</RECORDER>" + "          <IMGTIMEPOINT>52</IMGTIMEPOINT>"
                + "          <DESCRIBEID>3</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>318246</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>d25c240f-bd58-4863-a83e-88b92c1dfa27</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/d25c240f-bd58-4863-a83e-88b92c1dfa27.jpg</URL>"
                + "          <RECORDER>12</RECORDER>" + "          <IMGTIMEPOINT>654</IMGTIMEPOINT>"
                + "          <DESCRIBEID>16</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>369487</FILESIZE>" + "        </PAGE>" + "        <PAGE>"
                + "          <FILETYPE>1</FILETYPE>"
                + "          <PAGENAME>ec1493df-182b-407c-8727-7d161bb5906b</PAGENAME>"
                + "          <PAGESUFFIX>jpg</PAGESUFFIX>"
                + "          <URL>http://bucketr-1254603590.cossh.myqcloud.com/2018-04-27/24001/320000/ec1493df-182b-407c-8727-7d161bb5906b.jpg</URL>"
                + "          <RECORDER>13</RECORDER>" + "          <IMGTIMEPOINT>82</IMGTIMEPOINT>"
                + "          <DESCRIBEID>4</DESCRIBEID>" + "          <RECDATE></RECDATE>"
                + "          <RECTIME></RECTIME>" + "          <RECDURATION></RECDURATION>"
                + "          <FILESIZE>334967</FILESIZE>" + "        </PAGE>" + "      </PAGES>"
                + "    </VIDEO>" + "  </TRANSBODY>" + "</TRANSDATA>";
        System.out.println(inputXml);
        String appUrl = "http://localhost:8080/services/EasyRecord?wsdl";
//        String appUrl ="http://localhost:8081/easyrecord/services/serverService?wsdl";
        try {
            String res = easyScanInterface(inputXml, appUrl);
            System.out.println(res);
            XStream xs1 = new XStream();
            xs1.alias("TRANSDATA", Transdata.class);
            xs1.alias("TRANSBODY", Transbody.class, TransbodyRes.class);
            Transdata tmp = (Transdata) xs1.fromXML(res);
            TransbodyRes transbodyRes = (TransbodyRes) tmp.getTransbody();
            String returncode = transbodyRes.getTRANSRESULT().RETURNCODE;
            String message = transbodyRes.getTRANSRESULT().MESSAGE;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public  static String getReq81019(){
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        th.setTRANSCODE("81019");
        th.setCOMPANY("24001");
        TransbodyReq81019 tb = new TransbodyReq81019();

       PRODUCTMANAGEMENT  prt=new PRODUCTMANAGEMENT();
           prt.setISDEATH("0");
           prt.setISHEALTH("1");
           prt.setPRODUCTID("000019");
           prt.setPRODUCTCODE("03265412314631513123-31111");
           prt.setPRODUCTNAME("指令");
           prt.setPRODUCTTYPENAME("报i西安");
           prt.setPRODUCTTYPECODE("2124543d2a1sd113a");
           prt.setCOMPANYNAME("");
           prt.setBUSINESSTYPECODE("");
           prt.setBUSINESSTYPENAME("");
           prt.setCOMPANYNAME("");
           prt.setGREATNUMBERLIMIT("");
           prt.setTYPE("y");
           prt.setPRODUCTRISKLEVELS("");

        tb.setPRODUCTMANAGEMENT(prt);
        td.setTranshead(th);
        td.setTransbody(tb);


        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
//        xstream.alias("PRODUCTMANAGEMENTS", TransbodyReq81019.PRODUCTMANAGEMENTS.class);
        xstream.alias("PRODUCTMANAGEMENT", PRODUCTMANAGEMENT.class);
//        xstream.addImplicitCollection(TransbodyReq81019.PRODUCTMANAGEMENTS.class, "PRODUCTMANAGEMENT");
        return xstream.toXML(td);


    }



//    public static String getReq70001() {
//        Transdata td = new Transdata();
//        Transhead th = new Transhead();
//        th.setTRANSCODE("81017");
//        th.setCOMPANY("24001");
//
//        TransbodyReq81017 tb = new TransbodyReq81017();
//        TransbodyReq81017.EASYRECORDINFOS   easyrecordinfos=new TransbodyReq81017.EASYRECORDINFOS();
//        List<TransbodyReq81017.EASYRECORDINFO> easyrecordinfoList = new ArrayList<>();
//        for (int i = 0; i < 30; i++) {
//            TransbodyReq81017.EASYRECORDINFO easyrecordinfo =new TransbodyReq81017.EASYRECORDINFO();
//            easyrecordinfo.PRTNO = "0000"+i;//保单的单号
//            easyrecordinfo.UPLOADDATEFIRST = "";
//            easyrecordinfo.UPLOADTIMEFIRST = "";
//            easyrecordinfo.QCRECORDCOUNT = "";
//            easyrecordinfo.UPLOADDATESECOND = "";
//            easyrecordinfo.UPLOADTIMESECOND = "";
//            easyrecordinfo.UPLOADDATETHIRD = "";
//            easyrecordinfo.UPLOADTIMETHIRD = "";
//            easyrecordinfo.QCCONCLUSION = "A";//保单的状态
//            easyrecordinfo.RESOURCE = "";
//            easyrecordinfo.INSPECTDATE = "2018-05-24";//变更的日期
//            easyrecordinfo.INSPECTTIME = "12:00:00";//保单变更的时间
//            easyrecordinfoList.add(easyrecordinfo);
//        }
//        easyrecordinfos.setEASYRECORDINFOLIST(easyrecordinfoList);
//        easyrecordinfos.setEASYRECORDINFOCOUNT(easyrecordinfoList.size()+"");
//        tb.setEASYRECORDINFOS(easyrecordinfos);
//        td.setTransbody(tb);
//        td.setTranshead(th);
//        XStream xstream = new XStream();
//        xstream.aliasSystemAttribute(null, "class");
//        xstream.alias("TRANSDATA", Transdata.class);
//        xstream.alias("EASYRECORDINFOS",TransbodyReq81017.EASYRECORDINFOS.class);
//        xstream.alias("EASYRECORDINFO", TransbodyReq81017.EASYRECORDINFO.class);
//        xstream.addImplicitCollection(TransbodyReq81017.EASYRECORDINFOS.class, "EASYRECORDINFOLIST");
//        return xstream.toXML(td);
//    }


    public static String easyScanInterface(String inputXml, String appUrl) throws Exception {
        String url = appUrl;
        String method = "easyRecord";
        String result = sendService(inputXml, url, method);
        return result;
    }

    /**
     * 发送请求
     *
     * @param xmlStr
     * @param url
     * @param method
     * @return
     * @throws Exception
     */
    private static String sendService(String xmlStr, String url, String method) throws Exception {

        String xml = null;

        RPCServiceClient serviceClient = new RPCServiceClient();

        Options options = serviceClient.getOptions();

        EndpointReference targetEPR = new EndpointReference(url);

        options.setTo(targetEPR);
        options.setAction(method);
        options.setManageSession(true);
        options.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, true);
        // 在创建QName对象时，QName类的构造方法的第一个参数表示WSDL文件的命名空间名，也就是<wsdl:definitions>元素的targetNamespace属性值

//        QName opAddEntry = new QName("sinosoft.platform.webservice.infservice.EasyScanInterface", method);
        QName opAddEntry = new QName("http://infservice.webservice.platform.sinosoft", method);
//        QName opAddEntry = new QName("http://server.easyrecord.sinosoft.com", method);

        // 参数，如果有多个，继续往后面增加即可，不用指定参数的名称

        Object[] opAddEntryArgs = new Object[]{xmlStr};

        // 返回参数类型，这个和axis1有点区别

        // invokeBlocking方法有三个参数，其中第一个参数的类型是QName对象，表示要调用的方法名；

        // 第二个参数表示要调用的WebService方法的参数值，参数类型为Object[]；

        // 第三个参数表示WebService方法的返回值类型的Class对象，参数类型为Class[]。

        // 当方法没有参数时，invokeBlocking方法的第二个参数值不能是null，而要使用new Object[]{}

        // 如果被调用的WebService方法没有返回值，应使用RPCServiceClient类的invokeRobust方法，

        // 该方法只有两个参数，它们的含义与invokeBlocking方法的前两个参数的含义相同

        Class[] classes = new Class[]{String.class};

        xml = (String) serviceClient.invokeBlocking(opAddEntry, opAddEntryArgs, classes)[0];
        serviceClient.cleanupTransport();
        return xml;

    }

//	public static String getRes80004(){
//		Transdata td = new Transdata();
//		Transhead th = new Transhead();
//		TransbodyReq80004 tb = new TransbodyReq80004();
//
//		th.setTRANSCODE("80004");
//		th.setCOMPANY("2001");
//		TransbodyReq80004.GENERATIONS generations = new TransbodyReq80004.GENERATIONS();
//		TransbodyReq80004.GENERATION generation = new TransbodyReq80004.GENERATION();
//
//		generation.VALIDFLAG ="0";
//		generation.APPOINTEDATE = "2017-9-7";
//		generation.APPOINTSDATE = "2017-9-7";
//		generation.COMPANY = "123";
//		generation.AGENTCOM ="123";
//
//		generations.GENERATION.add(generation);
//		generations.GENERATIONCOUNT="1";
//		tb.setGENERATIONS(generations);
//		td.setTranshead(th);
//		td.setTransbody(tb);
//
//		XStream xstream = new XStream();
//		xstream.aliasSystemAttribute(null, "class");
//		xstream.alias("TRANSDATA", Transdata.class);
//		xstream.alias("GENERATIONS", TransbodyReq80004.GENERATIONS.class);
//		xstream.alias("GENERATION", TransbodyReq80004.GENERATION.class);
//		xstream.addImplicitCollection(TransbodyReq80004.GENERATIONS.class, "GENERATION");
//		return xstream.toXML(td);
//	}

    //	public static String getRes80002(){
//		Transdata td = new Transdata();
//		Transhead th = new Transhead();
//		TransbodyReq80002 tb = new TransbodyReq80002();
//
//		th.setTRANSCODE("80002");
//		th.setCOMPANY("2001");
//		TransbodyReq80002.ORGANIZATIONS organizations = new TransbodyReq80002.ORGANIZATIONS();
//		TransbodyReq80002.ORGANIZATION organization = new TransbodyReq80002.ORGANIZATION();
//		organization.COMCODE="110";
//		organization.COMNAME="神祕的机构";
//		organization.COMPANY="00000000";
//
//		organizations.ORGANIZATION.add(organization);
//
//		tb.setORGANIZATIONS(organizations);
//		td.setTranshead(th);
//		td.setTransbody(tb);
//
//		XStream xstream = new XStream();
//		xstream.aliasSystemAttribute(null, "class");
//		xstream.alias("TRANSDATA", Transdata.class);
//		xstream.alias("ORGANIZATIONS", TransbodyReq80002.ORGANIZATIONS.class);
//		xstream.alias("ORGANIZATION", TransbodyReq80002.ORGANIZATION.class);
//		xstream.addImplicitCollection(TransbodyReq80002.ORGANIZATIONS.class, "ORGANIZATION");
//		return xstream.toXML(td);
//	}
    public static String getRes80009() {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransBodyReq80009 tb = new TransBodyReq80009();

        th.setCOMPANY("2001");
        th.setTRANSCODE("80009");
//        TransbodyReq80002.ORGANIZATIONS organizations = new TransbodyReq80002.ORGANIZATIONS();
//        TransbodyReq80002.ORGANIZATION organization = new TransbodyReq80002.ORGANIZATION();
//        organization.COMCODE="110";
//        organization.COMNAME="神祕的机构";
//        organization.COMPANY="00000000";

//        organizations.ORGANIZATION.add(organization);

        tb.AGENTCODE = "1111";
        tb.COMCODE = "121111";
        tb.NAME = "aiaaa";
        tb.USEFLAG = "22";
        tb.WORKFLAG = "22";
        tb.SALECOMCODE = "11";
        tb.SALECOMNAME = "21";
        tb.REGISTERTIME = "2017-09-13 11:03:11";
        td.setTranshead(th);
        td.setTransbody(tb);

        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        return xstream.toXML(td);
    }

    //	public static String getRes80005(){
//		Transdata td = new Transdata();
//		Transhead th = new Transhead();
//		TransBodyReq80005 tb = new TransBodyReq80005();
//
//		th.setTRANSCODE("80005");
//		th.setCOMPANY("1");
//
//		TransBodyReq80005.QCFEEDBACKS backs = new TransBodyReq80005.QCFEEDBACKS();
//		TransBodyReq80005.QCFEEDBACK back = new TransBodyReq80005.QCFEEDBACK();
//
//
//		back.AGENTID="1";
//		back.DOCCODE = "1";
//		back.ISSUEDATE = "1";
//		back.ISSUEDESC = "1";
//		back.ISSUETYPES = "1";
//		back.QCOPERATOR = "1";
//
//		backs.QCFEEDBACK.add(back);
//		backs.QCFEEDBACKCOUNT = "1";
//		backs.BUSINESSNO ="1";
//		tb.setQCFEEDBACKS(backs);
//		td.setTranshead(th);
//		td.setTransbody(tb);
//
//
//		XStream xstream = new XStream();
//		xstream.aliasSystemAttribute(null, "class");
//		xstream.alias("TRANSDATA", Transdata.class);
//		xstream.alias("QCFEEDBACKS", TransBodyReq80005.QCFEEDBACKS.class);
//		xstream.alias("QCFEEDBACK", TransBodyReq80005.QCFEEDBACK.class);
//		xstream.addImplicitCollection(TransBodyReq80005.QCFEEDBACKS.class, "QCFEEDBACK");
//		return xstream.toXML(td);
//	}
//
//
//	public static String getRes80003(){
//		Transdata td = new Transdata();
//		Transhead th = new Transhead();
//		TransBodyReq80003 tb = new TransBodyReq80003();
//
//		th.setTRANSCODE("80003");
//		th.setCOMPANY("1");
//		TransBodyReq80003.VERBALS verbals = new TransBodyReq80003.VERBALS();
//		TransBodyReq80003.VERBAL verbal = new TransBodyReq80003.VERBAL();
//
//		verbal.COMPANY = "1";
//		verbal.DESCRIBEID ="1";
//		verbal.ORDERNO="1";
//		verbal.QCPOINT="1";
//		verbal.QCTRICK="1";
//		verbal.RISKTYPECODE="juvenileInsurance";
//		verbal.RISKTYPENAME="1";
//		verbals.VERBAL.add(verbal);
//		verbals.VERBALCOUNT="1";
//		tb.setVERBALS(verbals);
//		td.setTranshead(th);
//		td.setTransbody(tb);
//
//
//		XStream xstream = new XStream();
//		xstream.aliasSystemAttribute(null, "class");
//		xstream.alias("TRANSDATA", Transdata.class);
//		xstream.alias("VERBALS", TransBodyReq80003.VERBALS.class);
//		xstream.alias("VERBAL", TransBodyReq80003.VERBAL.class);
//		xstream.addImplicitCollection(TransBodyReq80003.VERBALS.class, "VERBAL");
//		return xstream.toXML(td);
//	}
    public static String getRes80007() {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransbodyReq80007 tb = new TransbodyReq80007();

        th.setTRANSCODE("80007");
        th.setCOMPANY("1");
        TransbodyReq80007.CHANNELS channels = new TransbodyReq80007.CHANNELS();
        TransbodyReq80007.CHANNEL channel = new TransbodyReq80007.CHANNEL();
        List<TransbodyReq80007.CHANNEL> list = new ArrayList<TransbodyReq80007.CHANNEL>();
        channel.CHANNELCODE = "2";
        channel.CHANNELNAME = "测试数据4";
        TransbodyReq80007.CHANNEL channe2 = new TransbodyReq80007.CHANNEL();
        channe2.CHANNELCODE = "1";
        channe2.CHANNELNAME = "测试修改数据";
        list.add(channel);
        list.add(channe2);
        channels.CHANNEL = list;
        channels.CHANNELCOUNT = "2";
        tb.setCHANNELS(channels);
        td.setTranshead(th);
        td.setTransbody(tb);


        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("CHANNELS", TransbodyReq80007.CHANNELS.class);
        xstream.alias("CHANNEL", TransbodyReq80007.CHANNEL.class);
        xstream.addImplicitCollection(TransbodyReq80007.CHANNELS.class, "CHANNEL");
        return xstream.toXML(td);
    }

    //
    public static String getReq81008() {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransBodyReq81008 tb = new TransBodyReq81008();

        th.setTRANSCODE("81008");
        th.setCOMPANY("1");

        TransBodyReq81008.QCFEEDBACKS backs = new TransBodyReq81008.QCFEEDBACKS();
        TransBodyReq81008.QCFEEDBACK back = new TransBodyReq81008.QCFEEDBACK();
        TransBodyReq81008.VERBAL verbal = new TransBodyReq81008.VERBAL();
        TransBodyReq81008.QCPOINTS qcpoints = new TransBodyReq81008.QCPOINTS();
        TransBodyReq81008.QCQUESTIONS qcquestions = new TransBodyReq81008.QCQUESTIONS();
        backs.BUSINESSNO = "3ad0515c-83de-4675-9f02-fafb4c4d4498";
        backs.DOCCODE = "123123123123,456456456456,789789789789";
        backs.AGENTID = "1";
        backs.QCOPERATOR = "1";
        backs.AGENTID = "1";
        backs.QCRECORDCOUNT = "1";
        backs.ISFLAG = "1";


        back.ISSUEDATE = "1";
        back.ISSUEDESC = "1";
        back.ISSUETYPES = "1";

        qcpoints.VERBALCOUNT = "1";

        verbal.COMCODE = "1";
        verbal.COMPANY = "1";
        verbal.DESCRIBEID = "1";
        verbal.ORDERNO = "1";
        verbal.QCPOINT = "1";
        verbal.QCTRICK = "1";
        verbal.RISKCODE = "1";
        verbal.RISKNAME = "1";
        verbal.QCPOINTCODE = "1";

        backs.QCQUESTIONS.QCFEEDBACK.add(back);
        backs.QCQUESTIONS.QCFEEDBACKCOUNT = "1";
        backs.BUSINESSNO = "1";
        tb.setQCFEEDBACKS(backs);
        td.setTranshead(th);
        td.setTransbody(tb);


        XStream xs1 = new XStream();
        xs1.aliasSystemAttribute(null, "class");
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransBodyReq81008.class);
        xs1.alias("QCFEEDBACKS", TransBodyReq81008.QCFEEDBACKS.class);
        xs1.alias("QCFEEDBACK", TransBodyReq81008.QCFEEDBACK.class);
        xs1.alias("QCPOINTS", TransBodyReq81008.QCPOINTS.class);
        xs1.alias("VERBAL", TransBodyReq81008.VERBAL.class);
        xs1.addImplicitCollection(TransBodyReq81008.QCQUESTIONS.class, "QCFEEDBACK");
        xs1.addImplicitCollection(TransBodyReq81008.QCPOINTS.class, "VERBAL");
        return xs1.toXML(td);
    }

    public static String getResult() {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(th);
        td.setTransbody(tr);
        XStream xstream = new XStream();
//		xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSBODY", TransbodyRes.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

    public static String getRes81003() {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransBodyReq81003 tb = new TransBodyReq81003();

        th.setTRANSCODE("81003");
        th.setCOMPANY("1");
        TransBodyReq81003.VERBALS verbals = new TransBodyReq81003.VERBALS();
        TransBodyReq81003.VERBAL verbal = new TransBodyReq81003.VERBAL();

        verbal.COMPANY = "1";
        verbal.DESCRIBEID = "1";
        verbal.ORDERNO = "1";
        verbal.QCPOINT = "1";
        verbal.QCTRICK = "1";
        verbal.RISKCODE = "juvenileInsurance";
        verbal.RISKNAME = "1";
        verbal.RISKTYPE = "1";
        verbal.QCPOINTCODE = "1";
        verbals.VERBAL.add(verbal);
        verbals.VERBALCOUNT = "1";
        tb.setVERBALS(verbals);
        td.setTranshead(th);
        td.setTransbody(tb);


        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("VERBALS", TransBodyReq81003.VERBALS.class);
        xstream.alias("VERBAL", TransBodyReq81003.VERBAL.class);
        xstream.addImplicitCollection(TransBodyReq81003.VERBALS.class, "VERBAL");
        return xstream.toXML(td);
    }



}
