package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSTalkNew;

import java.util.List;

/**
 * Created by zf on 2017/7/27.
 */
public interface TalkNewDao {
    List<LSTalkNew> findTalkList(String comCode, String insurComCode, String riskType);

    List<LSTalkNew> findByComCode(String comCode);

    void deleteByComCode(String comCode);

    void save(LSTalkNew lsTalk);

    LSTalkNew findOneByPkId(String pkId);

    List<LSTalkNew> findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(String comCode, String insurComCode, String orgCode, String riskType);


    LSTalkNew findTop1ByTalkPointCode(String talkPointCode);
}
