package com.sinosoft.easyrecord.entity;

import javax.persistence.*;

@Entity
@Table(name = "LSTalkRunTime")
public class LSTalkRunTime {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "PkId")
    private String pkId;
    @Column(name = "RiskType")
    private String riskType;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "Step")
    private String step;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "TaleConent")
    private String taleConent;
    @Column(name = "OrderNum")
    private int orderNum;
    @Column(name = "ComCode")
    private String comCode;
    @Column(name = "OrgCode")
    private String orgCode;
    @Column(name = "InsurComCode")
    private String insurComCode;
    @Column(name = "UpdateTime")
    private String updateTime;
    @Column(name = "BusiNum")
    private String busiNum;
    @Column(name = "Operator")
    private String operator;
    @Column(name = "IsFlag")
    private String isFlag;

    @Column(name = "Type")
    private String type;
    @Column(name = "TalkPointCode")
    private String talkPointCode;
    @Column(name = "isRead")
    private String isRead;

    @Column(name = "contNo")
    private String contNo;

    public String getContNo(){return contNo;}

    public void setContNo(String contNo){this.contNo = contNo;}


    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTalkPointCode() {
        return talkPointCode;
    }

    public void setTalkPointCode(String talkPointCode) {
        this.talkPointCode = talkPointCode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getTaleConent() {
        return taleConent;
    }

    public void setTaleConent(String taleConent) {
        this.taleConent = taleConent;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getInsurComCode() {
        return insurComCode;
    }

    public void setInsurComCode(String insurComCode) {
        this.insurComCode = insurComCode;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getIsFlag() {
        return isFlag;
    }

    public void setIsFlag(String isFlag) {
        this.isFlag = isFlag;
    }

    public LSTalkRunTime() {
        super();
    }

    public LSTalkRunTime(String id, LSTalkNew lsTalk, String updateTime, String busiNum, String operator) {
        super();
        this.id = id;
        this.pkId = lsTalk.getPkid();
        this.riskType = lsTalk.getRiskType();
        this.step = lsTalk.getStep();
        this.taleConent = lsTalk.getTalkContent();
        this.orderNum = lsTalk.getOrderNum();
        this.comCode = lsTalk.getComCode();
        this.orgCode = lsTalk.getOrgCode();
        this.insurComCode = lsTalk.getInsurComCode();
        this.updateTime = updateTime;
        this.busiNum = busiNum;
        this.operator = operator;
    }

    @Override
    public String toString() {
        return "LSTalkRunTime [id=" + id + ", pkId=" + pkId + ", riskType=" + riskType + ", step=" + step
                + ", taleConent=" + taleConent + ", orderNum=" + orderNum + ", comCode=" + comCode + ", orgCode="
                + orgCode + ", insurComCode=" + insurComCode + ", updateTime=" + updateTime + ", busiNum=" + busiNum
                + ", operator=" + operator + ", isFlag=" + isFlag + ", type=" + type + ", talkPointCode="
                + talkPointCode + "]";
    }


}
