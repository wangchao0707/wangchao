package com.sinosoft.easyrecord.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "lstalkruntimebak")
public class LSTalkRunTimeBak {

    @Id
    @Column(name = "BakId")
    private String bakId;
    @Column(name = "Id")
    private String id;
    @Column(name = "PkId")
    private String pkId;
    @Column(name = "RiskType")
    private String riskType;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "Step")
    private String step;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "TaleConent")
    private String taleConent;
    @Column(name = "OrderNum")
    private int orderNum;
    @Column(name = "ComCode")
    private String comCode;
    @Column(name = "OrgCode")
    private String orgCode;
    @Column(name = "InsurComCode")
    private String insurComCode;
    @Column(name = "UpdateTime")
    private String updateTime;
    @Column(name = "BusiNum")
    private String busiNum;
    @Column(name = "Operator")
    private String operator;
    @Column(name = "IsFlag")
    private String isFlag;

    @Column(name = "Type")
    private String type;
    @Column(name = "TalkPointCode")
    private String talkPointCode;
    @Column(name = "ModifyDate")
    private Date modifyDate;
    @Column(name = "ModifyTime")
    private String modifyTime;



    @Column(name = "isRead")
    private String isRead;

    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }

    public LSTalkRunTimeBak(String bakId, LSTalkRunTime lsTalkRunTime, Date modifyDate, String modifyTime) {
        super();
        this.bakId = bakId;
        this.id = lsTalkRunTime.getId();
        this.pkId = lsTalkRunTime.getPkId();
        this.riskType = lsTalkRunTime.getRiskType();
        this.step = lsTalkRunTime.getStep();
        this.taleConent = lsTalkRunTime.getTaleConent();
        this.orderNum = lsTalkRunTime.getOrderNum();
        this.comCode = lsTalkRunTime.getComCode();
        this.orgCode = lsTalkRunTime.getOrgCode();
        this.insurComCode = lsTalkRunTime.getInsurComCode();
        this.updateTime = lsTalkRunTime.getUpdateTime();
        this.busiNum = lsTalkRunTime.getBusiNum();
        this.operator = lsTalkRunTime.getOperator();
        this.isFlag = lsTalkRunTime.getIsFlag();
        this.type = lsTalkRunTime.getType();
        this.talkPointCode = lsTalkRunTime.getTalkPointCode();
        this.modifyDate = modifyDate;
        this.modifyTime = modifyTime;
        this.isRead = lsTalkRunTime.getIsRead();

    }

    public LSTalkRunTimeBak() {
        super();
    }

    public String getBakId() {
        return bakId;
    }

    public void setBakId(String bakId) {
        this.bakId = bakId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getTaleConent() {
        return taleConent;
    }

    public void setTaleConent(String taleConent) {
        this.taleConent = taleConent;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getInsurComCode() {
        return insurComCode;
    }

    public void setInsurComCode(String insurComCode) {
        this.insurComCode = insurComCode;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getIsFlag() {
        return isFlag;
    }

    public void setIsFlag(String isFlag) {
        this.isFlag = isFlag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTalkPointCode() {
        return talkPointCode;
    }

    public void setTalkPointCode(String talkPointCode) {
        this.talkPointCode = talkPointCode;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    @Override
    public String toString() {
        return "LSTalkRunTimeBak [bakId=" + bakId + ", id=" + id + ", pkId=" + pkId + ", riskType=" + riskType
                + ", step=" + step + ", taleConent=" + taleConent + ", orderNum=" + orderNum + ", comCode=" + comCode
                + ", orgCode=" + orgCode + ", insurComCode=" + insurComCode + ", updateTime=" + updateTime
                + ", busiNum=" + busiNum + ", operator=" + operator + ", isFlag=" + isFlag + ", type=" + type
                + ", talkPointCode=" + talkPointCode + ", modifyDate=" + modifyDate + ", modifyTime=" + modifyTime
                + "]";
    }


}
