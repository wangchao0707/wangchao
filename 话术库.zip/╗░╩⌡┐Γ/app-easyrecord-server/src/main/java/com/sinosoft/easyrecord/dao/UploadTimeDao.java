package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSUploadTime;

public interface UploadTimeDao {

    void saveUploadTime(LSUploadTime lsUploadTime);

    LSUploadTime findBySerialNum(String serialNum);

}
