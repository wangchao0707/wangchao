package com.sinosoft.easyrecord.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.dom4j.tree.AbstractElement;
import org.dom4j.tree.DefaultAttribute;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class XmlToJson {


    /**
     * 根据XML内容转换为json
     * @param xmlContent
     * @return
     * @throws Exception
     */
    public static JSONObject xmlContentToJson(String xmlContent) throws Exception {
        SAXReader reader = new SAXReader();
        Document document = reader.read(new ByteArrayInputStream(xmlContent.getBytes("UTF-8")));
        JSONObject jsonObject = new JSONObject();
        //获取根节点元素对象
        Element root = document.getRootElement();
        iterateNodes(root, jsonObject);
        return jsonObject;
    }

    public static JSONObject xmlContentToJson2(String xmlContent) throws Exception {
        SAXReader reader = new SAXReader();
        Document document = reader.read(new ByteArrayInputStream(xmlContent.getBytes("GBK")));
        JSONObject jsonObject = new JSONObject();
        //获取根节点元素对象
        AbstractElement root = (AbstractElement)document.getRootElement();
        iterateNodes(root, jsonObject);
        return jsonObject;
    }

    /**
     * 根据xml文件路径转换为json
     * @param xmlfilePath
     * @return
     * @throws Exception
     */
    public static JSONObject xmlFiletoJson(String xmlfilePath) throws Exception {
        SAXReader reader = new SAXReader();
        Document document = reader.read(new File(xmlfilePath).toString());
        JSONObject jsonObject = new JSONObject();
        //获取根节点元素对象
        Element root = document.getRootElement();
        iterateNodes(root, jsonObject);
        return jsonObject;
    }

    public static void iterateNodes(Element node, JSONObject json){
        //获取当前元素的名称
        String nodeName = node.getName();
        //判断已遍历的JSON中是否已经有了该元素的名称
        if(json.containsKey(nodeName)){
            //该元素在同级下有多个
            Object Object = json.get(nodeName);
            JSONArray array = null;
            if(Object instanceof JSONArray){
                array = (JSONArray) Object;
            }else {
                array = new JSONArray();
                array.add(Object);
            }
            //获取该元素下所有子元素
            List<Element> listElement = node.elements();
            if(listElement.isEmpty()){
                //该元素无子元素，获取元素的值
                String nodeValue = node.getTextTrim();
                array.add(nodeValue);
                json.put(nodeName, array);
                return ;
            }
            //有子元素
            JSONObject newJson = new JSONObject();
            //遍历所有子元素
            for(Element e:listElement){
                //递归
                iterateNodes(e,newJson);
            }
            array.add(newJson);
            json.put(nodeName, array);
            return ;
        }
        //该元素同级下第一次遍历
        //获取该元素下所有子元素
        List<Element> listElement = node.elements();
        if(listElement.isEmpty()){
            //该元素无子元素，获取元素的值
            String nodeValue = node.getTextTrim();
            json.put(nodeName, nodeValue);
            return ;
        }
        //有子节点，新建一个JSONObject来存储该节点下子节点的值
        JSONObject object = new JSONObject();
        //遍历所有一级子节点
        for(Element e:listElement){
            //递归
            iterateNodes(e,object);
        }
        json.put(nodeName, object);
        return ;
    }

    public static void iterateNodes(AbstractElement node, JSONObject json){
        /**
         * 获取节点对应的属性
         */
        List<Attribute> attributeList = getAttributeList(node);
        //获取当前元素的名称
        String nodeName = node.getName();
        //判断已遍历的JSON中是否已经有了该元素的名称
        if(json.containsKey(nodeName)){
            //该元素在同级下有多个
            Object Object = json.get(nodeName);
            JSONArray array = null;
            if(Object instanceof JSONArray){
                array = (JSONArray) Object;
            }else {
                array = new JSONArray();
                if(!"".equals(Object)){
                    array.add(Object);
                }
            }
            //获取该元素下所有子元素
            List<Element> listElement = node.elements();
            if(listElement.isEmpty()){
                //该元素无子元素，获取元素的值
//                boolean flag = false;
                JSONObject jsonObject1 = new JSONObject();
                jsonObject1 = setAttributeValue(attributeList,jsonObject1);
                array.add(jsonObject1);
                String nodeValue = node.getTextTrim();
                if(nodeValue != null && !"".equals(nodeValue)){
                    array.add(nodeValue);
                }
                json.put(nodeName, array);
                return ;
            }
            //有子元素
            //遍历所有子元素
            JSONObject newJson = new JSONObject();
            for(int i=0;i<listElement.size();i++){
                AbstractElement e = (AbstractElement) listElement.get(i);
                //递归
                iterateNodes(e,newJson);
                newJson = setAttributeValue(attributeList,newJson);
            }
            array.add(newJson);
            json.put(nodeName, array);
            return ;
        }
        //该元素同级下第一次遍历
        //获取该元素下所有子元素
        List<Element> listElement = node.elements();
        if(listElement.isEmpty()){
            //该元素无子元素，获取元素的值
            String nodeValue = node.getTextTrim();
            json.put(nodeName, nodeValue);
            return ;
        }
        //有子节点，新建一个JSONObject来存储该节点下子节点的值
        JSONObject object = new JSONObject();
        //遍历所有一级子节点
        for(int i = 0;i<listElement.size();i++){
            AbstractElement e = (AbstractElement)listElement.get(i);
            //递归
            iterateNodes(e,object);
            object = setAttributeValue(attributeList,object);
        }
       /* for(AbstractElement e:listElement){

        }*/
        json.put(nodeName, object);
        return ;
    }
    private static JSONObject setAttributeValue(List<Attribute> attributes, JSONObject finalJson){
        for(Attribute attribute:attributes){
            if(attribute != null){
                String attributeName = attribute.getQualifiedName();
                String attributeValue = attribute.getValue();
                finalJson.put(attributeName,attributeValue);
            }
        }
        return finalJson;
    }
    private static List<Attribute> getAttributeList(AbstractElement node){
        List<Attribute> attributeList = new ArrayList<Attribute>();
        List<Attribute> defaultAttributes = node.attributes();
        for(int i = 0;i<defaultAttributes.size();i++){
            DefaultAttribute defaultAttribute = (DefaultAttribute) defaultAttributes.get(i);
            String attributeName = defaultAttribute.getName();
            Attribute attribute = node.attribute(attributeName);
            if(attribute != null){
                attributeList.add(attribute);
            }
        }
        return attributeList;
    }
}
