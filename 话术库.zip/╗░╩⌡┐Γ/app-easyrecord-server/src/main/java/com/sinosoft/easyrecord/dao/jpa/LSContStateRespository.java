package com.sinosoft.easyrecord.dao.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LsContState;

public interface LSContStateRespository extends JpaRepository<LsContState, String> {


}
