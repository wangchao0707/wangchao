//package com.sinosoft.easyrecord.controller;
//
//import com.sinosoft.easyrecord.service.CmsService;
//import com.yuancore.cms.client.exception.CMSException;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.Map;
//
///**
// * @author SunYu
// * @date 2019/2/25 11:30
// */
//@RestController
//public class CmsTestController {
//    @Autowired
//    private CmsService cmsService;
//    private Logger logger = LoggerFactory.getLogger(CmsTestController.class);
//
//    @RequestMapping("/testCms")
//    public Map testEmail(@RequestParam("filePath") String filePath){
//        logger.info("filePath = " + filePath);
//        return cmsService.testUploadVideo(filePath);
//    }
//
//    @RequestMapping("/getToken")
//    public String getToken(){
//        return cmsService.getToken();
//    }
//
//    @RequestMapping("/getM3u8")
//    public String getM3u8(@RequestParam("objectId") String objectId){
//        return cmsService.getM3u8(objectId);
//    }
//
//    @RequestMapping("/getMeatInfo")
//    public Map getMeat(@RequestParam("objectId") String objectId) throws CMSException {
//        Map map = cmsService.getIndex(objectId);
//        String status = map.get("isbs_transcoding_status").toString();
//        logger.info("status: {}",status);
//        if("TRANS_CODING_FINISHED".equals(status)){
//            logger.info("++++++");
//        }
//        return map;
//    }
//
//    @RequestMapping("/picture")
//    public String getPicture(@RequestParam("objectId") String objectId) throws CMSException {
//        return cmsService.getPicture(objectId, "0", 3);
//    }
//}
