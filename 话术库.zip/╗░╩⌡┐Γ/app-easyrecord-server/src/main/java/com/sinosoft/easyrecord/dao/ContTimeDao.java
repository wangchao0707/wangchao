package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSContTime;

import java.util.List;

public interface ContTimeDao {

    void saveContTime(LSContTime lsContTime);

    LSContTime findContTime(String contNo);

    LSContTime findByContNo(String contNo);

    List<String> findByBusiNum(String busiNum);
}
