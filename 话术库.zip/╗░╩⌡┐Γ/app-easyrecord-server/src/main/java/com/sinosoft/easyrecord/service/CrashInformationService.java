package com.sinosoft.easyrecord.service;


import com.sinosoft.almond.commons.transmit.vo.RequestResult;

public interface CrashInformationService {

    RequestResult saveCrashInformation(String crashInformation, String equipmentInformation);


}
