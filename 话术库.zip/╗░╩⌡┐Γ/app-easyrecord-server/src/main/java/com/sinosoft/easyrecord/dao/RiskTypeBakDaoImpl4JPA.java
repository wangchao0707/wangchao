package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.RiskTypeBakDao;
import com.sinosoft.easyrecord.dao.jpa.LSRiskTypeBakRepository;
import com.sinosoft.easyrecord.entity.LSRiskTypeBak;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by zf on 2017/8/8.
 */
@Component
public class RiskTypeBakDaoImpl4JPA implements RiskTypeBakDao {
    @Autowired
    private LSRiskTypeBakRepository riskTypeBakRepository;

    public void setRiskTypeBakRepository(LSRiskTypeBakRepository riskTypeBakRepository) {
        this.riskTypeBakRepository = riskTypeBakRepository;
    }

    @Override
    public void save(LSRiskTypeBak riskTypeBak) {
        //要不要判断从核心来的comCode

        riskTypeBakRepository.saveAndFlush(riskTypeBak);
    }
}
