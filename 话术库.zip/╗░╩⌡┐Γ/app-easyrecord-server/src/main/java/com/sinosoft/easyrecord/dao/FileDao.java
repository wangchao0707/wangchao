package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSFile;

public interface FileDao {

    LSFile findByContNo(String contNo);

    void saveFileLog(LSFile fileLog);

    void del(String fileID);
}
