package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSAppntRepository;
import com.sinosoft.easyrecord.entity.LSAppnt;

import java.util.List;
import java.util.Optional;

@Component
public class AppntDaoImpl4JPA implements AppntDao {
    @Autowired
    private LSAppntRepository appntRepository;

    public void setAppntRepository(LSAppntRepository appntRepository) {
        this.appntRepository = appntRepository;
    }

    @Override
    public LSAppnt findByAppntNo(String appntNo) {
        Optional<LSAppnt> res = appntRepository.findById(appntNo);
        return res.orElse(null);
    }

    @Override
    public void save(LSAppnt appnt) {
        appntRepository.saveAndFlush(appnt);

    }

    @Override
    public LSAppnt findByContNo(String contNo) {
        return appntRepository.findByContNo(contNo);
    }

    @Override
    public LSAppnt findByClientContNo(String clientContno) {
        return appntRepository.findTop1ByClientContNo(clientContno);
    }

}
