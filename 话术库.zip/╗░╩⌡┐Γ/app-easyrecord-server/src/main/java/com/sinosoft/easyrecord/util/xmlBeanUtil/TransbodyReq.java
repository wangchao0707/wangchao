package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransbodyReq implements Transbody, Serializable {

    private static final long serialVersionUID = -5516458734124140937L;

    private VIDEO VIDEO;

    public VIDEO getVIDEO() {
        return VIDEO;
    }

    public void setVIDEO(VIDEO vIDEO) {
        VIDEO = vIDEO;
    }

    public static class VIDEO {
        public String DOCCODE;//!-- 投保单号码 -->
        public String TYPE;//<!-- 上传类型--新单或问题件 -->
        public String HOSTNAME;//<!-- 服务器名写固定值COS -->
        public String BUSINESSNO;//<!-- 业务流水号 -->
        public String BEFOREBUSINESSNO;//<!-- 上次业务流水号 -->
        public String REQUESTID; //语音转文字标识码
        public String BUSSTYPE;//<!-- 类型--直播（ZB）或点播（DB） -->
        public String SUBTYPE;//<!-- 子类型--直播视频（ZB001）点播视频（DB001） -->
        public String CHANNEL;//<!-- 写固定值1-->
        public String NUMPAGES;//<!-- 文件和图片共有多少个 -->
        public String AGENTID;//<!-- 代理人ID -->
        public String AGENTNAME;//<!-- 代理人姓名 -->
        public String COMPANY;//<!-- 保险所属保险公司 -->
        public String RISKTYPECODE;//<!-- 产品类别编码 -->
        public String COMCODE; //机构编码
        public String APPNTNAME;//<!-- 投保人姓名 -->
        public String APPNTIDTYPE;//<!-- 投保人证件类型 -->
        public String APPNTIDNO;//<!-- 投保人证件号码 -->
        public String APPNTIDIMG; //投保人证件图片 -->
        public String APPNTBIRTHDAY;//<!-- 投保人生日 -->
        public String APPNTADRESS;//<!-- 投保人地址 -->
        public String APPNTSEX;//<!-- 投保人性别 1-男 2-女-->
        public String APPNTAGE;//<!-- 投保人年龄 -->
        public String INSURDENAME;//<!-- 被投保人姓名 -->
        public String INSUREDIDTYPE;//<!-- 被投保人证件类型 -->
        public String INSUREDIDIMG; //被投保人证件图片 -->
        public String INSUREDIDNO;//<!-- 被投保人证件号码 -->
        public String INSUREDBIRTHDAY;//<!-- 被投保人生日 -->
        public String INSUREDADRESS;//!-- 被投保人地址 -->
        public String INSUREDSEX;//<!-- 被投保人性别 1-男 2-女-->
        public String INSUREDAGE;//<!-- 被投保人年龄 -->
        public String POLAPPLYDATE;//<!-- 投保日期 -->
        public String RECDATE; //-视频录制日期-->
        public String RECTIME; //--视频录制时间-->
        public String UPLOADDATE; //--视频上传日期-->
        public String UPLOADTIME; //视频上传时间-->

        public PAGES PAGES;

        public PAGES getPAGES() {
            return PAGES;
        }

        public void setPAGES(PAGES pAGES) {
            PAGES = pAGES;
        }


    }

    public static class PAGES {
        public String PAGECOUNT;
        public List<PAGE> PAGE = new ArrayList<>();
    }

    public static class PAGE {
        public String FILETYPE;//<!-- 文件类型--0-视频或1-图片 -->
        public String PAGENAME;//<!-- 文件名--不带后缀 -->
        public String PAGESUFFIX;//<!-- 文件后缀 -->
        public String URL;//<!-- 图片或视频地址 -->
        public String RECORDER;//<!--图片顺序  第几条数据-->
        public String IMGTIMEPOINT;//<!-- 图片时点 -->
        public String DESCRIBEID;//<!-- 图片对应话术ID -->
        public String RECDATE;//<!-- 录制日期 -->
        public String RECTIME;//<!-- 录制时间 -->
        public String RECDURATION;//<!-- 录制时长 -->
        public String FILESIZE; //文件大小
    }

}
