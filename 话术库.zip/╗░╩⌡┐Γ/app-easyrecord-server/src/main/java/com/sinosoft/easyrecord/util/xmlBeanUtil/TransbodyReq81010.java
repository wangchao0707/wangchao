package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;

//投保单号校验
public class TransbodyReq81010 implements Transbody, Serializable {

    private String DOCCODE;   //<!--投保单号，以逗号隔开-->

    private String RISKTYPECODE; //险种编码

    private String AGENTCODE; //代理人工号

    public String getDOCCODE() {
        return DOCCODE;
    }

    public void setDOCCODE(String dOCCODE) {
        DOCCODE = dOCCODE;
    }

    public String getRISKTYPECODE() {
        return RISKTYPECODE;
    }

    public void setRISKTYPECODE(String RISKTYPECODE) {
        this.RISKTYPECODE = RISKTYPECODE;
    }

    public String getAGENTCODE() {
        return AGENTCODE;
    }

    public void setAGENTCODE(String AGENTCODE) {
        this.AGENTCODE = AGENTCODE;
    }
}
