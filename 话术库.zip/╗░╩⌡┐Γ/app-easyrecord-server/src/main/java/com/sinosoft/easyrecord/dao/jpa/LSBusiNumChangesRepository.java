package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSBusiNumChanges;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by wh on 2018/1/5.
 */
public interface LSBusiNumChangesRepository extends JpaRepository<LSBusiNumChanges, String> {
}
