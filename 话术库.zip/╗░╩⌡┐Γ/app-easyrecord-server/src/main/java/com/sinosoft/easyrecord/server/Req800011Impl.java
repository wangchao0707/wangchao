package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.ws.rs.HEAD;
import javax.xml.namespace.QName;

/*
 * 发送短信验证码
 * */
@Service("req800011")
public class Req800011Impl implements Req800011 {


    @Value(value = "${self.verification.coreUrl}")
    private String coreUrl;

    private static Logger logger = LoggerFactory.getLogger(Req800011Impl.class);


    public String getReq800011(String phoneNum, String code) {

        String inputXml = getReq(phoneNum, code);
        logger.info("phoneNum {} req800011 inputXml {}", phoneNum, inputXml);
        String appUrl = coreUrl;
        String result = "";
        String returncode = null;
        try {
            String method = "easyRecord";
            result = sendService(inputXml, appUrl, method);
            logger.info("phoneNum {} req800011 resultXml {}", phoneNum, result);
            // 解析核心报文
            XStream xs1 = new XStream();
            xs1.alias("TRANSDATA", Transdata.class);
            xs1.alias("TRANSBODY", Transbody.class, TransbodyRes.class);
            Transdata tmp = (Transdata) xs1.fromXML(result);
            TransbodyRes transbodyRes = (TransbodyRes) tmp.getTransbody();
            returncode = transbodyRes.getTRANSRESULT().RETURNCODE;
            String message = transbodyRes.getTRANSRESULT().MESSAGE;
            logger.info("returncode:" + returncode);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return returncode;
    }


    public static String getReq(String phoneNum, String code) {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransbodyReq800011 tb = new TransbodyReq800011();

        th.setCOMPANY("24001");
        th.setTRANSCODE("70002");

        td.setTranshead(th);

        tb.TARGET = phoneNum;
        tb.MSGCONTENT = code;

        td.setTransbody(tb);
        XStream xs1 = new XStream();
        xs1.aliasSystemAttribute(null, "class");
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq800011.class);
        String xmlString = xs1.toXML(td);
//        xmlString = xmlString.replaceAll(" ", "");
//        xmlString = xmlString.replaceAll("\\n", "");
//        xmlString = xmlString.replaceAll("\\r", "");

        return xmlString;
    }

    /**
     * 发送请求
     *
     * @param xmlStr
     * @param url
     * @param method
     * @return
     * @throws Exception
     */
    private static String sendService(String xmlStr, String url, String method) throws Exception {

        String xml = null;

        RPCServiceClient serviceClient = new RPCServiceClient();

        Options options = serviceClient.getOptions();

        EndpointReference targetEPR = new EndpointReference(url);

        options.setTo(targetEPR);
        options.setAction(method);
        options.setManageSession(true);
        options.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, true);
        // 在创建QName对象时，QName类的构造方法的第一个参数表示WSDL文件的命名空间名，也就是<wsdl:definitions>元素的targetNamespace属性值

        QName opAddEntry = new QName("http://infservice.webservice.platform.sinosoft", method);

        // 参数，如果有多个，继续往后面增加即可，不用指定参数的名称

        Object[] opAddEntryArgs = new Object[]{xmlStr};

        // 返回参数类型，这个和axis1有点区别

        // invokeBlocking方法有三个参数，其中第一个参数的类型是QName对象，表示要调用的方法名；

        // 第二个参数表示要调用的WebService方法的参数值，参数类型为Object[]；

        // 第三个参数表示WebService方法的返回值类型的Class对象，参数类型为Class[]。

        // 当方法没有参数时，invokeBlocking方法的第二个参数值不能是null，而要使用new Object[]{}

        // 如果被调用的WebService方法没有返回值，应使用RPCServiceClient类的invokeRobust方法，

        // 该方法只有两个参数，它们的含义与invokeBlocking方法的前两个参数的含义相同

        Class[] classes = new Class[]{String.class};

        xml = (String) serviceClient.invokeBlocking(opAddEntry, opAddEntryArgs, classes)[0];
        serviceClient.cleanupTransport();
        return xml;

    }
}
