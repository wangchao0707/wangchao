package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSBankRepository;
import com.sinosoft.easyrecord.entity.LSBank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * Created by wds on 2018-3-17.
 */
@Component
public class BankDaoImpl4JPA implements BankDao {

    @Autowired
    private LSBankRepository bankRepository;

    public void setBankRepository(LSBankRepository bankRepository) {
        this.bankRepository = bankRepository;
    }

    @Override
    public void save(LSBank lsbank) {
        bankRepository.save(lsbank);
    }

    @Override
    public void delete() {
        bankRepository.deleteAll();
    }

    @Override
    public List<LSBank> getBankList() {
        return bankRepository.findAll();
    }

    @Override
    public LSBank findByBankCode(String bankCode) {
        Optional<LSBank> res = bankRepository.findById(bankCode);
        return res.orElse(null);
    }
}
