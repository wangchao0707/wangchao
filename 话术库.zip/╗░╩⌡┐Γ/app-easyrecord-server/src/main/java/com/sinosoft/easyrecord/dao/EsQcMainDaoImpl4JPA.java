package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.EsQcMainDao;
import com.sinosoft.easyrecord.dao.jpa.EsQcMainRepository;
import com.sinosoft.easyrecord.entity.EsQcMain;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class EsQcMainDaoImpl4JPA implements EsQcMainDao {
    @Autowired
    private EsQcMainRepository esQcMainRepository;
    @Override
    public EsQcMain findMinDateByBusinessNo(String businessNo) {
        return esQcMainRepository.findFirstByBusinessNoOrderByInspectDate(businessNo);
    }

    @Override
    public List<EsQcMain> findByBusinessNoOrderByInspectDate(String businessNo) {
        return esQcMainRepository.findByBusinessNoOrderByInspectDate(businessNo);
    }
}
