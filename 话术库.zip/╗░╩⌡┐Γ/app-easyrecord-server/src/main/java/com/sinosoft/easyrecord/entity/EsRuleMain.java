package com.sinosoft.easyrecord.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "es_rule_main")
@Entity
public class EsRuleMain {

    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "channel")
    private String channel;

    @Column(name = "comcode")
    private String comCode;

    @Column(name = "bankCode")
    private String bankCode;

    @Column(name = "scale")
    private String scale;

    @Column(name = "status")
    private String status;

    @Column(name = "createDateTime")
    private String createDateTime;

    @Column(name = "modifyDateTime")
    private String modifyDateTime;

    @Column(name = "operator")
    private String operator;

    @Column(name = "makeTime")
    private String makeTime;

    @Column(name = "riskTypeCode")
    private String riskTypeCode;

    @Column(name = "appntage")
    private String appntage;

    @Column(name = "operation")
    private String operation;

    @Column(name = "effectbegintime")
    private String effectbegintime;

    @Column(name = "recagent")
    private String recagent;

    @Column(name = "effectendtime")
    private String effectEndTime;

    @Column(name = "province")
    private String province;

    @Column(name = "city")
    private String city;

    @Column(name = "count")
    private String count;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getScale() {
        return scale;
    }

    public void setScale(String scale) {
        this.scale = scale;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateDateTime() {
        return createDateTime;
    }

    public void setCreateDateTime(String createDateTime) {
        this.createDateTime = createDateTime;
    }

    public String getModifyDateTime() {
        return modifyDateTime;
    }

    public void setModifyDateTime(String modifyDateTime) {
        this.modifyDateTime = modifyDateTime;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getRiskTypeCode() {
        return riskTypeCode;
    }

    public void setRiskTypeCode(String riskTypeCode) {
        this.riskTypeCode = riskTypeCode;
    }

    public String getAppntage() {
        return appntage;
    }

    public void setAppntage(String appntage) {
        this.appntage = appntage;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getEffectbegintime() {
        return effectbegintime;
    }

    public void setEffectbegintime(String effectbegintime) {
        this.effectbegintime = effectbegintime;
    }

    public String getRecagent() {
        return recagent;
    }

    public void setRecagent(String recagent) {
        this.recagent = recagent;
    }

    public String getEffectEndTime() {
        return effectEndTime;
    }

    public void setEffectEndTime(String effectEndTime) {
        this.effectEndTime = effectEndTime;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "EsRuleMain{" +
                "id='" + id + '\'' +
                ", channel='" + channel + '\'' +
                ", comCode='" + comCode + '\'' +
                ", bankCode='" + bankCode + '\'' +
                ", scale='" + scale + '\'' +
                ", status='" + status + '\'' +
                ", createDateTime='" + createDateTime + '\'' +
                ", modifyDateTime='" + modifyDateTime + '\'' +
                ", operator='" + operator + '\'' +
                ", makeTime='" + makeTime + '\'' +
                ", riskTypeCode='" + riskTypeCode + '\'' +
                ", appntage='" + appntage + '\'' +
                ", operation='" + operation + '\'' +
                ", effectbegintime='" + effectbegintime + '\'' +
                ", recagent='" + recagent + '\'' +
                ", effectEndTime='" + effectEndTime + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", count='" + count + '\'' +
                '}';
    }
}
