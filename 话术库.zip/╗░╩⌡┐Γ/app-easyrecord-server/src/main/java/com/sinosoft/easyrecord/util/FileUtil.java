package com.sinosoft.easyrecord.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Date;

/**
 * Created by wh on 2018/1/8.
 */
public class FileUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtil.class);
    //复制文件到另一个目录
    public static long forChannel(File f1, File f2){
        FileInputStream in = null;
        FileOutputStream out = null;
        FileChannel inC = null;
        FileChannel outC = null;
        try {
            long time = new Date().getTime();
            int length = 2097152;
            in = new FileInputStream(f1);
            out = new FileOutputStream(f2);
            inC = in.getChannel();
            outC = out.getChannel();
            ByteBuffer b = null;
            while (true) {
                if (inC.position() == inC.size()) {
                    inC.close();
                    outC.close();
                    in.close();
                    out.close();
                    return new Date().getTime() - time;
                }
                if ((inC.size() - inC.position()) < length) {
                    length = (int) (inC.size() - inC.position());
                } else
                    length = 2097152;
                b = ByteBuffer.allocateDirect(length);
                inC.read(b);
                b.flip();
                outC.write(b);
                outC.force(false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null){
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (out != null){
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outC != null){
                try {
                    outC.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (inC != null){
                try {
                    inC.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return 1l;
    }

    public static void writeFile(File file, InputStream inputStream) throws Exception{
        int len;
        byte[] buf = new byte[2048];
        createFile(file);
        try (
             BufferedInputStream bs = new BufferedInputStream(inputStream);
             FileOutputStream fos = new FileOutputStream(file)
        ) {
            while ((len = bs.read(buf)) != -1) {
                fos.write(buf, 0, len);
                fos.flush();
            }
        }
    }

    public static void createFile(File file){
        File parent = file.getParentFile();
        if(!parent.exists()) {
            parent.mkdirs();
        }

        if(!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    
    /**
     * 删除文件
     *
     * @param filePath 文件
     * @return
     */
    public static void deleteFile(String filePath)
    {
        File file = new File(filePath);
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists())
        {
            file.delete();
            LOGGER.info("删除文件成功！");
        }
    }
    

}
