package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSMessageBuk;

public interface MessageBukDao {

    void save(LSMessageBuk lsMessageBuk);
}
