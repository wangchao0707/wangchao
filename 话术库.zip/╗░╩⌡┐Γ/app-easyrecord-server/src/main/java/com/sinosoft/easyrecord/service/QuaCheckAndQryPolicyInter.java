package com.sinosoft.easyrecord.service;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.httpclient.*;

import java.util.Map;

public interface QuaCheckAndQryPolicyInter {
    NameValuePair[] orgnizeRequestData(Map<String,String> params);

    /*JSONObject doQuaCheckAndQryPolicyInfoRequest(Map map);*/

    String doQuaCheck(String data);

    String doQryPolicyInfo(String uniqueNo);

    String doMessageRequest(String data);

    void saveResponseMessage(JSONObject jsonObject,String contno) throws Exception;
}
