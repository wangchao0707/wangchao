package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSMessageRepository;
import com.sinosoft.easyrecord.entity.LSMessage;
import com.sinosoft.easyrecord.util.SortUtil;
import com.sinosoft.easyrecord.vo.QueryMessageForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

/**
 * Created by WinterLee on 2017/7/22.
 */
@Component
public class MessageDaoImpl4JPA implements MessageDao {

    @Autowired
    private LSMessageRepository messageRepository;

    public LSMessageRepository getMessageRepository() {
        return messageRepository;
    }


    @Override
    public Page<LSMessage> getMessageList(QueryMessageForm messageQueryForm) {

        PageRequest request = new PageRequest(messageQueryForm.getPageNo(), messageQueryForm.getPageSize());

        Page<LSMessage> messages = messageRepository.findByUserNoOrderByMakeDateDesc(messageQueryForm.getUserNo(), request);

        return messages;

    }

    @Override
    public LSMessage getMessage(String messageNo) {
        Optional<LSMessage> res = messageRepository.findById(messageNo);
        return res.orElse(null);
    }

    @Override
    public void save(LSMessage message) {
        messageRepository.saveAndFlush(message);
    }

    @Override
    public List<LSMessage> findByContNo(String contNo) {
        return messageRepository.findByContNo(contNo);
    }

    @Override
    public void del(LSMessage lsMessage) {
        messageRepository.delete(lsMessage);
    }


    @Override
    public List<LSMessage> findMessage() {
        Sort sort = SortUtil.basicSort(new SortUtil("makeDate"), new SortUtil("makeTime"));

        return messageRepository.findAll(sort);
    }

    @Override
    public List<LSMessage> findByUserNoOrderByMakeDateDescAndMakeTimeDesc(String userNo) {
        return messageRepository.findByUserNoOrderByMakeDateDescMakeTimeDesc(userNo);
    }

    @Value(value = "${self.pageSize}")
    private int pageSize;

    @Override
    public Page<LSMessage> findByUserNo(String userNo, Date makeDate, String maketime, int pageNo) {
        PageRequest pageRequest = new PageRequest(pageNo, pageSize);
        return messageRepository.findByUserNoAndMakeDateLessThanOrMakeDateAndMakeTimeLessThanEqualOrderByMakeDateDescMakeTimeDesc(userNo, makeDate, makeDate, maketime, pageRequest);
    }

    @Override
    public Long countByUserNo(String userNo) {
        return messageRepository.countByUserNo(userNo);
    }

    @Override
    public Page<LSMessage> findByUserNoOrderByMakeDateDescMakeTimeDesc(String userNo, int pageNo) {
        return messageRepository.findByUserNoOrderByMakeDateDescMakeTimeDesc(userNo, new PageRequest(pageNo, pageSize));
    }

    @Override
    public List<LSMessage> findByStatus(char status) {
        return messageRepository.findTop20ByState(status);
    }

    @Override
    public List<LSMessage> findByBusinum(String businum){
        return messageRepository.findByBusiNum(businum);
    }
}
