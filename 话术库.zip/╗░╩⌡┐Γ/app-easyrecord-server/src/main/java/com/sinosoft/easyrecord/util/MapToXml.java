package com.sinosoft.easyrecord.util;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapToXml {
	 private Map<String, Object> xmlMap = new HashMap<String, Object>();
	 private String rootName="";
	  public void put(String key, Map<String, Object> value) {
		  rootName = key;
		  xmlMap = value;
      }
	  public void close(){
		  xmlMap.clear();
	  }
	  private static void toElement(Object object, Element root) {
		    if(object!=null){
		      if ((object instanceof Number)||
		        (object instanceof Boolean)||
		        (object instanceof String)||
		        (object instanceof Double)||
		        (object instanceof Float)){
		        root.setText(object.toString());
		      }else if (object instanceof Map){
		        mapToElement((Map) object,root);
		      }else if(object instanceof Collection){
		          collToElement((Collection) object,root);
		      }
		    }else{
		      root.setText("");
		    }
		  }
	  /**
	   * map中存放的数据类型有基本类型、用户自定对象
	   * map、list
	   * @param map
	   * @param root
	   */
	  @SuppressWarnings("unchecked")
	  private static void mapToElement(Map<String, Object> map, Element root) {
	    for (Iterator<?> it = map.entrySet().iterator(); it.hasNext();) {
	      Map.Entry entry=(Map.Entry)it.next();
	      String name = (String)entry.getKey();
	      if (null == name) continue ;
	      String[] attriber = name.split("&");
	      String rootName = "";
	      int length = attriber.length;
	      boolean flag = false;
	      if(length>1){
	    	  rootName = attriber[0];
	    	  flag = true;
	      }else{
	    	  rootName = name;
	      }
	      Object value=entry.getValue();
	      Element elementValue=root.addElement(rootName);
	      if(flag){
	    	 for(int i=1;i<length;i++){
	    		 String[] val = attriber[i].split("=");
	    		 elementValue.addAttribute(val[0], val[1]);
	    	 }
	      }
	      toElement(value,elementValue);
	    }
	  }
	  /**
	   * list中存放的数据类型有基本类型、用户自定对象
	   * map、list
	   * @param coll
	   * @param root
	   */
	  @SuppressWarnings("unchecked")
	  private static void collToElement(Collection<?> coll, Element root) {
	    for (Iterator<?> it = coll.iterator(); it.hasNext();) {
	      Object value=it.next();
	      if(coll==value){
	        continue;
	      }
	      if ((value instanceof Number)||
	        (value instanceof Boolean)||
	        (value instanceof String)||
	        (value instanceof Double)||
	        (value instanceof Float)){
	        Class<?> classes = value.getClass();
	        String objName=classes.getName();
	        String elementName=objName.substring(objName.lastIndexOf(".")+1, objName.length());
	        Element elementOfObject = root.addElement(elementName);
	        elementOfObject.setText(value.toString());
	      }else if (value instanceof Map){
	        mapToElement((Map) value,root);
	      }else if(value instanceof Collection){
	        collToElement((Collection) value,root);
	      }else{
	        toElement(value,root);
	      }

	    }
	  }
	  /**
	   * rootName  根节点名
	   * encoding  编码格式
	   * @return
	   */
	 public String toXml(String encoding){
		 String xmlStr="";
		 	try {
				Document xmlDoc = DocumentHelper.createDocument();
				if(xmlMap!=null&&!xmlMap.isEmpty()){
					Element root = xmlDoc.addElement(rootName);
				    toElement(xmlMap,root);
				    OutputFormat format = OutputFormat.createPrettyPrint();
				    format.setEncoding(encoding);    // 指定XML编码
				    StringWriter writerStr = new StringWriter();
				    XMLWriter xmlw = new XMLWriter(writerStr, format);
				    try {
				      xmlw.write(xmlDoc);
				      xmlw.close();
				    } catch (IOException e) {
				    }
				    xmlStr = writerStr.getBuffer().toString();
				}
			} catch (Exception e) {
		 		e.printStackTrace();
			}finally{
				close();
			}
		return xmlStr;
	 }
}
