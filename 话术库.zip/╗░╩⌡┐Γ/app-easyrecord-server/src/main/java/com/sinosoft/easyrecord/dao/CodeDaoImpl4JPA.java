package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LDCodeRepository;
import com.sinosoft.easyrecord.entity.LDCode;
import com.sinosoft.easyrecord.entity.LDCode.LDCodePk;

import java.util.List;
import java.util.Optional;

@Component
public class CodeDaoImpl4JPA implements CodeDao {


    private LDCodeRepository ldCodeRepository;

    @Autowired
    public void setLdCodeRepository(LDCodeRepository ldCodeRepository) {
        this.ldCodeRepository = ldCodeRepository;
    }


    @Override
    public LDCode findCode(LDCodePk lCodePk) {
            Optional<LDCode> res = ldCodeRepository.findById(lCodePk);
        return res.orElse(null);
    }

    @Override
    public LDCode findByCodeRiskType(String codeRistType) {
        return ldCodeRepository.findByCodeRiskType(codeRistType);
    }

    @Override
    public LDCode findByCode(LDCodePk lCodePk) {
        return this.findCode(lCodePk);
    }

    @Override
    public void saveLdCode(LDCode ldCode) {
        ldCodeRepository.saveAndFlush(ldCode);
    }

    @Override
    public List<LDCode> findByCodeType(String codeType) {
        return ldCodeRepository.findAllByCodeType(codeType);
    }

    @Override
    public List<LDCode> findAllByCodeTypeAndCodeRiskType(String CodeType, String codeName) {
        return ldCodeRepository.findAllByCodeTypeAndCodeRiskType(CodeType,codeName);
    }
}
