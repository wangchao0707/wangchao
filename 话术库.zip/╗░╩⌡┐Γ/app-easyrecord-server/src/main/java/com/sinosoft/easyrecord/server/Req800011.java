package com.sinosoft.easyrecord.server;

public interface Req800011 {

    //短信验证码
    String getReq800011(String phoneNum, String code);
}
