package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSMessage;
import com.sinosoft.easyrecord.vo.QueryMessageForm;
import org.springframework.data.domain.Page;

import java.sql.Date;
import java.util.List;


/**
 * Created by WinterLee on 2017/7/22.
 */
public interface MessageDao {

    LSMessage getMessage(String messageNo);

    Page<LSMessage> getMessageList(QueryMessageForm messageQueryForm);

    void save(LSMessage message);

    List<LSMessage> findByContNo(String contNo);

    void del(LSMessage lsMessage);

    List<LSMessage> findMessage();

    List<LSMessage> findByUserNoOrderByMakeDateDescAndMakeTimeDesc(String userNo);

    Page<LSMessage> findByUserNo(String userNo, Date makeDate, String maketime, int pageNo);

    Long countByUserNo(String userNo);

    Page<LSMessage> findByUserNoOrderByMakeDateDescMakeTimeDesc(String userNo, int pageNo);

    List<LSMessage> findByStatus(char status);

    List<LSMessage> findByBusinum(String businum);

}
