package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSUser;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/14.
 */
public interface UserDao {

    LSUser getByIDNoOrPhoneNo(String no);

    LSUser getByIDNo(String idno);

    LSUser getByPhoneNo(String phoneNo);

    //    LSUser getByComInfo(String company, String org, String agentCode);
    LSUser getByComInfo(String company, String agentCode);

    LSUser getUser(String userid);

    void save(LSUser user);

    List<LSUser> findByIsPush(String isPush);

    //增加
    List<LSUser> findAll(String comCode);

    LSUser findByAgentCode(String propersonCode);
    
    boolean findUserByAgentCode(String agentCode);

    LSUser findByUserId(String userId);
    


    //void updateUserbyIdNo(String newPhoneNum, String idNo ,String comCode);

    //LSUser updateUser(LSUser lsUser);

//    LSUser update(LSUser user);


}
