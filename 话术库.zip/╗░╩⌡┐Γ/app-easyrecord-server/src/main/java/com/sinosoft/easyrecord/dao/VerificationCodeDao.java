package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSVerificationCode;

public interface VerificationCodeDao {

    void saveVerificationCode(LSVerificationCode lsVerificationCode);

    LSVerificationCode findByPhoneNum(String phoneNum);

}
