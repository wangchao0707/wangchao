package com.sinosoft.easyrecord.service;

import com.sinosoft.easyrecord.entity.LSFileDown;

import java.util.List;
import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-08
 * Time: 16:26
 * 产品文件下载 service
 */
public interface FileDownService {


    /**
     * 查询全部 列表
     **/
    Map findAll();

}
