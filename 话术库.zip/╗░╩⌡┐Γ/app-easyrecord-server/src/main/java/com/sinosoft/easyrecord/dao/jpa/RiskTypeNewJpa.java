package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LsRiskTypeNew;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RiskTypeNewJpa extends JpaRepository<LsRiskTypeNew,String> {


    List<LsRiskTypeNew> findByContNo(String contNo);
}
