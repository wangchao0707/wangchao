package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.vo.Token;

/**
 * Created by WinterLee on 2017/7/18.
 */
public interface TokenManager {

    Token createToken(String userId);

    ServiceResult<String, String> findUser(String accessToken);

    ServiceResult<Token, String> refresh(String refreshToken);

    void delToken(String userId);

}
