package com.sinosoft.easyrecord.controller;

import com.sinosoft.easyrecord.service.AccessService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Map;

/**
 * Created by  lijunming
 * on  date 2018-11-06
 * time 15:00
 */
@RestController
@RequestMapping("/access")
public class AccessController {
    @Resource
    private AccessService accessService;

    /**
     * 调阅视频
     **/
    @RequestMapping("/Video")
    public Map Video(@RequestBody Map data) {
        return accessService.RequestAccess((data));
    }
}
