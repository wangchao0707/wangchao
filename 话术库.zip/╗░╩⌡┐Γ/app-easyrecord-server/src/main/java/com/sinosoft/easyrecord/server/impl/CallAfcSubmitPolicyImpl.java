package com.sinosoft.easyrecord.server.impl;

public class CallAfcSubmitPolicyImpl {
}
