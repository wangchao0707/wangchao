package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSBusiNum")
public class LSBusiNum {

    @Id
    @Column(name = "BusiNum")
    private String busiNum;
    @Column(name = "ContNo")
    private String contNo;
    @Column(name = "ComCode")
    private String comCode;
    @Column(name = "InsurComCode")
    private String insurComCode;


    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getInsurComCode() {
        return insurComCode;
    }

    public void setInsurComCode(String insurComCode) {
        this.insurComCode = insurComCode;
    }

}
