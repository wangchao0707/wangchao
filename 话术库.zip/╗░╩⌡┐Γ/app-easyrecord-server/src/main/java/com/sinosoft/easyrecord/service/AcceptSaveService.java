package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;

public interface AcceptSaveService {
    String addVideo(String name, String path, String num, String address, String[] nodes, String trans_type);
}
