package com.sinosoft.easyrecord.dto;

import java.io.Serializable;

/**
 * @create 2020/2/29 0029
 */
public class VideoAddress implements Serializable {

    private static final long serialVersionUID = -3272022189890744654L;

    private String downloadUrl; //视频地址
    private String status; //777000 视频已经生成，并已经被解密 777001 文件已经生成，但是从未被解密过
                            //777002 视频文件尚未生成


    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "VideoAddress{" +
                "downloadUrl='" + downloadUrl + '\'' +
                ", status=" + status +
                '}';
    }
}
