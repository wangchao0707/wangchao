package com.sinosoft.easyrecord.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "LDCode")
public class LDCode implements Serializable {


    @EmbeddedId
    private LDCode.LDCodePk ldCodePk;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "CodeName")
    private String codeName;
    @Column(name = "CodeNameEn")
    private String codeNameEn;
    @Column(name = "CodeRiskType")
    private String codeRiskType;
    @Column(name = "Sort")
    private Integer sort;

    public LDCode() {
        this(new LDCodePk());
    }

    public LDCode(LDCodePk pk) {
        this.ldCodePk = pk;
    }

    public String getCodeType() {
        return ldCodePk.getCodeType();
    }

    public void setCodeType(String codeType) {
        ldCodePk.setCodeType(codeType);
    }

    public String getCode() {
        return ldCodePk.getCode();
    }

    public void setCode(String code) {
        ldCodePk.setCode(code);
    }


    public String getCodeName() {
        return codeName;
    }


    public void setCodeName(String codeName) {
        this.codeName = codeName;
    }


    public String getCodeNameEn() {
        return codeNameEn;
    }


    public void setCodeNameEn(String codeNameEn) {
        this.codeNameEn = codeNameEn;
    }


    public String getCodeRiskType() {
        return codeRiskType;
    }

    public void setCodeRiskType(String codeRiskType) {
        this.codeRiskType = codeRiskType;
    }

    public Integer getSort() {
        return sort;
    }


    public void setSort(Integer sort) {
        this.sort = sort;
    }


    @Embeddable
    public static class LDCodePk implements Serializable {
        @Column(name = "CodeType")
        private String codeType;
        @Column(name = "Code")
        private String code;


        public LDCodePk(String codeType, String code) {
            super();
            this.codeType = codeType;
            this.code = code;
        }

        public LDCodePk() {
            super();
        }

        public String getCodeType() {
            return codeType;
        }

        public void setCodeType(String codeType) {
            this.codeType = codeType;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((code == null) ? 0 : code.hashCode());
            result = prime * result + ((codeType == null) ? 0 : codeType.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            LDCodePk other = (LDCodePk) obj;
            if (code == null) {
                if (other.code != null)
                    return false;
            } else if (!code.equals(other.code))
                return false;
            if (codeType == null) {
                if (other.codeType != null)
                    return false;
            } else if (!codeType.equals(other.codeType))
                return false;
            return true;
        }

    }
}
