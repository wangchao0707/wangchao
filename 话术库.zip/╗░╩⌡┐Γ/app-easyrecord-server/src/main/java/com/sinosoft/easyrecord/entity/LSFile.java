package com.sinosoft.easyrecord.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSFile")
public class LSFile implements Serializable {
    @Id
    @Column(name = "FileId")
    private String fileId;
    @Column(name = "ContNo")
    private String contNo;
    @Column(name = "SaveDir")
    private String saveDir;
    @Column(name = "FileName")
    private String fileName;
    @Column(name = "Complete")
    private char complete;
    @Column(name = "BreakPosition")
    private int breakPosition;
    @Column(name = "md5")
    private String md5;

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getSaveDir() {
        return saveDir;
    }

    public void setSaveDir(String saveDir) {
        this.saveDir = saveDir;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public char getComplete() {
        return complete;
    }

    public void setComplete(char complete) {
        this.complete = complete;
    }

    public int getBreakPosition() {
        return breakPosition;
    }

    public void setBreakPosition(int breakPosition) {
        this.breakPosition = breakPosition;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }


}
