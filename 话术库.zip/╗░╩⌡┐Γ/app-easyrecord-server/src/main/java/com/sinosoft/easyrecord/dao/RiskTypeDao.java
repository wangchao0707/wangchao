package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSRiskType;

import java.util.List;

/**
 * Created by zf on 2017/7/27.
 */
public interface RiskTypeDao {
    List<LSRiskType> findByComCodeAndInsurComCode(String comCode, String insurComCode, String orgCode);

    List<LSRiskType> findByComCode(String comCode);

    void deleteByComCode(String comCode);

    void save(LSRiskType lsRiskType);

    LSRiskType findByComCodeAndRiskType(String comCode, String riskType, String orgCode);

}
