package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSTalkNewRepository;
import com.sinosoft.easyrecord.entity.LSTalkNew;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zf on 2017/7/27.
 */
@Component
public class TalkNewDaoImpl4JPA implements TalkNewDao {
    @Autowired
    private LSTalkNewRepository talkRepository;

    @Override
    public List<LSTalkNew> findTalkList(String comCode, String insurComCode, String riskType) {
        List<LSTalkNew> ls = talkRepository.findByComCodeAndInsurComCodeAndRiskTypeOrderByOrderNumAsc(comCode, insurComCode, riskType);
        return ls;
    }

    @Override
    public List<LSTalkNew> findByComCode(String comCode) {
        return talkRepository.findByComCode(comCode);
    }

    @Override
    public void deleteByComCode(String comCode) {
        talkRepository.deleteByComCode(comCode);
        talkRepository.flush();
    }

    @Override
    public void save(LSTalkNew lsTalk) {
        talkRepository.saveAndFlush(lsTalk);
    }

    @Override
    public List<LSTalkNew> findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(String comCode,
                                                                                            String insurComCode, String orgCode, String riskType) {
        return talkRepository.findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(comCode, insurComCode, orgCode, riskType);
    }

    @Override
    public LSTalkNew findOneByPkId(String pkId) {
        return talkRepository.findByPkid(pkId);
    }

    @Override
    public LSTalkNew findTop1ByTalkPointCode(String talkPointCode) {
        return talkRepository.findTop1ByTalkPointCode(talkPointCode);
    }
}
