package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.QCloudPushEvent;

import java.util.List;

public interface QCloudPushEventDao {

    void savePushEvent(QCloudPushEvent pushEvent);

    List<QCloudPushEvent> findTop10ByDealNodeKeyIsNull();

    List<QCloudPushEvent> findByDealNodeKey(String dealNodeKey);

    void assignEvent(QCloudPushEvent event);

    void saveStatus(QCloudPushEvent event);

}
