package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.service.Req81013;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyRes;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transdata;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transhead;
import com.thoughtworks.xstream.XStream;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.util.List;

@Component("serverService")
public class ServerServiceImpl implements ServerService {

    private Logger logger = LoggerFactory.getLogger(ServerServiceImpl.class);



    private Req80005 req80005;

    @Autowired
    public void setReq80005(Req80005 req80005) {
        this.req80005 = req80005;
    }


    private Req81003 req81003;

    @Autowired
    public void setReq81003(Req81003 req81003) {
        this.req81003 = req81003;
    }

    private Req80004 req80004;

    @Autowired
    public void setReq80004(Req80004 req80004) {
        this.req80004 = req80004;
    }

    private Req80003 req80003;

    @Autowired
    public void setReq80003(Req80003 req80003) {
        this.req80003 = req80003;
    }

    private Req80002 req80002;

    @Autowired
    public void setReq80002(Req80002 req80002) {
        this.req80002 = req80002;
    }

    @Autowired
    private Req80007 req80007;

    public void setReq80007(Req80007 req80007) {
        this.req80007 = req80007;
    }

    @Autowired
    private Req80008 req80008;

    public void setReq80008(Req80008 req80008) {
        this.req80008 = req80008;
    }

    @Autowired
    private Req81008 req81008;

    public void setReq81008(Req81008 req81008) {
        this.req81008 = req81008;
    }

    @Autowired
    private Req80009 req80009;

    public void setReq80009(Req80009 req80009) {
        this.req80009 = req80009;
    }

    @Autowired
    private Req81011 req81011;

    public void setReq81011(Req81011 req81011) {
        this.req81011 = req81011;
    }

    @Autowired
    private Req81016 req81016;

    @Autowired
    private Req81015 req81015;


    public void setReq81016(Req81016 req81016) {
        this.req81016 = req81016;
    }

    public void setReq81015(Req81015 req81015) {
        this.req81015 = req81015;
    }

    @Autowired
    private Req81013 req81013;
    public void setReq81013(Req81013 req81013) {
        this.req81013 = req81013;
    }

    @Autowired
    private  Req81019 req81019;

    public void setReq81019(Req81019 req81019) {
        this.req81019 = req81019;
    }

    @Override
    public String easyScanInterface(String xml) {
        logger.info("serverService xml {}", xml);
        String TRANSCODE = "";
        String COMPANY = "";
        StringReader read = new StringReader(xml);
        // 创建新的输入源SAX 解析器将使用 InputSource 对象来确定如何读取 XML 输入
        InputSource source = new InputSource(read);
        SAXReader saxReader = new SAXReader();
        try {
            Document document = saxReader.read(source);
            Element element = document.getRootElement();

            List<Element> elements = element.elements();
            for (Element element2 : elements) {
                List<Element> elements2 = element2.elements();
                for (Element element3 : elements2) {
                    if (element3.getName().equals("TRANSCODE")) {
                        TRANSCODE = element3.getStringValue();
                    }
                    if (element3.getName().equals("COMPANY")) {
                        COMPANY = element3.getStringValue();
                    }
                }
            }
        } catch (DocumentException e) {
            e.printStackTrace();
        }

        if (TRANSCODE.equals("80002")) {
            String result = req80002.req80002(xml);
            return result;
        }
        if (TRANSCODE.equals("80003")) {
            String result = req80003.req80003(xml);
            return result;
        }
        if (TRANSCODE.equals("80004")) {
            String result = req80004.req80004(xml);
            return result;
        }
        if (TRANSCODE.equals("80005")) {
            String result = req80005.req80005(xml);
            return result;
        }
        if (TRANSCODE.equals("80007")) {
            return req80007.getReq80007(xml);
        }
        if (TRANSCODE.equals("80008")) {
            return req80008.getReq80008(xml);
        }
        if (TRANSCODE.equals("81008")) {
            return req81008.getReq81008(xml);
        }
        if (TRANSCODE.equals("80009")) {
            return req80009.getReq80009(xml);
        }
        if (TRANSCODE.equals("81003")) {
            return req81003.getReq81003(xml);
        }
        if (TRANSCODE.equals("81011")) {
            return req81011.getReq81011(xml);
        }

        if (TRANSCODE.equals("81015")) {
            return req81015.getReq81015(xml);
        }

        if (TRANSCODE.equals("81016")) {
            return req81016.getReq81016(xml);
        }
        if (TRANSCODE.equals("81013")) {
            String result = req81013.req81013(xml);
            return result;
        }if (TRANSCODE.equals("81019")) {
            String result = req81019.getReq81019(xml);
            return result;
        }




        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransbodyRes tr = new TransbodyRes();

        th.setTRANSCODE(TRANSCODE);
        th.setCOMPANY(COMPANY);

        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "100027";
        result.MESSAGE = "没有对应接口";

        tr.setTRANSRESULT(result);
        td.setTranshead(th);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }







    }



