package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSStateLoca;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LSStateLocaRepository extends JpaRepository<LSStateLoca, String> {

    List<LSStateLoca> findTop100ByIsSend(String isSend);

    LSStateLoca  findTop1ByBusiNum(String busiNum);
}
