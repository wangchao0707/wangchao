package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSTalkBakRepository;
import com.sinosoft.easyrecord.entity.LSTalkBak;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by zf on 2017/8/8.
 */
@Component
public class TalkBakDaoImpl4JPA implements TalkBakDao {
    @Autowired
    private LSTalkBakRepository talkBakRepository;

    public void setTalkBakRepository(LSTalkBakRepository talkBakRepository) {
        this.talkBakRepository = talkBakRepository;
    }

    @Override
    public void save(LSTalkBak lsTalkBak) {
        talkBakRepository.saveAndFlush(lsTalkBak);
    }
}
