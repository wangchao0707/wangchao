package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSCom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/19.
 */
public interface LSComRepository extends JpaRepository<LSCom, String> {
    //根据登陆或者注册，拿到ComCode，根据ComCode来来查询第一个框里的内容
    //查出来的comtype 用来判断代理人是保险公司（I）的还是代理公司（G）的

    //	//1.保险公司情况(如果是保险公司业务员，那么第一个框就是一个公司)
//	@Query("select ComName,ComType from lscom where ComCode=?")
//	LSCom findByComCode(String comCode);
//
    //2.代理公司(代理公司业务员，那么第一框显示的就是代理公司代理的所有保险公司)
    //查出代理公司代理了多少个保险公司
    @Query("select c from LSCom c where c.comCode in (select r.pk.relaComCode from LSComSignedOnRela r where r.pk.comCode=?1 and r.state='Y')")
    List<LSCom> findByComCode(String comCode);


}
