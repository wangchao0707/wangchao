package com.sinosoft.easyrecord.server;

public interface CallRemoteAfcServiceUtilFactory {

    CallRemoteAfcServiceUtil getInstance(String comcode);
}
