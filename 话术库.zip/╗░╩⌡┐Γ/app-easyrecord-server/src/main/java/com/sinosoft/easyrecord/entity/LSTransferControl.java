package com.sinosoft.easyrecord.entity;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-22
 * Time: 9:57
 * 迁移控制器
 */
@Entity
@Table(name = "LSTransferControl")
public class LSTransferControl {

    @EmbeddedId
    private TransferControlId transferControlId;

    /**
     * 迁移状态控制
     *  N 未处理 H 处理中 F 处理完成 L 处理失败
     **/
    @Column(name = "isEnable")
    private char enable;

    @Column(name = "total")
    private int number;

    @Column(name = "OrderNum")
    private int orderNum;

    @Column(name = "NasPath")
    private String nasPath;

    public TransferControlId getTransferControlId() {
        return transferControlId;
    }

    public void setTransferControlId(TransferControlId transferControlId) {
        this.transferControlId = transferControlId;
    }

    public char getEnable() {
        return enable;
    }

    public void setEnable(char enable) {
        this.enable = enable;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }

    public String getNasPath() {
        return nasPath;
    }

    public void setNasPath(String nasPath) {
        this.nasPath = nasPath;
    }

    @Override
    public String toString() {
        return "LSTransferControl{" +
                "transferControlId=" + transferControlId +
                ", enable=" + enable +
                ", number=" + number +
                ", orderNum=" + orderNum +
                ", nasPath='" + nasPath + '\'' +
                '}';
    }

    @Embeddable
    public static class TransferControlId implements Serializable {

        @Column(name = "OrgCode")
        private String orgCode;

        @Column(name = "Modifydate")
        private Date modifyDate;

        public String getOrgCode() {
            return orgCode;
        }

        public void setOrgCode(String orgCode) {
            this.orgCode = orgCode;
        }

        public Date getModifyDate() {
            return modifyDate;
        }

        public void setModifyDate(Date modifyDate) {
            this.modifyDate = modifyDate;
        }

        @Override
        public String toString() {
            return "TransferControlId{" +
                    "orgCode='" + orgCode + '\'' +
                    ", modifyDate=" + modifyDate +
                    '}';
        }
    }

}
