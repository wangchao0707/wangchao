package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.OrgCodeToCittcBankCode;

public interface OrgCodeToCittcBankCodeDao {

    OrgCodeToCittcBankCode findByAreaCode(String areaCode);

}
