package com.sinosoft.easyrecord.dao.jpa;


import com.sinosoft.easyrecord.entity.LSCrashInformation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LSCrashInformationRepository extends JpaRepository<LSCrashInformation, String> {


}
