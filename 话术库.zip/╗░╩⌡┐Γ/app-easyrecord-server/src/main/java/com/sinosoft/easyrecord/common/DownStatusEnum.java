package com.sinosoft.easyrecord.common;

import java.util.Arrays;

public enum DownStatusEnum {
    VIEWO_CREATE_DECODE("视频已经生成，并已经被解密","777000"),
    VIEWO_CREATE_NO_DECODE("文件已经生成，但是从未被解密过，下载地址为空","777001"),
    VIEWO_NO_CREATE_NO_DECODE("视频文件尚未生成,下载地址为空","777002");

    private String name;
    private String code;


    DownStatusEnum(String name, String code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public  static String parseToDesc(String code){
        DownStatusEnum[] values = DownStatusEnum.values();
        return Arrays.asList(values).stream().filter(value -> code.equals(value.getCode())).map(value -> value.getName()).findAny().orElse(null);
    }
}
