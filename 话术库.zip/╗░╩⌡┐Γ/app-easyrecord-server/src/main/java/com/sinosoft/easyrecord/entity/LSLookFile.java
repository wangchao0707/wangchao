package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 调阅信息表
 * Created by wh on 2018/3/3.
 */
@Entity
@Table(name = "LSLookFile")
public class LSLookFile {

    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "ContNo")
    private String contNo;
    //保单状态
    @Column(name = "ContState")
    private String contState;
    @Column(name = "DownState")
    private String downState;
    // 上传图片状态
    @Column(name = "PicState")
    private String picState;
    // 抽帧状态
    @Column(name = "ScreenShorState")
    private String screenShorState;
    // 上传视频状态
    @Column(name = "VideoState")
    private String videoState;
    // 发送报文 80014 接口 状态
    @Column(name = "MessageState")
    private String messageState;

    //创建表和修改表日期时间
    //增加创建表和修改表的时间
    @Column(name ="makeDate")
    private String makeDate;
    @Column(name="makeTime")
    private String makeTime;
    @Column(name ="modifyDate")
    private String modifyDate;
    @Column(name = "modifyTime")
    private String modifyTime;


    public String getId() {
        return id;
    }

    public void setId(String id) { this.id = id; }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getContState() {
        return contState;
    }

    public void setContState(String contState) {
        this.contState = contState;
    }

    public String getDownState() {
        return downState;
    }

    public void setDownState(String downState) {
        this.downState = downState;
    }

    public String getPicState() {
        return picState;
    }

    public void setPicState(String picState) {
        this.picState = picState;
    }

    public String getScreenShorState() {
        return screenShorState;
    }

    public void setScreenShorState(String screenShorState) {
        this.screenShorState = screenShorState;
    }

    public String getVideoState() {
        return videoState;
    }

    public void setVideoState(String videoState) {
        this.videoState = videoState;
    }

    public String getMessageState() {
        return messageState;
    }

    public void setMessageState(String messageState) {
        this.messageState = messageState;
    }


    public void setMakeDate(String makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeDate() {
        return makeDate;
    }


    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getMakeTime() {
        return makeTime;
    }
    public String getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    @Override
    public String toString() {
        return "LSLookFile{" +
                "id='" + id + '\'' +
                ", contNo='" + contNo + '\'' +
                ", contState='" + contState + '\'' +
                ", downState='" + downState + '\'' +
                ", picState='" + picState + '\'' +
                ", screenShorState='" + screenShorState + '\'' +
                ", videoState='" + videoState + '\'' +
                ", messageState='" + messageState + '\'' +
                '}';
    }
}
