package com.sinosoft.easyrecord.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Arrays;
import java.util.Date;
public class LsBasicOcr {
    @Id
    private String id;
    private String businum;
    private String steptext;
    private String identifyresult;
    private Date identifytime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBusinum() {
        return businum;
    }

    public void setBusinum(String businum) {
        this.businum = businum;
    }

    public String getSteptext() {
        return steptext;
    }

    public void setSteptext(String steptext) {
        this.steptext = steptext;
    }

    public String getIdentifyresult() {
        return identifyresult;
    }

    public void setIdentifyresult(String identifyresult) {
        this.identifyresult = identifyresult;
    }

    public Date getIdentifytime() {
        return identifytime;
    }

    public void setIdentifytime(Date identifytime) {
        this.identifytime = identifytime;
    }

    @Override
    public String toString() {
        return "LsBasicOcr{" +
                "id='" + id + '\'' +
                ", businum='" + businum + '\'' +
                ", steptext='" + steptext + '\'' +
                ", identifyresult='" + identifyresult + '\'' +
                ", identifytime=" + identifytime +
                '}';
    }
}
