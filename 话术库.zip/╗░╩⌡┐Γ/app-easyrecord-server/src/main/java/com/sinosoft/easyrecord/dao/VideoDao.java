package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSVideo;

public interface VideoDao {

    void save(LSVideo lsVideo);

//	LSVideo findByVideoNameAndContNo(String videoName,String ContNo);

    LSVideo findByContNo(String contNo);

    LSVideo findByContNoAndClientContNo(String contNo, String clientContNo);

    LSVideo getVideoStateByCloudFileId(String cloudFileId);
    void  saveVideo(LSVideo lsVideo);
}
