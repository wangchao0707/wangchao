package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSCont;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSContTime;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LSContTimeRepository extends JpaRepository<LSContTime, String> {

    LSContTime findByContNo(String contNo);

    @Query(value = "select ct.zipurl from lsconttime ct where ct.contno in (select contno from lscont where businum=?1) ",nativeQuery = true)
    List<String> findByBusiNum(String busiNum);
}
