package com.sinosoft.easyrecord.transfer;

import com.sinosoft.easyrecord.dao.TransferInfoDao;
import com.sinosoft.easyrecord.entity.LSTransferInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.Transactional;
import java.util.Map;

/**
 * @author SunYu
 * @date 2019/3/26 16:17
 */
@RestController
public class TransferController {
    private static final Logger logger = LoggerFactory.getLogger(TransferController.class);
    @Autowired
    private TransferInfoDao transferInfoDao;
    @RequestMapping(value = "/transferCallBack")
    @Transactional
    public void transferCallBack(@RequestBody Map map){
        logger.info("transfer callBack map : {}",map);
        String objectId = (String) map.get("objectId");
        String contNo = (String) map.get("contNo");
        LSTransferInfo lsTransferInfo = transferInfoDao.findByContNo(contNo);
        lsTransferInfo.setStatus("U");
        transferInfoDao.saveTransferInfo(lsTransferInfo);
    }
}
