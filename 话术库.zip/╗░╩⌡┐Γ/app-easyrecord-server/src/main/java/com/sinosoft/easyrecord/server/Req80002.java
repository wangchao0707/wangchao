package com.sinosoft.easyrecord.server;

public interface Req80002 {

    public String req80002(String xml);
}
