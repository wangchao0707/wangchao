//package com.sinosoft.easyrecord.service;
//
//import com.sinosoft.easyrecord.vo.TransferVideoForm;
//import com.sinosoft.easyrecord.vo.VideoStatusVo;
//import org.springframework.scheduling.annotation.Async;
//
//public interface TransferVideoService {
//
//    @Async
//    void transferVideo(TransferVideoForm param) ;
//    VideoStatusVo getUploadProgress(String contId);
//}
