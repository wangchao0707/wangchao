package com.sinosoft.easyrecord.test;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.activation.URLDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;




/**
 * java mail 工具类 支持多附件添加、远程附件添加、 附件重命名、普通文本内容发送等操作。 并处理了附件中文乱码等问题. 面向的是windows平台
 *
 * @author zpf
 *
 */
public class MailTool {

	/**
	 * 紧急
	 */
	public static final int EMERGENCY = 1;
	/**
	 * 普通
	 */
	public static final int CUSTOM = 3;
	/**
	 * 缓慢
	 */
	public static final int SLOWLY = 5;

	private MailTool() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * 使用新定义的附件名称添加多个附件
	 *
	 * @param from
	 *            邮件的发送方email
	 * @param to
	 *            邮件的接收方email列表
	 * @param user
	 *            发送方email用户
	 * @param password
	 *            发送方email用户密码
	 * @param subject
	 *            邮件的主题
	 * @param content
	 *            邮件的内容
	 * @param filePath
	 *            附件的路径（完整路径）
	 * @param newName
	 *            附件重命名
	 * @param smtpHost
	 *            smtp邮件服务器
	 * @param classProper
	 *            邮件的优先级
	 * @param useValidate
	 *            是否启用用户验证
	 * @return 邮件是否发送成功
	 */
	public static boolean sendEmail(String from, String[] to, String user,
			String password, String subject, String content, String filePath[],
			String newName[], String smtpHost, int classProper,
			boolean useValidate) {
		return MailTool.createSendInfo(from, to, user, password, subject,
				content, filePath, newName, smtpHost, classProper, useValidate);
	}

	/**
	 * 使用单一的附件
	 *
	 * @param from
	 *            邮件的发送方email
	 * @param to
	 *            邮件的接收方email列表
	 * @param user
	 *            发送方email用户
	 * @param password
	 *            发送方email用户密码
	 * @param subject
	 *            邮件的主题
	 * @param content
	 *            邮件的内容
	 * @param filePath
	 *            附件的路径（完整路径）
	 * @param newName
	 *            附件重命名
	 * @param smtpHost
	 *            smtp邮件服务器
	 * @param classProper
	 *            邮件的优先级
	 * @param useValidate
	 *            是否启用用户验证
	 * @return 邮件是否发送成功
	 */
	public static boolean sendEmail(String from, String[] to, String user,
			String password, String subject, String content, String filePath,
			String newName, String smtpHost, int classProper,
			boolean useValidate) {
		String pathArray[] = new String[1];
		pathArray[0] = filePath;
		String newNameArray[] = new String[1];
		newNameArray[0] = newName;
		return MailTool.createSendInfo(from, to, user, password, subject,
				content, pathArray, newNameArray, smtpHost, classProper,
				useValidate);
	}

	/**
	 * 不使用附件
	 *
	 * @param from
	 *            邮件的发送方email
	 * @param to
	 *            邮件的接收方email列表
	 * @param user
	 *            发送方email用户
	 * @param password
	 *            发送方email用户密码
	 * @param subject
	 *            邮件的主题
	 * @param content
	 *            邮件的内容
	 * @param smtpHost
	 *            smtp邮件服务器
	 * @param classProper
	 *            邮件的优先级
	 * @param useValidate
	 *            是否启用用户验证
	 * @return 邮件是否发送成功
	 */
	public static boolean sendEmail(String from, String[] to, String user,
			String password, String subject, String content, String smtpHost,
			int classProper, boolean useValidate) {
		// System.out.println("222222+subject:" + subject);
		return MailTool.createSendInfo(from, to, user, password, subject,
				content, null, null, smtpHost, classProper, useValidate);
	}

	public static boolean sendEmail(String from, String[] to, String user,
			String password, String subject, String content, String[] filePath,
			String smtpHost) {
		return MailTool.sendEmail(from, to, user, password, subject, content,
				filePath, smtpHost, MailTool.CUSTOM, true);
	}

	/**
	 * 使用原始的名字添加多个附件
	 *
	 * @param from
	 *            邮件的发送方email
	 * @param to
	 *            邮件的接收方email列表
	 * @param user
	 *            发送方email用户
	 * @param password
	 *            发送方email用户密码
	 * @param subject
	 *            邮件的主题
	 * @param content
	 *            邮件的内容
	 * @param filePath
	 *            附件的路径（完整路径）
	 * @param smtpHost
	 *            smtp邮件服务器
	 * @param classProper
	 *            邮件的优先级
	 * @param useValidate
	 *            是否启用用户验证
	 * @return 邮件是否发送成功
	 */
	public static boolean sendEmail(String from, String[] to, String user,
			String password, String subject, String content, String filePath[],
			String smtpHost, int classProper, boolean useValidate) {
		return MailTool.createSendInfo(from, to, user, password, subject,
				content, filePath, null, smtpHost, classProper, useValidate);
	}

	/**
	 * 无附件，无验证设定
	 *
	 * @param from
	 *            邮件的发送方email
	 * @param to
	 *            邮件的接收方email列表
	 * @param user
	 *            发送方email用户
	 * @param password
	 *            发送方email用户密码
	 * @param subject
	 *            邮件的主题
	 * @param content
	 *            邮件的内容
	 * @param smtpHost
	 *            smtp邮件服务器
	 * @param classProper
	 *            邮件的优先级
	 * @return 邮件是否发送成功
	 */
	public static boolean sendEmail(String from, String[] to, String user,
			String password, String subject, String content, String smtpHost,
			int classProper) {
		return MailTool.createSendInfo(from, to, user, password, subject,
				content, null, null, smtpHost, classProper, true);
	}

	// /**
	// * 无附件、无验证、无级别设定
	// *
	// * @param from
	// * @param to
	// * @param user
	// * @param password
	// * @param subject
	// * @param content
	// * @param smtpHost
	// * @return 发送邮件是否成功
	// */
	// public static boolean sendEmail(String from, String[] to, String user,
	// String password, String subject, String content, String smtpHost) {
	// System.out.println("hehehe");
	// return sendEmail(from, to, user, password, subject, content, smtpHost,
	// MailTool.CUSTOM, true);
	// }

	/**
	 * 单个附件，无验证、无级别 /** 使用新定义的附件名称添加多个附件
	 *
	 * @param from
	 *            邮件的发送方email
	 * @param to
	 *            邮件的接收方email
	 * @param user
	 *            发送方email用户
	 * @param password
	 *            发送方email用户密码
	 * @param subject
	 *            邮件的主题
	 * @param content
	 *            邮件的内容
	 * @param filePath
	 *            附件的路径（完整路径）
	 * @param newName
	 *            附件重命名
	 * @param smtpHost
	 *            smtp邮件服务器
	 * @return 邮件是否发送成功
	 */
	public static boolean sendEmail(String from, String[] to, String user,
			String password, String subject, String content, String filePath,
			String newName, String smtpHost) {
		return sendEmail(from, to, user, password, subject, content, filePath,
				newName, smtpHost, MailTool.CUSTOM, true);
	}

	private static boolean checkInput(String from, String[] to, String user,
			String password, String subject, String smtpHost,
			boolean useValidate) {
		if (from == null || from.trim().equals(""))
			return false;
		if (to == null)
			return false;
		if (useValidate) {
			if (user == null || user.trim().equals(""))
				return false;
			if (password == null || password.trim().equals(""))
				return false;
		}
		if (subject == null || subject.trim().equals(""))
			return false;
		if (smtpHost == null || smtpHost.trim().equals(""))
			return false;
		return true;
	}

	private static boolean createSendInfo(String from, String[] to,
			String user, String password, String subject, String content,
			String filePath[], String newName[], String smtpHost,
			int classProper, boolean useValidate) {
		if (!checkInput(from, to, user, password, subject, smtpHost,
				useValidate))
			return false;

		if (smtpHost == null) {
			String errMsg = "smtp is null";
			throw new RuntimeException(errMsg);
		}

		String senderAddress = from;

		System.out.println(senderAddress);
		System.out.println(smtpHost);

		// try {
		// Properties props = System.getProperties();
		// props.put("mail.smtp.host", smtpHost);
		// props.put("mail.debug", "true");
		// Session session = null;
		//
		// final String user1 = user;
		// final String pwd = password;
		// System.out.println(user);
		// System.out.println(pwd);
		// if (user != null && pwd != null) {
		// props.put("mail.smtp.auth", "true");
		// props.put("mail.smtp.user", user);// 自己信箱的用户名
		// props.put("mail.smtp.password", pwd);// 信箱密码
		// // System.out.println("auth=true");
		// } else {
		// props.put("mail.smtp.auth", "false");
		// // System.out.println("auth=false");
		// // session = Session.getDefaultInstance(props, null );
		// }
		// session = Session.getInstance(props,
		// new javax.mail.Authenticator() {
		// protected PasswordAuthentication getPasswordAuthentication() {
		// return new PasswordAuthentication(user1, pwd);
		// }
		// });
		//
		// MimeMessage message = new MimeMessage(session);
		// message.addHeader("Content-type", "text/plain");
		// message.setSubject(subject);
		// message.setFrom(new InternetAddress(senderAddress, user));
		//
		// for (String email : to) {
		// // String email = (String) it.next();
		// message.addRecipients(Message.RecipientType.TO, email);
		// }
		//
		// message.setText(content);
		// message.setSentDate(new Date());
		// Transport.send(message);
		// } catch (Exception e) {
		// // String errorMsg = "邮件发送失败";
		// throw new RuntimeException(e);
		// }

		// /////////////////////////////////////////////////////

		Properties props = new Properties();
		props.put("mail.smtp.host", smtpHost);
		// props.put("mail.smtp.auth", String.valueOf(useValidate));
		props.put("mail.smtp.auth", useValidate);
		props.put("mail.debug", "true");

		Session mailSession = null;
		if (useValidate) {
			SmtpAuth auth = new SmtpAuth();
			auth.setAccount(user, password);
			mailSession = Session.getInstance(props, auth);
		} else {
			mailSession = Session.getInstance(props, null);
		}

		Message message = new MimeMessage(mailSession);
		try {
			message.setFrom(new InternetAddress(from));
			int toLenth = to.length;
			InternetAddress toAddressArray[] = new InternetAddress[toLenth];
			for (int i = 0; i < toLenth; i++)
				toAddressArray[i] = new InternetAddress(to[i]);
			message.addRecipients(Message.RecipientType.TO, toAddressArray);

			message.setSubject(subject);
			Multipart multipart = new MimeMultipart(); // 用来封装详细的内容。
			multipart.addBodyPart(MailTool.getContentObject(content));// 普通的内容
			if (filePath != null) {
				String newNames[] = getNewNames(filePath, newName);
				int argLenth = filePath.length;
				int nameLenth = newNames.length;
				if (argLenth <= nameLenth) {
					for (int i = 0; i < argLenth; i++) {
						if (filePath[i].indexOf("http") >= 0)// 是远程文件
						{
							multipart.addBodyPart(MailTool
									.getRemotAddtionalObject(filePath[i],
											newNames[i]));
						} else // 是本地文件
						{
							multipart.addBodyPart(MailTool
									.getLocalAddtionalObject(filePath[i],
											newNames[i]));
						}
					}
				} else
					return false;
			}
			message.setContent(multipart);
			message.setSentDate(new Date());
			message.setHeader("X-Priority", classProper + "");

			message.saveChanges();

			Transport transport = mailSession.getTransport("smtp");
			transport.connect(smtpHost, user, password);
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
			// Transport.send(message, message.getAllRecipients());

			return true;

		} catch (AddressException e) {
			e.printStackTrace();
			return false;
		} catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}
	}

	private static String[] getNewNames(String filePath[], String newName[]) {
		if (filePath == null)
			return null;
		else {
			if (newName == null) {
				ArrayList<String> fileName = new ArrayList<String>();
				int len = filePath.length;
				for (int i = 0; i < len; i++) {
					if (filePath[i].indexOf("http") >= 0)// 是远程文件
						fileName.add(filePath[i].substring(filePath[i]
								.lastIndexOf("/") + 1));
					else
						// 是本地文件
						fileName.add(filePath[i].substring(filePath[i]
								.lastIndexOf("\\") + 1));

				}
				String returnArray[] = new String[fileName.size()];
				return fileName.toArray(returnArray);
			} else {
				ArrayList<String> fileName = new ArrayList<String>();
				int len = filePath.length;
				int nameLen = newName.length;
				String temp = null;
				for (int i = 0; i < len; i++) {
					if (i == nameLen) {
						if (filePath[i].indexOf("http") >= 0)// 是远程文件
							fileName.add(filePath[i].substring(filePath[i]
									.lastIndexOf("/") + 1));
						else
							// 是本地文件
							fileName.add(filePath[i].substring(filePath[i]
									.lastIndexOf("\\") + 1));
					} else {
						temp = newName[i];
						if (temp == null || temp.trim().equals("")) {
							if (filePath[i].indexOf("http") >= 0)// 是远程文件
								fileName.add(filePath[i].substring(filePath[i]
										.lastIndexOf("/") + 1));
							else
								// 是本地文件
								fileName.add(filePath[i].substring(filePath[i]
										.lastIndexOf("\\") + 1));
						} else
							fileName.add(newName[i]);
					}

				}
				String returnArray[] = new String[fileName.size()];
				System.out.println("finale:" + fileName);
				return fileName.toArray(returnArray);
			}
		}
	}

	/**
	 * 利用远程的文件创建一个附件
	 *
	 * @param remotAddtionalObjectUrl
	 *            表示远程文件的一个url 如：http://localhost:8080/jspstudy/email/xx.gif
	 * @param newName
	 *            文件的显示名字，可以和原来的名字不同，默认为文件的原名
	 * @return
	 */
	private static MimeBodyPart getRemotAddtionalObject(
			String remotAddtionalObjectUrl, String newName) {
		MimeBodyPart mdp = new MimeBodyPart();
		URLDataSource ur = null;
		try {
			ur = new URLDataSource(new URL(remotAddtionalObjectUrl));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 注:这里用的参数只能为URL对象,不能为URL字串,
		DataHandler dataHandle = new DataHandler(ur);
		try {
			mdp.setFileName(MimeUtility.encodeText(newName, "GBK", "B"));
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			mdp.setDataHandler(dataHandle);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mdp;

	}

	/**
	 * 普通文本
	 *
	 * @param tcontent
	 * @return
	 */
	private static BodyPart getContentObject(String tcontent) {
		// 设置信件文本内容
		BodyPart mbp = new MimeBodyPart();// 新建一个存放信件内容的BodyPart对象
		try {
			mbp.setContent(
					"<meta http-equiv=Content-Type content=text/html;charset=gb2312>"
							+ tcontent, "text/html;charset=GB2312");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}// 给BodyPart对象设置内容和格式/编码方式

		return mbp;

	}

	/**
	 * 普通文本作为作为附件
	 *
	 * @param content
	 * @param newName
	 * @return
	 */
	private static MimeBodyPart getLocalAddtionalObjectUseContent(
			String content, String newName) {
		MimeBodyPart mdp = new MimeBodyPart();
		DataHandler ur = null;
		ur = new DataHandler(content, "text/plain;charset=gb2312");
		try {
			mdp.setFileName(MimeUtility.encodeText(newName, "GBK", "B"));
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			mdp.setDataHandler(ur);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return mdp;

	}

	/**
	 * 本地文件作为附件 附件标题必须是US-ASCII字符, 所以在发送中文标题的附件时需要编码成US-ASCII字符, 有两种编码方式: B
	 * (BASE64), Q (Quoted-Printable), 这些方法在MimeUtility里都已经做了封装, 所以在发送附件时使用方法:
	 * setFileName(MimeUtility.encodeText(fileName, "GBK"));
	 * 不过现在邮件系统对此处实现的不是很一致, 所以可能有个别邮件系统收到的是乱码, 可根据情况自己选择相应的编码方式.
	 * 如以前提过的直接取ISO8859-1的字节:setFileName(new String(file.getName().getBytes(),
	 * "ISO8859-1"));
	 *
	 * @param LocalAddtionalObjectUrl
	 * @param newName
	 * @return
	 */
	private static MimeBodyPart getLocalAddtionalObject(
			String LocalAddtionalObjectUrl, String newName) {
		MimeBodyPart mdp = new MimeBodyPart();
		FileDataSource ur = null;
		ur = new FileDataSource(LocalAddtionalObjectUrl);
		// 注:这里用的参数只能为URL对象,不能为URL字串.
		DataHandler dataHandle = new DataHandler(ur);
		try {
			mdp.setFileName(MimeUtility.encodeText(newName, "GBK", "B"));
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			mdp.setDataHandler(dataHandle);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return mdp;

	}

	private static class SmtpAuth extends Authenticator {

		private String user;// .;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar;E:\workspace\jmail\src\javaMail\mail.jar;E:\workspace\jmail\src\javaMail\activation.jar

		private String password;

		public SmtpAuth() {
			super();
			// TODO Auto-generated constructor stub
		}

		public void setAccount(String user, String password) {
			// TODO Auto-generated method stub
			this.user = user;
			this.password = password;
		}

		public PasswordAuthentication getPasswordAuthentication() {
			return new PasswordAuthentication(user, password);
		}

	}

	public static void main(String[] args) {
		// String from = "***@sinosoft.com.cn";
//		String[] to = { "lidong@sinosoft.com.cn" };
		String to = "lidong@sinosoft.com.cn" ;
		// String user = null;
		// String password = null;
		// String user = "1";
		// String password = "1";
		String subject = "邮件系统测试";
		String content = "asdfasdfasdf";

		// String newNames[] = { "remoteJIF" };
		// String smtpHost = "SMTP.126.com";
		// String smtpHost = "mail.sinosoft.com.cn";
		// MailTool.sendEmail(from,to,user,password,subject,content,null,smtpHost);
		// boolean res = sendEmail(from, to, user, password, subject, content,
		// smtpHost);

		boolean res = sendEmail(to, subject, content);
		System.out.print("ok    " + res);
	}

	/**
	 * 发送邮件的相关配置信息
	 */
	private static String FROM_EMAIL = null;

	private static String SERVER = null;

	private static String USERCODE = null;

	private static String PASSWORD = null;

	private static int PORT = 25;

	private static boolean USER_VALIDATE = false;

//	static {
//		initData();
//	}

//	public static void initData() {
//
//		LDSysVarDB db = new LDSysVarDB();
//		db.setSysVarType("EM");
//		LDSysVarSet res = db.query();
//
//		if (res.size() > 0) {
//			// for (LDCodeSchema tmpLDCodeSchema : inRs) {
//			for (int i = 1; i <= res.size(); i++) {
//				LDSysVarSchema ldsysvar = res.get(i);
//				String code = ldsysvar.getSysVar();
//				String value = ldsysvar.getSysVarValue();
//				if ("FROM_EMAIL".equals(code)) {
//					FROM_EMAIL = value;
//				} else if ("SERVER".equals(code)) {
//					SERVER = value;
//				} else if ("USERCODE".equals(code)) {
//					USERCODE = value;
//				} else if ("PASSWORD".equals(code)) {
//					PASSWORD = value;
//				} else if ("PORT".equals(code)) {
//					try {
//						PORT = Integer.parseInt(value);
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				} else if ("USER_VALIDATE".endsWith(code)) {
//					try {
//						USER_VALIDATE = Boolean.parseBoolean(value);
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				}
//			}
//
////			if (!USER_VALIDATE) {
////				USERCODE = null;
////				PASSWORD = null;
////			}
//		}
//
//	}

	public static boolean sendEmail(String toEmail, String title, String context) {
//		EmailMessage emailMessage = new EmailMessage();
//		emailMessage.setFrom(FROM_EMAIL);
//		emailMessage.setPort(PORT);
//		emailMessage.setServer(SERVER);
//		emailMessage.setUserName(USERCODE);
//		emailMessage.setPassword(PASSWORD);
//
//		emailMessage.setSubject(title);
//		emailMessage.setTo(toEmail);
//		emailMessage.setContent(context);
		SimpleEmail e = new SimpleEmail();
		e.setHostName(SERVER);// 设置使用发电子邮件的邮件服务器
		e.setSmtpPort(PORT);
		try {
			// 收件人邮箱
			e.addTo(toEmail);
			// 邮箱服务器身份验证
			e.setAuthentication(FROM_EMAIL, PASSWORD);
			// 发件人邮箱
			e.setFrom(FROM_EMAIL);
			// 邮件主题
			e.setSubject(title);
			// 邮件内容
			e.setContent(context,"text/html;charset=UTF-8");
			//SmtpEmail smtpEmail = new SmtpEmail();
			//smtpEmail.sendEmail(emailMessage);
			e.send();
			// sendRs = "1";// 成功
			return true;
		} catch (EmailException ex) {
//			ex.printStackTrace();
			// sendRs = "0";// 失败
			return false;

	}

}
}
