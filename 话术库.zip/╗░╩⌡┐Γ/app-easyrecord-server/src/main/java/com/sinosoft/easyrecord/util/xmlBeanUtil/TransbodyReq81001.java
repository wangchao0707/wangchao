package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransbodyReq81001 implements Transbody, Serializable {

    private static final long serialVersionUID = -5516458734124140937L;

    private VIDEO VIDEO;

    public VIDEO getVIDEO() {
        return VIDEO;
    }

    public void setVIDEO(VIDEO vIDEO) {
        VIDEO = vIDEO;
    }

    public static class VIDEO {
        /*判断抽检是不是抽中*/
        public String ISSAMPLING;
        public String DOCCODE;//!-- 投保单号码 -->
        public String TYPE;//<!-- 上传类型--新单或问题件 -->
        public String HOSTNAME;//<!-- 服务器名写固定值COS -->
        public String BUSINESSNO;//<!-- 业务流水号 -->
        public String BEFOREBUSINESSNO;//<!-- 上次业务流水号 -->

        public String REQUESTID; //语音转文字标识码
        public String BUSSTYPE;//<!-- 类型--直播（ZB）或点播（DB） -->
        public String SUBTYPE;//<!-- 子类型--直播视频（ZB001）点播视频（DB001） -->
        public String CHANNEL;//<!-- 写固定值1-->
        public String NUMPAGES;//<!-- 文件和图片共有多少个 -->
        public String AGENTID;//<!-- 代理人ID -->  整改人
        public String AGENTNAME;//<!-- 代理人姓名 -->
        public String COMPANY;//<!-- 保险所属保险公司 -->
        //增
        public String RISKTYPE;//!-- 产品类别 0-单个产品 1-捆绑型产品 -->
        public String RISKTYPECODE;//<!-- 产品类别编码 -->
        public String COMCODE; //机构编码
        public String APPNTNAME;//<!-- 投保人姓名 -->
        public String APPNTIDTYPE;//<!-- 投保人证件类型 -->
        public String APPNTIDNO;//<!-- 投保人证件号码 -->
        public String APPNTIDIMG; //投保人证件图片 -->
        public String APPNTBIRTHDAY;//<!-- 投保人生日 -->
        public String APPNTADRESS;//<!-- 投保人地址 -->
        public String APPNTSEX;//<!-- 投保人性别 1-男 2-女-->
        public String APPNTAGE;//<!-- 投保人年龄 -->
        public String INSURDENAME;//<!-- 被投保人姓名 -->
        public String INSUREDIDTYPE;//<!-- 被投保人证件类型 -->
        public String INSUREDIDIMG; //被投保人证件图片 -->
        public String INSUREDIDNO;//<!-- 被投保人证件号码 -->
        public String INSUREDBIRTHDAY;//<!-- 被投保人生日 -->
        public String INSUREDADRESS;//!-- 被投保人地址 -->
        public String INSUREDSEX;//<!-- 被投保人性别 1-男 2-女-->
        public String INSUREDAGE;//<!-- 被投保人年龄 -->
        public String POLAPPLYDATE;//<!-- 投保日期 -->
        public String RECDATE; //-视频录制日期-->
        public String RECTIME; //--视频录制时间-->
        public String UPLOADDATE; //--视频上传日期-->
        public String UPLOADTIME; //视频上传时间-->
        //银保新增节点
        public String BANKCODE; //银行编码
        public String BANKNETWORK; //银行网点
        public String PROPERSON; //专管员
        public String RESOURCE; //影像来源 0是app，1是银行-->
        public String DATATYPE;//<!--有无双录文件，0是有，1是没有-->
        public String STATUS; //<!--质检状态 0-待质检 1-已质检 默认为0 都需要质检-->
        public String QCCONCLUSION; //<!--质检结论 当质检状态为  1-已质检时，需要有质检结论 0-通过  1-不通过  2-整改-->

        public String OPERATION; //<!--业务 0-自营 1-银保 -->operation
        public String REPEATPERSON; //所属人 -->
        public String REPEATPERSONCODE; //所属人编码 -->

        /**
         * 智能双录 新增标识
         **/
        public String ISINTELLIGENCE;

        public PAGES PAGES;

        public PAGES getPAGES() {
            return PAGES;
        }

        public void setPAGES(PAGES pAGES) {
            PAGES = pAGES;
        }


        //添加实时话术节点
        public TALK TALK;
    }

    public static class PAGES {
        public String PAGECOUNT;
        public List<PAGE> PAGE = new ArrayList<>();
    }

    public static class PAGE {
        public String FILETYPE;//<!-- 文件类型--0-视频或1-图片 -->
        public String PAGENAME;//<!-- 文件名--不带后缀 -->
        public String PAGESUFFIX;//<!-- 文件后缀 -->
        public String URL;//<!-- 图片或视频地址 -->
        public String RECORDER;//<!--图片顺序  第几条数据-->
        public String IMGTIMEPOINT;//<!-- 图片时点 -->
        public String DESCRIBEID;//<!-- 图片对应话术ID -->
        public String QCPOINTCODE; // 要点id
        public String RECDATE;//<!-- 录制日期 -->
        public String RECTIME;//<!-- 录制时间 -->
        public String RECDURATION;//<!-- 录制时长 -->
        public String FILESIZE; //文件大小
        public String ISREAD; //18-09-20增加是否可读字段

        public String DESCRIBETEXT; // 话术具体内容
        public String ISPLAYER; // 是否播报
    }

    public static class TALK {
        public String APPNTNAME = "XX"; //投保人姓名 
        public String INSUREDNAME = "XX"; //被保人姓名
        public String COMNAME = "XX"; //销售人员所属公司名称
        public String USERNAME = "XX"; //销售人员姓名
        public String RISKNAME = "XX"; //保险产品全称—多个产品以逗号隔开
        public String INTERSECTIONPAYINTV = "XX"; //期交产品缴费方式
        public String INTERSECTIONPREM = "XX"; //期交产品保费
        public String INTERSECTIONPAYENDYEAR = "XX"; //期交产品缴费期间
        public String INTERSECTIONINSUYEAR = "XX"; //期交产品保险期间
        public String WHOLESALEPREM = "XX"; //趸交产品保费
        public String WHOLESALEINSUYEAR = "XX"; //趸交产品保险期间
        public String WHOLESALEHESITATION = "XX"; //趸交产品犹豫期
    }

}
