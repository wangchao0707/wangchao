package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSTalkContent;

import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2018-10-13
 * Time: 15:07
 */
public interface TalkContentDao {

    LSTalkContent findByBusiNumAndRiskTypeAndPkid(String busiNum, String risktype, String pkid);

    void saveTalkContent(LSTalkContent talkContent);

    void delTalkContent(LSTalkContent lsTalkContent);

    List<LSTalkContent> findByBusiNumAndRiskType(String busiNum,String riskType);

    List<LSTalkContent> findByBusiNum(String busiNum);

    List<LSTalkContent> findByBusiNumAndPkid(String busiNum,String pkid);


}
