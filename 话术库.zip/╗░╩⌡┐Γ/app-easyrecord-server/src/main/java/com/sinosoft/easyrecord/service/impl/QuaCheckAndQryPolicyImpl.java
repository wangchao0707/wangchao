package com.sinosoft.easyrecord.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.google.gson.annotations.JsonAdapter;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.dao.jpa.LSAppntClientRepository;
import com.sinosoft.easyrecord.dao.jpa.LSInsuredClientRepository;
import com.sinosoft.easyrecord.dao.jpa.LSPolClientRepository;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.service.QuaCheckAndQryPolicyInter;
import com.sinosoft.easyrecord.util.AgeUtil;
import com.sinosoft.easyrecord.util.HttpsInterfaceUtil;
import com.sinosoft.easyrecord.util.StringUtil;
import com.sinosoft.easyrecord.util.XmlToJson;
import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import sun.nio.cs.ext.GBK;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class QuaCheckAndQryPolicyImpl implements QuaCheckAndQryPolicyInter {

    private static final Logger logger = LoggerFactory.getLogger(QuaCheckAndQryPolicyImpl.class);
    @Autowired
    private OrganizeRequestXml organizeRequestXml;
    @Autowired
    private LSAppntClientDaoImpl4JPA lsAppntClientDaoImpl4JPA;
    @Autowired
    private LSPolClientDaoImpl4JPA lsPolClientDaoImpl4JPA;
    @Autowired
    private LSInsuredClientDaoImpl4JPA lsInsuredClientDaoImpl4JPA;
    /** 密钥 */
    @Value("${qcqp.key}")
    private String key;
    /**  */
    @Value("${qcqp.partner}")
    private String partner;
    /** 短信平台url */
    @Value("${qcqp.messageUrl}")
    private String messageUrl;
    /** 资质校验和信息查询接口url */
    @Value("${qcqp.url}")
    private String url;
    /** 短信类型(优先级) */
    @Value(("${qcqp.smsType}"))
    private String smsType;
    /** 短信接口用来判断是否是本地环境 */
    /*@Value("${qcqp.environment}")
    private String environment;*/
    /** 平台代码 */
    @Value("${qcqp.platCode}")
    private String platCode;
    /** 合作方代码  */
    @Value("${qcqp.partnerCode}")
    private String partnerCode;
    /** 合作方名称 */
    @Value("${qcqp.partnerName}")
    private String partnerName;
    /** 请求报文流水号前拼接的平台标识 */
    @Value("${qcqp.sign}")
    private String sign;
    @Override
    public NameValuePair[] orgnizeRequestData(Map<String, String> params) {
        int i = 0;
        for (Iterator iter = params.keySet().iterator(); iter.hasNext(); ) {
            String keyName = (String) iter.next();
            params.put(keyName, URLEncoder.encode((String) params.get(keyName)));
        }
        Map<String, String> newParams = HttpsInterfaceUtil.paraFilter(params);
        String sign = HttpsInterfaceUtil.buildMysign(newParams,key);
        params.put("partner",partner);
        params.put("sign",sign);
        NameValuePair data[] = new NameValuePair[params.size()];
        for(Map.Entry<String,String> entry:params.entrySet()){
            data[i++] = new NameValuePair(entry.getKey(),entry.getValue());
        }
        return data;
    }

    @Override
    public String doQuaCheck(String data){
        JSONObject jsonObject = null;
        JSONObject jsonObjectForLSCom = null;
        PostMethod postMethod = null;
        HttpClient client = null;
        String requestXML = null;
        try{
            postMethod = new PostMethod(url);
            client = new HttpClient();
            Map<String,Object> xmlMap = new HashMap<String,Object>();
            Map<String,String> temp = new HashMap<String,String>();
            JSONObject requestParam = JSONObject.parseObject(data);
            xmlMap.put("RequestCode","QuaCheck");
            xmlMap.put("PlatCode",platCode);
            xmlMap.put("sign",sign);
            xmlMap.put("PartnerCode",partnerCode);
            xmlMap.put("PartnerName",partnerName);
            xmlMap.put("AgentCode",requestParam.get("agentCode"));
            xmlMap.put("AgentName",requestParam.get("agentName"));
            xmlMap.put("BranchCode",requestParam.get("branchCode"));
            requestXML = organizeRequestXml.organizeQualificationCheck(xmlMap,"GBK");
            logger.info("请求报文为:{}",requestXML);
            temp.put("requestXML",requestXML);
            NameValuePair nameValuePairs[] = orgnizeRequestData(temp);
            postMethod.setRequestBody(nameValuePairs);
            if(HttpStatus.SC_OK == client.executeMethod(postMethod)){
                jsonObject = XmlToJson.xmlContentToJson2(postMethod.getResponseBodyAsString()).getJSONObject("Transaction").getJSONObject("Transaction_Header").getJSONObject("Tran_Response");
                jsonObjectForLSCom = XmlToJson.xmlContentToJson2(postMethod.getResponseBodyAsString()).getJSONObject("Transaction").getJSONObject("Transaction_Body");
                jsonObject.put("ManageName",jsonObjectForLSCom.get("ManageNmae"));
                jsonObject.put("ManageCom",jsonObjectForLSCom.get("ManageCom"));
                logger.info("接收到的响应信息为:{}",jsonObject.toJSONString());
            }
        }catch (Exception e){
            logger.error("{}",e);
        }finally {
            if(postMethod != null){
                postMethod.releaseConnection();
            }
        }
        return jsonObject.toJSONString();
    }

    @Override
    public String doQryPolicyInfo(String data){
        JSONObject resultJsonObject =null;
        PostMethod postMethod = null;
        HttpClient client = null;
        String requestXML = null;
        try{
            postMethod = new PostMethod(url);
            client = new HttpClient();
            Map<String,Object> xmlMap = new HashMap<String,Object>();
            Map<String,String> temp = new HashMap<String,String>();
            JSONObject requestJSON = JSONObject.parseObject(data);
            xmlMap.put("RequestCode","QryPolicyInfo");
            xmlMap.put("UniqueNo",String.valueOf(requestJSON.get("uniqueNo")));
            xmlMap.put("BranchCode",String.valueOf(requestJSON.get("branchCode")));
            xmlMap.put("AgentCode",String.valueOf(requestJSON.get("agentCode")));
            xmlMap.put("AgentName",String.valueOf(requestJSON.get("agentName")));
            String contno  = String.valueOf(requestJSON.get("contNo"));
            xmlMap.put("PlatCode",platCode);
            xmlMap.put("sign",sign);
            xmlMap.put("PartnerCode",partnerCode);
            xmlMap.put("PartnerName",partnerName);
            requestXML = organizeRequestXml.organizeInformationAcquisition(xmlMap,"GBK");
            logger.info("请求报文为:{}",requestXML);
            temp.put("requestXML",requestXML);
            NameValuePair[] nameValuePairs = orgnizeRequestData(temp);
            postMethod.setRequestBody(nameValuePairs);
            if(HttpStatus.SC_OK == client.executeMethod(postMethod)){
                String responseXML = postMethod.getResponseBodyAsString();
                logger.info("响应xml报文为:{}",responseXML);
                JSONObject jsonObject = XmlToJson.xmlContentToJson2(responseXML);
                logger.info("接收到的响应信息为:{}",jsonObject.toJSONString());
                /** 对接收到响应信息进行处理返回 */
                JSONObject tran_Response = jsonObject.getJSONObject("Transaction").getJSONObject("Transaction_Header").getJSONObject("Tran_Response");
                JSONObject responseJSON = new JSONObject();
                if("S".equalsIgnoreCase(String.valueOf(tran_Response.get("ReturnCode")))){
                    JSONObject tb = jsonObject.getJSONObject("Transaction").getJSONObject("Transaction_Body");
                    //JSONArray riskListJsonObject = tb.getJSONArray("riskList");
                    Object riskList = tb.get("riskList");
                    if (riskList instanceof JSONObject){
                        JSONArray riskListJsonArray = JSONArray.parseArray("["+String.valueOf(riskList)+"]");
                        tb.put("riskList",riskListJsonArray);
                    }
                    responseJSON.put("Transaction_Body",tb);
                    responseJSON.put("Tran_Response",tran_Response);
                    if(contno != null && !"".equals(contno)){
                        saveResponseMessage(tb,contno);
                    }
                    responseJSON.put("success",true);
                }else{
                    responseJSON.put("Tran_Response",tran_Response);
                    responseJSON.put("success",false);
                    responseJSON.put("msg",tran_Response.get("ReturnMsg"));
                }
                resultJsonObject = responseJSON;
                logger.info("返回前台信息为:{}",resultJsonObject.toJSONString());
            }else{
                logger.error("");
                resultJsonObject.put("success",false);
                resultJsonObject.put("msg","请求获取失败");
            }
        }catch (Exception e){
            logger.info("请求失败{}",e);
            resultJsonObject.put("result",false);
            resultJsonObject.put("errorMsg",e.getMessage());
        }finally {
            if(postMethod != null){
                postMethod.releaseConnection();
            }
        }
        return resultJsonObject.toJSONString();
    }

    @Override
    public String doMessageRequest(String data) {
        JSONObject result = null;
        HttpClient client = null;
        PostMethod postMethod = null;
        String requestXML = null;
        String errorMsg = "";
        Map<String,Object> map = new HashMap<String,Object>();
        JSONObject requestJSON = JSONObject.parseObject(data);
        map.put("phone_no",requestJSON.get("phoneNo"));
        map.put("smsContent",requestJSON.get("smsContent"));
        String msg="";
        try{
            result = new JSONObject();
            client = new HttpClient();
            postMethod = new PostMethod(messageUrl);
            map.put("smsType",smsType);
            requestXML = organizeRequestXml.organizeMessageRequestXML(map,"GBK");
            logger.info("doMessageRequest接口请求报文为:{}",requestXML);
            postMethod.setRequestEntity(new StringRequestEntity(requestXML,"application/xml","GBK"));

            if(HttpStatus.SC_OK == client.executeMethod(postMethod)){
                String resposeXML = postMethod.getResponseBodyAsString();
                logger.info("响应日志为{}",resposeXML);
                Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(resposeXML.getBytes("GBK")));
                XPath xPath = XPathFactory.newInstance().newXPath();
                String xmlRsult= xPath.evaluate("/request/result",doc);
                logger.info("result节点信息为{}",xmlRsult);
                if(StringUtils.isNotEmpty(xmlRsult) &&"保存成功".equals(xmlRsult)){
                    result.put("result",true);
                }else{
                    result.put("result",false);
                    logger.info("errormassage节点信息为{}",xPath.evaluate("/request/queryinfo/filed[@name='ERRORMASSAGE']",doc));
                    result.put("errorMsg",xPath.evaluate("/request/queryinfo/filed[@name='ERRORMASSAGE']",doc));
                }
            }
        }catch (Exception e){
            result.put("result",false);
            result.put("errorMsg",msg);
            logger.error("调用短信平台错误");
            logger.error("{}",e);
        }finally {
            if(postMethod != null){
                postMethod.releaseConnection();
            }
        }
        logger.info("doMessageRequest响应前台报文为:{}",result.toJSONString());
        return result.toJSONString();
    }

    @Override
    public void saveResponseMessage(JSONObject responseJson,String contno){
        JSONObject appntJSON = responseJson.getJSONObject("Appnt");
        JSONObject insuredJSON = responseJson.getJSONObject("Insured");
        /*JSONArray jsonArray = responseJson.getJSONArray("riskList");*/
        //Object object = jsonObject.getJSONObject("Transaction").getJSONObject("Transaction_Body").get("riskList");
        Object object = responseJson.get("riskList");
        JSONArray jsonArrayRiskList =new JSONArray();
        if (object instanceof JSONObject) {
            JSONObject jsonObject=responseJson.getJSONObject("riskList");
            jsonArrayRiskList.add(jsonObject);
        }
        if (object instanceof JSONArray) {
            JSONArray getJsonObjectRiskList=responseJson.getJSONArray("riskList");
            jsonArrayRiskList.addAll(getJsonObjectRiskList);
        }
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd&HH:mm:ss");
        String date = dateFormat.format(new java.util.Date());
        String appntno = UUID.randomUUID().toString();
        String insuredno = UUID.randomUUID().toString();
        try{
            lsAppntClientDaoImpl4JPA.save(organizedAppnt(appntJSON,contno,appntno,date));
            lsInsuredClientDaoImpl4JPA.save(organizedInsured(insuredJSON,contno,appntno,insuredno,date));
            List<LspolClient> clients = lsPolClientDaoImpl4JPA.findLspolClientByContno(contno);
            if(clients != null && clients.size() > 0){
                lsPolClientDaoImpl4JPA.deleteLspolClientByContno(contno);
            }
            lsPolClientDaoImpl4JPA.saveAll(organizedLspol(jsonArrayRiskList,contno,appntno,insuredno,date));
        }catch (Exception e){
            logger.error("获取投被保人信息接口出错:{}",e);
        }
    }

    /**
     * 根据返回json数据组织投保人数据
     * @param appntJSON
     * @param contno
     * @param appntno
     * @param date
     * @return
     * @throws Exception
     */
    private LsappntClient organizedAppnt(JSONObject appntJSON, String contno,String appntno,String date) throws Exception{
        LsappntClient lsAppnt = new LsappntClient();
        lsAppnt.setContno(contno);
        lsAppnt.setAppntno(appntno);
        lsAppnt.setIdtype(String.valueOf(appntJSON.get("AppIdtype")));
        String appBirthday = String.valueOf(appntJSON.get("AppBirthday"));
        String formatAppntBirthday = appBirthday.substring(0,4)+"-"+appBirthday.substring(4,6)+"-"+appBirthday.substring(6,8);
        lsAppnt.setAppntbirthday(Date.valueOf(formatAppntBirthday));
        lsAppnt.setAddress(appntJSON.get("AppAdress").toString().equalsIgnoreCase("null") ? null : appntJSON.get("AppAdress").toString());
        lsAppnt.setAppntsex(appntJSON.get("AppSex").toString());
        lsAppnt.setIdno(appntJSON.get("AppIdno").toString());
        lsAppnt.setAppntname(appntJSON.get("AppName").toString());
        lsAppnt.setAppntage(AgeUtil.calAgeFromBirthday(formatAppntBirthday));
        lsAppnt.setMakedate(Date.valueOf(date.split("[&]")[0]));
        lsAppnt.setMaketime(date.split("[&]")[1]);
        lsAppnt.setModifydate(Date.valueOf(date.split("[&]")[0]));
        lsAppnt.setModifytime(date.split("[&]")[1]);
        return lsAppnt;
    }
    /**
     * 根据返回json数据
     */
    private LsinsuredClient organizedInsured(JSONObject insuredJSON,String contno,String appntno,String insuredno,String date){
        LsinsuredClient lsinsuredClient = new LsinsuredClient();
        lsinsuredClient.setContno(contno);
        lsinsuredClient.setInsuredno(insuredno);
        lsinsuredClient.setAppntno(appntno);
        lsinsuredClient.setName(insuredJSON.get("InsurName").toString());
        lsinsuredClient.setAddress(insuredJSON.get("InsurAdress").toString().equalsIgnoreCase("null") ? null : insuredJSON.get("InsurAdress").toString());
        lsinsuredClient.setIdno(insuredJSON.get("InsurIdno").toString());
        String insuredBirthday = String.valueOf(insuredJSON.get("InsurBirthday"));
        String formatInsuredBirthdaty = insuredBirthday.substring(0,4)+"-"+insuredBirthday.substring(4,6)+"-"+insuredBirthday.substring(6,8);
        lsinsuredClient.setBirthday(Date.valueOf(formatInsuredBirthdaty));
        lsinsuredClient.setRelationtoappnt(insuredJSON.get("relationToAppnt").toString());
        lsinsuredClient.setIdtype(insuredJSON.get("InsurIdtype").toString());
        lsinsuredClient.setSex(insuredJSON.get("InsurSex").toString());
        lsinsuredClient.setAge(AgeUtil.calAgeFromBirthday(formatInsuredBirthdaty));
        lsinsuredClient.setMakedate(Date.valueOf(date.split("[&]")[0]));
        lsinsuredClient.setMaketime(date.split("[&]")[1]);
        lsinsuredClient.setModifydate(Date.valueOf(date.split("[&]")[0]));
        lsinsuredClient.setModifytime(date.split("[&]")[1]);
        return lsinsuredClient;
    }

    private List<LspolClient> organizedLspol(JSONArray riskJSONArray, String contno, String appntno, String insuredno, String date) throws Exception{
        List<LspolClient> lspolClients = new ArrayList<LspolClient>();
        for (Object o : riskJSONArray) {
            JSONObject riskJson = (JSONObject)o;
            LspolClient lspolClient = new LspolClient();
            String polno = UUID.randomUUID().toString();
            lspolClient.setContno(contno);
            lspolClient.setPolno(polno);
            lspolClient.setSalechnl(null);
            lspolClient.setInsuredno(insuredno);
            lspolClient.setAppntno(appntno);
            lspolClient.setRiskcode(String.valueOf(riskJson.get("RiskCode")));
            lspolClient.setRiskname(String.valueOf(riskJson.get("RiskName")));
            lspolClient.setPayintv(String.valueOf(riskJson.get("PayIntv")));
            lspolClient.setPayendyear(String.valueOf(riskJson.get("PayEndYear")));
            lspolClient.setPrem(Double.valueOf(String.valueOf(riskJson.get("prem"))));
            lspolClient.setInsuyear(String.valueOf(riskJson.get("InsuYear")));
            lspolClient.setMakedate(Date.valueOf(date.split("[&]")[0]));
            lspolClient.setMaketime(date.split("[&]")[1]);
            lspolClient.setModifydate(Date.valueOf(date.split("[&]")[0]));
            lspolClient.setModifytime(date.split("[&]")[1]);
            lspolClients.add(lspolClient);
        }
        return lspolClients;
    }
}
