package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSTalkContentRepository;
import com.sinosoft.easyrecord.entity.LSTalkContent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2018-10-13
 * Time: 15:10
 */
@Component
public class TalkContentDaoImpl implements TalkContentDao{

    @Autowired
    private LSTalkContentRepository talkContentRepository;


    @Override
    public void saveTalkContent(LSTalkContent talkContent) {
        talkContentRepository.save(talkContent);
    }

    @Override
    public void delTalkContent(LSTalkContent lsTalkContent) {
        talkContentRepository.delete(lsTalkContent);
    }

    @Override
    public LSTalkContent findByBusiNumAndRiskTypeAndPkid(String busiNum, String risktype, String pkid) {
        return talkContentRepository.findByBusiNumAndRiskTypeAndPkid(busiNum,risktype,pkid);
    }

    @Override
    public List<LSTalkContent> findByBusiNumAndRiskType(String busiNum, String riskType) {
        return talkContentRepository.findByBusiNumAndRiskType(busiNum,riskType);
    }

    @Override
    public List<LSTalkContent> findByBusiNum(String busiNum) {
        return talkContentRepository.findByBusiNum(busiNum);
    }


    @Override
    public List<LSTalkContent> findByBusiNumAndPkid(String busiNum, String pkid) {
        return talkContentRepository.findByBusiNumAndPkid(busiNum,pkid);
    }
}

