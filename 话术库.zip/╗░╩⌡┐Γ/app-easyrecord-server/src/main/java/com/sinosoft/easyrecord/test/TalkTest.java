//package com.sinosoft.easyrecord.test;
//
//import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyReq81001;
//
///**
// * Description:
// * User: weihao
// * Date: 2018-06-26
// * Time: 11:00
// */
//public class TalkTest {
//
//    public static void main(String[] args) {
//
//        TransbodyReq81001.TALK talk = new TransbodyReq81001.TALK();
//        System.out.println(talk.APPNTNAME);
//
//    }
//
//}
