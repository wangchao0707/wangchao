package com.sinosoft.easyrecord.test;

import com.alibaba.fastjson.JSON;
import com.sinosoft.easyrecord.util.HttpUtil;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2018-06-26
 * Time: 14:24
 */
public class MessageTest {

    public static void main(String[] args) {
        // 组织发送 质检消息
        //组织封装数据
        JSONObject sendMap = new JSONObject();
        sendMap.put("sendType","1");
        sendMap.put("sendTo","1");
        sendMap.put("dataSource","sl");
        sendMap.put("message","1");
        sendMap.put("title","1");
        sendMap.put("msgType","sl");
        sendMap.put("topMsgType","01");
        //把质检消息发送给e店
        try {
            HttpUtil.doPost("http://127.0.0.1:8081/easyrecord/forword/sendMessageTest",sendMap.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
