package com.sinosoft.easyrecord.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.dao.InforImgDao;
import com.sinosoft.easyrecord.entity.LSInforImg;
import com.sinosoft.easyrecord.entity.LSInforImgComp;
import com.sinosoft.easyrecord.service.InforImgService;
import com.sinosoft.easyrecord.vo.InforImgForm;

@Service
public class InforImgServiceImpl implements InforImgService {

    @Autowired
    private InforImgDao inforImgDao;

    public void setInforImgDao(InforImgDao inforImgDao) {
        this.inforImgDao = inforImgDao;
    }


    @Override
    public ServiceResult<String, String[]> save(InforImgForm imgForm) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);

        LSInforImg lsInforImg = new LSInforImg(new LSInforImgComp(imgForm.getContNo(), imgForm.getType()), imgForm.getImage(), imgForm.getImagePath());

        inforImgDao.save(lsInforImg);
        return builder.createSuccessResult(lsInforImg.toString());
    }

}
