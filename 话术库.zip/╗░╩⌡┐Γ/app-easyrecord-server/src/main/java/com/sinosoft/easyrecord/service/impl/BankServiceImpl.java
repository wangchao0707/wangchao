package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.dao.BankDao;
import com.sinosoft.easyrecord.entity.LSBank;
import com.sinosoft.easyrecord.service.BankService;
import com.sinosoft.easyrecord.vo.BankForm;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2018-3-19.
 */
@Service
public class BankServiceImpl implements BankService {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(ComManagerImpl.class);

    @Autowired
    private BankDao bankDao;

    @Override
    public List<BankForm> getBankList() {
        logger.info("getBankList");
        List<LSBank> bankList = bankDao.getBankList();
        List<BankForm> list = new ArrayList<>();
        if (bankList != null && bankList.size() != 0) {
            for (LSBank bf : bankList) {
                BankForm bf1 = new BankForm();
                bf1.setBankInitials(bf.getBankInitials());
                bf1.setBankCompleteSpelling(bf.getBankCompleteSpelling());
                bf1.setBankCode(bf.getBankCode());
                bf1.setBankName(bf.getBankName());
                list.add(bf1);
            }
        }
        return list;
    }
}
