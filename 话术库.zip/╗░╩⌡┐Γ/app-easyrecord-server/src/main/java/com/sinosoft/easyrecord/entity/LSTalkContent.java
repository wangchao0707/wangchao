package com.sinosoft.easyrecord.entity;

import javax.persistence.*;

/**
 * Description:
 * User: weihao
 * Date: 2018-10-13
 * Time: 15:04
 */
@Entity
@Table(name = "LSTalkContent")
public class LSTalkContent {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "Businum")
    private String busiNum;
    @Column(name = "riskType")
    private String riskType;
    @Column(name = "pkid")
    private String pkid;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "TalkContent")
    private String talkContent;
    @Column(name = "orderNum")
    private String orderNum;

    @Column(name = "talkTitle")
    private String talkTitle;

    @Column(name = "contNo")
    private String contNo;


    @Column(name = "question")
    private String question;
    @Column(name = "isKey")
    private String isKey;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getIsKey() {
        return isKey;
    }

    public void setIsKey(String isKey) {
        this.isKey = isKey;
    }


    public String getContNo(){return contNo;}

    public void setContNo(String contNo){this.contNo = contNo;}

    public String getTalkTitle(){return talkTitle;}

    public void setTalkTitle(String talkTitle){
        this.talkTitle = talkTitle;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getPkid() {
        return pkid;
    }

    public void setPkid(String pkid) {
        this.pkid = pkid;
    }

    public String getTalkContent() {
        return talkContent;
    }

    public void setTalkContent(String talkContent) {
        this.talkContent = talkContent;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    @Override
    public String toString() {
        return "LSTalkContent{" +
                "id='" + id + '\'' +
                ", busiNum='" + busiNum + '\'' +
                ", riskType='" + riskType + '\'' +
                ", pkid='" + pkid + '\'' +
                ", talkContent='" + talkContent + '\'' +
                ", orderNum='" + orderNum + '\'' +
                '}';
    }
}
