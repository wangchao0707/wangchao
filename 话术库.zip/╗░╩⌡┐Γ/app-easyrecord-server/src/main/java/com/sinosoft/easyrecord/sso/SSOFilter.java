package com.sinosoft.easyrecord.sso;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.entity4afc.UserSession;
import com.sinosoft.easyrecord.service.TokenManager;
import com.sinosoft.easyrecord.service.UserService;
import com.sinosoft.easyrecord.service.UserSessionService;
import com.sinosoft.easyrecord.vo.UserBasicInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by WinterLee on 2017/7/18.
 */
// @WebFilter(filterName = "sso-filter", urlPatterns = "api/*")
public class SSOFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(SSOFilter.class);

    // @Value("${sso.token.httpHeadKey}")


    private String KEY_token = "sino-token";
    private TokenManager tokenManager;

    private UserService userService;

    private UserSessionService userSessionService;

    // @Autowired
    public void setTokenManager(TokenManager tokenManager) {
        logger.info("set  token-manager");
        this.tokenManager = tokenManager;
    }

    // @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }
    public void setUserSessionService(UserSessionService userSessionService) {
        this.userSessionService = userSessionService;
    }
    public void setKeyToken(String keyToken) {
        this.KEY_token = keyToken;
    }

    public SSOFilter() {
        logger.info("create SSOFilter");
    }


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;

        UserBasicInfo userBasicInfo;
        //KEY_token

        String token = request.getHeader(KEY_token);
        //String token = "2d513a0c-e0a2-48d4-babe-9c2cb0411b34";
        logger.info("token的值为："+token);
        if (StringUtils.isEmpty(token)) {

            servletResponse.setCharacterEncoding("UTF-8");
            Writer writer = servletResponse.getWriter();

            logger.info("{success: false, messages: [\"请求头信息中没有设置'sino-token'\"] }");
            writer.append("{success: false, messages: [\"登录已过期，请重新登录\"] }");
            return;

        }

        boolean isQCUser = false;
        if(token.startsWith("QC:")){
            token = token.substring(3);
            isQCUser = true;
        }
        logger.info("截取之后的token的值为："+token);
        ServiceResult<String, String> tokenResult = tokenManager.findUser(token);
        if (!tokenResult.isSuccess()) {
            servletResponse.setCharacterEncoding("UTF-8");
            Writer writer = servletResponse.getWriter();

            logger.info("{success: false, messages: [\"请重新登录系统\"] }");
            writer.append(tokenResult.getFailResult());
            return;
        }

        String userid = tokenResult.getSuccessResult();

        logger.info("token[{}]  ==>> user[{}]", token, userid);

        logger.info("isQCUser的值为："+isQCUser);
        if(isQCUser){
            logger.info("人名："+userid);
            List<UserSession> userList = userSessionService.getUserList(userid);
            LSUser lsusr = new LSUser();
            userBasicInfo = new UserBasicInfo(lsusr);

            //若有两个机构,则用,拼接起来
            lsusr.setComCode(userList.stream().map(user -> user.getComCode()).collect(Collectors.joining(",")));
            lsusr.setUserId(userList.get(0).getUserId());
        } else {
            ServiceResult<UserBasicInfo, String> result = userService.getUserInfo(userid);
            if (!result.isSuccess()) {
                servletResponse.setCharacterEncoding("UTF-8");
                Writer writer = servletResponse.getWriter();
                writer.append("{success: false, messages: [\"用户信息获取失败\"] }");
                logger.info("用户信息获取失败");
                return;
            }

            userBasicInfo = result.getSuccessResult();
        }

        CurrentUser.setUser(userBasicInfo);

        filterChain.doFilter(servletRequest, servletResponse);

        CurrentUser.remove();

    }

    @Override
    public void destroy() {

    }
}
