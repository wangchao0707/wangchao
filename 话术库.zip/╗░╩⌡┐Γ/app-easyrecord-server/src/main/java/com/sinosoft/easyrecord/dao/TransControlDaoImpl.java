package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSTransferControlRepository;
import com.sinosoft.easyrecord.entity.LSTransferControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-22
 * Time: 10:19
 */
@Component
public class TransControlDaoImpl implements TransferControlDao {


    @Autowired
    private LSTransferControlRepository transferControlRepository;

    @Override
    public LSTransferControl findByOrgCodeAndModifyDate(LSTransferControl.TransferControlId transferControlId) {
        Optional<LSTransferControl> res = transferControlRepository.findById(transferControlId);
        return res.orElse(null);
    }

    @Override
    public void saveTransControl(LSTransferControl lsTransferControl) {
        transferControlRepository.saveAndFlush(lsTransferControl);
    }

    @Override
    public LSTransferControl findByEnable(char enable) {
        return transferControlRepository.findTop1ByEnableOrderByOrderNumAsc(enable);
    }
}
