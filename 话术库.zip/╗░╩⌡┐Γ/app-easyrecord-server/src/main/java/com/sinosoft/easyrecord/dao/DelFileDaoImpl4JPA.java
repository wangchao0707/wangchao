package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSDelFileRespository;
import com.sinosoft.easyrecord.entity.LSDelFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;

/**
 * Created by wh on 2018/3/2.
 */
@Component
public class DelFileDaoImpl4JPA implements DelFileDao{

    @Autowired
    private LSDelFileRespository lsDelFileRespository;

    public void setLsDelFileRespository(LSDelFileRespository lsDelFileRespository) {
        this.lsDelFileRespository = lsDelFileRespository;
    }

    @Override
    public void saveDelFile(LSDelFile lsDelFile) {
        lsDelFileRespository.saveAndFlush(lsDelFile);
    }

    @Override
    public List<LSDelFile> findByIsDelPic(String isDelPic) {
        return lsDelFileRespository.findTop10ByIsDelPic(isDelPic);
    }

    @Override
    public List<LSDelFile> findByIsDelVideo(String isDelVideo) {
        return lsDelFileRespository.findTop10ByIsDelVideo(isDelVideo);
    }

    @Override
    public void updateIsDelPicByPicId(String isDelPic, String picId) {
        lsDelFileRespository.updateIsDelPicByPicId(isDelPic,picId);
    }

    @Override
    public void updateIsDelVideoByVideoId(String isDelVideo, String videoId) {
        lsDelFileRespository.updateIsDelVideoByVideoId(isDelVideo,videoId);
    }
}
