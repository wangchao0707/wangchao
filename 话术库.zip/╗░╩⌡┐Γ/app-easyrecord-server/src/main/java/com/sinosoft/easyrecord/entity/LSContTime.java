package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.ws.rs.core.Context;

@Entity
@Table(name = "LSContTime")
public class LSContTime {

    @Id
    @Column(name = "ContNo")
    private String contNo;
    @Column(name = "ContBeginTime")
    private String contBeginTime;
    @Column(name = "ContEndTime")
    private String contEndTime;
    @Column(name = "FileBeginTime")
    private String fileBeginTime;
    @Column(name = "FileEndTime")
    private String fileEndTime;
    @Column(name = "ZipBeginTime")
    private String zipBeginTime;
    @Column(name = "ZipEndTime")
    private String zipEndTime;
    @Column(name = "PicBeginTime")
    private String picBeginTime;
    @Column(name = "PicEndTime")
    private String picEndTime;
    @Column(name = "VTMp3BeginTime")
    private String vTMp3BeginTime;
    @Column(name = "VTMp3EndTime")
    private String vTMp3EndTime;
    @Column(name = "Mp3BeginTime")
    private String mp3BeginTime;
    @Column(name = "Mp3EndTime")
    private String mp3EndTime;
    @Column(name = "VideoBeginTime")
    private String videoBeginTime;
    @Column(name = "VideoEndTime")
    private String videoEndTime;
    @Column(name = "MessageBeginTime")
    private String messageBeginTime;
    @Column(name = "MessageEndTime")
    private String messageEndTime;
    @Column(name = "ZipUrl")
    private String zipUrl;
    @Column(name = "ScreenShotBeginTime")
    private String screenShotBeginTime;
    @Column(name = "ScreenShotEndTime")
    private String screenShotEndTime;

    @Column(name="VideoAgain")
    private String videoAgain;
    @Column(name="Cnt")
    private Integer cnt;

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getContBeginTime() {
        return contBeginTime;
    }

    public void setContBeginTime(String contBeginTime) {
        this.contBeginTime = contBeginTime;
    }

    public String getContEndTime() {
        return contEndTime;
    }

    public void setContEndTime(String contEndTime) {
        this.contEndTime = contEndTime;
    }

    public String getFileBeginTime() {
        return fileBeginTime;
    }

    public void setFileBeginTime(String fileBeginTime) {
        this.fileBeginTime = fileBeginTime;
    }

    public String getFileEndTime() {
        return fileEndTime;
    }

    public void setFileEndTime(String fileEndTime) {
        this.fileEndTime = fileEndTime;
    }

    public String getZipBeginTime() {
        return zipBeginTime;
    }

    public void setZipBeginTime(String zipBeginTime) {
        this.zipBeginTime = zipBeginTime;
    }

    public String getZipEndTime() {
        return zipEndTime;
    }

    public void setZipEndTime(String zipEndTime) {
        this.zipEndTime = zipEndTime;
    }

    public String getPicBeginTime() {
        return picBeginTime;
    }

    public void setPicBeginTime(String picBeginTime) {
        this.picBeginTime = picBeginTime;
    }

    public String getPicEndTime() {
        return picEndTime;
    }

    public void setPicEndTime(String picEndTime) {
        this.picEndTime = picEndTime;
    }

    public String getvTMp3BeginTime() {
        return vTMp3BeginTime;
    }

    public void setvTMp3BeginTime(String vTMp3BeginTime) {
        this.vTMp3BeginTime = vTMp3BeginTime;
    }

    public String getvTMp3EndTime() {
        return vTMp3EndTime;
    }

    public void setvTMp3EndTime(String vTMp3EndTime) {
        this.vTMp3EndTime = vTMp3EndTime;
    }

    public String getMp3BeginTime() {
        return mp3BeginTime;
    }

    public void setMp3BeginTime(String mp3BeginTime) {
        this.mp3BeginTime = mp3BeginTime;
    }

    public String getMp3EndTime() {
        return mp3EndTime;
    }

    public void setMp3EndTime(String mp3EndTime) {
        this.mp3EndTime = mp3EndTime;
    }

    public String getVideoBeginTime() {
        return videoBeginTime;
    }

    public void setVideoBeginTime(String videoBeginTime) {
        this.videoBeginTime = videoBeginTime;
    }

    public String getVideoEndTime() {
        return videoEndTime;
    }

    public void setVideoEndTime(String videoEndTime) {
        this.videoEndTime = videoEndTime;
    }

    public String getMessageBeginTime() {
        return messageBeginTime;
    }

    public void setMessageBeginTime(String messageBeginTime) {
        this.messageBeginTime = messageBeginTime;
    }

    public String getMessageEndTime() {
        return messageEndTime;
    }

    public void setMessageEndTime(String messageEndTime) {
        this.messageEndTime = messageEndTime;
    }

    public String getZipUrl() {
        return zipUrl;
    }

    public void setZipUrl(String zipUrl) {
        this.zipUrl = zipUrl;
    }

    public String getScreenShotBeginTime() {
        return screenShotBeginTime;
    }

    public void setScreenShotBeginTime(String screenShotBeginTime) {
        this.screenShotBeginTime = screenShotBeginTime;
    }

    public String getScreenShotEndTime() {
        return screenShotEndTime;
    }

    public void setScreenShotEndTime(String screenShotEndTime) {
        this.screenShotEndTime = screenShotEndTime;
    }

    public String getVideoAgain() {
        return videoAgain;
    }

    public void setVideoAgain(String videoAgain) {
        this.videoAgain = videoAgain;
    }

    public Integer getCnt() {
        return cnt;
    }

    public void setCnt(Integer cnt) {
        this.cnt = cnt;
    }
}
