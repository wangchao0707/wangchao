package com.sinosoft.easyrecord.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Component
public class CoreTimer {


    private static Logger logger = LoggerFactory.getLogger(CoreTimer.class);

    @Autowired
    CoreTimerService coreTimerService;
    @Scheduled(cron="${core.corn}")
    public void startCoreTimer(){
        try {
            //TODO 1可能会重复推（集群的方式进行部署）

            //TODO 数据可能不一致

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar nowTime = Calendar.getInstance();
            nowTime.add(Calendar.MINUTE, -5);
            String date =sdf.format(nowTime.getTime());
            logger.info("当前时间"+date);
            coreTimerService.sendMsgToCore(date);
        } catch (Exception e) {
            logger.error("核心推送核心出现错误"+e.getMessage());
            e.printStackTrace();
        }

    }
}
