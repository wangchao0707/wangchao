package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.dao.TokenDao;
import com.sinosoft.easyrecord.entity.LDToken;
import com.sinosoft.easyrecord.service.TokenManager;
import com.sinosoft.easyrecord.vo.Token;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by WinterLee on 2017/7/18.
 */
@Service
public class TokenManagerImpl implements TokenManager {

    private static final Logger logger = LoggerFactory.getLogger(TokenManagerImpl.class);

    @Value("${sso.token.expiresIn}")
    private int tokenExpiresIn;

    public void setTokenExpiresIn(int tokenExpiresIn) {
        this.tokenExpiresIn = tokenExpiresIn;
    }

    @Autowired
    private TokenDao tokenDao;

    public void setTokenDao(TokenDao tokenDao) {
        this.tokenDao = tokenDao;
    }

    @Override
    public Token createToken(String userId) {

        LDToken tokenObj = createAndSaveToken(userId);

        Token token = new Token(tokenObj);

        return token;
    }

    private LDToken createAndSaveToken(String userId) {
        LDToken token = new LDToken();
        token.createToken();
        token.setUserId(userId);
        token.setExpiresIn(tokenExpiresIn);

        logger.info("create token: user[{}]  -->>>  [{}]", userId, token);

        tokenDao.save(token);

        return token;
    }

    @Override
    public ServiceResult<String, String> findUser(String accessToken) {

        ServiceResult.Builder<String, String> builder = ServiceResult.build(String.class, String.class);

        LDToken token = tokenDao.getToken(accessToken);

        if (token == null) {
//            return builder.createFailResult("{\"success\": false,\"code\":10006, \"messages\": [\"您的账号近期在另一台手机上登录。如非本人操作，则密码可能已经泄露，建议修改密码。\"] }");
            return builder.createFailResult("{\"success\": false,\"code\":10006, \"messages\": [\"您的登录信息已过期，请重新登录系统!\"] }");
        }

        long expire = token.getCreateTime() + token.getExpiresIn();
        long currentTime = System.currentTimeMillis() / 1000;

        logger.info("find user: AccessToken[{}]  -->>>  [{}]", accessToken, token);

        /*if (currentTime > expire) {
            logger.info("Token[{}] timeout by [{}]", token, expire);
            return builder.createFailResult("{\"success\": false,\"code\":10006, \"messages\": [\"您的登录信息已过期，请重新登录系统!\"] }");
        } else {*/
        return builder.createSuccessResult(token.getUserId());
        //}

    }

    public ServiceResult<Token, String> refresh(String refreshToken) {

        ServiceResult.Builder<Token, String> builder = ServiceResult.build(Token.class, String.class);

        LDToken token = tokenDao.getTokenByRefreshToken(refreshToken);
        if (token == null) {
            logger.warn("RefreshToken[{}] is Invalid", refreshToken);
            return builder.createFailResult("令牌已失效");
        }

        Token newToken = refresh(token);

        return builder.createSuccessResult(newToken);
    }

    @Transactional
    private Token refresh(LDToken token) {

        String accessToken = token.getAccessToken();
        String userId = token.getUserId();

        tokenDao.disable(accessToken);
        return this.createToken(userId);

    }


    @Transactional
    @Override
    public void delToken(String userId) {

        List<LDToken> list = tokenDao.findByUserId(userId);
        if (list != null && list.size() != 0) {
            for (LDToken ldToken : list) {
                tokenDao.delToken(ldToken);
            }
        }


    }
}
