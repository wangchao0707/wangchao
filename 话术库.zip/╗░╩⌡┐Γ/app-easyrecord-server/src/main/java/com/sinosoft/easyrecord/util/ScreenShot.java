package com.sinosoft.easyrecord.util;

import it.sauronsoftware.jave.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
/**
 * User: weihao
 * Date: 2018/5/17
 * Time: 9:44
 *  抽帧
 */
public class ScreenShot {
    private static  Logger logger = LoggerFactory.getLogger(ScreenShot.class);

    public static void showDemo(File source, File target, Float timeNode) {
        logger.info("screenShot picture start file name {} timeNode{}", target, timeNode);
        VideoAttributes video = new VideoAttributes();
        video.setCodec("png");// 转图片
        video.setSize(new VideoSize(600, 500));
        EncodingAttributes attrs = new EncodingAttributes();
        attrs.setFormat("image2");// 转图片
        attrs.setOffset(timeNode);// 设置偏移位置，即开始转码位置（3秒）
        attrs.setDuration(0.01f);// 设置转码持续时间（1秒）
        attrs.setVideoAttributes(video);
        Encoder encoder = new Encoder();
        try {
            encoder.encode(source, target, attrs);
            logger.info("screenShot picture end file name {} timeNode{}", target, timeNode);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InputFormatException e) {
            e.printStackTrace();
        } catch (EncoderException e) {
            e.printStackTrace();
        } finally {

        }
        logger.info("screenShot end");
    }

//    public static void main(String[] args) {
//        for (int i = 0; i < 10000; i = i + 20) {
//            File source = new File("f:\\videotest.mp4");
//            File targets = new File("f:\\video\\picture\\"
//                    + i + ".jpg");//转图片
//            float a = i;
//            showDemo(source, targets, a);
//        }
//
//
//    }
}
