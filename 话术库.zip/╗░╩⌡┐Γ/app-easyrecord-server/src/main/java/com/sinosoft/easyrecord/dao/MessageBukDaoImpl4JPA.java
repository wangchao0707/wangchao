package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSMessageBukRepository;
import com.sinosoft.easyrecord.entity.LSMessageBuk;

@Component
public class MessageBukDaoImpl4JPA implements MessageBukDao {

    private LSMessageBukRepository messageBukRepository;

    @Autowired
    public void setMessageBukRepository(LSMessageBukRepository messageBukRepository) {
        this.messageBukRepository = messageBukRepository;
    }

    @Override
    public void save(LSMessageBuk lsMessageBuk) {
        messageBukRepository.saveAndFlush(lsMessageBuk);
    }
}
