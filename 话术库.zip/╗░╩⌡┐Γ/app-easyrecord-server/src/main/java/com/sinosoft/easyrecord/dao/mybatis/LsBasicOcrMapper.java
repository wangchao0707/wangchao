package com.sinosoft.easyrecord.dao.mybatis;

import com.sinosoft.easyrecord.entity.LsBasicOcr;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface LsBasicOcrMapper {

    void saveLsBasicOcr(LsBasicOcr lsBasicOcr);
}
