package com.sinosoft.easyrecord.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinosoft.easyrecord.dao.FileDao;
import com.sinosoft.easyrecord.entity.LSFile;
import com.sinosoft.easyrecord.service.FileService;


@Service("fileLogService")
public class FileServiceImpl implements FileService {

    @Autowired
    private FileDao fileLogDao;

    public void setFileLogDao(FileDao fileLogDao) {
        this.fileLogDao = fileLogDao;
    }


    @Override
    public void saveFileLog(LSFile fileLog) {
        fileLogDao.saveFileLog(fileLog);
    }

    @Override
    public LSFile findByContNo(String contNo) {
        return fileLogDao.findByContNo(contNo);
    }

    @Override
    public void del(String fileID) {
        fileLogDao.del(fileID);
    }

}
