package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.dao.VersionDao;
import com.sinosoft.easyrecord.entity.LSVersion;
import com.sinosoft.easyrecord.service.VersionService;
import com.sinosoft.easyrecord.util.Md5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Map;

@Service
public class VersionServiceImpl implements VersionService {

    private Logger logger = LoggerFactory.getLogger(VersionServiceImpl.class);

    @Autowired
    private VersionDao versionDao;

    public void setVersionDao(VersionDao versionDao) {
        this.versionDao = versionDao;
    }

    @Value(value = "${com.code}")
    private String comcode;

    @Value(value = "${com.enable}")
    private boolean enable;

    @Override
    public ServiceResult<LSVersion, String[]> saveVersion(String versionId, String type, String comCode) {
        ServiceResult.Builder<LSVersion, String[]> result = ServiceResult.build(LSVersion.class, String[].class);

        if (enable) {
            logger.info("comcode setting : {}", comcode);
            comCode = comcode;
        }

        LSVersion lsVersion = versionDao.findByIsNewAndComCode("Y", comCode);
        logger.info("client versionNum {} server versionnum android {} ios {}", versionId, lsVersion.getVersionId(), lsVersion.getVersionIOSId());
        logger.info("version {}", lsVersion);
        if (lsVersion == null) {
            lsVersion = new LSVersion();
            lsVersion.setMessage("2");
            return result.createSuccessResult(lsVersion);
        }
        if (type.equalsIgnoreCase("ios")) {
            if (!versionId.equals(lsVersion.getVersionIOSId())) {
                lsVersion.setMessage("2");
                lsVersion.setVersionPath(lsVersion.getVersionIOSPath());
                lsVersion.setVersionId(lsVersion.getVersionIOSId());
                lsVersion.setVersionFile("");
                lsVersion.setVersionIOSPath("");
                lsVersion.setIsNew("");
                lsVersion.setVersionIOSId("");
                lsVersion.setVersionInfor(lsVersion.getVersionIosInfor());
                return result.createSuccessResult(lsVersion);
            } else {
                lsVersion = new LSVersion();
                lsVersion.setMessage("2");
                return result.createSuccessResult(lsVersion);
            }
        } else if (type.equals("android")) {
            String testMd5 = lsVersion.getMd5();
            if (!lsVersion.getVersionId().equals(versionId)) {
//                String path = lsVersion.getVersionFile();
//                File file = new File(path);
//                String md5 = Md5Util.getMD5(file);
                lsVersion.setMessage("2");
                lsVersion.setVersionFile("");
                lsVersion.setMd5(testMd5);
                lsVersion.setVersionIOSPath("");
                lsVersion.setIsNew("");
                lsVersion.setVersionIOSId("");
                return result.createSuccessResult(lsVersion);
            } else {
                lsVersion = new LSVersion();
                lsVersion.setMd5(testMd5);
                lsVersion.setMessage("2");
                return result.createSuccessResult(lsVersion);
            }
        } else {
            return result.createFailResult(new String[]{"设备类型编号错误！"});
        }

    }


    @Override
    public ServiceResult<String, String[]> checkVersion(String comCode, String eqInfor, String versionNum) {
        ServiceResult.Builder<String, String[]> result = ServiceResult.build(String.class, String[].class);
        LSVersion lsVersion = versionDao.findByIsNewAndComCode("Y", comCode);
        if (eqInfor.equals("ios")) {
            if (!lsVersion.getVersionIOSId().equals(versionNum)) {
                return result.createFailResult(new String[]{"您的系统版本太低，请更新到最新版本。"});
            }
        }
        if (eqInfor.equals("android")) {
            if (!lsVersion.getVersionId().equals(versionNum)) {
                return result.createFailResult(new String[]{"您的系统版本太低，请更新到最新版本。"});
            }
        }

        return result.createSuccessResult("OK");
    }

    @Override
    public RequestResult updateMd5(Map reqMap){
        LSVersion lsVersion = versionDao.findByIsNewAndComCode("Y",(String) reqMap.get("comCode"));
        lsVersion.setMd5((String) reqMap.get("md5"));
        versionDao.saveVision(lsVersion);
        RequestResult requestResult = new RequestResult(true);
        requestResult.setData(lsVersion);
        return requestResult;
    }
}
