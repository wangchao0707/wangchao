package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSComSignedOnRelaRepository;
import com.sinosoft.easyrecord.entity.LSComSignedOnRela;
import com.sinosoft.easyrecord.entity.LSComSignedOnRela.LSComSignedOnRelaPK;

import java.util.Optional;

@Component
public class ComSignedOnRelaDaoImpl4JPA implements ComSignedOnRelaDao {

    @Autowired
    private LSComSignedOnRelaRepository lsComSignedOnRelaRepository;

    public void setLsComSignedOnRelaRepository(LSComSignedOnRelaRepository lsComSignedOnRelaRepository) {
        this.lsComSignedOnRelaRepository = lsComSignedOnRelaRepository;
    }

    @Override
    public void deleteByRelaComcode(LSComSignedOnRela lsComSignedOnRela) {
        lsComSignedOnRelaRepository.delete(lsComSignedOnRela);
        lsComSignedOnRelaRepository.flush();
    }

    @Override
    public void save(LSComSignedOnRela lsComSignedOnRela) {
        lsComSignedOnRelaRepository.save(lsComSignedOnRela);
    }

    @Override
    public LSComSignedOnRela find(LSComSignedOnRelaPK lComSignedOnRelaPK) {
        Optional<LSComSignedOnRela> res = lsComSignedOnRelaRepository.findById(lComSignedOnRelaPK);
        return res.orElse(null);
    }
}
