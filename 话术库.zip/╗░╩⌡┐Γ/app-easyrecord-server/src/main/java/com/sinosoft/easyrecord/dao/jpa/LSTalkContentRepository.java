package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSTalkContent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2018-10-13
 * Time: 15:07
 */
public interface LSTalkContentRepository extends JpaRepository<LSTalkContent,String> {


    LSTalkContent findByBusiNumAndRiskTypeAndPkid(String busiNum,String risktype,String pkid);

    List<LSTalkContent> findByBusiNumAndRiskType(String busiNum,String riskType);


    List<LSTalkContent> findByBusiNum(String busiNum);

    List<LSTalkContent> findByBusiNumAndPkid(String busiNum,String pkid);
}
