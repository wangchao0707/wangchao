package com.sinosoft.easyrecord.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

/**
 * Created by WinterLee on 2017/7/22.
 */
@Entity
@Table(name = "lsmessage")
public class LSMessage implements Serializable {

    @Id
    @Column(name = "MessageNo")
    private String messageNo;

    @Column(name = "UserNo", nullable = false)
    private String userNo;

    @Column(name = "Title")
    private String title;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "Message")
    private String message;

    @Column(name = "Type")
    private String type;

    @Column(name = "MakeDate")
    private Date makeDate;

    @Column(name = "MakeTime")
    private String makeTime;

    @Column(name = "Source")
    private String source;

    @Column(name = "State")
    private char state;

    @Column(name = "ContNo")
    private String contNo;

    @Column(name = "BusiNum")
    private String busiNum;

    @Column(name = "Ocopertor")
    private String ocopertor;

    @Column(name = "IssueDate")
    private String issueDate;

    public String getMessageNo() {
        return messageNo;
    }

    public void setMessageNo(String messageNo) {
        this.messageNo = messageNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(Date makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public char getState() {
        return state;
    }

    public void setState(char state) {
        this.state = state;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getOcopertor() {
        return ocopertor;
    }

    public void setOcopertor(String ocopertor) {
        this.ocopertor = ocopertor;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("LSMessage{");
        sb.append("messageNo='").append(messageNo).append('\'');
        sb.append(", userNo='").append(userNo).append('\'');
        sb.append(", title='").append(title).append('\'');
        sb.append(", message='").append(message).append('\'');
        sb.append(", type='").append(type).append('\'');
        sb.append(", makeDate=").append(makeDate);
        sb.append(", makeTime='").append(makeTime).append('\'');
        sb.append(", source='").append(source).append('\'');
        sb.append(", state=").append(state);
        sb.append('}');
        return sb.toString();
    }
}
