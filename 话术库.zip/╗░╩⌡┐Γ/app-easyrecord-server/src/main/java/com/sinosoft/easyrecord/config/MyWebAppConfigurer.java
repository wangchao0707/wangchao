package com.sinosoft.easyrecord.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Created by  lijunming
 * on  date 2018-11-06
 * time 18:45
 * 配置虚拟路径映射
 * 此方法用于调阅配置 ， 存的是视频，貌似不用了
 */
@Configuration
public class MyWebAppConfigurer extends WebMvcConfigurerAdapter {
    @Value("${video.videoPath}")
    private String videoPath;
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/accessVideo/**").addResourceLocations("file:"+videoPath);
    }
}
