package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSSteprela")
public class LSSteprela {
    @Id
    @Column(name = "PKID")
    private String pkId;

    @Column(name = "ComCode")
    private String comCode;

    @Column(name = "StepCode")
    private String stepCode;

    @Column(name = "RiskType")
    private String riskType;

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getStepCode() {
        return stepCode;
    }

    public void setStepCode(String stepCode) {
        this.stepCode = stepCode;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

}
