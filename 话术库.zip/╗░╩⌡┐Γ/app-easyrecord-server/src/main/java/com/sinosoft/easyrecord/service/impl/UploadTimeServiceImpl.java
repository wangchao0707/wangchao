package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.dao.TokenDao;
import com.sinosoft.easyrecord.dao.UploadTimeDao;
import com.sinosoft.easyrecord.entity.LDToken;
import com.sinosoft.easyrecord.entity.LSUploadTime;
import com.sinosoft.easyrecord.service.UploadTimeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/*
 * 上传时间保存
 * */
@Service
public class UploadTimeServiceImpl implements UploadTimeService {

    private UploadTimeDao uploadTimeDao;

    @Autowired
    public void setUploadTimeDao(UploadTimeDao uploadTimeDao) {
        this.uploadTimeDao = uploadTimeDao;
    }

    private TokenDao tokenDao;

    @Autowired
    public void setTokenDao(TokenDao tokenDao) {
        this.tokenDao = tokenDao;
    }

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private Logger logger = LoggerFactory.getLogger(UploadTimeServiceImpl.class);

    @Override
    public String saveUploadTime(String busiNum, String eqInfor, String versionNum, String sign, String userId) {
        LSUploadTime lsUploadTime = new LSUploadTime();

        lsUploadTime.setId(UUID.randomUUID().toString());
        //上传流水号
        String serialNum = UUID.randomUUID().toString();
        lsUploadTime.setSerialNum(serialNum);
        lsUploadTime.setBusiNum(busiNum);
        lsUploadTime.setEqInfor(eqInfor);
        lsUploadTime.setVersionNum(versionNum);
        lsUploadTime.setSign(sign);
        //获取token
        LDToken ldToken = tokenDao.getTokenByUserId(userId);
        lsUploadTime.setToken(ldToken.getAccessToken());
        Date date = new Date();
        lsUploadTime.setSignTime(sdf.format(date));
        logger.info("uploadtime {}", lsUploadTime);
        uploadTimeDao.saveUploadTime(lsUploadTime);
        return serialNum;
    }

    @Override
    public void saveUploadTime(String serialNum) {
        LSUploadTime lsUploadTime = uploadTimeDao.findBySerialNum(serialNum);
        if (lsUploadTime != null) {
            lsUploadTime.setUploadTime(sdf.format(new Date()));
            uploadTimeDao.saveUploadTime(lsUploadTime);
            logger.info("uploadtime {}", lsUploadTime);
        } else {
            logger.info("serialNum {} lsuplaodtime null", serialNum);
        }
    }

}
