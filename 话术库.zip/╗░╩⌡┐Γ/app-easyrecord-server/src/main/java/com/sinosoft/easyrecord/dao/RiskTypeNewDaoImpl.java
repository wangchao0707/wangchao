package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.RiskTypeNewJpa;
import com.sinosoft.easyrecord.entity.LsRiskTypeNew;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RiskTypeNewDaoImpl implements RiskTypeNewDao{


    @Autowired
    private RiskTypeNewJpa riskTypeNewJpa;

    @Override
    public void saveRiskTypeNew(LsRiskTypeNew lsRiskTypeNew) {
        riskTypeNewJpa.saveAndFlush(lsRiskTypeNew);
    }

    public List<LsRiskTypeNew> findByContNo(String contNo){
        return riskTypeNewJpa.findByContNo(contNo);
    }
}
