package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.EsRuleMain;

import java.util.List;

public interface EsRuleMainDao {

    List<EsRuleMain> findByChannel(String channel);

    void save(EsRuleMain esRuleMain);

    List<EsRuleMain> findByChannelAndRiskTypeCodeIn(String channel,List<String> riskTypeCodeList);
}
