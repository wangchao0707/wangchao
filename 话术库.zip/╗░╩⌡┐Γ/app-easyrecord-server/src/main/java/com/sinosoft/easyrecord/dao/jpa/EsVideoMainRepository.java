package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.EsVideoMain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EsVideoMainRepository extends JpaRepository<EsVideoMain,String> {


    public EsVideoMain findUpLoadCountByDocCode(String docCode);
}
