package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSFileDown;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-08
 * Time: 16:23
 */
public interface LSFileDownRepository  extends JpaRepository<LSFileDown,String>{
}
