package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LDTokenRepository;
import com.sinosoft.easyrecord.entity.LDToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * Created by WinterLee on 2017/7/18.
 */
@Component
public class TokenDaoImpl4JPA implements TokenDao {

    @Autowired
    private LDTokenRepository tokenRepository;

    public void setTokenRepository(LDTokenRepository tokenRepository) {
        this.tokenRepository = tokenRepository;
    }

    @Override
    public void save(LDToken token) {
        tokenRepository.saveAndFlush(token);
    }

    @Override
    public LDToken getToken(String accessToken) {
        Optional<LDToken> res = tokenRepository.findById(accessToken);
        return res.orElse(null);
    }

    @Override
    public LDToken getTokenByRefreshToken(String refreshToken) {
        return this.tokenRepository.findTop1ByRefreshTokenAndValid(refreshToken, 'Y');
    }

    @Override
    public void disable(String accessToken) {
        this.tokenRepository.updateValidById(accessToken, 'N');
    }

    @Override
    public LDToken getTokenByUserId(String userId) {
        return tokenRepository.findTop1ByUserIdOrderByCreateTimeDesc(userId);
    }

    @Override
    public List<LDToken> findByUserId(String userId) {
        return tokenRepository.findByUserId(userId);
    }

    @Override
    public void delToken(LDToken ldToken) {
        tokenRepository.delete(ldToken);
    }
}
