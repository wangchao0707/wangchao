package com.sinosoft.easyrecord.util;

import com.qcloud.sms.*;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * User: weihao
 * Date: 2018/5/17
 * Time: 9:51
 * 发送短信 工具类
 */
public class SMSUtil {

    private static Logger logger = LoggerFactory.getLogger(SMSUtil.class);

    public static String getVerification(String phoneNum, String verificationCode) {

        //配置数据
        int appid = 1400045690;
        String appkey = "1efa3c358d2775a5176b6b659fbadfb9";
        int tmplId = 49703;
        String phoneNumber = phoneNum;

        //初始化单发
        SmsSingleSender singleSender;
        SmsSingleSenderResult singleSenderResult = null;
        try {
            singleSender = new SmsSingleSender(appid, appkey);

            //指定模板单发
            ArrayList<String> params = new ArrayList<>();
            params.add(verificationCode);
            singleSenderResult = singleSender.sendWithParam("86", phoneNumber, tmplId, params, "", "", "");
            logger.info("phone {} sms result {}", phoneNum, singleSenderResult);

        } catch (Exception e) {
            e.printStackTrace();
        }
        String result = String.valueOf(singleSenderResult.result);

        return result;
    }

//    public static void main(String args[]) {
//        String result = getVerification("18733505618", "测试数据");
//        System.out.println(result);
//    }

}
