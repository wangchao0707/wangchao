package com.sinosoft.easyrecord.server;

public interface CallRemoteAfcServiceUtil {

    String sendService(String xmlStr) throws Exception;

}
