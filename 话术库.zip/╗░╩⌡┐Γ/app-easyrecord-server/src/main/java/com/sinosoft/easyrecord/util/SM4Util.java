package com.sinosoft.easyrecord.util;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.pqc.math.linearalgebra.ByteUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
//import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Arrays;
import java.util.Base64;

public class SM4Util {

    static private final Logger logger = LoggerFactory.getLogger(SM4Util.class);

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    private static final String ENCODING = "UTF-8";

    public static final String ALGORITHM_NAME = "SM4";

    public static final String ALGORITHM_NAME_ECB_PADDING = "SM4/ECB/PKCS5Padding";

    public static final int DEFAULT_KEY_SIZE = 128;

    private static Cipher generateEcbCipher(String algorithmName, int mode, byte[] key) throws Exception {
        Cipher cipher = Cipher.getInstance(algorithmName, BouncyCastleProvider.PROVIDER_NAME);
        Key sm4Key = new SecretKeySpec(key, ALGORITHM_NAME);
        cipher.init(mode, sm4Key);
        return cipher;
    }


    public static byte[] generateKey() throws Exception {
        return generateKey(DEFAULT_KEY_SIZE);
    }

    public static byte[] generateKey(int keySize) throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance(ALGORITHM_NAME, BouncyCastleProvider.PROVIDER_NAME);
        kg.init(keySize, new SecureRandom());
        return kg.generateKey().getEncoded();
    }


    public static String encryptEcb(String hexKey, String paramStr) throws Exception {
        String cipherText = "";
        byte[] keyData = ByteUtils.fromHexString(hexKey);
        byte[] srcData = paramStr.getBytes(ENCODING);
        byte[] cipherArray = encrypt_Ecb_Padding(keyData, srcData);
        cipherText = ByteUtils.toHexString(cipherArray);
        return cipherText;
    }

    public static byte[] encrypt_Ecb_Padding(byte[] key, byte[] data) throws Exception {
        Cipher cipher = generateEcbCipher(ALGORITHM_NAME_ECB_PADDING, Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(data);
    }


    public static String decryptEcb(String hexKey, String cipherText) throws Exception {
        String decryptStr = "";
        byte[] keyData = ByteUtils.fromHexString(hexKey);
        byte[] cipherData = ByteUtils.fromHexString(cipherText);

        byte[] srcData = decrypt_Ecb_Padding(keyData, cipherData);
        decryptStr = new String(srcData, ENCODING);
        return decryptStr;
    }

    public static byte[] decrypt_Ecb_Padding(byte[] key, byte[] cipherText) throws Exception {
        Cipher cipher = generateEcbCipher(ALGORITHM_NAME_ECB_PADDING, Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(cipherText);
    }

    public static boolean verifyEcb(String hexKey, String cipherText, String paramStr) throws Exception {
        boolean flag = false;

        byte[] keyData = ByteUtils.fromHexString(hexKey);

        byte[] cipherData = ByteUtils.fromHexString(cipherText);

        byte[] decryptData = decrypt_Ecb_Padding(keyData, cipherData);

        byte[] srcData = paramStr.getBytes(ENCODING);

        flag = Arrays.equals(decryptData, srcData);
        return flag;
    }


    public static void main(String[] args) throws Exception {

//       String data = "iohzd8M6v8iLRUWK3dDWmHsqf4o70YvxIuBhMLZb4Lh0/ROhwFyDA9/dX26syYWj8e2893daFtIStUt/1ZKgd11sd9iwI76lr2SEf1eNoMsaD7y+QdSTUko+vszJ9K48msoiTZmXT1JYQ89VEPTbvEJ5lz7X2LxbGcQwqAJgqbvPjEa5wY3l8dhmnLjKn42cFOYFT/Tis+xVR3DnfgYaY+Cy6J3lABrkWNJZRb+LRIBE1NdiZS26rYRK2h3etGY/8l9iUzPRCehCAgBQLcE7gytmLoNTGXlnFwB9oGfYn3UXFcEdU0iegjCqS1PVuwgmiHgFi0e39zKLSmZFuoAmpci4tFoa9qC+BH2cIbAvFwOjzrB1mBmoCVijjvOImMfS3Rc3S2nDC3cre/k2nLiwxir6kk0kOgibHPnjaHJSwCd2E7qOPfXV99rhTUGc6L8MvqHutp+R1EXT7bsjFH1qSL4JBE2LxtWpRsHzKi3z0WvJJwVWHOvr92Qm/p8OXsPXV+5JPN+m87pM+W/Jw+RskQF1MCKqITFLCJIwEZlnNoeGqE3GSaFElcxzjVdtTNBHFQ6QaicS1mXEd707JbmXg6fCAmFjR+IunkK/kRlQFJ0yew7oY/BFLaCXq+Q8wYuqLWiIaToRKjS6x/PRZYcGlEeeCEVfh4B0cyJ5IOZj84S0yThw8qtRmOGElqz0AjrawaX6TYCr0FJgGxO6cCyQlQZ0L674+isEfHhPs8DxpUEcEx24gmfwfqEVhmpWYWOhYKBv/PCQT4CgGvrG9pAhhRX2KftE5IP3F8OwlPo35uz6Qw8BFi2y5Sg4+sK5f0xsmoxhG/QGypMPbuRZ0cJrR4yilmWr1KnpynntgLlI2qo7Fnwb52jzk7FHBLjxvF54DZsSfAJiG1gg2Yh1jY83B95UVgHyDKcXjWi9gITXqmdv9ZwUfteH9xtdz3slz5LfbStJCz6EeQsa8ruX0uWcI7Vx6T4weeVyz5xul8+QFGl2moZ7c6/5gQ+22Mu0s0iOdZ/AbjdTNDRZXOXFYEHSBngEmOAeuQ3qLhCtO8TCA37VTQk4guopqSRMfD+Wrp05iEVY0ngLaQKLaKXod3S7vgbulaTMYJtuJQMF1/wmnvx3GecjVvSq87eOlBPgygn3+QFUehHyEH6QczxhRN5+zw==";
// String data = "vMwIub/0jKnQ9KkrT7Ffc5zdf/SzRvedu3xZDvhCUsHCVVGxkcMfwLuDTgqU4xzD28DfpOLK/8koR8/UhnPZTMThvqYRwwdLY5lkOdIIEZBiMNvmd/p/P8QrOaDhCJhr4E8iVmqfmc+vy1BOBNQfghVQ/QmRDwSxeqjBDGYUZCGqCvQiV6N+ivOdMk2HW+5E/AXIDAowI6aOlBypmza3KTMeR16JAOC7YKr5EXXp5xVNSt6KxNQOUHT8D8fdPsVFe5JLfvb6QhIT3ewMeZnUK4zP4q0UnO+VbFCCTrt+P+TOYyZrZR7dXnTeMVeglDaSNaovuYGrXicI3wBQ6nLoPCoUXx7+lLJKlACSZzshpHFIRDbUqfi1NqBzJjTSqx2Fv1o/EKI6iT+Do7fOQTYhKQPvWhXoyJx3z8c6GA1BDwGTM0ATO7KRyczZfGN6vy4NJg8Ogl++l25i4ZZerAZDHvikn+y8+1Pbc1JbTaDoN8R6BGYmhwIm/KRIetwGK9rUJzt01XNm0L9le/MotYO98SMs+sD5h7dW36yg7Z0U7hRXCCLWhGFTTh3VZdtk+KJR9EHQUUQHUTvowAO56OU0OM3EASPWKW3QO5pZ3CMq5bMXJ1MnRzIkeHbQJJnbXkWL8YXFlHQb6z76aa0XAAkm5mguX6tPVFdnNvlzm940GjEAwRsbhkDlO3D97MhIHw8H3lRMCgqhniOK90dbEGCi/lh4pBb1loGlrktre0+o2LHl+Z13E3kVodcTSm9PZa+uPbAuXwDOHct6+GgxGM1mjlXkYlSCgK2S6vgkCIs90lLC2ENLGGzwa2AoaZhxNNMT/UBUNFSIQYza10FdXxhxMA5/GiiYJpP9h/bLDXzpEZv+JDxLIxg8ZPnOQoGx+Sr30sHHvS7/rJm2VIM4wGjJNU7gfUwxxbdPEOe7Rt+v8RDi3OdRuvUpy7SBZ1kqWaGgNtB19U4EhwMcUanHDJU+zKWijRVf/ahcoEBQbDuHJ9olx9+YyTrTYapWb/IFSLWpeJ+Newqs4Fj00t4x1TU3Qpf0IHDQKLB67vD1o4YE3/lN6KFa1neHILY9CZY78to0+fT1JYyhTTYhpGEniJL0CW8pOMLo7BmkwPfb/aDKswEsgj/ZR9/b9chtWBD7INsMWHikFvWWgaWuS2t7T6jYsTDOZO5vaHuz4oxCnKVt+kG0jy05kygBg41vTQxwQGCTxoX6267VcpvYElkOz6YD6/PeFUJU/QGm+/vBefHQ8BF/RMdRoGozd9L9zov1LxaO2qBAb/3RrSSVJ/4IUv7I/bOjwfhPj8EvFc3wxgVNpq6eQYRwI8r+o/CNi22zQRLmXRlIbnG2Qx5j8O7MvseARpbkkreRDe/pr/G3qvXpb3XGY9SdNtWwF8B48Gz9DiajMUF+0MScpEMYdvCZqiQ1EQw2ybf59L6tKjuqm+bp5g7QnkTsrprwcb3z+x2xn5e3dFE7VQk/kPSxGuePzP0PSlRwR4qYV21JEsP6bwpJP8WMdy4KeMawZR1UMogpQUs4qwLzWNL2utpAoXtXokuYzNS30CFnWQ+w0w54FGvtCpdo5tTk60eV//zQwsW0+TojTv61FPl34Nq7fcB6OOdDJid2s/yIPY8P0sGWnV5aGF39bAeIsijOitYZy0DHdV1c7RJcyVy7yHhNFTcjRK0XNZK2pni0lwwmgB7HmXSfCspNBL+2sNmtm9aqFQ+oR0dPfpl8ZsbqbTtYFf3jJvDOZC77gV5IW9NswYDt0XdiXkQ=";
//String data = "iohzd8M6v8iLRUWK3dDWmHsqf4o70YvxIuBhMLZb4Lh0/ROhwFyDA9/dX26syYWj8e2893daFtIStUt/1ZKgd11sd9iwI76lr2SEf1eNoMsaD7y+QdSTUko+vszJ9K48msoiTZmXT1JYQ89VEPTbvEJ5lz7X2LxbGcQwqAJgqbvPjEa5wY3l8dhmnLjKn42cFOYFT/Tis+xVR3DnfgYaY+Cy6J3lABrkWNJZRb+LRIBE1NdiZS26rYRK2h3etGY/8l9iUzPRCehCAgBQLcE7gytmLoNTGXlnFwB9oGfYn3UXFcEdU0iegjCqS1PVuwgmiHgFi0e39zKLSmZFuoAmpci4tFoa9qC+BH2cIbAvFwOjzrB1mBmoCVijjvOImMfS3Rc3S2nDC3cre/k2nLiwxir6kk0kOgibHPnjaHJSwCd2E7qOPfXV99rhTUGc6L8MvqHutp+R1EXT7bsjFH1qSL4JBE2LxtWpRsHzKi3z0WvJJwVWHOvr92Qm/p8OXsPXV+5JPN+m87pM+W/Jw+RskQF1MCKqITFLCJIwEZlnNoeGqE3GSaFElcxzjVdtTNBHFQ6QaicS1mXEd707JbmXg6fCAmFjR+IunkK/kRlQFJ0yew7oY/BFLaCXq+Q8wYuqLWiIaToRKjS6x/PRZYcGlEeeCEVfh4B0cyJ5IOZj84S0yThw8qtRmOGElqz0AjrawaX6TYCr0FJgGxO6cCyQlQZ0L674+isEfHhPs8DxpUEcEx24gmfwfqEVhmpWYWOhYKBv/PCQT4CgGvrG9pAhhRX2KftE5IP3F8OwlPo35uz6Qw8BFi2y5Sg4+sK5f0xsmoxhG/QGypMPbuRZ0cJrR4yilmWr1KnpynntgLlI2qo7Fnwb52jzk7FHBLjxvF54DZsSfAJiG1gg2Yh1jY83B95UVgHyDKcXjWi9gITXqmdv9ZwUfteH9xtdz3slz5LfbStJCz6EeQsa8ruX0uWcI7Vx6T4weeVyz5xul8+QFGl2moZ7c6/5gQ+22Mu0s0iOdZ/AbjdTNDRZXOXFYEHSBngEmOAeuQ3qLhCtO8TCA37VTQk4guopqSRMfD+Wrp05iEVY0ngLaQKLaKXod3S7vgbulaTMYJtuJQMF1/wmnvx3GecjVvSq87eOlBPgygn3+QFUehHyEH6QczxhRN5+zw==";
//String data = "8DJof5KDUx07UjH4/URD0XtBYKppu7f0cDpBjoDHB8auQ48TXvkMqgnXAXM0IJESrAWy9eHCW7IcJDcb697L4mfwOmp1LNc4U82fsOFuUAmiEZJUPgaF3p6LOCM3E5DP";
//String data = "PzWvRnZfSYU4EjA7UAiJpEcaQ2Y3jpuhQP/SAuqlcM4XWX+md/lgQmdJlTbs9exo21MPDEfkq39eOlm+locKHX5WmBBFQR0rnkf9fWQzuH0tMaLlzuqanfEwA+lhiiGP7NRCFTSrVIWcydgOIoD+nLu61yPvdWpX3Ecnq5FIrMcM+l5AO59p343yiDUgZKAlibQPXVVyXNBXVbmO70ub9hQtio4uu+zfeKm8R68U5wih6ICRQtJfwUX5JgpLLO4SCN7TOEysGtTrcvojRkcr0cfRjnVJdMZjhkOYnT54U0WO7nsepykHJ3KkMSEc3tse41Oc9bDlagt5El51R8A8TGQNvRwOmk4xc2e5IcOZcy/KfbH0LJgX6wsQqBYLoqKMjSgjlWk/21q/fJ4Zk5e2ra+dO2ikjeHnTQQpnDh7cbapS+cHe5Anb/mXQeCcJ3tVPSzuziEgp/fvVGqCZKHNP6zhQVJJ8MoG9NB3sMKlaus8y+1WA12aTWIwEjDfYnez/jEfQ746ci/eXV1IW65cVwUWkGmnTU20XgjOm3G0VbzFGkvq1yb0hw81QLSVHmc2KikoeH+apkZZcifpVWanI/N1MAdMmFaAB16OqGtev0tZi9UP+vjScpNmnwnb/FeFBbeuXAMIZspsTGFOmYd/OtmPbRulyD0ebQFKgfopeN6TAuWbqmvq2gWZg3uSBf4Dg+GvO1+18/xWpxkZq39JLytPDtayuSh2W4GILhPYKsMqObzNxVm2fwrrfvuuA4Iamxzzy8Pnn8stoyDTGqJPv47Q9SSXLQs+7+3ASpkf1C3020DQSMSqPjgaVusZJtn9YQ4KFYGkEzXgscv8xDdfde1nM78zkjW8jqv7wgDkZ2w8fH/DMB8RyBpVcQNQNUDqCgDcO6QIDYjnuTzp6bLPFJ9Cfm9YBerSfJGLh3gdftdgVGtqWwzs3DdypoTmMRWMPMCKEe+wwsDcxJD7Jfx+wBEW5+EtBSb/Pgc1nGo2w50ooYRsuvN6Tbkf+DpAifoYIyvyRMDCt5yFjfH1pQys7nMQBvdmLENwWKEq48LUFlso4MaDFZC0k70Aar6RAztBhkcaK6pVCZSQINP8o0YAwpzOhvK4KJ5oxsP8CxtPuNhUlHHODUZG3ir/8cJY3PV0I/PbWIUIMwhuy3Vkn4wAiA==";
// String data = "PzWvRnZfSYU4EjA7UAiJpEcaQ2Y3jpuhQP/SAuqlcM4XWX+md/lgQmdJlTbs9exo21MPDEfkq39eOlm+locKHX5WmBBFQR0rnkf9fWQzuH0tMaLlzuqanfEwA+lhiiGP7NRCFTSrVIWcydgOIoD+nLu61yPvdWpX3Ecnq5FIrMcM+l5AO59p343yiDUgZKAlibQPXVVyXNBXVbmO70ub9hQtio4uu+zfeKm8R68U5wih6ICRQtJfwUX5JgpLLO4SCN7TOEysGtTrcvojRkcr0cfRjnVJdMZjhkOYnT54U0WO7nsepykHJ3KkMSEc3tse41Oc9bDlagt5El51R8A8TGQNvRwOmk4xc2e5IcOZcy/KfbH0LJgX6wsQqBYLoqKMjSgjlWk/21q/fJ4Zk5e2ra+dO2ikjeHnTQQpnDh7cbapS+cHe5Anb/mXQeCcJ3tVPSzuziEgp/fvVGqCZKHNP6zhQVJJ8MoG9NB3sMKlaus8y+1WA12aTWIwEjDfYnez/jEfQ746ci/eXV1IW65cVwUWkGmnTU20XgjOm3G0VbzFGkvq1yb0hw81QLSVHmc2VLFE90vRM3g1OPHVjb9WxLC82er/kIn9RCwwLwMPhyLzdTAHTJhWgAdejqhrXr9LWYvVD/r40nKTZp8J2/xXhQW3rlwDCGbKbExhTpmHfzrZj20bpcg9Hm0BSoH6KXjekwLlm6pr6toFmYN7kgX+A4PhrztftfP8VqcZGat/SS8rTw7WsrkodluBiC4T2CrDKjm8zcVZtn8K6377rgOCGpsc88vD55/LLaMg0xqiT7+O0PUkly0LPu/twEqZH9Qt9NtA0EjEqj44GlbrGSbZ/WEOChWBpBM14LHL/MQ3X3XtZzO/M5I1vI6r+8IA5GdsPHx/wzAfEcgaVXEDUDVA6goA3DukCA2I57k86emyzxSfQn5vWAXq0nyRi4d4HX7XYFRralsM7Nw3cqaE5jEVjDzAihHvsMLA3MSQ+yX8fsARFufhLQUm/z4HNZxqNsOdKKGEbLrzek25H/g6QIn6GCMr8kTAwrechY3x9aUMrO5zEAb3ZixDcFihKuPC1BZbKODGgxWQtJO9AGq+kQM7QYZHGiuqVQmUkCDT/KNGAMKczobyuCieaMbD/AsbT7jYVJRxzg1GRt4q//HCWNz1dCPz21iFCDMIbst1ZJ+MAIg=";

        HttpUtil HttpUtil = new HttpUtil();
        String s = HttpUtil.doGet("https://10.20.30.102:80/chinaLifeMobile/nopaper/sign/getRecall.serv?params=8DJof5KDUx07UjH4%2FURD0TLCNwJuzAdR6NXjoU4GjvPZz6R%2FrDvM2LX23BFGBOx4RdUCIYMss4uM8l%2B9jmNRElS24tCN%2BqiC7EE9qdbV1bDDEvy8AcSHwKNbtCoT5JY%2B");
        System.out.println(s);
        JSONObject jsonS = new JSONObject(s);

        if(!jsonS.getBoolean("success")){
            System.out.println(jsonS.getString("message"));
            return  ;
        }

//        String data = "PzWvRnZfSYU4EjA7UAiJpEcaQ2Y3jpuhQP/SAuqlcM4XWX+md/lgQmdJlTbs9exo21MPDEfkq39eOlm+locKHX5WmBBFQR0rnkf9fWQzuH0tMaLlzuqanfEwA+lhiiGP7NRCFTSrVIWcydgOIoD+nLu61yPvdWpX3Ecnq5FIrMcM+l5AO59p343yiDUgZKAlibQPXVVyXNBXVbmO70ub9hQtio4uu+zfeKm8R68U5wih6ICRQtJfwUX5JgpLLO4SCN7TOEysGtTrcvojRkcr0cfRjnVJdMZjhkOYnT54U0WO7nsepykHJ3KkMSEc3tse41Oc9bDlagt5El51R8A8TGQNvRwOmk4xc2e5IcOZcy/KfbH0LJgX6wsQqBYLoqKMjSgjlWk/21q/fJ4Zk5e2ra+dO2ikjeHnTQQpnDh7cbapS+cHe5Anb/mXQeCcJ3tVPSzuziEgp/fvVGqCZKHNP6zhQVJJ8MoG9NB3sMKlaus8y+1WA12aTWIwEjDfYnez/jEfQ746ci/eXV1IW65cVwUWkGmnTU20XgjOm3G0VbzFGkvq1yb0hw81QLSVHmc2VLFE90vRM3g1OPHVjb9WxLC82er/kIn9RCwwLwMPhyLzdTAHTJhWgAdejqhrXr9LWYvVD/r40nKTZp8J2/xXhQW3rlwDCGbKbExhTpmHfzrZj20bpcg9Hm0BSoH6KXjekwLlm6pr6toFmYN7kgX+A4PhrztftfP8VqcZGat/SS8rTw7WsrkodluBiC4T2CrDKjm8zcVZtn8K6377rgOCGpsc88vD55/LLaMg0xqiT7+O0PUkly0LPu/twEqZH9Qt9NtA0EjEqj44GlbrGSbZ/WEOChWBpBM14LHL/MQ3X3XtZzO/M5I1vI6r+8IA5GdsPHx/wzAfEcgaVXEDUDVA6goA3DukCA2I57k86emyzxSfQn5vWAXq0nyRi4d4HX7XYFRralsM7Nw3cqaE5jEVjDzAihHvsMLA3MSQ+yX8fsARFufhLQUm/z4HNZxqNsOdKKGEbLrzek25H/g6QIn6GCMr8kTAwrechY3x9aUMrO5zEAb3ZixDcFihKuPC1BZbKODGgxWQtJO9AGq+kQM7QYZHGiuqVQmUkCDT/KNGAMKczobyuCieaMbD/AsbT7jYVJRxzg1GRt4q//HCWNz1dCPz21iFCDMIbst1ZJ+MAIg=";
        String data = jsonS.getString("data");

        byte[] x =  Base64.getDecoder().decode(data);
        String strX = new String(x, "GBK");
        logger.info("x: {}", strX);

       String secretKey = "JeF8U9wHFOMfs2Y8";
       byte[] keyData = secretKey.getBytes(ENCODING);
       x = decrypt_Ecb_Padding(keyData, x);

       strX = new String(x, "GBK");
       logger.info("x: {}", strX);

       JSONObject jsonObject = new JSONObject(strX);

       logger.info(jsonObject.toString());

//       String textx = "{\"success\": false,\"code\":10006, \"messages\": [\"您的登录信息已过期，请重新登录系统!\"] }";
//        JSONObject xxxx = new JSONObject(textx);
//       int i = xxxx.getInt("code");
//
//       logger.info("{}",i);

    }

}
