package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="es_qc_main")
public class EsQcMain {
    @Id
    @Column(name="id")
    private String id;

    @Column(name="businessno")
    private String businessNo;

    @Column(name="doccode")
    private String docCode;

    @Column(name="mainPoint_ids")
    private String mainPointIds;

    @Column(name="describe_ids")
    private String describeIds;

    @Column(name="remarks")
    private String remarks;

    @Column(name="status")
    private char status;

    @Column(name="verdict")
    private String verdict;

    @Column(name="create_datetime")
    private Date createDateTime;

    @Column(name="modify_datatime")
    private Date modifyDataTime;

    @Column(name="operator")
    private String operator;

    @Column(name="agentid")
    private String agentId;

    @Column(name = "inspectdate")
    private Date inspectDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBusinessNo() {
        return businessNo;
    }

    public void setBusinessNo(String businessNo) {
        this.businessNo = businessNo;
    }

    public String getDocCode() {
        return docCode;
    }

    public void setDocCode(String docCode) {
        this.docCode = docCode;
    }

    public String getMainPointIds() {
        return mainPointIds;
    }

    public void setMainPointIds(String mainPointIds) {
        this.mainPointIds = mainPointIds;
    }

    public String getDescribeIds() {
        return describeIds;
    }

    public void setDescribeIds(String describeIds) {
        this.describeIds = describeIds;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public String getVerdict() {
        return verdict;
    }

    public void setVerdict(String verdict) {
        this.verdict = verdict;
    }

    public Date getCreateDateTime() {
        return createDateTime;
    }

    public void setCreateDateTime(Date createDateTime) {
        this.createDateTime = createDateTime;
    }

    public Date getModifyDataTime() {
        return modifyDataTime;
    }

    public void setModifyDataTime(Date modifyDataTime) {
        this.modifyDataTime = modifyDataTime;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public Date getInspectDate() {
        return inspectDate;
    }

    public void setInspectDate(Date inspectDate) {
        this.inspectDate = inspectDate;
    }

    @Override
    public String toString() {
        return "EsQcMain{" +
                "id='" + id + '\'' +
                ", businessNo='" + businessNo + '\'' +
                ", docCode='" + docCode + '\'' +
                ", mainPointIds='" + mainPointIds + '\'' +
                ", describeIds='" + describeIds + '\'' +
                ", remarks='" + remarks + '\'' +
                ", status=" + status +
                ", verdict='" + verdict + '\'' +
                ", createDateTime=" + createDateTime +
                ", modifyDataTime=" + modifyDataTime +
                ", operator='" + operator + '\'' +
                ", agentId='" + agentId + '\'' +
                ", inspectDate=" + inspectDate +
                '}';
    }
}
