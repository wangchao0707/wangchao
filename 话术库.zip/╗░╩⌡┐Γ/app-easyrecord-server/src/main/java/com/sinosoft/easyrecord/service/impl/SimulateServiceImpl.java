package com.sinosoft.easyrecord.service.impl;

import com.alibaba.fastjson.JSON;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.entity4afc.LMProduct;
import com.sinosoft.easyrecord.entity4afc.LSOrganization;
import com.sinosoft.easyrecord.server.Req800011;
import com.sinosoft.easyrecord.service.*;
import com.sinosoft.easyrecord.util.MD5;
import com.sinosoft.easyrecord.util.StringSortUtil;
import com.sinosoft.easyrecord.util.UserActionUtil;
import org.apache.tools.ant.filters.StringInputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by wds on 2018-5-14.
 */
@Service
public class SimulateServiceImpl implements SimulateService {

    private Logger logger = LoggerFactory.getLogger(SimulateServiceImpl.class);

    @Autowired
    private UserActionLogService userActionLogService;

    @Value(value = "${com.code}")
    private String comCode;
    @Value("${sso.token.expiresIn}")
    private int tokenExpiresIn;

    @Autowired
    private UserDao userDao;

    @Autowired
    private TokenDao tokenDao;

    @Autowired
    private ContDao contDao;

    @Autowired
    private Req800011 req800011;

    @Autowired
    private AuthenticationDao authenticationDao;

    @Autowired
    private MessageService messageService;

    @Autowired
    private ReplaceTalkDao replaceTalkDao;

    @Autowired
    private  LMProductDao  lmProductDao;

    @Autowired
    private OrganizationDao organizationDao;

    /**
     * User: weihao
     * Date: 2018/5/14
     * Time: 18:56
     * 跳转到 保单录入页面
     */
    @Transactional
    @Override
    public RequestResult doKinescope(JSONObject jsonObject,String ot) {

        RequestResult requestResult = new RequestResult(false);
//        JSONObject jsonObject = new JSONObject(data);
        JSONObject user = jsonObject.getJSONObject("user");
        logger.info("user: {}", user.toString());
        try{
            if(user.getString("townBranchNo")!=null && ! user.getString("townBranchNo").equals("")){
                user.put("orgCode",user.getString("townBranchNo"));
            }
        }catch(Exception ex){
            logger.error("获取渠道过程出错！",user.getString("townBranchNo"),ex);
        }
        JSONObject cont = jsonObject.getJSONObject("cont");

        logger.info("cont: {}", cont);
        logger.info("user: {}", user);
        //校验cont 字段是否完好
        Map contValidate = contValidate(cont);
        //增加被保人信息
        if (!cont.has("insured")){
            JSONObject appnt = cont.getJSONObject("appnt");
            appnt.put("InsuredRelationship", "M"); // 补充关系：本人
            cont.put("insured",appnt);
//        }else
//        {
//            JSONObject insured = cont.getJSONObject("insured");
//            insured.put("insuredRelationship",insured.get("InsuredRelationship"));
//            cont.put("insured",insured);
        }


        Boolean rflag = (Boolean) contValidate.get("rflag");
        if (!rflag) {
            requestResult.setMessage((String) contValidate.get("message"));
            return requestResult;
        }
        //去除重复的busiNum编号
        String onlyBusiNum = replaceBusiNum(cont.getString("busiNum"));
        cont.put("busiNum",onlyBusiNum);

        // 效验 user 字段 非空校验
        Map userValidate = userValidate(user);
        rflag = (Boolean) userValidate.get("rflag");
        if (!rflag) {
            requestResult.setMessage((String) userValidate.get("message"));
            return requestResult;
        }
        //校验talk 字段是否完好
        JSONObject talk = cont.getJSONObject("talk");
        Map talkValidate = replaceTalkValidate(talk);
        rflag = (Boolean) talkValidate.get("rflag");
        if (!rflag) {
            requestResult.setMessage((String) talkValidate.get("message"));
            return requestResult;
        }


        String agentcode = user.getString("agentCode");
        String phoneNo = user.getString("phoneNo");
        //验证手机号格式是否正确
        if (phoneNo.length() != 11) {
            requestResult.setMessage("手机号格式不对");
            return requestResult;
        }
        //判断代理人是否已经注册成功
        Boolean flag = true;
        LSUser lsUser = userDao.getByPhoneNo(phoneNo);
        if (lsUser == null) {
            lsUser = userDao.getByComInfo("24001",agentcode);
            if (lsUser == null){
                flag = false;
            }else{
               String  phoneNum = lsUser.getPhoneNo();
               if(phoneNum != null || phoneNum.equals("")){
                   if(!phoneNum.equals(phoneNo)){
                       requestResult.setMessage("双录的手机号与E店的手机号不一致");
                       return requestResult;
                   }
               }
            }

        } else if (!lsUser.getAgentCode().equals(agentcode)) {
            requestResult.setMessage("代理人手机号已经绑定另一个工号");
            return requestResult;
        }
        //ceshi
//        req800011.getReq800011("18733505618", "ceshi");
        //如果代理人没有注册成功，则 代替代理人进行注册
        if (!flag) {
            SecureRandom random1 = null;
            try {
                random1 = SecureRandom.getInstance("SHA1PRNG");
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            int random;
            if (random1!=null){
                random= Math.abs(random1.nextInt());
            }else {
                random = 123;
            }
            String password = MD5.stringToMD5(random+"");
            //验证通过则模拟注册成功，并且把随机6位密码发送短信给用户
            //正常注册
            //保存User的方法
            Boolean saveBoolean = saveUser(user.toString(), password);
            //注册成功给把随机6位密码发给用户
            req800011.getReq800011(phoneNo, "您的双录app系统密码是" + random);

        }
        Map tokenMap = null;

        logger.info("扫码方式： {}", ot);
        if("QR".equalsIgnoreCase(ot)){
            // 扫码方式，不需要重新登录
            try {
                tokenMap = doLoginByAgentCode(agentcode);
            } catch (Exception ex) {
                logger.error("agentcode: {}, errmsg: {}", agentcode,ex.getMessage(), ex);
                requestResult.setMessage("用户验证有误！！！[E-008 AC: " + agentcode + ", " + ex.getMessage() + "]");
                return requestResult;
            }
        } else {
            //模拟登陆
            //最终返回的结果集
            tokenMap = doLogin(phoneNo);
        }
        if (tokenMap.containsKey("rflag")) {
            requestResult.setMessage((String) tokenMap.get("message"));
            return requestResult;
        }
        Hashtable<String, Object> map = new Hashtable<String, Object>();
        map.put("jumpTermn", "kinescope");
        //添加返回comcode
        cont.put("comCode", comCode);
        //添加risktype字段
        String riskType = "";
        String riskName = "";
        JSONArray risk = cont.getJSONArray("risk");
        for (int i = 0; i < risk.length(); i++) {
            JSONObject riskObject = risk.getJSONObject(i);
            /**
             * 判断险种在双录里面是否有数据，如无数据则删除数据
             **/
            String riskTypeFind =  riskObject.getString("riskType");
            LMProduct  lmProduct = lmProductDao.findByProductCode(riskTypeFind);

            if (!riskType.equals("")) {
                riskType += ",";
            }
            riskType += riskObject.getString("riskType");
            if (!riskName.equals("")) {
                riskName += ",";
            }
            riskName += riskObject.getString("riskName");
        }
        cont.put("riskType", riskType);
        cont.put("riskName", riskName);

        //排序保单号
        String busiNum = cont.getString("busiNum");
        busiNum = StringSortUtil.getArrayStringSort(busiNum);
        cont.put("busiNum", busiNum);
        //自保件
        String isSelf = judgeIsSelf(cont.getJSONObject("appnt"),user);
        cont.put("isSelf",isSelf);
        //投保场景
        String sendScene = user.getString("sendScene");
        cont.put("sendScene",sendScene);
        //渠道
        String channel = user.getString("channel");
        logger.info("channel:{}",channel);
        cont.put("channel",channel);
        //机构
        String orgCode = user.getString("orgCode");
        cont.put("orgCode",orgCode);
        //来源
        cont.put("resource","2");
        try {
            //新增参数user，为了sendScene带入到lsReplaceTalk
            saveRelaceTalk(cont,user);
        } catch (Exception ex) {
            logger.warn(ex.getMessage(),ex);
            requestResult.setMessage("请在您手机的待上传清单中找一下。[D-001]");
            return requestResult;
        }

        Map contMap = (Map) JSON.parse(cont.toString());
        // 去掉话术信息
        contMap.remove("talk");
        map.put("cont", contMap);
        map.put("token", tokenMap);
        logger.info("simulate service kinescope res map {}", map);
        // 添加 返回用户 数据
        requestResult.setSuccess(true);
        requestResult.setMessages("");
        requestResult.setData(map);
        UserActionUtil.info("e-home",agentcode , jsonObject.toString());
        return requestResult;
    }


    private SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

    /**
     * User: weihao
     * Date: 2018/5/15
     * Time: 10:06
     * 正常注册用户
     */
    public Boolean saveUser(String user, String password) {
        JSONObject jsonObject = new JSONObject(user);
        //解析用户信息
        String agentCode = jsonObject.getString("agentCode");
        String channel = jsonObject.getString("channel");
        String phoneNo = jsonObject.getString("phoneNo");
        String name = jsonObject.getString("name");
        String sex = jsonObject.getString("sex");
        String birthday = "1980-01-01";
        String orgCode = jsonObject.getString("orgCode");
        logger.info("orgCode="+orgCode);
        //组织用户数据
        LSUser lsUser = new LSUser();
        lsUser.setUserId(UUID.randomUUID().toString());
        lsUser.setAgentCode(agentCode);
        lsUser.setChannel(channel);
        lsUser.setComCode(comCode);
        lsUser.setIdNo(jsonObject.getString("idNo"));
        lsUser.setIdType("4");
        lsUser.setIsPush("N");
        java.sql.Date currDate = new java.sql.Date(System.currentTimeMillis());
        String currTime = format.format(currDate);
        lsUser.setMakeDate(currDate);
        lsUser.setMakeTime(currTime);
        lsUser.setModifyDate(currDate);
        lsUser.setModifyTime(currTime);
        lsUser.setBrithday(birthday);
        lsUser.setUseFalg("1");
        lsUser.setWorkFlag("0");
        lsUser.setName(name);
        lsUser.setOrgCode(orgCode);
        lsUser.setSex(sex);
        lsUser.setPhoneNo(phoneNo);

        //通过state字段的值区分银保注册虚拟账号  Y 为银保数据 1 为 app数据
        lsUser.setState('1');
        //设置角色为营销员
        lsUser.setRole("S");
        //保存代理人
        userActionLogService.info("SYSTEM", "create_lsuser", "SimulateServiceImpl > saveUser \n user: " + lsUser, new Exception());
        userDao.save(lsUser);

        //为代理人创建一个密码 默认密码为 111111
        LSAuthentication lsAuthentication = new LSAuthentication();
        lsAuthentication.setUserId(lsUser.getUserId());
        lsAuthentication.setPassword(password);
        authenticationDao.save(lsAuthentication);

        return true;
    }

    /**
     * User: weihao
     * Date: 2018/5/15
     * Time: 10:31
     * 模拟登录
     */
    public Map doLogin(String phoneNo) {
        Map<String, Object> res = new HashMap<>();

        //查询用户信息
        LSUser lsUser = userDao.getByPhoneNo(phoneNo);
        if (lsUser == null) {
            res.put("rflag", false);
            res.put("message", "代理人没有注册");
            return res;
        }
        String userId = lsUser.getUserId();
        LDToken ldToken = tokenDao.getTokenByUserId(userId);
        //判断是否登录
        if (ldToken == null) {
            ldToken = createAndSaveToken(userId);
        } else {
            //删除token
            tokenDao.delToken(ldToken);
            ldToken = createAndSaveToken(userId);
        }
        logger.info("simulate service impl token {}", ldToken);
        //组织返回数据
        res.put("access_token", ldToken.getAccessToken());
        res.put("expires_in", ldToken.getExpiresIn());
        res.put("refresh_token", ldToken.getRefreshToken());
        return res;
    }

    public Map doLoginByAgentCode(String agentCode) {
        Map<String, Object> res = new HashMap<>();

        //查询用户信息
        LSUser lsUser = userDao.getByComInfo("24001", agentCode);
        if (lsUser == null) {
            res.put("rflag", false);
            res.put("message", "代理人没有注册");
            return res;
        }
        String userId = lsUser.getUserId();
        LDToken ldToken = tokenDao.getTokenByUserId(userId);
//        //判断是否登录
//        if (ldToken == null) {
//            ldToken = createAndSaveToken(userId);
//        } else {
//            //删除token
//            tokenDao.delToken(ldToken);
//            ldToken = createAndSaveToken(userId);
//        }
        logger.info("simulate service impl token {}", ldToken);
        //组织返回数据
        res.put("access_token", ldToken.getAccessToken());
        res.put("expires_in", ldToken.getExpiresIn());
        res.put("refresh_token", ldToken.getRefreshToken());
        return res;
    }

    /**
     * User: weihao
     * Date: 2018/5/15
     * Time: 10:32
     * 新建token
     */
    private LDToken createAndSaveToken(String userId) {
        LDToken token = new LDToken();
        token.createToken();
        token.setUserId(userId);
        token.setExpiresIn(tokenExpiresIn);
        tokenDao.save(token);
        return token;
    }


    /**
     * 跳转待上传列表
     */
    @Transactional
    @Override
    public RequestResult doWarrantyStatu(String data) {

        RequestResult requestResult = new RequestResult(false);
        JSONObject jsonObject = new JSONObject(data);
        JSONObject user = jsonObject.getJSONObject("user");
        String phoneNo = user.getString("phoneNo");
        //模拟登陆
        //最终返回的结果集
        Map tokenMap = doLogin(phoneNo);
        if (tokenMap.containsKey("rflag")) {
            requestResult.setMessage((String) tokenMap.get("message"));
            return requestResult;
        }
        Hashtable resMap = new Hashtable<>();
        resMap.put("token", tokenMap);
        resMap.put("jumpTermn", "warrantyStatu");
        requestResult.setSuccess(true);
        requestResult.setData(resMap);
        return requestResult;
    }


    /**
     * 查询保单详情
     *
     * @return
     */
    @Transactional
    @Override
    public RequestResult doWarrantyDetail(String data) {
        RequestResult requestResult = new RequestResult(false);
        JSONObject jsonObject = new JSONObject(data);
        JSONObject user = jsonObject.getJSONObject("user");
        String phoneNo = user.getString("phoneNo");
        //模拟登陆
        //最终返回的结果集
        Map tokenMap = doLogin(phoneNo);
        if (tokenMap.containsKey("rflag")) {
            requestResult.setMessage((String) tokenMap.get("message"));
            return requestResult;
        }
        //根据保单号查询当前 客户端唯一标识
        String busiNum = jsonObject.getString("busiNum");
        //排序投保单号
        busiNum = StringSortUtil.getArrayStringSort(busiNum);

        LSCont lsCont = contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne(comCode, comCode, busiNum, 'Y');
        if (lsCont == null) {
            requestResult.setMessage("该投保单号没有上传记录");
            return requestResult;
        }
        Hashtable<String, Object> resMap = new Hashtable<>();

        //查询保单信息
        requestResult = messageService.findByContNo(lsCont.getClientContNo());
        if (!requestResult.isSuccess()) {
            logger.info("not find contNo{}", busiNum);
            return requestResult;
        } else {
            resMap = (Hashtable<String, Object>) requestResult.getData();
        }
        resMap.put("jumpTermn", "warrantyDetail");
        resMap.put("token", tokenMap);
//        requestResult.setSuccess(true);
        requestResult.setData(resMap);
        return requestResult;
    }

    /**
     * User: weihao
     * Date: 2018/5/16
     * Time: 10:14
     * 校验cont字段是否完好
     */
    public Map contValidate(JSONObject cont) {
        Map<String, Object> map = new HashMap<>();
        Boolean rflag = true;
        String message = "";
        if (!cont.has("busiNum")) {
            rflag = false;
            message += "busiNum 参数为空\n";
        }else{
            // 银保业务控制
            String contbusiNums = (String)cont.get("busiNum");
            String busiNums[] = contbusiNums.split(",");
            for(String b : busiNums)
            {
                if(b.startsWith("1188"))
                {
                    rflag = false;
                    message += "该单是银保单，请单独通过双录APP录制。\n";
                }
            }
        }

        if (!cont.has("risk")) {
            rflag = false;
            message += "risk 参数为空\n";
        } else {
            JSONArray risk = cont.getJSONArray("risk");
            if (risk.length() == 0) {
                rflag = false;
                message += "risktype 参数为空\n";
            } else {
                for (int i = 0; i < risk.length(); i++) {
                    if (!risk.getJSONObject(i).has("riskType")) {
                        rflag = false;
                        message += "risktype 参数为空\n";
                    }
                    if (!risk.getJSONObject(i).has("riskName")) {
                        rflag = false;
                        message += "riskName 参数为空\n";
                    }
                }
            }
        }
        if (!cont.has("scanDate")) {
            rflag = false;
            message += "scanDate 参数为空\n";
        }
        if (!cont.has("scanTime")) {
            rflag = false;
            message += "scanTime 参数为空\n";
        }
        if (!cont.has("appnt")) {
            rflag = false;
            message += "appnt 参数为空\n";
        } else {
            JSONObject appnt = cont.getJSONObject("appnt");
            if (!appnt.has("name")) {
                rflag = false;
                message += "投保人name 参数为空\n";
            }
            if (!appnt.has("sex")) {
                rflag = false;
                message += "投保人sex 参数为空\n";
            }
            if (!appnt.has("birthday")) {
                rflag = false;
                message += "投保人birthday 参数为空\n";
            }
            if (!appnt.has("idNo")) {
                rflag = false;
                message += "投保人idNo 参数为空\n";
            }
            if (!appnt.has("address")) {
                rflag = false;
                message += "投保人address 参数为空\n";
            }
            if(rflag){//通过非空验证则转义投保人证件类型
                appnt.put("idType",replaceIdType(appnt.getString("idType")));
            }
        }
        if (cont.has("insured")) {
            JSONObject insured = cont.getJSONObject("insured");
            if (!insured.has("name")) {
                rflag = false;
                message += "被保人name 参数为空\n";
            }
            if (!insured.has("sex")) {
                rflag = false;
                message += "被保人sex 参数为空\n";
            }
            if (!insured.has("birthday")) {
                rflag = false;
                message += "被保人birthday 参数为空\n";
            }
            if (!insured.has("idNo")) {
                rflag = false;
                message += "被保人idNo 参数为空\n";
            }
            if (!insured.has("address")) {
                rflag = false;
                message += "被保人address 参数为空\n";
            }

        }

        if (!cont.has("talk")) {
            rflag = false;
            message += "实时话术内容不能为空\n";
        }
        map.put("rflag", rflag);
        map.put("message", message);
        return map;
    }

    /**
     * 验证实时话术数据
     *
     * @param talk
     * @return
     */
    public Map replaceTalkValidate(JSONObject talk) {
        Map result = new HashMap();
        boolean rflag = true;
        StringBuffer sb = new StringBuffer("");
        if (!talk.has("appntName")) {
            rflag = false;
            sb.append("投保人姓名不能为空\n");
        }
        if (!talk.has("comName")) {
            rflag = false;
            sb.append("销售人员所属公司名称不能为空\n");
        }

        if (!talk.has("insuredName")) {
            rflag = false;
            sb.append("被保人姓名不能为空\n");
        }
        if (!talk.has("userName")) {
            rflag = false;
            sb.append("销售人员姓名不能为空\n");
        }

        if (!talk.has("risk")) {
            rflag = false;
            sb.append("产品信息不能为空\n");
        } else {
            JSONArray risks = talk.getJSONArray("risk");
            for (int i = 0; i < risks.length(); i++) {
                JSONObject risk = risks.getJSONObject(i);
                if (!risk.has("riskCode")) {
                    rflag = false;
                    sb.append("产品信息编码不能为空\n");
                }
                if (!risk.has("riskName")) {
                    rflag = false;
                    sb.append("产品信息名称不能为空\n");
                }
                if (risk.has("intersection")) {
                    JSONObject intersection = risk.getJSONObject("intersection");
                    if (!intersection.has("payIntv")) {
                        rflag = false;
                        sb.append("期交产品缴费方式不能为空\n");
                    }
                    if (!intersection.has("prem")) {
                        rflag = false;
                        sb.append("期交产品保费不能为空\n");
                    }
                    if (!intersection.has("payEndYear")) {
                        rflag = false;
                        sb.append("期交产品缴费期间不能为空\n");
                    }
                    if (!intersection.has("insuYear")) {
                        rflag = false;
                        sb.append("期交产品保险期间不能为空\n");
                    }
                    if (!intersection.has("payEndYearFlag")) {
                        rflag = false;
                        sb.append("交费期间标记值不能为空\n");
                    }
                    if (!intersection.has("insuYearFlag")) {
                        rflag = false;
                        sb.append("保险期间标记值\n");
                    }

                }
                if (risk.has("wholesale")) {
                    JSONObject wholesale = risk.getJSONObject("wholesale");
                    if (!wholesale.has("prem")) {
                        rflag = false;
                        sb.append("趸交产品保费不能为空\n");
                    }
                    if (!wholesale.has("insuYear")) {
                        rflag = false;
                        sb.append("趸交产品保险期间不能为空\n");
                    }
                    if (!wholesale.has("insuYearFlag")) {
                        rflag = false;
                        sb.append("保险期间标记值\n");
                    }

//                    if(!wholesale.has("hesitation")){
//                        rflag=false;
//                        sb.append("趸交产品犹豫期不能为空\n");
//                    }
                }
                if (!risk.has("intersection") && !risk.has("wholesale")) {
                    rflag = false;
                    sb.append("产品信息不能为空\n");
                }
            }
        }

        result.put("rflag", rflag);
        result.put("message", sb.toString());
        return result;
    }

    /**
     * User: weihao
     * Date: 2018/6/28
     * Time: 10:24
     * user 非空校验
     */
    public Map userValidate(JSONObject user) {
        Map<String, Object> map = new HashMap<>();
        Boolean rflag = true;
        String message = "";

        if (!user.has("agentCode")) {
            rflag = false;
            message += "代理人工号不能为空";
        }
        if (!user.has("channel")) {
            rflag = false;
            message += "代理人渠道不能为空";
        }
        if (!user.has("phoneNo")) {
            rflag = false;
            message += "代理人手机号不能为空";
        }
        if (!user.has("name")) {
            rflag = false;
            message += "代理人姓名不能为空";
        }
        if (!user.has("sex")) {
            rflag = false;
            message += "代理人性别不能为空";
        }
        if (!user.has("orgCode")) {
            rflag = false;
            message += "代理人机构编码不能为空";
        }
        if(rflag){
            //替换用户的渠道
            user.put("channel",replaceUserChannel(user.getString("channel")));
        }
        map.put("rflag", rflag);
        map.put("message", message);
        return map;
    }

    /**
     * User: weihao
     * Date: 2018/6/25
     * Time: 14:21
     * 保存实时话术内容
     */
    public void saveRelaceTalk(JSONObject cont,JSONObject user) {
        JSONObject talk = cont.getJSONObject("talk");
        JSONArray risks=talk.getJSONArray("risk");
        String businum=cont.getString("busiNum");
        businum = StringSortUtil.getArrayStringSort(businum);
        JSONObject risk=null;

        JSONObject appnt = cont.getJSONObject("appnt");
        JSONObject insured = cont.getJSONObject("insured");
       for(int i=0;i<risks.length();i++){
            risk=risks.getJSONObject(i);

           //保存talk对象的属性
           LSReplacetalk lsReplacetalk = replaceTalkDao.findByBusiNumAndRiskCode(businum,risk.getString("riskCode"));
           if (lsReplacetalk == null) {
               lsReplacetalk = new LSReplacetalk();
               lsReplacetalk.setId(UUID.randomUUID().toString());
           }
           // 保存 实时话术具体内容
           lsReplacetalk.setBusiNum(businum);
           lsReplacetalk.setAppntName(talk.getString("appntName"));
           lsReplacetalk.setComName(talk.getString("comName"));
           lsReplacetalk.setInsuredName(talk.getString("insuredName"));
           lsReplacetalk.setUserName(talk.getString("userName"));
           lsReplacetalk.setRiskName(risk.getString("riskName"));
           lsReplacetalk.setRiskCode(risk.getString("riskCode"));
           lsReplacetalk.setAppntBirthday(appnt.getString("birthday"));
           lsReplacetalk.setInsuredBirthday(insured.getString("birthday"));
           //lsReplacetalk.setInsuredRelationship(insured.getString("InsuredRelationship"));

           if (risk.has("intersection")) {
               JSONObject intersection = risk.getJSONObject("intersection");
               lsReplacetalk.setIntersectionInsuYear(intersection.getString("insuYear"));
               lsReplacetalk.setIntersectionPayEndYead(intersection.getString("payEndYear"));
               lsReplacetalk.setIntersectionPayInty(intersection.getString("payIntv"));
               lsReplacetalk.setIntersectionPrem(intersection.getString("prem"));
               lsReplacetalk.setIntersectionPayEndYearFlag(intersection.getString("payEndYearFlag"));
               lsReplacetalk.setIntersectionInsuYearFlag(intersection.getString("insuYearFlag"));
               lsReplacetalk.setWholesaleHesitation("XX");
               lsReplacetalk.setWholesaleInsuYear("XX");
               lsReplacetalk.setWholesalePrem("XX");
           }
           if (risk.has("wholesale")) {
               JSONObject wholesale = risk.getJSONObject("wholesale");
               lsReplacetalk.setWholesaleHesitation("XX");
               if (wholesale.has("hesitation") && StringUtils.isEmpty(wholesale.getString("hesitation"))) {
                   lsReplacetalk.setWholesaleHesitation(wholesale.getString("hesitation"));
               }
               lsReplacetalk.setWholesaleInsuYear(wholesale.getString("insuYear"));
               lsReplacetalk.setWholesalePrem(wholesale.getString("prem"));
               lsReplacetalk.setWholesaleInsuYearFlag(wholesale.getString("insuYearFlag"));
               lsReplacetalk.setIntersectionInsuYear("XX");
               lsReplacetalk.setIntersectionPayEndYead("XX");
               lsReplacetalk.setIntersectionPayInty("XX");
               lsReplacetalk.setIntersectionPrem("XX");
           }
           logger.info("save lsreplacetalk {}",lsReplacetalk);
           replaceTalkDao.saveReplaceTalk(lsReplacetalk);
       }
    }

    /**
     * 替换用户渠道
     * @param channel
     * @return 替换后的渠道
     */
    public String replaceUserChannel(String channel){
         switch (channel){
             case "PH":
                 channel="A10";//电商
                 break;
             case "B":
                 channel="A11";//银代
                 break;
             case "I":
                 channel="A13";//个险
                 break;
             case "BS":
                 channel="A14";//团险
                 break;
             case "SP":
                 channel="A15";//柜面直销
                 break;
         }
         return channel;
    }

    /**
     * 替换证件类型
     * @param idType
     * @return替换后的证件类型
     */
    public  String replaceIdType(String idType){
            switch (idType){
                case "I":
                    idType="4";
                    break;
                case "C":
                    idType="5";
                    break;
                case "P":
                    idType="7";
                    break;
                case "W":
                    idType="8";
                    break;
                case "G":
                    idType="9";
                    break;
                case "F":
                    idType="11";
                    break;
                case "O":
                    idType="13";
                    break;
                case "M":
                    idType="14";
                    break;
            }
            return  idType;
    }

    /**
     * 去除重复的busiNum
     * @param businum 替换前的
     * @return  替换后的
     */
    public String replaceBusiNum(String businum) {
        String[] arr = businum.split(",");
        if (arr.length != 1) {
            businum = "";
            for (String str : arr) {
                if (businum.indexOf(str) == -1) {
                    businum += str + ",";
                }
            }
            businum = businum.substring(0, businum.length() - 1);
        }
        return businum;
    }

    public String checkOrgCode(String agentCode) {
        agentCode = agentCode.substring(0, 4);
        if (agentCode.equals("0000")) {
            return "86";
        }
        List<LSOrganization> organizations = organizationDao.findAll(comCode);
        for (LSOrganization organization : organizations) {
            String orgCode = organization.getOrgCode();
            if (orgCode.length() > 3) {
                //判断前四位
                if (agentCode.equals(orgCode.substring(0, 4))) {
                    return orgCode;
                } else if (agentCode.substring(0, 2).equals(orgCode.substring(0, 2))) {
                    if (orgCode.substring(2, 4).equals("00")) {
                        return orgCode;
                    }
                }
            }
        }
        return null;
    }
    //判断自保件
    public String judgeIsSelf(JSONObject appnt, JSONObject user){
        //String userBirthday = user.getString("brithday");
        String userName = user.getString("name");
        String userSex = user.getString("sex");
        //String userIdType = user.getString("idType");
        String userIdNo= user.getString("idNo");
        //String appntBirthday = appnt.getString("birthday");
        String appntName = appnt.getString("name");
        String appntSex = appnt.getString("sex");
        //String appntIdType = appnt.getString("idType");
        String appntIdNo = appnt.getString("idNo");
        if(userName.equals(appntName)&&userSex.equals(appntSex)&&userIdNo.equals(appntIdNo)){
            return "Y";
        }else{
            return "N";
        }
    }

    public RequestResult newLoginOrRegist(String data){
        RequestResult requestResult = new RequestResult(false);
        JSONObject jsonObject = new JSONObject(data);
        JSONObject user = jsonObject.getJSONObject("user");
        logger.info("user: {}", user.toString());

        String agentcode = user.getString("agentCode");
        String phoneNo = user.getString("phoneNo");
        //验证手机号格式是否正确
        if (phoneNo.length() != 11) {
            requestResult.setMessage("手机号格式不对");
            return requestResult;
        }
        //判断代理人是否已经注册成功
        Boolean flag = true;
        LSUser lsUser = userDao.getByPhoneNo(phoneNo);
            if (lsUser == null){
                flag = false;
            }
            if (!flag) {
                logger.info("注册用户");
                SecureRandom random1 = null;
                try {
                    random1 = SecureRandom.getInstance("SHA1PRNG");
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
                int random;
                if (random1!=null){
                    random= Math.abs(random1.nextInt());
                }else {
                    random = 123;
                }
                String password = MD5.stringToMD5(random+"");
                //验证通过则模拟注册成功，并且把随机6位密码发送短信给用户
                //正常注册
                //保存User的方法
                Boolean saveBoolean = saveUser(user.toString(), password);
                //注册成功给把随机6位密码发给用户
                req800011.getReq800011(phoneNo, "您的双录app系统密码是" + random);

            }
            Map<String, Object> tokenMap = new HashMap<>();
            tokenMap = doLogin(phoneNo);
            Hashtable table = new Hashtable();
            table.put("token",tokenMap);
            requestResult.setSuccess(true);
            requestResult.setData(table);
            return requestResult;
    }
}
