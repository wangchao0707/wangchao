package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSBankNetWork;

import java.util.List;

/**
 * Created by wds on 2018-3-20.
 */
public interface BankNetWorkDao {

    void save(LSBankNetWork lsBankNetWork);

    void delete(String id);

    List<LSBankNetWork> findAllByBankNetWorkCode(String bankNetWorkCode);
}
