package com.sinosoft.easyrecord.util.xmlBeanUtil;

/**
 * 标记接口
 *
 * @author baoyang
 */
public interface Transbody {

}
