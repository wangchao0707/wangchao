package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.OrganizationBackupsDao;
import com.sinosoft.easyrecord.dao.OrganizationDao;
import com.sinosoft.easyrecord.entity4afc.LSOrganization;
import com.sinosoft.easyrecord.entity.LSOrganizationBackups;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
/**
 * User: weihao
 * Date: 2018/5/14
 * Time: 17:48
 *  同步机构信息
 */
@Service("req80002")
public class Req80002Impl implements Req80002 {

    private Logger logger = LoggerFactory.getLogger(Req80002Impl.class);


    @Autowired
    private OrganizationDao organizationDao;

    public void setOrganizationDao(OrganizationDao organizationDao) {
        this.organizationDao = organizationDao;
    }

    @Autowired
    private OrganizationBackupsDao organizationBackupsDao;

    public void setOrganizationBackupsDao(OrganizationBackupsDao organizationBackupsDao) {
        this.organizationBackupsDao = organizationBackupsDao;
    }

    @Override
    public String req80002(String xml) {

        logger.info("req80002 xml {}", xml);

        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq80002.class);
        xs1.alias("ORGANIZATIONS", TransbodyReq80002.ORGANIZATIONS.class);
        xs1.alias("ORGANIZATION", TransbodyReq80002.ORGANIZATION.class);
        xs1.addImplicitCollection(TransbodyReq80002.ORGANIZATIONS.class, "ORGANIZATION");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        Transhead head = tmp.getTranshead();
        TransbodyReq80002 body = (TransbodyReq80002) tmp.getTransbody();
        TransbodyReq80002.ORGANIZATIONS organizations = body.getORGANIZATIONS();
        List<TransbodyReq80002.ORGANIZATION> list = organizations.ORGANIZATION;

        String comcode = head.getCOMPANY();
        List<LSOrganization> lsOrganizations = organizationDao.findAll(comcode);
        if (lsOrganizations != null && lsOrganizations.size() != 0) {
            for (LSOrganization lsOrganization : lsOrganizations) {
                if (lsOrganization != null) {
                    LSOrganizationBackups backups = new LSOrganizationBackups();
                    backups.setId(UUID.randomUUID().toString());
                    backups.setOrgCode(lsOrganization.getOrgCode());
                    backups.setComCode(lsOrganization.getComCode());
                    backups.setOrgName(lsOrganization.getOrgName());
                    if (lsOrganization.getUpComCode() != null) {
                        backups.setUpComCode(lsOrganization.getUpComCode());
                        backups.setUpComName(lsOrganization.getUpComName());
                    }

                    Date date = new Date(System.currentTimeMillis());
                    backups.setModifyDate(date);
                    Long makeTime = date.getTime();
                    Date d = new Date(makeTime);
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                    backups.setModifyTime(sdf.format(d));
                    organizationBackupsDao.save(backups);
                    // 删除数据
                    organizationDao.deleteByOrgCode(lsOrganization.getOrgCode());
                }
            }
        }

        if (list != null && list.size() != 0) {

            for (TransbodyReq80002.ORGANIZATION organization : list) {

                // 插入数据
                LSOrganization lsorganization2 = new LSOrganization();
                lsorganization2.setOrgCode(organization.COMCODE);
                lsorganization2.setComCode(organization.COMPANY);
                lsorganization2.setOrgName(organization.COMNAME);
                lsorganization2.setUpComCode(organization.UPCOMCODE);
                lsorganization2.setUpComName(organization.UPCOMNAME);
                organizationDao.save(lsorganization2);

            }

        }
        // 返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

}
