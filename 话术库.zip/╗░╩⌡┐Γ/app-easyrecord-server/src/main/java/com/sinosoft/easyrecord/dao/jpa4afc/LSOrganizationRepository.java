package com.sinosoft.easyrecord.dao.jpa4afc;

import com.sinosoft.easyrecord.entity4afc.LSOrganization;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/19.
 */
public interface LSOrganizationRepository extends JpaRepository<LSOrganization, String> {

    //	LSOrganization findOne(LSOrganization org);
//
    List<LSOrganization> findByComCodeOrderByOrgCodeDesc(String comCode);


}
