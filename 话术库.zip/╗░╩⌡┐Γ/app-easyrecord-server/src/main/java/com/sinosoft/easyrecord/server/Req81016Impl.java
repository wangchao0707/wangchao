package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.entity4afc.LSOrganization;
import com.sinosoft.easyrecord.service.UserActionLogService;
import com.sinosoft.easyrecord.util.MD5;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;

/**
 * Created by wds on 2018-3-20.
 * 同步客户经理信息
 */
@Service("req81016")
public class Req81016Impl implements Req81016 {

    private static final Logger logger = LoggerFactory.getLogger(Req81016Impl.class);

    @Autowired
    private UserActionLogService userActionLogService;

    @Autowired
    private BankNetWorkDao bankNetWorkDao;

    @Autowired
    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Autowired
    private AuthenticationDao authenticationDao;

    public void setAuthenticationDao(AuthenticationDao authenticationDao) {
        this.authenticationDao = authenticationDao;
    }

    @Autowired
    private ChannelDao channelDao;

    public void setChannelDao(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    @Autowired
    private OrganizationDao organizationDao;

    public void setOrganizationDao(OrganizationDao organizationDao) {
        this.organizationDao = organizationDao;
    }

    @Override
    public String getReq81016(String xml) {
        logger.info("req 81016 xml {}", xml);

        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransBodyReq81016.class);
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        Transhead head = tmp.getTranshead();
        TransBodyReq81016 body = (TransBodyReq81016) tmp.getTransbody();
        if (body.TYPE.equals("DELETE")) {
            //刪除操作
            logger.info("delete banknet work id {}", body.ID);
            bankNetWorkDao.delete(body.ID);
        } else {
            LSBankNetWork ls = new LSBankNetWork();
            ls.setId(body.ID);
            ls.setBankNetWorkName(body.BANKNETWORKNAME);
            ls.setBankNetWorkCode(body.BANKNETWORKCODE);
            ls.setPropersonName(body.PROPERSONNAME);
            ls.setPropersonCode(body.PROPERSONCODE);
            bankNetWorkDao.save(ls);

            //虚拟注册 客户经理
            //根据客户经理工号去查询用户
            LSUser lsUser = userDao.findByAgentCode(body.PROPERSONCODE);
            if (lsUser == null) {
                //虚拟注册
                logger.info("虚拟注册 agentcode {}", body.PROPERSONCODE);
                saveUserByXuNi(body.PROPERSONCODE);
            }
        }
        // 返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }


    @Value(value = "${com.code}")
    private String comCode;

    // 客户经理 虚拟注册
    public void saveUserByXuNi(String agentCode) {
        logger.info("ManageCode {} regist ",agentCode);
        logger.info("虚拟注册");
        LSUser lsUser = new LSUser();
        SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
        lsUser.setUserId(UUID.randomUUID().toString());
        lsUser.setAgentCode(agentCode);
        LSChannel channelName = channelDao.findByChannelName("银代");
        if(channelName!=null){
            lsUser.setChannel(channelName.getChannelCode());
        }
        lsUser.setComCode(comCode);
        lsUser.setIdNo(agentCode);
        lsUser.setIsPush("N");
        java.sql.Date currDate = new java.sql.Date(System.currentTimeMillis());
        String currTime = format.format(currDate);
        lsUser.setMakeDate(currDate);
        lsUser.setMakeTime(currTime);
        lsUser.setModifyDate(currDate);
        lsUser.setModifyTime(currTime);
        lsUser.setBrithday("2018-01-01");
        lsUser.setUseFalg("1");
        lsUser.setWorkFlag("0");
        lsUser.setName(agentCode);
        //获取机构编码
        String orgCode = getOrgCode(agentCode);
        lsUser.setOrgCode(orgCode);
        lsUser.setSex("0");
        lsUser.setPhoneNo("");
        //通过state字段的值区分银保注册虚拟账号  Y 为银保数据 1 为 app数据
        lsUser.setState('Y');
        //设置角色为客户经理
        lsUser.setRole("M");
        //保存代理人
        userActionLogService.info("SYSTEM", "create_lsuser", "Req81016Impl > saveUserByXuNi \n user: " + lsUser, new Exception());
        userDao.save(lsUser);
        //为代理人创建一个密码 默认密码为 111111
        LSAuthentication lsAuthentication = new LSAuthentication();
        lsAuthentication.setUserId(lsUser.getUserId());
        lsAuthentication.setPassword(MD5.stringToMD5("111111"));
        authenticationDao.save(lsAuthentication);

    }


    public String getOrgCode(String agentCode) {
        agentCode = agentCode.substring(0, 4);
        if (agentCode.equals("0000")) {
            return "86";
        }
        List<LSOrganization> organizations = organizationDao.findAll(comCode);
        for (LSOrganization organization : organizations
                ) {
            String orgCode = organization.getOrgCode();
            if (orgCode.length() > 3) {
                //判断前四位
                if (agentCode.equals(orgCode.substring(0, 4))) {
                    return orgCode;
                } else if (agentCode.substring(0, 2).equals(orgCode.substring(0, 2))) {
                    if (orgCode.substring(2, 4).equals("00")) {
                        return orgCode;
                    }
                }
            }


        }
        return null;
    }


}
