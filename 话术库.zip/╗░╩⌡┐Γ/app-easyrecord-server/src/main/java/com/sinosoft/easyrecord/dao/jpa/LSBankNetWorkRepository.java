package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSBankNetWork;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by wds on 2018-3-20.
 */
public interface LSBankNetWorkRepository extends JpaRepository<LSBankNetWork, String> {

    List<LSBankNetWork> findByBankNetWorkCode(String bankNetWordCode);

    @Transactional
    void deleteById(String id);
}
