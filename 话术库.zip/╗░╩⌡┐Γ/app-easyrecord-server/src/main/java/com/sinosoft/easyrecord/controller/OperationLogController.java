package com.sinosoft.easyrecord.controller;

import java.util.Hashtable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.service.OperationLogService;

@RestController
@RequestMapping("/api/user")
public class OperationLogController {

    @Autowired
    private OperationLogService operationLogService;

    @RequestMapping(value = "/operationLog", method = RequestMethod.POST)
    @ResponseBody
    public RequestResult saveOperationLog(@RequestParam(value = "operationLog") MultipartFile operationLog, @RequestParam String userId, @RequestParam String equipmentInformation) {
        ServiceResult<String, String[]> result = operationLogService.saveOperationLog(operationLog, userId, equipmentInformation);
        if (!result.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(result.getFailResult());
            return requestResult;
        } else {
            RequestResult requestResult = new RequestResult(true);
            Hashtable<String, String> date = new Hashtable<>();
            date.put("logPath", result.getSuccessResult());
            requestResult.setData(date);
            return requestResult;

        }


    }

}
