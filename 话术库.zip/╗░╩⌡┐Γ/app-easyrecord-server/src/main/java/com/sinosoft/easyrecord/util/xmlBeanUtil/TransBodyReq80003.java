package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zf on 2017/8/8.
 */
public class TransBodyReq80003 implements Transbody, Serializable {

    private static final long serialVersionUID = -5516458734124140937L;

    private VERBALS VERBALS;

    public VERBALS getVERBALS() {
        return VERBALS;
    }

    public void setVERBALS(VERBALS VERBALS) {
        this.VERBALS = VERBALS;
    }

    public static class VERBALS {
        public String VERBALCOUNT;//<!--数据条数-->
        public List<VERBAL> VERBAL = new ArrayList<VERBAL>();

    }

    public static class VERBAL {
        public String COMPANY;//<!-- 保险公司代码 -->
        public String COMCODE;//公司机构编码
        public String DESCRIBEID;//<!-- 话术id -->
        public String RISKTYPECODE;//<!-- 产品类型编码 -->
        public String RISKTYPENAME;//<!-- 产品类型名称 -->
        public String QCPOINT;//<!-- 质检要点 -->
        public String QCTRICK;//<!-- 质检话术 -->
        public String ORDERNO;//<!-- 顺序号 -->s
    }
}
