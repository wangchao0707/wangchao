package com.sinosoft.easyrecord.util;

import org.springframework.data.domain.Sort;

public class SortUtil {

    //排序方式
    private String orderType;

    //排序字段
    private String orderField;

    public String getOrderField() {
        return orderField;
    }

    public void setOrderField(String orderField) {
        this.orderField = orderField;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public SortUtil(String orderType, String orderField) {
        this.orderType = orderType;
        this.orderField = orderField;
    }

    //默认为DESC排序
    public SortUtil(String orderField) {
        this.orderField = orderField;
        this.orderType = "desc";
    }

    public static Sort basicSort(SortUtil... dtos) {
        Sort result = null;
        for (int i = 0; i < dtos.length; i++) {
            SortUtil dto = dtos[i];
            if (result == null) {
                result = new Sort(Sort.Direction.fromString(dto.getOrderType()), dto.getOrderField());
            } else {
                result = result.and(new Sort(Sort.Direction.fromString(dto.getOrderType()), dto.getOrderField()));
            }
        }
        return result;
    }


}
