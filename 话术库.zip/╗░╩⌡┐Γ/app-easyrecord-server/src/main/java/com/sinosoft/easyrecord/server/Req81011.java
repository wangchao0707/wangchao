package com.sinosoft.easyrecord.server;

public interface Req81011 {

    public String getReq81011(String xml);
}
