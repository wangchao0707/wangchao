package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSDelFile;

import java.util.List;

/**
 * Created by wh on 2018/3/2.
 */
public interface DelFileDao {

    void saveDelFile(LSDelFile lsDelFile);


    List<LSDelFile> findByIsDelPic(String isDelPic);


    List<LSDelFile> findByIsDelVideo(String isDelVideo);


    void updateIsDelPicByPicId(String isDelPic, String picId);

    void updateIsDelVideoByVideoId(String isDelVideo, String videoId);
}
