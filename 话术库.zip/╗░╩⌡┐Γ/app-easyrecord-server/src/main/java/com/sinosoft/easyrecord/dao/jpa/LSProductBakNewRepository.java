package com.sinosoft.easyrecord.dao.jpa;


import com.sinosoft.easyrecord.entity.LSProductNewBak;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LSProductBakNewRepository extends JpaRepository<LSProductNewBak, String> {
}
