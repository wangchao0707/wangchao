//package com.sinosoft.easyrecord.service.impl;
//
//import com.sinosoft.easyrecord.dao.*;
//import com.sinosoft.easyrecord.entity.LDComConfig;
//import com.sinosoft.easyrecord.service.VideoUpload;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//@Component
//public class VideoUploadFactoryImpl4QCloud implements VideoUpload.VideoUploadFactory {
//
//    @Autowired
//    private ComConfigDao comConfigDao;
//
//    public void setComConfigDao(ComConfigDao comConfigDao) {
//        this.comConfigDao = comConfigDao;
//    }
//
//
//    /////////////////////
//
//
//    private PictureDao pictureDao;
//
//    @Autowired
//    public void setPictureDao(PictureDao pictureDao) {
//        this.pictureDao = pictureDao;
//    }
//
//
//    private ContStateDao contStateDao;
//
//    @Autowired
//    public void setContStateDao(ContStateDao contStateDao) {
//        this.contStateDao = contStateDao;
//    }
//
//
//    private VideoDao videoDao;
//
//    @Autowired
//    public void setVideoDao(VideoDao videoDao) {
//        this.videoDao = videoDao;
//    }
//
//    private ContDao contDao;
//
//    @Autowired
//    public void setContDao(ContDao contDao) {
//        this.contDao = contDao;
//    }
//
//
//    @Override
//    public VideoUpload getInstance(String comcode) {
//
////        String comCode = CurrentUser.getUser().getComCode();
//
//        LDComConfig comConfig = comConfigDao.findByComCode(comcode);
//
//        VideoUploadImpl4QCloud vodUpload = new VideoUploadImpl4QCloud(comConfig.getCloudSecretId(), comConfig.getCloudSecretKey(), comConfig.getVideoRegion());
//        vodUpload.setPictureDao(pictureDao);
//        vodUpload.setContStateDao(contStateDao);
//        vodUpload.setVideoDao(videoDao);
//        vodUpload.setContDao(contDao);
//        vodUpload.setStorageRegion(comConfig.getStorgeRegion());
//        return vodUpload;
//    }
//}
