package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.QCloudPushEventRepository;
import com.sinosoft.easyrecord.entity.QCloudPushEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("qCloudPushEventDao")
public class QCloudPushEventDaoImpl4JPA implements QCloudPushEventDao {

    @Autowired
    private QCloudPushEventRepository qCloudPushEventRepository;

    public void savePushEvent(QCloudPushEvent pushEvent) {
        qCloudPushEventRepository.save(pushEvent);
    }

    @Override
    public List<QCloudPushEvent> findTop10ByDealNodeKeyIsNull() {
        return qCloudPushEventRepository.findTop10ByDealNodeKeyIsNull();
    }

    @Override
    public List<QCloudPushEvent> findByDealNodeKey(String dealNodeKey) {
        return qCloudPushEventRepository.findByDealNodeKeyAndStatus(dealNodeKey, '0');
    }

    @Override
    public void assignEvent(QCloudPushEvent event) {
        qCloudPushEventRepository.assignEvent(event.getComCode(), event.getMsgHandle(), event.getDealNodeKey());
    }

    @Override
    public void saveStatus(QCloudPushEvent event) {
        qCloudPushEventRepository.saveStatus(event.getComCode(), event.getMsgHandle(), event.getStatus());
    }
}
