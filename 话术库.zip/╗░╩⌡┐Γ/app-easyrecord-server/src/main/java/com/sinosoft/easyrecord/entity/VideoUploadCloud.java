package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @create 2020/3/1 0001
 */
@Entity
@Table(name = "video_upload_cloud")
public class VideoUploadCloud implements Serializable {

    private static final long serialVersionUID = -6777002752326126525L;
    @Id
    @Column(name = "cont_id")
    private String contId;
    @Column(name = "com_code")
    private String comCode;
    @Column(name = "display_name")
    private String displayName;
    @Column(name = "meeting_room_id")
    private String meetingRoomId;
    @Column(name = "target_url")
    private String targetUrl;
    @Column(name = "start_time")
    private String startTime;
    @Column(name = "end_time")
    private String endTime;
    @Column(name = "error_msg")
    private String errorMsg;
    @Column(name = "upload_status")
    private String uploadStatus;
    @Column(name = "cloud_storage_path")
    private String cloudStoragePath;

    public String getContId() {
        return contId;
    }

    public void setContId(String contId) {
        this.contId = contId;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getMeetingRoomId() {
        return meetingRoomId;
    }

    public void setMeetingRoomId(String meetingRoomId) {
        this.meetingRoomId = meetingRoomId;
    }

    public String getTargetUrl() {
        return targetUrl;
    }

    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getUploadStatus() {
        return uploadStatus;
    }

    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }

    public String getCloudStoragePath() {
        return cloudStoragePath;
    }

    public void setCloudStoragePath(String cloudStoragePath) {
        this.cloudStoragePath = cloudStoragePath;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    @Override
    public String toString() {
        return "VideoUploadCloud{" +
                "contId='" + contId + '\'' +
                ", comCode='" + comCode + '\'' +
                ", displayName='" + displayName + '\'' +
                ", meetingRoomId='" + meetingRoomId + '\'' +
                ", targetUrl='" + targetUrl + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", errorMsg='" + errorMsg + '\'' +
                ", uploadStatus='" + uploadStatus + '\'' +
                ", cloudStoragePath='" + cloudStoragePath + '\'' +
                '}';
    }
}
