package com.sinosoft.easyrecord.controller;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.service.MessageService;
import com.sinosoft.easyrecord.sso.CurrentUser;
import com.sinosoft.easyrecord.vo.MessageByContForm;
import com.sinosoft.easyrecord.vo.PageUploadForm;
import com.sinosoft.easyrecord.vo.QueryMessageForm;
import com.sinosoft.easyrecord.vo.ReadMessageForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by WinterLee on 2017/7/22.
 */
@RestController
@RequestMapping("/api/message")
public class MessageController {


    @Autowired
    private MessageService messageService;

    //查询用户全部消息
    @RequestMapping(value = "/all", method = RequestMethod.POST)
    public RequestResult findMessage() {

        return messageService.findMessage();

    }

    //查询保单号 关联消息
    @RequestMapping(value = "/single", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    public RequestResult findByContNo(String contNo) {

        return findByContNo(new MessageByContForm(contNo));
    }

    @RequestMapping(value = "/single", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult findByContNo(@RequestBody MessageByContForm messageByContForm) {
        //非空校验
        ServiceResult<String, String[]> validateResult = messageByContForm.validate();
        if (!validateResult.isSuccess()) {

            RequestResult result = new RequestResult(false);
            result.setMessages(validateResult.getFailResult());

            return result;
        }
        RequestResult requestResult = messageService.findByContNo(messageByContForm.getContNo());
        return requestResult;

    }

    //消息列表分页查询
    @RequestMapping(value = "/pageMessage", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    public RequestResult pageMessage(@RequestParam Integer pageNo, @RequestParam String sortTime) {
        return pageMessage(new PageUploadForm(pageNo, sortTime));
    }

    @RequestMapping(value = "/pageMessage", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult pageMessage(@RequestBody PageUploadForm pageUploadForm) {
        ServiceResult<String, String[]> request = pageUploadForm.validate();
        if (!request.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(request.getFailResult());
            return requestResult;
        }
        return messageService.findMessage(pageUploadForm.getPageNo(), pageUploadForm.getSortTime());
    }


    @RequestMapping(value = "/query", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    public RequestResult getMessageList( //
                                         @RequestParam(name = "pageNo", required = false, defaultValue = "0") int pageNo, //
                                         @RequestParam(name = "pageSize", required = false, defaultValue = "10") int pageSize //
    ) {

        QueryMessageForm messageQuery = new QueryMessageForm();
        messageQuery.setPageNo(pageNo);
        messageQuery.setPageSize(pageSize);

        return getMessageList(messageQuery);
    }


    @RequestMapping(value = "/query", method = RequestMethod.POST, consumes = "application/json")
    public RequestResult getMessageList( //
                                         @RequestBody QueryMessageForm messageQuery //
    ) {

        String userId = CurrentUser.getUser().getUserId();
        messageQuery.setUserNo(userId);

        ServiceResult<String, String[]> validateResult = messageQuery.validate();
        if (!validateResult.isSuccess()) {

            RequestResult result = new RequestResult(false);
            result.setMessages(validateResult.getFailResult());

            return result;
        }

        return messageService.getMessageList(messageQuery);

    }


    @RequestMapping(value = "/read", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    public RequestResult readMessage(String messageNo) {
        return readMessage(new ReadMessageForm(messageNo));
    }

    @RequestMapping(value = "/read", method = RequestMethod.POST, consumes = "application/json")
    public RequestResult readMessage( //
                                      @RequestBody ReadMessageForm readMessageForm //
    ) {

        String userId = CurrentUser.getUser().getUserId();
        readMessageForm.setUserNo(userId);

        ServiceResult<String, String[]> dealResult = messageService.readMessage(readMessageForm);
        if (dealResult.isSuccess()) {
            return new RequestResult(true);
        } else {
            RequestResult result = new RequestResult(false);
            result.setMessages(dealResult.getFailResult());

            return result;
        }

    }

}
