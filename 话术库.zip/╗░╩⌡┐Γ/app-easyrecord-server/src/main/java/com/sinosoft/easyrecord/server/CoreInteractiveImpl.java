package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.service.NewTalkService;
import com.sinosoft.easyrecord.service.PolicyService;
import com.sinosoft.easyrecord.util.AgeUtil;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.sinosoft.easyrecord.vo.*;
import com.thoughtworks.xstream.XStream;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import javax.xml.namespace.QName;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * 保单详细信息上传接口
 */
public class CoreInteractiveImpl implements CoreInteractive {


    private BankDao bankDao;

    public void setBankDao(BankDao bankDao){
        this.bankDao = bankDao;
    }

    private LSComDao lsComDao;

    public void setLsComDao(LSComDao lsComDao) { this.lsComDao = lsComDao;}

    private NewTalkService newTalkService;

    public void setNewTalkService(NewTalkService newTalkService) {
        this.newTalkService = newTalkService;
    }



    private static final Logger logger = LoggerFactory.getLogger(CoreInteractiveImpl.class);

    private String afcServiceBaseUrl;
    private String afcServiceMethod;

    public CoreInteractiveImpl(LDComConfig comConfig) {
        this.afcServiceBaseUrl = comConfig.getServiceBusiURL();
        this.afcServiceMethod = comConfig.getServiceKey();
    }


    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    private AuthenticationDao authen;

    public void setAuthen(AuthenticationDao authen) {
        this.authen = authen;
    }

    private PolicyService policyService;

    public void setPolicyService(PolicyService policyService) {
        this.policyService = policyService;
    }

    private ContTimeDao contTimeDao;

    public void setContTimeDao(ContTimeDao contTimeDao) {
        this.contTimeDao = contTimeDao;
    }

    private LSStateLocaDao lsStateLocaDao;

    public void setLsStateLocaDao(LSStateLocaDao lsStateLocaDao) {
        this.lsStateLocaDao = lsStateLocaDao;
    }

    private ContStateDao contStateDao;

    public void setContStateDao(ContStateDao contStateDao) {
        this.contStateDao = contStateDao;
    }

    private OrganizationDao organizationDao;

    public void setOrganizationDao(OrganizationDao organizationDao) {
        this.organizationDao = organizationDao;
    }

    private MessageDao messageDao;

    public void setMessageDao(MessageDao messageDao) {
        this.messageDao = messageDao;
    }

    private EsVideoMainDao esVideoMainDao;



    private ContDao contDao;

    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }

    public ReplaceTalkDao replaceTalkDao;

    public void setReplaceTalkDao(ReplaceTalkDao replaceTalkDao) {
        this.replaceTalkDao = replaceTalkDao;
    }

    private TalkContentDao talkContentDao;

    public void setTalkContentDao(TalkContentDao talkContentDao) {
        this.talkContentDao = talkContentDao;
    }

//    private String picUrl;
//    private String videoToMp3Url;
//    private String videoUrl;
//    private String mp3Url;
    private String downloadZip;
    private String screenShotUrl;
    private String submitPolicyUrl;
//    private long picTime;
    private long videoTime;
//    private long videoToMp3Time;
//    private long mp3Time;
    private long downloadTime;
    private long screenShotTime;
    private String filePath;
    private String zipPath;
//    private String screenUrl;
    private String updateVideoUrl;

    public void setUpdateVideoUrl(String updateVideoUrl) {
        this.updateVideoUrl = updateVideoUrl;
    }

//    public void setScreenUrl(String screenUrl) {
//        this.screenUrl = screenUrl;
//    }

    public void setZipPath(String zipPath) {
        this.zipPath = zipPath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setScreenShotTime(long screenShotTime) {
        this.screenShotTime = screenShotTime;
    }

    public void setScreenShotUrl(String screenShotUrl) {
        this.screenShotUrl = screenShotUrl;
    }

    public void setDownloadTime(long downloadTime) {
        this.downloadTime = downloadTime;
    }

    public void setDownloadZip(String downloadZip) {
        this.downloadZip = downloadZip;
    }

//    public void setPicUrl(String picUrl) {
//        this.picUrl = picUrl;
//    }
//
//    public void setVideoToMp3Url(String videoToMp3Url) {
//        this.videoToMp3Url = videoToMp3Url;
//    }
//
//    public void setVideoUrl(String videoUrl) {
//        this.videoUrl = videoUrl;
//    }
//
//    public void setMp3Url(String mp3Url) {
//        this.mp3Url = mp3Url;
//    }
//
//    public void setPicTime(long picTime) {
//        this.picTime = picTime;
//    }
//
//    public void setVideoTime(long videoTime) {
//        this.videoTime = videoTime;
//    }
//
//    public void setVideoToMp3Time(long videoToMp3Time) {
//        this.videoToMp3Time = videoToMp3Time;
//    }
//
//    public void setMp3Time(long mp3Time) {
//        this.mp3Time = mp3Time;
//    }

    public void setSubmitPolicyUrl(String submitPolicyUrl) {
        this.submitPolicyUrl = submitPolicyUrl;
    }

    private SimpleDateFormat contSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
    private SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
    private SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");

    public void submitCont(LSCont.LSContPK lsContPK) {
        uploadHttp(lsContPK.getContNo(), submitPolicyUrl);
    }

    public void submitCont(LSCont lsCont) {
        // 获取报文
        String inputXml = "";

        lsCont.setInteractive("B");
        this.contDao.save(lsCont);

        inputXml = getReq81001(lsCont);
        logger.info("contNo {} inputXml:: {}", lsCont.getContNo(), inputXml);
        if (StringUtils.isEmpty(inputXml)) {
            logger.error("组织报文出错 contNo {}",lsCont.getContNo());
            return;
        }

        try {
            // 文件保存开始 时间节点
            LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
            java.util.Date date = new java.util.Date();
            lsContTime.setMessageBeginTime(contSdf.format(date));
            contTimeDao.saveContTime(lsContTime);

            // 核心交互 返回报文
            logger.info("core url {}", afcServiceBaseUrl);
            String returnxml = sendService(inputXml, afcServiceBaseUrl, afcServiceMethod);
            logger.info("returnxml::" + returnxml);
            // 解析核心报文
            XStream xs1 = new XStream();
            xs1.alias("TRANSDATA", Transdata.class);
            xs1.alias("TRANSBODY", Transbody.class, TransbodyRes.class);
            Transdata tmp = (Transdata) xs1.fromXML(returnxml);
            TransbodyRes transbodyRes = (TransbodyRes) tmp.getTransbody();
            String returncode = transbodyRes.getTRANSRESULT().RETURNCODE;
            String message = transbodyRes.getTRANSRESULT().MESSAGE;
            logger.info("returncode:" + returncode);
            // 核心返回值判断
            if (returncode.equals("000000")) {
                lsCont.setInteractive("M");
                policyService.saveCont(lsCont);

//                //添加保单状态变更轨迹记录
//                lsStateLocaDao.saveStateLoca(lsCont, "数据审核中");
//                logger.info("req 80001/81001 success");

                java.util.Date date1 = new java.util.Date();
                lsContTime.setMessageEndTime(contSdf.format(date1));
                contTimeDao.saveContTime(lsContTime);
                // 保存投保单号
            } else if (returncode.equals("100030")){
                lsCont.setInteractive("F");
                policyService.saveCont(lsCont);

//                //添加保单状态变更轨迹记录
//                lsStateLocaDao.saveStateLoca(lsCont, "数据审核中");
//                logger.info("req 80001/81001 success");

                java.util.Date date1 = new java.util.Date();
                lsContTime.setMessageEndTime(contSdf.format(date1));
                contTimeDao.saveContTime(lsContTime);
            }else {
                LSMessage lsMessage = new LSMessage();
                lsCont.setInteractive("E");
                lsMessage.setType("S");
                policyService.saveCont(lsCont);

                // 保存错误消息
                lsMessage.setBusiNum(lsCont.getBusiNum());
                lsMessage.setContNo(lsCont.getClientContNo());
                lsMessage.setMessage(message);
                lsMessage.setMessageNo(UUID.randomUUID().toString());
                lsMessage.setOcopertor("server");
                lsMessage.setSource("core");
                lsMessage.setState('N');
                lsMessage.setTitle("质检错误消息");

                lsMessage.setUserNo(lsCont.getOperator());
                java.sql.Date date2 = new java.sql.Date(System.currentTimeMillis());

                lsMessage.setMakeDate(date2);

                lsMessage.setMakeTime(sdfTime.format(date2));
                lsMessage.setIssueDate(contSdf.format(date2));
                messageDao.save(lsMessage);
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        } finally {
            // 删除文件
            String path = filePath + "/" + lsCont.getContNo();
            File dir = new File(path);
            if (dir.exists()) {
                File[] fileList = dir.listFiles();
                for (File file : fileList) {
                    String ext = FilenameUtils.getExtension(file.getName());
                    if (!ext.equals("mp3")) {
                        Boolean boolean1 = file.delete();
                        logger.info("contNo {} core success file {}  delete result {}", lsCont.getContNo(), file.getName(), boolean1);
                    }

                }
                //删除文件夹
                Boolean boolean1 = dir.delete();
                logger.info("contNo {} dir del file {}", lsCont.getContNo(), boolean1);

            }

//            // 删除 zip文件
//            File file = new File(zipPath + "/" + sdf.format(lsCont.getModifyDate()) + "/" + lsCont.getContNo());
//            if (file.exists()) {
//                File[] fileList = dir.listFiles();
//                for (File file2 : fileList) {
//                    Boolean boolean1 = file2.delete();
//                    logger.info("contNo {} zip file {} delete {}", lsCont.getContNo(), file2.getAbsolutePath(), boolean1);
//                }
//            }
        }
    }

    public void dealOneUser(LSUser lsUser) {
        String inputXml = getReq80006(lsUser);
        logger.info("user inputXml {}", inputXml);
        try {
            // 核心交互 返回报文
            String returnxml = sendService(inputXml, afcServiceBaseUrl, afcServiceMethod);
            logger.info("userId {} user return xml : {}", lsUser.getUserId(), returnxml);
            logger.info("更新人员信息返回的报文是 : {}", lsUser.getUserId(), returnxml);
            // 解析核心报文
            XStream xs1 = new XStream();
            xs1.alias("TRANSDATA", Transdata.class);
            xs1.alias("TRANSBODY", Transbody.class, TransbodyRes.class);
            Transdata tmp = (Transdata) xs1.fromXML(returnxml);
            TransbodyRes transbodyRes = (TransbodyRes) tmp.getTransbody();
            String returncode = transbodyRes.getTRANSRESULT().RETURNCODE;
            String message = transbodyRes.getTRANSRESULT().MESSAGE;
            logger.info("returncode:" + returncode);
            // 核心返回值判断
            if (returncode.equals("000000")) {
                lsUser.setIsPush("Y");
                lsUser.setUseFalg("0");
                userDao.save(lsUser);
                logger.info("核心返回成功");
            } else {
                logger.error("user {} upload fail message {}", lsUser.getUserId(), message);
            }
        } catch (Exception e) {
            logger.info("更新人员信息超时");
            e.printStackTrace();
        }
    }

    @Override
    public void uploadCloud(LSCont.LSContPK lsCont) {
        LsContState lsContState = contStateDao.getContState(lsCont.getContNo());
        if (lsContState == null) {
            logger.warn("ContState not found!!!!! contNo: {}", lsCont.getContNo());
            return;
        }
        String contNo = lsCont.getContNo();
        Long time = System.currentTimeMillis();

        //更新索引
        if (lsContState.getScreenShotState() != null && lsContState.getScreenShotState().equals("N")) {
            logger.info("uploadHttp(contNo: {}, screenShotUrl: {})", contNo, screenShotUrl);
            uploadHttp(contNo, screenShotUrl);
        } else {
            logger.info("contNo:{}  ==> [lsContState.getScreenShotState():{}] != null && [lsContState.getScreenShotState(): {}].equals(\"N\") && [lsContState.getVideoState(): {}].equals(\"N\")",
                    contNo, lsContState.getScreenShotState(), lsContState.getScreenShotState(), lsContState.getVideoState());
        }
        //获取上传图片的外链
        // 在新的回调方法中已经做了存库处理了
       /* if (lsContState.getPicState().equals("N")) {
            logger.info("uploadHttp(contNo: {}, picUrl: {})", contNo, picUrl);
            uploadHttp(contNo, picUrl);
        } else {
            logger.info("contNo:{}  ==> [lsContState.getPicState(): {}].equals(\"N\")",
                    contNo, lsContState.getPicState());
        }*/
//        if (lsContState.getVideoToMp3State().equals("N")) {
//            logger.info("uploadHttp(contNo: {}, videoToMp3Url);", contNo, videoToMp3Url);
//            uploadHttp(contNo, videoToMp3Url);
//        } else {
//            logger.info("contNo:{}  ==> [lsContState.getVideoToMp3State(): {}].equals(\"N\")",
//                    contNo, lsContState.getVideoToMp3State());
//        }
        //获取视频的m3u8地址
        // 在新的回调方法中已经做了存库处理了
        /*if (lsContState.getVideoState().equals("D")) {
            logger.info("uploadHttp(contNo: {}, videoUrl);", contNo, videoUrl);
            uploadHttp(contNo, videoUrl);
        } else {
            logger.info("contNo:{}  ==> [lsContState.getVideoState(): {}].equals(\"D\")",
                    contNo, lsContState.getVideoState());
        }*/

        //获取抽帧图片的外链
        // 在新的回调方法中已经做了存库处理了
        /*if(lsContState.getScreenShotState().equals("D")){
            logger.info("uploadHttp(contNo: {}, screenUrl);", contNo, screenUrl);
            uploadHttp(contNo, screenUrl);
        } else {
            logger.info("contNo:{}  ==> [lsContState.getScreenShotState(): {}].equals(\"D\")",
                    contNo, lsContState.getScreenShotState());
        }*/
//        if (lsContState.getMp3State().equals("N")) {
//            logger.info("uploadHttp(contNo: {}, mp3Url: {});", contNo, mp3Url);
//            uploadHttp(contNo, mp3Url);
//        } else {
//            logger.info("contNo:{}  ==> [lsContState.getMp3State(): {}].equals(\"N\")",
//                    contNo, lsContState.getMp3State());
//        }
        // 超时 再次 上传

        if (lsContState.getScreenShotTime() != null && lsContState.getScreenShotState().equals("D")
                && (time - lsContState.getScreenShotTime() >= screenShotTime)) {
            logger.info("uploadHttp(contNo: {}, screenShotUrl: {});", contNo, screenShotUrl);
            uploadHttp(contNo, screenShotUrl);
        } else {
            logger.info("contNo:{}  ==> [lsContState.getScreenShotTime(): {}] != null && [lsContState.getScreenShotState(): {}].equals(\"D\") && ([time: {}] - [lsContState.getScreenShotTime(): {}] >= [screenShotTime: {}])",
                    contNo, lsContState.getScreenShotTime(), lsContState.getScreenShotState(), time, lsContState.getScreenShotTime(), screenShotTime);
        }

//        if (lsContState.getPicTime() != null) {
//            if (lsContState.getPicState().equals("H") && (time - lsContState.getPicTime() >= picTime)) {
//                logger.info("contNo {} pic upload time out", lsCont.getContNo());
//                logger.info("uploadHttp(contNo: {}, picUrl: {});", contNo, picUrl);
//                uploadHttp(contNo, picUrl);
//            } else {
//                logger.info("contNo:{}  ==> [lsContState.getPicState(): {}].equals(\"H\") && ([time: {}] - [lsContState.getPicTime(): {}] >= [picTime: {}])",
//                        lsCont.getContNo(), lsContState.getPicState(), time, lsContState.getPicTime(), picTime);
//            }
//        } else {
//            logger.info("contNo:{}  ==> lsContState.getPicTime() is null",
//                    lsCont.getContNo());
//        }
//
//        if (lsContState.getMp3Time() != null) {
//            if (lsContState.getMp3State().equals("H") && (time - lsContState.getMp3Time() >= mp3Time)) {
//                logger.info("contNo{} mp3 upload time out", lsCont.getContNo());
//                logger.info("uploadHttp(contNo: {}, mp3Url: {});", contNo, mp3Url);
//                uploadHttp(contNo, mp3Url);
//            } else {
//                logger.info("contNo:{}  ==> [lsContState.getMp3State(): {}].equals(\"H\") && ([time: {}] - [lsContState.getMp3Time(): {}] >= [mp3Time: {}])",
//                        lsCont.getContNo(), lsContState.getMp3State(), time, lsContState.getMp3Time(), mp3Time);
//            }
//        } else {
//            logger.info("contNo:{}  ==> lsContState.getMp3Time() is null",
//                    lsCont.getContNo());
//        }
//
//        if (lsContState.getVideoToMp3Time() != null) {
//            if (lsContState.getVideoToMp3State().equals("H")
//                    && (time - lsContState.getVideoToMp3Time() >= videoToMp3Time)) {
//                logger.info("contNo {} videoTomp3 upload time out", lsCont.getContNo());
//                logger.info("uploadHttp(contNo: {}, videoToMp3Url: {});", contNo, videoToMp3Url);
//                uploadHttp(contNo, videoToMp3Url);
//            } else {
//                logger.info("contNo:{}  ==> [lsContState.getVideoToMp3State(): {}].equals(\"H\") && ([time: {}] - [lsContState.getVideoToMp3Time(): {}] >= [videoToMp3Time: {}])",
//                        lsCont.getContNo(), lsContState.getVideoToMp3State(), time, lsContState.getVideoToMp3Time(), videoToMp3Time);
//            }
//        } else {
//            logger.info("contNo:{}  ==> lsContState.getVideoToMp3Time() is null",
//                    lsCont.getContNo());
//        }
//
//        logger.info("contNo:{}  ==> [lsContState.getMp3State(): {}].equals(\"F\") && [lsContState.getPicState(): {}].equals(\"F\") && [lsContState.getVideoState(): {}].equals(\"F\") && [lsContState.getVideoToMp3State(): {}].equals(\"F\")",
//                lsCont.getContNo(), lsContState.getMp3State(), lsContState.getPicState(), lsContState.getVideoState(), lsContState.getVideoToMp3State());
//        if (lsContState.getMp3State().equals("F") && lsContState.getPicState().equals("F")
//                && lsContState.getVideoState().equals("F") && lsContState.getVideoToMp3State().equals("F")) {
//            LSCont contInfo = contDao.findByContNo(lsCont.getContNo());
//            contInfo.setInteractive("M");
//            logger.info("contNo:{}  ==> contDao.save(contInfo: {})",
//                    lsCont.getContNo(), contInfo);
//            contDao.save(contInfo);
//
////            //添加保单状态变更轨迹记录
////            lsStateLocaDao.saveStateLoca(contInfo, "数据待审核");
//        }

    }
    //长时间收不到回调，主动去获取索引
    @Override
    public void updateVideo(LSCont.LSContPK lsCont){
        String contNo = lsCont.getContNo();
        long now = System.currentTimeMillis();
        LSContTime lsContTime = contTimeDao.findContTime(contNo);
        if(lsContTime != null){
            //判断是第几次
            if(null == lsContTime.getCnt() || "".equals(lsContTime.getCnt()) || 1 == lsContTime.getCnt()){
                //获取更新索引的时间
                try {
                    Date date = contSdf.parse(lsContTime.getVideoBeginTime());
                    long time = date.getTime();
                    if(now - time > videoTime){
                        //超时，主动获取索引
                        uploadHttp(contNo, updateVideoUrl);
                    }
                }catch (Exception e){
                    logger.info("CoreInteractive updateVideo exception, {}", e);
                }
            }else {
                LSCont cont = policyService.findByContNo(contNo);
                SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm:ss");
                //第三次直接失败，保存失败信息
                LSMessage lsMessage2 = new LSMessage();
                lsMessage2.setMessageNo(UUID.randomUUID().toString());
                lsMessage2.setUserNo(cont.getOperator());
                lsMessage2.setTitle("获取索引失败");
                lsMessage2.setType("Z");
                // 修改 保单 状态
                lsMessage2.setContNo(contNo);
                lsMessage2.setMessage("保单号："+cont.getBusiNum()+",获取索引失败，请检查内容云");
                lsMessage2.setBusiNum(cont.getBusiNum());
                lsMessage2.setOcopertor("server");
                lsMessage2.setMakeDate(new java.sql.Date(System.currentTimeMillis()));
                lsMessage2.setMakeTime(sdfTime.format(new Date(System.currentTimeMillis())));
                lsMessage2.setIssueDate(contSdf.format(new java.sql.Date(System.currentTimeMillis())));
                lsMessage2.setSource("server");
                /**
                 * 添加内容 e店对接后初始 状态改为 H
                 * 然后发送成功变成 F 失败为L
                 **/
                lsMessage2.setState('H');
                messageDao.save(lsMessage2);
                cont.setInteractive("Z");
                policyService.saveCont(cont);
            }
        }
    }

    @Override
    public void downCloud(LSCont.LSContPK lsCont) {
        LsContState lsContState = contStateDao.getContState(lsCont.getContNo());
        if (lsContState == null) {
            logger.warn("ContState not found!!!!! contNo: {}", lsCont.getContNo());
            return;
        }
        Long time = System.currentTimeMillis();

        if (lsContState.getDownState().equals("N")) {
            uploadHttp(lsCont.getContNo(), downloadZip);
            return;
        }
        // 超时 再次 下载
        if (lsContState.getDownTime() != null) {
            if (lsContState.getDownState().equals("H") && (time - lsContState.getDownTime() > downloadTime)) {
                logger.info("contNo {} download time out", lsCont.getContNo());
                uploadHttp(lsCont.getContNo(), downloadZip);
            }
            return;
        }
        if (lsContState.getDownState().equals("F")) {
            // 修改保单状态
            LSCont contInfo = contDao.findByContNo(lsCont.getContNo());
            contInfo.setInteractive("F");
            contDao.save(contInfo);

            //添加保单状态变更轨迹记录
            lsStateLocaDao.saveStateLoca(contInfo, "数据待流转");
        }

    }

    private static OkHttpClient httpClient = new OkHttpClient();

    public void uploadHttp(String contNo, String url) {
//        OkHttpClient httpClient = new OkHttpClient();
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("contNo", contNo);
        FormBody formBody = builder.build();
        Request request = new Request.Builder() //
                .url(url) //
                .post(formBody) //
                .build();
        Response response = null;
        try {
            response = httpClient.newCall(request).execute();

            logger.info("url: {} \n response: {}", url, response);


        } catch (Exception ex) {
            logger.info("url: {} \n request-body: {}", url, formBody);
            logger.error(ex.getMessage(), ex);
        } finally {
            if (response!=null){
                response.close();
            }

        }
    }

    public String getReq81001(LSCont lsCont) {
        try{
            return _getReq81001(lsCont);
        }catch (Exception e){
            logger.error("getReq81001(LSCont lsCont) ~~~ ContNo {}",lsCont.getContNo(),e);
            return "";
        }
    }

    private String _getReq81001(LSCont lsCont) {
        logger.info("组织报文开始 contno: {}", lsCont.getContNo());
        LSAppnt lsAppnt = policyService.findAppntByContNo(lsCont.getContNo());
        logger.info(
                "policyService.findAppntByContNo(ContNo: {}) >> {} ",
                lsCont.getContNo(),lsAppnt
        );
        LSInsured lsInsured = policyService.findInsuredByContNo(lsCont.getContNo());
        logger.info(
                "policyService.findInsuredByContNo(ContNo: {}) >> {} ",
                lsCont.getContNo(),lsInsured
        );
        LSVideo lsVideo = policyService.findVideoByContNo(lsCont.getContNo());
        logger.info(
                "policyService.findVideoByContNo(ContNo: {}) >> {} ",
                lsCont.getContNo(),lsVideo
        );

        //查询所有人
        LSUser lsUser = policyService.findUserByUserId(lsCont.getOperator());
        logger.info(
                "policyService.findUserByUserId(Operator: {}) >> {} ",
                lsCont.getOperator(),lsUser
        );

        //查询整改人
        LSUser lsUser1 = policyService.findUserByUserId(lsCont.getRepeatPerson());
        logger.info(
                "policyService.findUserByUserId(RepeatPerson: {}) >> {} ",
                lsCont.getRepeatPerson(),lsUser1
        );

        List<LSPicture> lsPictures = policyService.findPictureByContNo(lsCont.getContNo());
        logger.info(
                "policyService.findPictureByContNo(ContNo: {}) >> res.size: {} ",
                lsCont.getContNo(),lsPictures==null ? 0: lsPictures.size()
        );

        // 创建 核心报文内容save
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransbodyReq81001 tb = new TransbodyReq81001();
        TransbodyReq81001.VIDEO video = new TransbodyReq81001.VIDEO();
        th.setTRANSCODE("81001");
        th.setBUSINESSNO(lsCont.getContNo()); // 业务单流水号
        th.setCOMPANY(lsCont.getComCode()); // 保险公司编码
//        th.setCOMPANY("24003"); // 保险公司编码
        td.setTranshead(th);
        String doccode = lsCont.getBusiNum();
        String[] split = lsCont.getRiskType().split(",");
        if (split.length > 1) {
            video.RISKTYPE = "1";
        } else {
            video.RISKTYPE = "0";
        }
        video.DOCCODE = doccode; // 投保单号码
        video.TYPE = String.valueOf(lsCont.getOperType()); // <!-- 上传类型--新单或问题件
        video.HOSTNAME = "COS"; // 服务器名 默认 cos
        video.BUSINESSNO = lsCont.getContNo();// 业务单流水号
        if (lsCont.getOrginContNo() == null) {
            video.BEFOREBUSINESSNO = "";
        } else {
            video.BEFOREBUSINESSNO = lsCont.getOrginContNo(); // 上次业务流水号
        }
        if (lsCont.getBankCode() == null) {
            video.BANKCODE = "";
        } else {
            video.BANKCODE = lsCont.getBankCode();
        }
        video.REQUESTID = lsVideo.getRequestId(); // 语音转文字标识码
        video.BUSSTYPE = lsVideo.getStorageType() + "B"; // 类型--直播（ZB）或点播（DB）
        video.SUBTYPE = lsVideo.getStorageType() + "B001"; // 子类型--直播视频（ZB001）点播视频（DB001）
        video.CHANNEL = lsCont.getChannel(); // 写固定值1
        video.NUMPAGES = String.valueOf(lsPictures.size() + 1); // 文件和图片共有多少个
        video.COMPANY = lsCont.getInsurComCode();// 保险所属保险公司
        //video.RISKTYPECODE = lsCont.getMainRiskName();// 产品类别ID
        video.RISKTYPECODE=lsCont.getRiskType();//产品名称
        video.COMCODE = lsCont.getOrgCode(); // 机构编码

        video.APPNTNAME = lsAppnt.getName();// 投保人姓名
        video.APPNTIDTYPE = lsAppnt.getIdType();// 投保人证件类型
        video.APPNTIDNO = lsAppnt.getIdNo();// 投保人证件号码
        video.APPNTBIRTHDAY = sdfDate.format(lsAppnt.getBirthday());// 投保人生日
        video.APPNTADRESS = lsAppnt.getAddress();// 投保人地址

        video.APPNTSEX = lsAppnt.getSex();

        if (lsAppnt.getAge() == null || lsAppnt.getAge().equals("")) {
            lsAppnt.setAge(AgeUtil.calAgeFromBirthday(lsAppnt.getBirthday()) + "");
        }
        video.APPNTAGE = lsAppnt.getAge(); // 投保人年龄

        if (lsInsured == null) {
            video.INSURDENAME = ""; // 被投保人姓名
            video.INSUREDIDTYPE = ""; // 被投保人证件类型
            video.INSUREDIDNO = ""; // 被投保人证件号码
            video.INSUREDBIRTHDAY = ""; // 被投保人生日
            video.INSUREDADRESS = ""; // 被投保人地址
            video.INSUREDSEX = "";
            video.INSUREDAGE = ""; // 被投保人年龄
        } else {
            video.INSURDENAME = lsInsured.getName(); // 被投保人姓名
            video.INSUREDIDTYPE = lsInsured.getIdType(); // 被投保人证件类型
            video.INSUREDIDNO = lsInsured.getIdNo(); // 被投保人证件号码
            video.INSUREDBIRTHDAY = sdfDate.format(lsInsured.getBirthday()); // 被投保人生日
            video.INSUREDADRESS = lsInsured.getAddress(); // 被投保人地址

            video.INSUREDSEX = lsInsured.getSex();

            video.INSUREDAGE = lsInsured.getAge(); // 被投保人年龄
            if (lsInsured.getAge() == null || lsInsured.getAge().equals("")) {
                lsInsured.setAge(AgeUtil.calAgeFromBirthday(lsInsured.getBirthday()) + "");
            }
        }

        video.POLAPPLYDATE = sdfDate.format(lsCont.getMakeDate()) + " " + lsCont.getMakeTime(); // 投保日期

        video.RECDATE = sdfDate.format(lsVideo.getBeginDate()); // 录制日期
        video.RECTIME = lsVideo.getBeginTime();// 录制时间
        video.UPLOADDATE = sdfDate.format(lsCont.getModifyDate()); //上传日期
        video.UPLOADTIME = lsCont.getModifyTime(); //上传时间
        video.APPNTIDIMG = ""; // 投保人身份证 图片url
        video.INSUREDIDIMG = ""; // 被保人身份证 图片 url

        //添加银保接口参数
        video.BANKCODE = lsCont.getBankCode(); //银行编码
        video.BANKNETWORK = lsCont.getBanknetWork(); //银行网点
        video.PROPERSON = lsCont.getProperson(); //专管员
        //影像来源 0 是 APP 1 是银保
        logger.info("clientContNo is =>{}",lsCont.getClientContNo());
        LSCont lastCont = contDao.findByClientContNoAndLastOne(lsCont.getClientContNo(), 'Y');
        video.RESOURCE = lastCont.getResource();
        //业务类型 0-自营 1-银保
        if (lsCont.getOperation() != null && lsCont.getOperation().equals("Y")) {
            video.OPERATION = "1";
        } else {
            video.OPERATION = "0";
        }
        //所属人
        video.REPEATPERSONCODE = lsUser.getAgentCode();
        video.REPEATPERSON = lsUser.getName();
        //整改人
        video.AGENTID = lsUser1.getAgentCode(); // 代理人id和姓名
        video.AGENTNAME = lsUser1.getName(); // <!-- 代理人姓名 -->
        if(lsCont.getSampling()==null || lsCont.getSampling().equals("")){//是否抽中
            video.ISSAMPLING = "true";
        }else{
            video.ISSAMPLING = lsCont.getSampling().toString();
        }
        video.DATATYPE = lsCont.getDataType(); //有无双录文件，0是有，1是没有-->
        video.STATUS = lsCont.getStatus(); //质检状态 0-待质检 1-已质检 默认为0 都需要质检-->
        video.QCCONCLUSION = lsCont.getQcconclusion(); //-质检结论 当质检状态为  1-已质检时，需要有质检结论 0-通过  1-不通过  2-整改-->

        /**
         * 新增智能双录标识
         **/
        video.ISINTELLIGENCE = "Y";

        try{
            List<LSTalkContent> talkContentLst = talkContentDao.findByBusiNum(doccode);
            logger.info("talkContentLst::{},lsCont.getIsIntelligence()::{}",talkContentLst,lsCont.getIsIntelligence());
            if(talkContentLst==null || talkContentLst.size() == 0){
                NewTalkDTO newTalkDTO = new NewTalkDTO();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                //投保人
                AppntForm appntForm = new AppntForm();
                appntForm.setAppntNo(lsAppnt.getAppntNo());// 投保人id
                appntForm.setName(lsAppnt.getName());
                appntForm.setSex(lsAppnt.getSex());
                appntForm.setBirthday(lsAppnt.getBirthday());
                appntForm.setStrBirthday(sdf.format(lsAppnt.getBirthday()));
                appntForm.setAddress(lsAppnt.getAddress());
                appntForm.setIdType(lsAppnt.getIdType());
                appntForm.setIdNo(lsAppnt.getIdNo());
                appntForm.setOperator(lsAppnt.getOperator());
                appntForm.setClientContNo(lsAppnt.getClientContNo());
                appntForm.setContNo(lsAppnt.getContNo());
                appntForm.setAge(lsAppnt.getAge());
                newTalkDTO.setAppnt(appntForm);
                //被保人
                InsuredForm insuredForm = new InsuredForm();
                insuredForm.setInsuredNo(lsInsured.getInsuredNo());
                insuredForm.setAddress(lsInsured.getAddress());
                insuredForm.setName(lsInsured.getName());//被保人姓名
                insuredForm.setSex(lsInsured.getSex());
                insuredForm.setBirthday(lsInsured.getBirthday());
                insuredForm.setStrBirthday(sdf.format(lsInsured.getBirthday()));
                insuredForm.setIdType(lsInsured.getIdType());
                insuredForm.setIdNo(lsInsured.getIdNo());
                insuredForm.setAppntNo(lsInsured.getAppntNo());
                insuredForm.setOperator(lsInsured.getOperator());
                insuredForm.setClientContNo(lsInsured.getClientContNo());
                insuredForm.setContNo(lsInsured.getContNo());
                insuredForm.setAge(lsInsured.getAge());
                insuredForm.setLDRelationship(lsInsured.getLDRelationshipCode());    //投保人是被投保人的关系
                insuredForm.setInsuredRelationship(lsInsured.getLDRelationshipCode()); //投被保人关系
                newTalkDTO.setInsured(insuredForm);
                newTalkDTO.setBusiNum(lsCont.getBusiNum());
                newTalkDTO.setRiskType(lsCont.getRiskType());
                newTalkDTO.setAgentOrgCode(lsCont.getOrgCode());
                newTalkDTO.setAgentCode(lsUser.getAgentCode());
                newTalkDTO.setIsSelf(lsCont.getIsSelf());
                newTalkDTO.setSendScene(lsCont.getSendScene());
                newTalkDTO.setResource(lsCont.getResource());
                newTalkDTO.setContNo(lsCont.getContNo());
                newTalkDTO.setClientContNo(lsCont.getClientContNo());
                newTalkDTO.setOperation(lsCont.getOperation());
                newTalkDTO.setOperator(lsCont.getOperator());
                newTalkDTO.setChannel(lsCont.getChannel());
                newTalkDTO.setIdNo(lsUser.getIdNo());
                newTalkDTO.setBankCode(lsCont.getBankCode());
                if (!StringUtils.isEmpty(lsCont.getBankCode())){
                LSBank lsBank = bankDao.findByBankCode(lsCont.getBankCode());
                if(lsBank!=null){
                    newTalkDTO.setBankName(lsBank.getBankName());
                }else {
                    newTalkDTO.setBankName("");
                }
            }
                newTalkDTO.setBanknetWork(lsCont.getBanknetWork());
                newTalkDTO.setInsurComCode(lsCont.getInsurComCode());
                newTalkDTO.setSex(lsUser.getSex());
                newTalkDTO.setName(lsUser.getName());
                newTalkDTO.setBrithday(lsUser.getBrithday());
                newTalkDTO.setPhoneNo(lsUser.getPhoneNo());
                newTalkDTO.setProperson(lsCont.getProperson());
                newTalkDTO.setScanDate(sdfDate.format(lsCont.getScanDate()));
                newTalkDTO.setEqInfor(lsCont.getEqInfor());
                newTalkDTO.setZipUrl(lsCont.getZipUrl());
                List<PointTalkDescribe> talkContents = newTalkService.getTalks(newTalkDTO);
                for (int i=0;i<talkContents.size();i++){
                    TalkForm talkForm = new TalkForm();
                    talkForm.setStep(talkContents.get(i).getPointcontent());
                    talkForm.setTalkContent(talkContents.get(i).getDescribecontent());
                    talkForm.setId(talkContents.get(i).getPointid());
                    talkForm.setIsRead(talkContents.get(i).getIsvoicebroadcast());
                    talkForm.setOrdernum(String.valueOf(i));
                    //保存替换话术
                    LSTalkContent lsTalkContent = new LSTalkContent();
                    lsTalkContent.setId(UUID.randomUUID().toString());
                    lsTalkContent.setBusiNum(doccode);
                    lsTalkContent.setRiskType(lsCont.getRiskType());
                    lsTalkContent.setPkid(talkForm.getId());
                    lsTalkContent.setTalkContent(talkForm.getTalkContent());
                    lsTalkContent.setOrderNum(talkForm.getOrdernum());
                    logger.info("save lstalk talk {}", talkForm.getTalkContent());
                    talkContentDao.saveTalkContent(lsTalkContent);
                }
            }
        }catch(Exception e){
            logger.info("doccode::{},gettalkContentLst出错！",doccode);
        }


        TransbodyReq81001.PAGES pages = new TransbodyReq81001.PAGES();

        int pagecount = 1;
        TransbodyReq81001.PAGE page = new TransbodyReq81001.PAGE();

        page.FILETYPE = "0"; // 文件类型--0-视频或1-图片
        page.PAGENAME = lsVideo.getVideoName(); // 文件名--不带后缀
        page.PAGESUFFIX = lsVideo.getVideoType(); // 文件后缀
        if (lsVideo.getURL() == null || lsVideo.getURL().equals("")) {
            page.URL = "null"; // 图片或视频地址
        }else{
            page.URL = lsVideo.getURL(); // 图片或视频地址
        }
        page.RECORDER = ""; // 图片顺序 第几条数据
        page.IMGTIMEPOINT = ""; // 图片时点
        page.DESCRIBEID = ""; // 要点ID
        page.RECDATE = sdfDate.format(lsVideo.getBeginDate()); // 录制日期
        page.RECTIME = lsVideo.getBeginTime();// 录制时间
        page.RECDURATION = lsVideo.getTimeLength(); // 录制时长
        page.FILESIZE = lsVideo.getFileSize(); // 文件大小

        pages.PAGE.add(page);

        if (lsPictures != null || lsPictures.size() != 0) {
            int i = 1;
            for (LSPicture lsPicture : lsPictures) {
                if (lsPicture.getBusiType().equals("ScreenShoot")) {
                    TransbodyReq81001.PAGE page1 = new TransbodyReq81001.PAGE();
                    page1.FILETYPE = "1"; // 文件类型--0-视频或1-图片
                    page1.PAGENAME = lsPicture.getPicName(); // 文件名--不带后缀
                    page1.PAGESUFFIX = lsPicture.getPicType(); // 文件后缀
                    if (lsPicture.getURL() == null || lsPicture.getURL().equals("")) {
                        page1.URL = "";
                    } else {
                        page1.URL = lsPicture.getURL(); // 图片或视频地址
                    }


                    page1.IMGTIMEPOINT = lsPicture.getTimeNode(); // 图片时点
                    page1.DESCRIBEID = lsPicture.getpKId(); // 话术ID
                    page1.RECDATE = ""; // 录制日期
                    page1.RECTIME = "";// 录制时间
                    page1.RECDURATION = ""; // 录制时长
                    page1.FILESIZE = lsPicture.getFileSize(); // 文件大小
                    if (lsPicture.getIsPlay()==null || lsPicture.getIsPlay().equals("") || "N".equals(lsPicture.getIsPlay())){
                        page1.ISPLAYER  ="否";  //（视频对应节点存在此数据，视频无）
                    }else {
                        page1.ISPLAYER  ="是";
                    }
                    //增加 替换话术内容
                    List<LSTalkContent> list = talkContentDao.findByBusiNumAndPkid(lsCont.getBusiNum(),lsPicture.getpKId());
                    logger.info(
                            "talkContentDao.findByBusiNumAndRiskTypeAndPkid(BusiNum: {},RiskType: {}, pKId:{} )",
                            lsCont.getBusiNum(),lsCont.getRiskType(),lsPicture.getpKId()
                    );
                    if (list!=null && list.size() != 0){
                        LSTalkContent lsTalkContent = list.get(0);
                        logger.info(
                                "talkContentDao.findByBusiNumAndRiskTypeAndPkid(BusiNum: {},RiskType: {}, pKId:{} ) >> {}",
                                lsCont.getBusiNum(),lsCont.getRiskType(),lsPicture.getpKId(),lsTalkContent.getTalkContent()
                        );
                        page1.DESCRIBETEXT = lsTalkContent.getTalkContent();
                        page1.RECORDER = lsTalkContent.getOrderNum(); // 图片顺序 第几条数据
//                        talkContentDao.delTalkContent(lsTalkContent);
                    } else {
                        logger.info(
                                "talkContentDao.findByBusiNumAndRiskTypeAndPkid(BusiNum: {},RiskType: {}, pKId:{} ) >> NULL",
                                lsCont.getBusiNum(),lsCont.getRiskType(),lsPicture.getpKId()
                        );
                        page1.DESCRIBETEXT = "";
                        page1.RECORDER = i + ""; // 图片顺序 第几条数据
                    }
                    pages.PAGE.add(page1);
                    i++;
                    pagecount++;
                }
                if (lsPicture.getBusiType().equals("AIDPic")) {
                    video.APPNTIDIMG = lsPicture.getURL();
                }
                if (lsPicture.getBusiType().equals("IIDPic")) {
                    video.INSUREDIDIMG = lsPicture.getURL();
                }

            }


        }
        pages.PAGECOUNT = String.valueOf(pagecount);


        video.setPAGES(pages);
        tb.setVIDEO(video);
        td.setTransbody(tb);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("VIDEO", TransbodyReq81001.VIDEO.class);
        xstream.alias("PAGES", TransbodyReq81001.PAGES.class);
        xstream.alias("PAGE", TransbodyReq81001.PAGE.class);
        xstream.alias("TALK", TransbodyReq81001.TALK.class);
        xstream.addImplicitCollection(TransbodyReq81001.PAGES.class, "PAGE");
        logger.info("组织报文开始 ContNo:{} buisNum: {}", lsCont.getContNo(), lsCont.getBusiNum());
        return xstream.toXML(td);
    }



    /**
     * User: weihao
     * Date: 2018/5/23
     * Time: 16:50
     * 提交 保单变更状态
     */
    @Override
    public void sendContState(List<LSStateLoca> lsStateLocaList,String comCode) {
        String inputXml = getReq70001(lsStateLocaList,comCode);
        logger.info("send contState inputXml {}", inputXml);
        System.out.println(inputXml);
        // 核心交互 返回报文
        try {
            String returnxml = sendService(inputXml, afcServiceBaseUrl, afcServiceMethod);
            // 解析核心报文
            XStream xs1 = new XStream();
            xs1.alias("TRANSDATA", Transdata.class);
            xs1.alias("TRANSBODY", Transbody.class, TransbodyRes.class);
            Transdata tmp = (Transdata) xs1.fromXML(returnxml);
            TransbodyRes transbodyRes = (TransbodyRes) tmp.getTransbody();
            String returncode = transbodyRes.getTRANSRESULT().RETURNCODE;
            String message = transbodyRes.getTRANSRESULT().MESSAGE;
            logger.info("returncode:" + returncode);
            // 核心返回值判断
            String  isSend="";
            if (returncode.equals("000000")) {
                isSend="F";
            }else{
                isSend="N";
            }
            for (LSStateLoca lsStateLoca: lsStateLocaList) {
                lsStateLoca.setIsSend(isSend);
                lsStateLocaDao.editStateLoca(lsStateLoca);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * User: weihao
     * Date: 2018/5/23
     * Time: 16:27
     * 组织发送 保单状态报文
     */
    public String getReq70001(List<LSStateLoca> lsStateLocaList,String comCode) {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        th.setTRANSCODE("81017");
        th.setCOMPANY(comCode);

        TransbodyReq81017 tb = new TransbodyReq81017();
        TransbodyReq81017.EASYRECORDINFOS   easyrecordinfos=new TransbodyReq81017.EASYRECORDINFOS();
        List<TransbodyReq81017.EASYRECORDINFO> easyrecordinfoList = new ArrayList<>();
        for (LSStateLoca lsStateLoca : lsStateLocaList) {
            TransbodyReq81017.EASYRECORDINFO easyrecordinfo =new TransbodyReq81017.EASYRECORDINFO();
            easyrecordinfo.PRTNO = lsStateLoca.getBusiNum();//保单的单号
            easyrecordinfo.UPLOADDATEFIRST = "";
            easyrecordinfo.UPLOADTIMEFIRST = "";
            easyrecordinfo.QCRECORDCOUNT = "";
            easyrecordinfo.UPLOADDATESECOND = "";
            easyrecordinfo.UPLOADTIMESECOND = "";
            easyrecordinfo.UPLOADDATETHIRD = "";
            easyrecordinfo.UPLOADTIMETHIRD = "";
            easyrecordinfo.QCCONCLUSION = lsStateLoca.getContState();//保单的状态
            easyrecordinfo.RESOURCE = "";
            easyrecordinfo.INSPECTDATE = sdfDate.format(lsStateLoca.getMakeDate());//变更的日期
            easyrecordinfo.INSPECTTIME = lsStateLoca.getMakeTime();//保单变更的时间
            easyrecordinfoList.add(easyrecordinfo);
        }
        easyrecordinfos.setEASYRECORDINFOLIST(easyrecordinfoList);
        easyrecordinfos.setEASYRECORDINFOCOUNT(easyrecordinfoList.size()+"");
        tb.setEASYRECORDINFOS(easyrecordinfos);
        td.setTransbody(tb);
        td.setTranshead(th);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("EASYRECORDINFOS",TransbodyReq81017.EASYRECORDINFOS.class);
        xstream.alias("EASYRECORDINFO", TransbodyReq81017.EASYRECORDINFO.class);
        xstream.addImplicitCollection(TransbodyReq81017.EASYRECORDINFOS.class, "EASYRECORDINFOLIST");
        return xstream.toXML(td);
    }



    /**
     * User: weihao
     * Date: 2018/5/24
     * Time: 15:29
     *  组织 发送 用户信息报文
     */
    public String getReq80006(LSUser lsUser) {

        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransBodyReq80006 tb = new TransBodyReq80006();

        th.setTRANSCODE("80006");
        th.setCOMPANY(lsUser.getComCode());

        String birthday = lsUser.getBrithday();
        Date birDate = null;
        try {
            birDate = sdfDate.parse(birthday);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        tb.AGE = AgeUtil.calAgeFromBirthday(birDate) + "";
        tb.AGENTCODE = lsUser.getAgentCode();
        tb.AGENTCOM = "";
        tb.AGENTGROUP = "";
        tb.BIRTHDAY = lsUser.getBrithday();
        tb.COMCODE = lsUser.getOrgCode();
        String lsComName = null;
        try{
            if(!(StringUtils.isEmpty(lsUser.getOrgCode()) && StringUtils.isEmpty(lsUser.getChannel()))){
                lsComName = lsComDao.getComNameByComCode(lsUser.getOrgCode(),lsUser.getChannel());
            }
        }catch(Exception e){
            logger.info("orgName获取错误：：{}",lsUser.getOrgCode());
        }

        //LSOrganization lsOrganization = organizationDao.findByOrgCode(lsUser.getOrgCode());
        tb.COMNAME = lsComName;
        tb.DEGREE = "";
        tb.EMAIL = "";
        tb.ENTRYNO = "";
        tb.IDNO = lsUser.getIdNo();
        tb.IDNOTYPE = "";
        tb.MOBILE = "";
        tb.NAME = lsUser.getName();
        tb.NATIONALITY = "";
        tb.NATIVEPLACE = "";
        tb.PASSWORD = authen.getPassword(lsUser.getUserId());
        tb.PHONE = lsUser.getPhoneNo();
        tb.REGISTERTIME = sdfDate.format(lsUser.getMakeDate()) + " " + lsUser.getMakeTime();
        tb.RGTADDRESS = "";
        tb.SEX = lsUser.getSex();
        // 新增
        tb.USEFLAG = lsUser.getUseFalg();
        tb.WORKFLAG = lsUser.getWorkFlag();
        tb.SALECOMCODE = lsUser.getSaleComCode();
        tb.SALECOMNAME = lsUser.getSaleComName();
        tb.CHANNEL = lsUser.getChannel();
        //新增2
        tb.ROLE = lsUser.getRole();
        if (lsUser.getBankCode() != null && lsUser.getDotCode() != null) {
            tb.BANKCODE = lsUser.getBankCode();
            tb.BANKNETWORK = lsUser.getDotCode();
        } else {
            tb.BANKCODE = "";
            tb.BANKNETWORK = "";
        }
        tb.PROPERSON = "";
        td.setTranshead(th);
        td.setTransbody(tb);

        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        return xstream.toXML(td);
    }

    /**
     * 发送请求
     *
     * param xmlStr
     * param url
     * @aram method
     * return
     * throws Exception
     */
    private String sendService(String xmlStr, String url, String method) throws Exception {

        String xml = null;
        RPCServiceClient serviceClient = new RPCServiceClient();
        Options options = serviceClient.getOptions();
        EndpointReference targetEPR = new EndpointReference(url);
        options.setTo(targetEPR);
        options.setAction(method);
        options.setManageSession(true);
        options.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, true);
        // 在创建QName对象时，QName类的构造方法的第一个参数表示WSDL文件的命名空间名，也就是<wsdl:definitions>元素的targetNamespace属性值
        QName opAddEntry = new QName("http://infservice.webservice.platform.sinosoft", method);
        // 参数，如果有多个，继续往后面增加即可，不用指定参数的名称
        Object[] opAddEntryArgs = new Object[]{xmlStr};
        // 返回参数类型，这个和axis1有点区别
        // invokeBlocking方法有三个参数，其中第一个参数的类型是QName对象，表示要调用的方法名；
        // 第二个参数表示要调用的WebService方法的参数值，参数类型为Object[]；
        // 第三个参数表示WebService方法的返回值类型的Class对象，参数类型为Class[]。
        // 当方法没有参数时，invokeBlocking方法的第二个参数值不能是null，而要使用new Object[]{}
        // 如果被调用的WebService方法没有返回值，应使用RPCServiceClient类的invokeRobust方法，
        // 该方法只有两个参数，它们的含义与invokeBlocking方法的前两个参数的含义相同
        Class[] classes = new Class[]{String.class};
        xml = (String) serviceClient.invokeBlocking(opAddEntry, opAddEntryArgs, classes)[0];
        logger.info("xml {}",xml);
        serviceClient.cleanupTransport();
        return xml;
    }




    /**
     * 发送请求
     *
     * param xmlStr
     * param url
     * @aram method
     * return
     * throws Exception
     */
    private String sendService4eShop(String xmlStr, String url) throws Exception {

        String xml = null;
        RPCServiceClient serviceClient = new RPCServiceClient();
        Options options = serviceClient.getOptions();
        EndpointReference targetEPR = new EndpointReference(url);
        options.setTo(targetEPR);
        options.setAction("RecallWSSOAP");
        options.setManageSession(true);
        options.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, true);
        // 在创建QName对象时，QName类的构造方法的第一个参数表示WSDL文件的命名空间名，也就是<wsdl:definitions>元素的targetNamespace属性值
        QName opAddEntry = new QName("http://www.e-chinalife.com/soa/", "RecallWSSOAP");
        // 参数，如果有多个，继续往后面增加即可，不用指定参数的名称
        Object[] opAddEntryArgs = new Object[]{xmlStr};
        // 返回参数类型，这个和axis1有点区别
        // invokeBlocking方法有三个参数，其中第一个参数的类型是QName对象，表示要调用的方法名；
        // 第二个参数表示要调用的WebService方法的参数值，参数类型为Object[]；
        // 第三个参数表示WebService方法的返回值类型的Class对象，参数类型为Class[]。
        // 当方法没有参数时，invokeBlocking方法的第二个参数值不能是null，而要使用new Object[]{}
        // 如果被调用的WebService方法没有返回值，应使用RPCServiceClient类的invokeRobust方法，
        // 该方法只有两个参数，它们的含义与invokeBlocking方法的前两个参数的含义相同
        Class[] classes = new Class[]{String.class};
        xml = (String) serviceClient.invokeBlocking(opAddEntry, opAddEntryArgs, classes)[0];
        logger.info("xml {}",xml);
        serviceClient.cleanupTransport();
        return xml;
    }
}
