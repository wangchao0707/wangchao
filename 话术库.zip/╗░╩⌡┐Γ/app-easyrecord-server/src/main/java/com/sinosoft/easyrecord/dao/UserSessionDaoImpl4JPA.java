package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa4afc.UserSessionRepository;
import com.sinosoft.easyrecord.entity4afc.UserSession;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
public class UserSessionDaoImpl4JPA implements UserSessionDao {

    @Resource
    UserSessionRepository userSessionRepository;

    @Override
    public List<UserSession> getUserSession(String publicId) {
        return userSessionRepository.findAllByPublicId(publicId);

    }
}
