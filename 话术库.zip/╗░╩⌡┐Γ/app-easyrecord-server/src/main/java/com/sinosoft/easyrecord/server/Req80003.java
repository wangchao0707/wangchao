package com.sinosoft.easyrecord.server;

/**
 * Created by zf on 2017/8/8.
 */
public interface Req80003 {
    public String req80003(String xml);
}
