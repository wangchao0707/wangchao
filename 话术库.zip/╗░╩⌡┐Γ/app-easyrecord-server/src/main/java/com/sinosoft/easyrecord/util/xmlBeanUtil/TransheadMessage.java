package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: weihao
 * Date: 2018-05-14
 * Time: 17:26
 * 核心前置 发送报文头
 */
public class TransheadMessage extends Transhead{

    private String VERSION = "1.0";
    private String SYSCODE;
    private String TRANSCODE;
    private String TRANUSER;
    private String TRANSTIMESTAMP;
    private String TRANSEXPIRED;
    private String TRANSNONCE;
    private String AUTHORIZATION;


    public String getVERSION() {
        return VERSION;
    }

    public void setVERSION(String VERSION) {
        this.VERSION = VERSION;
    }

    public String getSYSCODE() {
        return SYSCODE;
    }

    public void setSYSCODE(String SYSCODE) {
        this.SYSCODE = SYSCODE;
    }

    public String getTRANSCODE() {
        return TRANSCODE;
    }

    public void setTRANSCODE(String TRANSCODE) {
        this.TRANSCODE = TRANSCODE;
    }

    public String getTRANUSER() {
        return TRANUSER;
    }

    public void setTRANUSER(String TRANUSER) {
        this.TRANUSER = TRANUSER;
    }

    public String getTRANSTIMESTAMP() {
        return TRANSTIMESTAMP;
    }

    public void setTRANSTIMESTAMP(String TRANSTIMESTAMP) {
        this.TRANSTIMESTAMP = TRANSTIMESTAMP;
    }

    public String getTRANSEXPIRED() {
        return TRANSEXPIRED;
    }

    public void setTRANSEXPIRED(String TRANSEXPIRED) {
        this.TRANSEXPIRED = TRANSEXPIRED;
    }

    public String getTRANSNONCE() {
        return TRANSNONCE;
    }

    public void setTRANSNONCE(String TRANSNONCE) {
        this.TRANSNONCE = TRANSNONCE;
    }

    public String getAUTHORIZATION() {
        return AUTHORIZATION;
    }

    public void setAUTHORIZATION(String AUTHORIZATION) {
        this.AUTHORIZATION = AUTHORIZATION;
    }
}
