package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSTalkRunTimeRespository;
import com.sinosoft.easyrecord.entity.LSTalkRunTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TalkRunTimeImpl4JPA implements TalkRunTimeDao {

    private LSTalkRunTimeRespository talkRunTimeRespository;

    @Autowired
    public void setTalkRunTimeRespository(LSTalkRunTimeRespository talkRunTimeRespository) {
        this.talkRunTimeRespository = talkRunTimeRespository;
    }

    @Override
    public void saveTalkRunTime(LSTalkRunTime lsTalkRunTime) {
        talkRunTimeRespository.saveAndFlush(lsTalkRunTime);
    }

    @Override
    public List<LSTalkRunTime> findByBusiNumAndOperatorAndComCodeAndInsurComCode(String busiNum, String operator,
                                                                                 String comCode, String insurComCode) {
        return talkRunTimeRespository.findByBusiNumAndOperatorAndComCodeAndInsurComCode(busiNum, operator, comCode, insurComCode);
    }


    @Override
    public void deleteTalkRunTime(LSTalkRunTime lsTalkRunTime) {
        talkRunTimeRespository.delete(lsTalkRunTime);
    }


    @Override
    public List<LSTalkRunTime> findByBusiNum(String busiNum) {
        return talkRunTimeRespository.findByBusiNum(busiNum);
    }

    public List<LSTalkRunTime> findByContNo(String contNo){
        return talkRunTimeRespository.findByContNo(contNo);
    }
}
