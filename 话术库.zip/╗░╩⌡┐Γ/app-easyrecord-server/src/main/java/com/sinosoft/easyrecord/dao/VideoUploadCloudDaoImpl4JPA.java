package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.VideoUploadCloudRepository;
import com.sinosoft.easyrecord.entity.VideoUploadCloud;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * @create 2020/3/1 0001
 */
@Component
public class VideoUploadCloudDaoImpl4JPA implements VideoUploadCloudDao {

    @Autowired
    private VideoUploadCloudRepository VideoUploadCloudRepository;

    @Override
    public void insertOrUpdate(VideoUploadCloud videoUploadCloud) {
        VideoUploadCloudRepository.save(videoUploadCloud);
    }

    @Override
    public VideoUploadCloud getUploadStatus(String uploadStatus) {
        return VideoUploadCloudRepository.findById(uploadStatus).orElse(null);
    }

}
