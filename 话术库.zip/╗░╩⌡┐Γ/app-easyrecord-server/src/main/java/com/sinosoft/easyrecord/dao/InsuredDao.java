package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSInsured;

public interface InsuredDao {

    LSInsured findByInsuredNo(String insuredNo);

    void save(LSInsured insured);

    LSInsured findByContNo(String contNo);
}
