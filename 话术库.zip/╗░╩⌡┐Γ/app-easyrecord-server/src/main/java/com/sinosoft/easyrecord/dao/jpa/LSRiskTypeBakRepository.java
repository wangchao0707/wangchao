package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSRiskTypeBak;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by zf on 2017/8/8.
 */
public interface LSRiskTypeBakRepository extends JpaRepository<LSRiskTypeBak, String> {
}
