package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSHeadImgRepository;
import com.sinosoft.easyrecord.entity.LSHeadImg;

import java.util.Optional;

@Component
public class HeadImgDaoImpl4JPA implements HeadImgDao {

    @Autowired
    private LSHeadImgRepository lsHeadImgRepository;

    public void setLsHeadImgRepository(LSHeadImgRepository lsHeadImgRepository) {
        this.lsHeadImgRepository = lsHeadImgRepository;
    }

    @Override
    public LSHeadImg getHeadImg(String userId) {
        Optional<LSHeadImg> res = lsHeadImgRepository.findById(userId);
        return res.orElse(null);
    }

    @Override
    public void saveHeadImg(LSHeadImg lsHeadImg) {
        lsHeadImgRepository.saveAndFlush(lsHeadImg);
    }

}
