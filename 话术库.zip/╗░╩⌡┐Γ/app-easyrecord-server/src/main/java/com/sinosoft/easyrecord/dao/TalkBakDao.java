package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSTalkBak;

/**
 * Created by zf on 2017/8/8.
 */
public interface TalkBakDao {
    void save(LSTalkBak lsTalkBak);
}
