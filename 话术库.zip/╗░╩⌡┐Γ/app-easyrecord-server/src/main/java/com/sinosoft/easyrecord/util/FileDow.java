package com.sinosoft.easyrecord.util;

import it.sauronsoftware.jave.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Date;

public class FileDow {
    /**
     * 下载远程文件并保存到本地
     *
     * @param remoteFilePath 远程文件路径
     * @param localFilePath  本地文件路径
     */
//    public static void downloadFile(String remoteFilePath, String localFilePath)
//    {
//    	System.out.println("------------------down start");
//        URL urlfile = null;
//        HttpURLConnection httpUrl = null;
//        BufferedInputStream bis = null;
//        BufferedOutputStream bos = null;
//        File f = new File(localFilePath);
//        try
//        {
//            urlfile = new URL(remoteFilePath);
//            httpUrl = (HttpURLConnection)urlfile.openConnection();
//            httpUrl.connect();
//            bis = new BufferedInputStream(httpUrl.getInputStream());
//            bos = new BufferedOutputStream(new FileOutputStream(f));
//            int len = 2048;
//            byte[] b = new byte[len];
//            while ((len = bis.read(b)) != -1)
//            {
//                bos.write(b, 0, len);
//            }
//            bos.flush();
//            bis.close();
//            httpUrl.disconnect();
//            System.out.println("------------------down end");
//        }
//        catch (Exception e)
//        {
//            e.printStackTrace();
//            System.out.println("------------------down Exception");
//        }
//        finally
//        {
//            try
//            {
//                bis.close();
//                bos.close();
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    public static void star(String sload,String eload,String docid){
//    	 Runtime rt = Runtime.getRuntime(); 
// 	    try {
// 	    	    String file =  "D:/start"+docid+".bat "; 
// 				FileWriter fw=new FileWriter(file, false);	
// 				String tmovie = eload.replace(":", "\\:"); 
// 				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+sload+"\"  -vf hflip  -vf \"movie='"+tmovie+"logo1.png' [watermark];[in][watermark] overlay=10:10 [out]\" \""+eload+docid+"_09.mp4\"\r\n\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 02.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic01.jpg\"\r\n\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 04.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic02.jpg\"\r\n\n");
//				//fw.write("pause\r\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 06.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic03.jpg\"\r\n\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 08.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic04.jpg\"\r\n\n");
//				fw.write("exit\r\n\n");
//				//fw.write("start "+file);
//				fw.flush();   
// 				fw.close();
// 				rt.exec("C:/Windows/System32/cmd.exe /c  start " + file); 
// 		} catch (IOException e) {
// 			e.printStackTrace();
// 		} 
//    }
//    public static void star1(String sload,String eload,VideoPages docid){
//   	 Runtime rt = Runtime.getRuntime(); 
//	    try {
//	    	    String file =  "D:/start"+docid+".bat "; 
//				FileWriter fw=new FileWriter(file, false);	
//				String tmovie = eload.replace(":", "\\:"); 
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+sload+"\"  -vf hflip  -vf \"movie='"+tmovie+"logo1.png' [watermark];[in][watermark] overlay=10:10 [out]\" \""+eload+docid+"_09.mp4\"\r\n\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 02.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic01.jpg\"\r\n\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 04.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic02.jpg\"\r\n\n");
//				//fw.write("pause\r\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 06.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic03.jpg\"\r\n\n");
//				fw.write("D:/FFmpeg64-bit_3.1/bin/ffmpeg -i \""+eload+docid+"_09.mp4\" -f image2 -ss 08.010 -t 0.001 -s 320x240 \""+eload+docid+"_pic04.jpg\"\r\n\n");
//				fw.write("exit\r\n\n");
//				//fw.write("start "+file);
//				fw.flush();   
//				fw.close();
//				rt.exec("C:/Windows/System32/cmd.exe /c  start " + file); 
//		} catch (IOException e) {
//			e.printStackTrace();
//		} 
//   }

//    public static void changeToMp3(String sourcePath, String targetPath) {  
//        File source = new File(sourcePath);  
//        File target = new File(targetPath);  
//        AudioAttributes audio = new AudioAttributes();  
//        Encoder encoder = new Encoder();  
//  
//        audio.setCodec("libmp3lame");  
//        EncodingAttributes attrs = new EncodingAttributes();  
//        attrs.setFormat("mp3");  
//        attrs.setAudioAttributes(audio);  
//  
//        try {  
//            encoder.encode(source, target, attrs);  
//        } catch (IllegalArgumentException e) {  
//            e.printStackTrace();  
//        } catch (InputFormatException e) {  
//            e.printStackTrace();  
//        } catch (EncoderException e) {  
//            e.printStackTrace();  
//        }  
//    }  
//    
//    public static void changeToMp4(String sourcePath, String targetPath) throws Exception {  
//    	File source = new File(sourcePath);
//    	File target = new File(targetPath);
//    	AudioAttributes audio = new AudioAttributes();
//    	audio.setCodec("libfaac");
//    	audio.setBitRate(new Integer(64000));
//    	audio.setChannels(new Integer(1));
//    	audio.setSamplingRate(new Integer(22050));
//    	VideoAttributes video = new VideoAttributes();
//    	video.setCodec("mpeg4avc");//mpeg4
//    	video.setBitRate(new Integer(160000));
//    	video.setFrameRate(new Integer(15));
//    	video.setSize(new VideoSize(400, 300));
//    	EncodingAttributes attrs = new EncodingAttributes();
//    	attrs.setFormat("mp4");//mpegvideo
//    	attrs.setAudioAttributes(audio);
//    	attrs.setVideoAttributes(video);
//    	Encoder encoder = new Encoder();
//    	encoder.encode(source, target, attrs);
//    }
    public static void changeMp4ToMp3(String sourcePath, String targetPath) {

        File source = new File(sourcePath);
        File target = new File(targetPath);
        AudioAttributes audio = new AudioAttributes();
        audio.setCodec("libmp3lame");
        audio.setBitRate(new Integer(96000));
        audio.setChannels(new Integer(1));
        audio.setSamplingRate(new Integer(44100));
        EncodingAttributes attrs = new EncodingAttributes();
        attrs.setFormat("mp3");
        attrs.setAudioAttributes(audio);
        Encoder encoder = new Encoder();
        try {
            encoder.encode(source, target, attrs);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InputFormatException e) {
            e.printStackTrace();
        } catch (EncoderException e) {
            e.printStackTrace();
        }
    }
//    public static Document outXmlDocument(String filePath){
//    	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
//        DocumentBuilder builder = null;  
//        FileInputStream inputStream = null;  
//        Document doc = null;  
//        try {  
//            builder = factory.newDocumentBuilder();  
//  
//            /* 通过文件方式读取,注意文件保存的编码和文件的声明编码要一致(默认文件声明是UTF-8) */  
////            File file = new File(filePath);  
////            doc = builder.parse(file);  
//  
//            /* 通过一个URL方式读取 */  
////            URI uri = new URI(filePath);//filePath="http://java.sun.com/index.html"  
////            doc = builder.parse(uri.toString());  
//  
//            /* 通过java IO 流的读取 */  
//            inputStream = new FileInputStream(filePath);  
//            doc = builder.parse(inputStream);  
//            return doc;  
//        } catch (Exception e) {  
//            
//        } finally {  
//            if (inputStream != null) {  
//                try {  
//                    inputStream.close();  
//                } catch (IOException e) {  
//                }  
//            }  
//        }  
//        return null;     
//    }
    /**
     * Document 转换为 String 并且进行了格式化缩进 
     *
     * @param doc XML的Document对象 
     * @return String
     */
//    public static String doc2FormatString(Document doc) {         
//        StringWriter stringWriter = null;  
//        try {  
//            stringWriter = new StringWriter();  
//            if(doc != null){  
//                OutputFormat format = new OutputFormat(doc,"UTF-8",true);  
//                //format.setIndenting(true);//设置是否缩进，默认为true  
//                //format.setIndent(4);//设置缩进字符数  
//                //format.setPreserveSpace(false);//设置是否保持原来的格式,默认为 false  
//                //format.setLineWidth(500);//设置行宽度  
//                XMLSerializer serializer = new XMLSerializer(stringWriter,format);  
//                serializer.asDOMSerializer();  
//                serializer.serialize(doc);  
//                return stringWriter.toString();  
//            } else {  
//                return null;  
//            }  
//        } catch (Exception e) {  
//            return null;  
//        } finally {  
//            if(stringWriter != null){  
//                try {  
//                    stringWriter.close();  
//                } catch (IOException e) {  
//                    return null;  
//                }  
//            }  
//        }  
//    }  
    /**
     * xml文件读出Excel
     * @param path
     * @return
     */
//    public static String outXmlString(String path){
//    	path = "E:\\双录报文\\"+path;
//    	return doc2FormatString(outXmlDocument(path));
//    }  
//    public static void main(String[] args) {
//    	//FileDow.downloadFile("http://1252015361.vod2.myqcloud.com/d781b6b9vodgzp1252015361/e107b3019031868223065183083/f0.mp4", "D:/幸福人寿/lylx/src/main/webapp/filevideo/f0.mp4");
////    	FileDow.star();
////    	 String mp4 = "D:/sl01.mp4";  
////         String mp3 = "D:\\sl01-01.mp3";  
////         try {
////			changeMp4ToMp3(mp4, mp3);
////		} catch (Exception e) {
////			e.printStackTrace();
////		} 
////         System.out.println("----------ok---------");
//    	
////    	String mp4 = "d:/123.MOV";
////    	String mp3 = "d:/456.mp3";
////    	changeMp4ToMp3(mp4, mp3);
////    	System.out.println("---");
////    	System.out.println("ok");
//    	String urlString = "http://1254260866.vod2.myqcloud.com/76785367vodgzp1254260866/2dcac9ed9031868223263096677/OftinSvlM5oA.mp4";
//    	String path = "d://zxc.mp4";
//    	downloadFile(urlString, path);
//    	System.out.println("-----");
//    
//	}
//


}
