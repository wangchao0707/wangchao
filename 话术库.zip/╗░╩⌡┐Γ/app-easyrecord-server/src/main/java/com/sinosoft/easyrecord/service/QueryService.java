package com.sinosoft.easyrecord.service;


import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.vo.QueryExitForm;

public interface QueryService {

    RequestResult status(QueryExitForm queryExitForm);

    RequestResult isExit(QueryExitForm queryExitForm);
}
