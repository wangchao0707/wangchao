package com.sinosoft.easyrecord.sso;

import org.apache.shiro.authc.AuthenticationException;

public class SinoAuthenticationException extends AuthenticationException {

    public SinoAuthenticationException(String message, AuthenticationException cause) {
        super(message, cause);
    }

}
