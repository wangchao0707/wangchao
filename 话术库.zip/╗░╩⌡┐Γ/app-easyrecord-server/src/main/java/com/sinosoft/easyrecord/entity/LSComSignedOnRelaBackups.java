package com.sinosoft.easyrecord.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSComSignedOnRelaBackups")
public class LSComSignedOnRelaBackups implements Serializable {


    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "ComCode")
    private String ComCode;

    @Column(name = "RelaComCode")
    private String RelaComCode;

    @Column(name = "StartDate")
    private java.sql.Date startDate;

    @Column(name = "EndDate")
    private java.sql.Date endDate;

    @Column(name = "State")
    private char state;

    @Column(name = "ModifyDate")
    private Date ModifyDate;

    @Column(name = "ModifyTime")
    private String ModifyTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getComCode() {
        return ComCode;
    }

    public void setComCode(String comCode) {
        ComCode = comCode;
    }

    public String getRelaComCode() {
        return RelaComCode;
    }

    public void setRelaComCode(String relaComCode) {
        RelaComCode = relaComCode;
    }

    public java.sql.Date getStartDate() {
        return startDate;
    }

    public void setStartDate(java.sql.Date startDate) {
        this.startDate = startDate;
    }

    public java.sql.Date getEndDate() {
        return endDate;
    }

    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    public char getState() {
        return state;
    }

    public void setState(char state) {
        this.state = state;
    }

    public Date getModifyDate() {
        return ModifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        ModifyDate = modifyDate;
    }

    public String getModifyTime() {
        return ModifyTime;
    }

    public void setModifyTime(String modifyTime) {
        ModifyTime = modifyTime;
    }


}
