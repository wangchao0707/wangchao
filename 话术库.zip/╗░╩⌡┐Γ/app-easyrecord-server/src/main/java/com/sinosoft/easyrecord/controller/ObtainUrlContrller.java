//package com.sinosoft.easyrecord.controller;
//
//import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//import com.sinosoft.easyrecord.entity.LSPicture;
//import com.sinosoft.easyrecord.entity.LSVideo;
////import com.sinosoft.easyrecord.service.CmsService;
//import com.sinosoft.easyrecord.service.PolicyService;
//import com.sinosoft.easyrecord.vo.PicResultForm;
//import com.sinosoft.easyrecord.vo.VAndPResultForm;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.util.StringUtils;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.List;
//
///**
// * Created by  h
// * 质检端根据 Contno 请求 Url
// *
// */
//@RestController
//@RequestMapping("/obtainUrl")
//public class ObtainUrlContrller {
//
////    @Autowired
////    private CmsService cmsService;
//
////    @Value("${cms.outernet}")
////    private String outernet;
//
//    private static final Logger logger = LoggerFactory.getLogger(ObtainUrlContrller.class);
//    @Autowired
//    private PolicyService policyService;
//
//
//    @RequestMapping(value = "/obtainVideoAndPicUrl" , method = {RequestMethod.POST,RequestMethod.GET} )
//    public RequestResult RequestGainUrl(@RequestParam("contno") String contno){
//        logger.info("质检端传过来的contno"+contno);
//        //返回数据VO
//        VAndPResultForm res = new VAndPResultForm();
//        //查询视频信息
//        LSVideo lsVideo = policyService.findVideoByContNo(contno);
//        //视频的cmsID
//        String cmsID = lsVideo.getVideoNo();
//        //图片的objectID
//        //String objectId = null;
//        String screenShotUrl =null;
//        String m3u8 = null;
//        String url = null;
//        if(lsVideo != null){
//            //cmsID = lsVideo.getCloudFileId();
//            //获取url
//            //m3u8 = cmsService.getM3u8(cmsID);
//            //url = outernet+m3u8;
//            url = lsVideo.getURL();
//
//        }
//        res.setCONTNO(contno);
//        res.setVIDEOURL(url);
//        res.setCMSID(cmsID);
//        logger.info("VIDEOURL = " + outernet+m3u8+"  AND cmsID = "+cmsID);
//
//        //查询图片信息
//        List<LSPicture> lsPictures = policyService.findPictureByContNo(contno);
//        //获取图片的外连接地址
//        if (lsPictures != null || lsPictures.size() != 0){
//            for (LSPicture lsPicture : lsPictures){
//                if (lsPicture.getBusiType().equals("ScreenShoot")){
//                    PicResultForm picRes = new PicResultForm();
//                    //objectId = cmsID+ "_" + lsPicture.getTimeNode().split("\\.")[0] + ".jpeg";
//                    //screenShotUrl = cmsService.getPicture(objectId, "1",3);
//                    picRes.setOBJECTID(lsPicture.getPictureId());
//                    if(!StringUtils.isEmpty(lsPicture.getURL())) {
//                        //picRes.setPICURL(outernet + screenShotUrl);
//                        picRes.setPICURL(lsPicture.getURL());
//                    }else{
//                        picRes.setPICURL("");
//                    }
//                    picRes.setBUSITYPE(lsPicture.getBusiType());
//                    picRes.setPICTYPE(lsPicture.getPicType());
//                    picRes.setTIMENODE(lsPicture.getTimeNode());
//                    logger.info(picRes.toString());
//                    res.getPicRes().add(picRes);
//                }else{
//                    PicResultForm picRes = new PicResultForm();
//                    //screenShotUrl = cmsService.getPicture(lsPicture.getTimeNode(), "0",3);
//                    picRes.setOBJECTID(lsPicture.getTimeNode());
//                    if(!StringUtils.isEmpty(lsPicture.getURL())) {
//                       // picRes.setPICURL(outernet + screenShotUrl);
//                        picRes.setPICURL(lsPicture.getURL());
//                    }else{
//                        picRes.setPICURL("");
//                    }
//                    picRes.setBUSITYPE(lsPicture.getBusiType());
//                    picRes.setPICTYPE(lsPicture.getPicType());
//                    picRes.setTIMENODE(lsPicture.getTimeNode());
//                    logger.info(picRes.toString());
//                    res.getPicRes().add(picRes);
//                }
//            }
//
//
//        }
//        logger.info(res.toString());
//        RequestResult requestRes = new RequestResult(true);
//
//        if (res!=null){
//            requestRes.setData(res);
//        } else if (res.getVIDEOURL()==null){
//            requestRes.setMessage("未获取到视频的url");
//        }
//
//        return requestRes;
//    }
//
//}
