package com.sinosoft.easyrecord.controller;

/*import com.qcloud.Utilities.Json.JSONArray;
import com.qcloud.Utilities.Json.JSONObject;*/
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.dao.ContStateDao;
import com.sinosoft.easyrecord.dao.ContTimeDao;
import com.sinosoft.easyrecord.dao.VideoDao;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSContTime;
import com.sinosoft.easyrecord.entity.LSVideo;
import com.sinosoft.easyrecord.entity.LsContState;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/event/qcloud")
public class QCloudEventListener {

    private static final Logger logger = LoggerFactory.getLogger(QCloudEventListener.class);

    @Value("${self.baseUrl}/event/qcloud/on")
    private String baseUrl;

    @Autowired
    private ContStateDao contStateDao;

    @Autowired
    private VideoDao videoDao;

    @Autowired
    private ContTimeDao contTimeDao;

    @Autowired
    private ContDao contDao;

    private SimpleDateFormat contSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

    @RequestMapping(value = "ProcedureStateChanged")
    public @ResponseBody
    RequestResult onProcedureStateChanged(@RequestBody String jsonParam //
    ) {
        logger.info(jsonParam);

        JSONObject json_result = new JSONObject(jsonParam);
        JSONObject data = json_result.getJSONObject("data");

        if (!"FINISH".equals(data.getString("status"))) {
            logger.warn("status is not FINISH, break \n {}", jsonParam);
            return new RequestResult(false);
        }

        String fileId = data.getString("fileId");
        if (0 != data.getInt("errCode")) {
            String message = data.getString("message");
            logger.warn("Procedure Fail, break \n {}", jsonParam);

            return new RequestResult(false, fileId + " :: " + message);
        }

        JSONArray processTaskList = data.getJSONArray("processTaskList");

        for (int i = 0; i < processTaskList.length(); i++) {
            JSONObject task = processTaskList.getJSONObject(i);
            task.put("fileId", fileId);

            Thread tFireEvent = new Thread(new FireEvent(baseUrl, task));

            tFireEvent.start();

        }

        return new RequestResult(true);
    }

    @RequestMapping(value = "onTranscode")
    public @ResponseBody
    RequestResult onTranscodeComplete(@RequestBody String jsonParam //
    ) {
        JSONObject jsonResult = new JSONObject(jsonParam);
        String fileId = jsonResult.getString("fileId");

        if ("PROCESSING".equals(jsonResult.getString("status"))) {
            logger.warn("status is PROCESSING, break \n {}", jsonParam);
            return new RequestResult(false);
        }

        LSVideo video = videoDao.getVideoStateByCloudFileId(fileId);
        if (video == null) {

            String message = "not found video fileId:[" + fileId + "], BREAK!!!!!";
            logger.error(message);

            return new RequestResult(false, message);
        }
        LsContState contState = contStateDao.getContState(video.getContNo());

        boolean isSuccess = true;

        try {
            if ("FAIL".equals(jsonResult.getString("status"))) {
                logger.error("status is FAIL, break \n {}", jsonParam);
                isSuccess = false;
                return new RequestResult(isSuccess);
            }

            if (0 != jsonResult.getInt("errCode")) {
                logger.error("Procedure Fail, break \n {}", jsonParam);

                String message = jsonResult.getString("message");
                isSuccess = false;
                return new RequestResult(isSuccess, fileId + " :: " + message);
            }

            String url = jsonResult.getJSONObject("output").getString("url");
            logger.info("fileId:  {}, url:  {}", fileId, url);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = new Date();
            video.setEndTime(sdf.format(date));
            video.setURL(url);
            videoDao.save(video);

            //修改保单状态回去
            LSCont lsCont = contDao.findByContNo(video.getContNo());
            if (lsCont != null) {
                lsCont.setInteractive("F");
                contDao.save(lsCont);
            }

            // 文件保存结束 时间节点
            LSContTime lsContTime = contTimeDao.findContTime(video.getContNo());
            lsContTime.setVideoEndTime(contSdf.format(date));
            contTimeDao.saveContTime(lsContTime);

            isSuccess = true;
            return new RequestResult(true);

        } catch (Exception ex) {

            logger.error("Procedure Fail, break \n {}", jsonParam);
            logger.error(ex.getMessage(), ex);
            isSuccess = false;
            return new RequestResult(isSuccess);
        } finally {
            contState.setVideoState(isSuccess ? "F" : "N");
            logger.info("QCloudEventListener类中的onTranscodeComplete方法可能将视频状态设置成N,视频状态为 {}",contState.getVideoState());
            contStateDao.save(contState);

        }

    }

    // 假装有数据处理数据

    @RequestMapping(value = "onSnapByTime")
    public @ResponseBody
    RequestResult onSnapByTime(@RequestBody String jsonParam //
    ) {
//		JSONObject jsonResult = new JSONObject(jsonParam);
//		String vodTaskId = jsonResult.getString("vodTaskId");
//		String fileId = jsonResult.getString("fileId");
//		String url = jsonResult.getString("url");

        // pictureDao.save();

        // if ("PROCESSING".equals(jsonResult.getString("status"))) {
        // logger.warn("status is PROCESSING, break \n {}", jsonParam);
        // return new RequestResult(false);
        // }

        // LSVideo video = videoDao.getVideoStateByCloudFileId(fileId);
        // if(video == null){
        //
        // String message = "not found video fileId:[" + fileId + "],
        // BREAK!!!!!";
        // logger.error(message);
        //
        // return new RequestResult(false, message);
        // }
        // LsContState contState = contStateDao.getContState(video.getContNo());
        //
        // boolean isSuccess = true;
        //
        // try {
        // if ("FAIL".equals(jsonResult.getString("status"))) {
        // logger.error("status is FAIL, break \n {}", jsonParam);
        // isSuccess = false;
        // return new RequestResult(isSuccess);
        // }
        //
        // if (0 != jsonResult.getInt("errCode")) {
        // logger.error("Procedure Fail, break \n {}", jsonParam);
        //
        // String message = jsonResult.getString("message");
        // isSuccess = false;
        // return new RequestResult(isSuccess, fileId + " :: " + message);
        // }
        //
        // String url = jsonResult.getJSONObject("output").getString("url");
        // logger.info("fileId: {}, url: {}", fileId, url);
        //
        // video.setURL(url);
        // videoDao.save(video);
        //
        // isSuccess = true;
        // return new RequestResult(true);
        //
        // } catch (Exception ex) {
        //
        // logger.error("Procedure Fail, break \n {}", jsonParam);
        // logger.error(ex.getMessage(), ex);
        // isSuccess = false;
        // return new RequestResult(isSuccess);
        // } finally {
        // contState.setVideoState(isSuccess ? "F" : "N");
        // contStateDao.save(contState);
        //
        // }

        return new RequestResult(true);
    }

    private class FireEvent implements Runnable {

        private String baseUrl;

        // private String taskType;

        private JSONObject jsonParam;

        public FireEvent(String baseUrl, JSONObject jsonParam) {
            this.baseUrl = baseUrl;
            // this.taskType = jsonParam.getString("taskType");
            this.jsonParam = jsonParam;
        }

        @Override
        public void run() {

            String taskType = jsonParam.getString("taskType");
            logger.info("fire event:::   {}", taskType);

            String linsterUrl = baseUrl + taskType;

            OkHttpClient httpClient = new OkHttpClient();
            MediaType JSON = MediaType.parse("application/json;charset=utf-8");
            okhttp3.RequestBody requestBody = okhttp3.RequestBody.create(JSON, jsonParam.toString());
            Request request = new Request.Builder() //
                    .url(linsterUrl) //
                    .post(requestBody) //
                    .build();
            try {
                Response response = httpClient.newCall(request).execute();

                logger.info("url: {} \n response: {}", linsterUrl, response);

            } catch (Exception ex) {
                logger.info("url: {} \n request-body: {}", linsterUrl, requestBody);
                logger.error(ex.getMessage(), ex);
            }
        }
    }

}
