package com.sinosoft.easyrecord.dto;

import java.io.Serializable;

/**
 * @create 2020/2/28 0028
 */
public class VideoInfo implements Serializable {

    private static final long serialVersionUID = 7572041070264430499L;

    private Integer vodId;            //视频的ID
    private String displayName;       //视频的默认名称,一般为时间
    private Long startTime;           //录制的开始时间 UNIX时间毫秒
    private Long endTime;             //录制的结束时间 UNIX时间毫秒
    private Long fileSize;            //文件大小,单位字节
    private String meetingRoomNumber; //云会议室录制的云会议号,如果是小鱼录制,则为空
    private Integer nemoNumber;       //小鱼录制的小鱼号
    private String vodMetadataType;   ////LOCAL_RECORD(本地小鱼录像机录制),SERVER_RECORD(会议录制),LIVE_RECORD(直播录制),


    public Integer getVodId() {
        return vodId;
    }

    public void setVodId(Integer vodId) {
        this.vodId = vodId;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getMeetingRoomNumber() {
        return meetingRoomNumber;
    }

    public void setMeetingRoomNumber(String meetingRoomNumber) {
        this.meetingRoomNumber = meetingRoomNumber;
    }

    public Integer getNemoNumber() {
        return nemoNumber;
    }

    public void setNemoNumber(Integer nemoNumber) {
        this.nemoNumber = nemoNumber;
    }

    public String getVodMetadataType() {
        return vodMetadataType;
    }

    public void setVodMetadataType(String vodMetadataType) {
        this.vodMetadataType = vodMetadataType;
    }

    @Override
    public String toString() {
        return "VideoInfo{" +
                "vodId=" + vodId +
                ", displayName='" + displayName + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", fileSize=" + fileSize +
                ", meetingRoomNumber='" + meetingRoomNumber + '\'' +
                ", nemoNumber=" + nemoNumber +
                ", vodMetadataType='" + vodMetadataType + '\'' +
                '}';
    }
}
