package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSComRepository;
import com.sinosoft.easyrecord.entity.LSCom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

/**
 * Created by WinterLee on 2017/7/19.
 */
@Component
public class ComDaoImpl4JPA implements ComDao {

    @Autowired
    private LSComRepository comRepository;

    public LSComRepository getComRepository() {
        return comRepository;
    }

    @Override
    //@Cacheable(value = "company_list")
    public List<LSCom> getComList() {
        return comRepository.findAll();
    }

    @Override
    //@Cacheable(value = "company", key = "#comCode")
    public LSCom getCom(String comCode) {
        Optional<LSCom> res = comRepository.findById(comCode);
        return res.orElse(null);
    }

    @Override
    public List<LSCom> findByComCode(String comCode) {
        return comRepository.findByComCode(comCode);
    }
}
