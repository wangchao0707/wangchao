package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSOperationLog")
public class LSOperationLog {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "UploadTime")
    private String uploadTime;
    @Column(name = "UserId")
    private String userId;
    @Column(name = "EquipmentInformation")
    private String equipmentInformation;
    @Column(name = "LogPath")
    private String logPath;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getEquipmentInformation() {
        return equipmentInformation;
    }

    public void setEquipmentInformation(String equipmentInformation) {
        this.equipmentInformation = equipmentInformation;
    }

    public String getLogPath() {
        return logPath;
    }

    public void setLogPath(String logPath) {
        this.logPath = logPath;
    }


}
