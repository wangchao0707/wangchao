package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;

public class TransBodyReq80009 implements Transbody, Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 654612316549321643L;
    public String AGENTCODE;//<!-- 代理人编码 -->
    public String AGENTGROUP;//!-- 代理人小组 -->
    public String COMCODE;//管理机构编码 -->
    public String COMNAME;//管理机构 -->
    public String AGENTCOM;//经代公司编码 如果代理人是保险公司内勤人员，此字段为空-->
    public String PASSWORD;//- 密码 -->
    public String ENTRYNO;// 注册编码 -->
    public String NAME;// 姓名 -->
    public String AGE;// 年龄 -->
    public String SEX;//性别 1-男 2-女 -->
    public String BIRTHDAY;//!-- 生日 -->
    public String PHONE;// 手机 -->
    public String MOBILE;//电话 -->
    public String EMAIL;// 邮箱 -->
    public String IDNO;//证件号码 -->
    public String IDNOTYPE;// 证件类型 -->
    public String NATIONALITY;//!-- 民族 -->
    public String NATIVEPLACE;//!-- 国家 -->
    public String DEGREE;// 学历 -->
    public String RGTADDRESS;//- 家庭住址 -->
    public String REGISTERTIME;//-- 注册时间 -->
    public String USEFLAG; //-- 代理人启用状态 -->
    public String WORKFLAG; //代理人在职状态 -->

    //改
    public String CHANNEL;  //营销员渠道编码
    public String SALECOMCODE;  //销售机构编码
    public String SALECOMNAME;  //销售机构名称

    //新增字段
    public String ROLE;//<!-- 角色 0:银行柜员 1:营销员 2:客户经理 3:保险规划师(银代渠道下保险公司员工)-->
    public String BANKCODE;//<!-- 银行编码 -->
    public String BANKNETWORK;//<!-- 银行网点编码 -->
    public String PROPERSON;//<!-- 客户经理编码 -->

}
