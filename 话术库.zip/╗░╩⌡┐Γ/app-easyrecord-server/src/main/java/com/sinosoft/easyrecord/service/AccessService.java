package com.sinosoft.easyrecord.service;

import java.util.Map;

/**
 * Created by  lijunming
 * on  date 2018-11-06
 * time 15:10
 */
public interface AccessService {

    Map RequestAccess(Map param);
}
