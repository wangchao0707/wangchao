package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSOperationLogRepository;
import com.sinosoft.easyrecord.entity.LSOperationLog;

@Component
public class OperationLogDaoImpl4JPA implements OperationLogDao {

    @Autowired
    private LSOperationLogRepository operationLogRepository;

    public void setOperationLogRepository(LSOperationLogRepository operationLogRepository) {
        this.operationLogRepository = operationLogRepository;
    }

    @Override
    public void saveOperationLog(LSOperationLog lsOperationLog) {
        operationLogRepository.saveAndFlush(lsOperationLog);
    }
}
