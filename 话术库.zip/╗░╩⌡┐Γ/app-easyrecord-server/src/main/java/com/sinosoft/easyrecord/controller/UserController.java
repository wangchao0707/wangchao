package com.sinosoft.easyrecord.controller;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.entity.LSVersion;
import com.sinosoft.easyrecord.service.UserService;
import com.sinosoft.easyrecord.sso.CurrentUser;
import com.sinosoft.easyrecord.vo.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.annotation.RequestScope;

/**
 * Created by WinterLee on 2017/7/19.
 */
@RestController
@RequestMapping("/api/user")
public class UserController {

    private Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/basic", method = RequestMethod.POST)
    @ResponseBody
    public RequestResult getBasicUserInfo() {
        UserBasicInfo basicInfo = CurrentUser.getUser();

        RequestResult res = new RequestResult(true);
        res.setData(basicInfo);
        return res;
    }


    /**
     * User: weihao
     * Date: 2019/3/11
     * Time: 11:07
     * 登录后 版本信息校验接口
     */
    @RequestMapping(value = "/version", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @RequestScope
    public RequestResult userVersion(@RequestParam String versionId, String type, String comCode) {
        VersionForm versionForm = new VersionForm();
        versionForm.setVersionId(versionId);
        versionForm.setType(type);
        versionForm.setComCode(comCode);
        return userVersion(versionForm);
    }

    //回迁废掉
    @RequestMapping(value = "/version", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult userVersion(@RequestBody VersionForm versionForm) {

        ServiceResult<String, String[]> build = versionForm.validate();
        if (!build.isSuccess()) {
            RequestResult result = new RequestResult(false);
            result.setMessages(build.getFailResult());
            return result;
        }

        ServiceResult<LSVersion, String[]> result = userService.userVerSion(versionForm.getVersionId(), versionForm.getType());
        RequestResult res = new RequestResult(true);
        if (result.isSuccess()) {
            res.setData(result.getSuccessResult());
        } else {
            res.setMessages(result.getFailResult());
        }
        logger.info("version info {}", res);
        return res;

    }


    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:24
     *  获取代理人全部信息
     */
    @RequestMapping(value = "/all", method = RequestMethod.POST)
    @ResponseBody
    public RequestResult getUserInfo() {
        UserBasicInfo basicInfo = CurrentUser.getUser();

        ServiceResult<UserInfo, String> result = userService.basicInfo2UserInfo(basicInfo);

        if (result.isSuccess()) {
            RequestResult res = new RequestResult(true);
            res.setData(result.getSuccessResult());
            return res;
        } else {
            RequestResult res = new RequestResult(false);
            res.setMessage(result.getFailResult());
            return res;
        }
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:25
     *  修改代理人信息接口
     */
    @RequestMapping(value = "/extended", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult saveExtended(
            String cciaNo, String isecDate, String isecNo, String name, String sex, String channel, String orgCode, String role
    ) {

        return saveExtended(new UserExtendedForm(cciaNo, isecDate, isecNo, name, sex, channel, orgCode, role));

    }

    @RequestMapping(value = "/extended", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult saveExtended(
            @RequestBody UserExtendedForm userExtendedForm
    ) {

        String userId = CurrentUser.getUser().getUserId();
        userExtendedForm.setUserId(userId);

        ServiceResult<String, String[]> validateResult = userExtendedForm.validate();
        if (!validateResult.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateResult.getFailResult());
            return res;
        }

        ServiceResult<String, String[]> serviceResult = userService.saveExtended(userExtendedForm);
        return getRequestResult(serviceResult);

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:25
     *  修改密码
     */
    @RequestMapping(value = "/changepwd", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult changePwd(@RequestParam String oldPassword, @RequestParam String randomCode, @RequestParam String newPassword) {
        return changePwd(new UserChangePwdForm(oldPassword, newPassword, randomCode));
    }

    @RequestMapping(value = "/changepwd", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult changePwd(@RequestBody UserChangePwdForm userChangePwdForm) {

        ServiceResult<String, String[]> serviceResult = userChangePwdForm.validate();
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            return requestResult;
        }

        String oldPassword = userChangePwdForm.getOldPassword();
        if (oldPassword.length() == 31) {
            oldPassword = "0" + oldPassword;
        }
        userChangePwdForm.setOldPassword(oldPassword);

        String newPassword = userChangePwdForm.getNewPassword();
        if (newPassword.length() == 31) {
            newPassword = "0" + newPassword;
        }
        userChangePwdForm.setNewPassword(newPassword);
        ServiceResult<String, String[]> serviceResult2 = userService.updatePassword(userChangePwdForm.getOldPassword(), userChangePwdForm.getNewPassword(), userChangePwdForm.getRandomCode());
        return getRequestResult(serviceResult2);
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:26
     *  消息反馈接口
     */
    @RequestMapping(value = "/feedback", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult saveFeedback(@RequestParam String title, @RequestParam String content, @RequestParam String priority) {
        return saveFeedback(new FeedbackForm(title, content, priority));
    }

    @RequestMapping(value = "/feedback", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult saveFeedback(@RequestBody FeedbackForm feedbackForm) {
        ServiceResult<String, String[]> serviceResult = feedbackForm.validate();
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            return requestResult;
        }
        ServiceResult<String, String[]> result = userService.saveFeedback(feedbackForm);
        return getRequestResult(result);


    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:26
     * 修改代理人手机号  发送短信接口
     */
    @RequestMapping(value = "/changePhoneValiCode", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult changePhoneValiCode(@RequestParam String phoneNum, @RequestParam String comCode) {
        return changePhoneValiCode(new VerificationForm(comCode, phoneNum));
    }

    @RequestMapping(value = "/changePhoneValiCode", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult changePhoneValiCode(@RequestBody VerificationForm verificationForm) {
        ServiceResult<String, String[]> result = verificationForm.validate();
        if (!result.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(result.getFailResult());
            return requestResult;
        }
        ServiceResult<String, String[]> serviceResult = userService.getPhoneNumVerification(verificationForm.getPhoneNum(), verificationForm.getComCode());
        return getRequestResult(serviceResult);
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:27
     * 修改手机号
     */
    @RequestMapping(value = "/changePhoneNo", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult changePhoneNo(@RequestParam String password, @RequestParam String newPhoneNum,
                                       @RequestParam String valicode, @RequestParam String randomCode) {
        return changePhoneNo(new UnboundFrom(password, newPhoneNum, valicode, randomCode));
    }

    @RequestMapping(value = "/changePhoneNo", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult changePhoneNo(@RequestBody UnboundFrom unboundFrom) {

        ServiceResult<String, String[]> serviceResult = unboundFrom.validate();
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            return requestResult;
        }
        ServiceResult<String, String[]> serviceResult2 = userService.changePhoneNo(unboundFrom.getPassword(), unboundFrom.getNewPhoneNum(), unboundFrom.getValicode(), unboundFrom.getRandomCode());
        return getRequestResult(serviceResult2);

    }

    private RequestResult getRequestResult(ServiceResult<String, String[]> serviceResult) {
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);

            requestResult.setMessages(serviceResult.getFailResult());
            return requestResult;
        } else {
            RequestResult requestResult = new RequestResult(true);
            return requestResult;
        }
    }

}

