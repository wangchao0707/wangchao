//package com.sinosoft.easyrecord.service.impl;
//
//import com.alibaba.fastjson.JSONObject;
//import com.sinosoft.easyrecord.common.DownStatusEnum;
//import com.sinosoft.easyrecord.config.OKHttpClientBuilder;
//import com.sinosoft.easyrecord.dao.VideoUploadCloudDao;
//import com.sinosoft.easyrecord.dto.VideoAddress;
//import com.sinosoft.easyrecord.dto.VideoInfo;
//import com.sinosoft.easyrecord.entity.VideoUploadCloud;
//import com.sinosoft.easyrecord.service.TransferVideoService;
//import com.sinosoft.easyrecord.stroage.service.QCloudService;
//import com.sinosoft.easyrecord.util.FileUtil;
//import com.sinosoft.easyrecord.util.SignatureSample;
//import com.sinosoft.easyrecord.vo.TransferVideoForm;
//import com.sinosoft.easyrecord.vo.VideoStatusVo;
//import okhttp3.OkHttpClient;
//import okhttp3.Response;
//import okhttp3.ResponseBody;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import org.springframework.util.StringUtils;
//
//import java.io.File;
//import java.io.IOException;
//import java.io.InputStream;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.List;
//
//
///**
// * @create 2020/2/28 0028
// */
//@Service
//public class TransferVideoServiceImpl implements TransferVideoService {
//
//    private static final Logger LOGGER = LoggerFactory.getLogger(TransferVideoServiceImpl.class);
//
//    @Value("${fish.videoListUrl}")
//    private String videoListUrl;
//
//    @Value("${fish.downLoadUrl}")
//    private String downLoadUrl;
//
//    @Value("${fish.token}")
//    private String token;
//
//    @Value("${fish.enterpriseId}")
//    private String enterpriseId;
//
//    @Value("${filesystem.temp-path}")
//    private String tmpVideoDir;
//
//    @Autowired
//    private QCloudService qCloudService;
//
//    @Autowired
//    private VideoUploadCloudDao uploadCloudDao;
//
//    @Override
//    public void transferVideo(TransferVideoForm param) {
//        VideoUploadCloud uploadCloud = buildVideoUploadCloud(param);
//        uploadCloudDao.insertOrUpdate(uploadCloud);
//        String displayName = param.getDisPlayName();
//        try {
//            List<VideoInfo> videoInfos = reqFishVideoList(param);
//            String vodId = videoInfos.stream().filter(viewInfo -> displayName.equals(viewInfo.getDisplayName().split("_")[0]))
//                    .map(viewInfo -> String.valueOf(viewInfo.getVodId())).findAny().orElse(null);
//            String downUrl = reqFishDownUrl(vodId);
//            downloadAndUploadQCloud(downUrl, param, uploadCloud);
//        } catch (Exception e) {
//            LOGGER.error("下载并上传腾讯云发生异常:[{}]", e);
//            uploadCloud.setUploadStatus("0");
//            uploadCloud.setErrorMsg(e.getMessage());
//            uploadCloudDao.insertOrUpdate(uploadCloud);
//            return;
//        }
//    }
//
//    @Override
//    public VideoStatusVo getUploadProgress(String contId) {
//        VideoUploadCloud videoUpload = uploadCloudDao.getUploadStatus(contId);
//        if (videoUpload != null) {
//            VideoStatusVo statusVo = new VideoStatusVo();
//            String errorMsg = videoUpload.getErrorMsg();
//            if (!StringUtils.isEmpty(errorMsg)){
//                statusVo.setErrorMsg(errorMsg);
//            }
//            statusVo.setStatus(videoUpload.getUploadStatus());
//            return statusVo;
//        }
//        return null;
//    }
//
//    private List<VideoInfo> reqFishVideoList(TransferVideoForm param) {
//        String formatUrl = String.format(videoListUrl, param.getMeetingRoomId(), enterpriseId, param.getStartTime(), param.getEndTime());
//        String videoListSignature = SignatureSample.getFishSignature("GET", formatUrl, token, null);
//        String finalUrl = formatUrl + "&signature=" + videoListSignature;
//        String jsonStr = null;
//        try {
//            jsonStr = reqGetByOkHttp(finalUrl).string();
//        } catch (Exception e) {
//            LOGGER.error("获取视频列表响应体发生异常！地址为[{}]", finalUrl);
//            throw new RuntimeException("获取视频列表为空");
//        }
//        return JSONObject.parseArray(jsonStr, VideoInfo.class);
//    }
//
//    private String reqFishDownUrl(String vodId) {
//        String formatUrl = String.format(downLoadUrl, vodId, enterpriseId);
//        String downLoadSignature = SignatureSample.getFishSignature("GET", formatUrl, token, null);
//        String finalUrl = formatUrl + "&signature=" + downLoadSignature;
//        String jsonStr = null;
//        try {
//            jsonStr = reqGetByOkHttp(finalUrl).string();
//        } catch (Exception e) {
//            LOGGER.error("获取下载地址响应体发生异常！视频id为[{}]", vodId);
//            throw new RuntimeException("获取视频下载地址为空");
//        }
//        VideoAddress videoAddress = JSONObject.parseObject(jsonStr, VideoAddress.class);
//        if (!"777000".equals(videoAddress.getStatus())) {
//            String errMsg= DownStatusEnum.parseToDesc(videoAddress.getStatus());
//            LOGGER.error(errMsg);
//            throw new RuntimeException(errMsg);
//        }
//        return videoAddress.getDownloadUrl();
//    }
//
//    private void downloadAndUploadQCloud(String downUrl, TransferVideoForm param, VideoUploadCloud uploadCloud) {
//        String workSpace = tmpVideoDir + File.separator + getNameFromUrl(downUrl);
//        File file = new File(workSpace);
//        LOGGER.info("视频暂时存在这：[{}]", workSpace);
//        long time1 = System.currentTimeMillis();
//        uploadCloud.setUploadStatus("2");//开始下载
//        uploadCloudDao.insertOrUpdate(uploadCloud);
//        String respUrl = null;
//        try {
//            InputStream is = reqGetByOkHttp(downUrl).byteStream();
//            FileUtil.writeFile(file, is); //视频暂时存储位置
//            respUrl = qCloudService.uploadCloud(param.getComCode(), param.getTargetUrl(), workSpace, "down");
//        } catch (Exception e) {
//            LOGGER.error("视频上传发生异常"+e.getMessage());
//            throw new RuntimeException("下载视频上传腾讯云失败");
//        }finally {
//            FileUtil.deleteFile(workSpace);
//        }
//        if (!StringUtils.isEmpty(respUrl)) {
//            uploadCloud.setUploadStatus("3");
//            uploadCloud.setCloudStoragePath(respUrl);
//            uploadCloudDao.insertOrUpdate(uploadCloud); //结束下载
//            long time2 = System.currentTimeMillis();
//            LOGGER.info("下载小鱼视频并上传腾讯云耗时:[{}]ms", time2 - time1);
//        }else {
//            LOGGER.error("读取数据超时，检查网络");
//            throw new RuntimeException("上传腾讯云失败，返回存储地址为空");
//        }
//    }
//
//    private String getNameFromUrl(String url) {
//        int result = url.indexOf("?");
//        if (result != -1) {
//            return url.split("[?]")[0].substring(url.lastIndexOf("/") + 1);
//        }
//        return url.substring(url.lastIndexOf("/") + 1);
//    }
//
//    private ResponseBody reqGetByOkHttp(String url) {
//        OkHttpClient.Builder client = OKHttpClientBuilder.buildOKHttpClient();
//        okhttp3.Request request = new okhttp3.Request.Builder().url(url).get().build();
//        ResponseBody result = null;
//        try {
//            Response response = client.build().newCall(request).execute();
//            if (response.isSuccessful()) {
//                result = response.body();
//            }
//        } catch (Exception e) {
//            LOGGER.error("okhttp请求接口发生异常！");
//            throw new RuntimeException("okhttp请求接口发生异常！");
//        }
//        return result;
//    }
//
//    private VideoUploadCloud buildVideoUploadCloud(TransferVideoForm param) {
//        VideoUploadCloud vuc = new VideoUploadCloud();
//        vuc.setContId(param.getContId());
//        vuc.setComCode(param.getComCode());
//        vuc.setDisplayName(param.getDisPlayName());
//        vuc.setMeetingRoomId(param.getMeetingRoomId());
//        vuc.setTargetUrl(param.getTargetUrl());
//        vuc.setStartTime(stringTransferDate(param.getStartTime()));
//        vuc.setEndTime(stringTransferDate(param.getEndTime()));
//        vuc.setUploadStatus("1");
//        return vuc;
//    }
//
//    private String stringTransferDate(String timeS) {
//        long time = Long.parseLong(timeS);
//        Date date = new Date(time);
//        SimpleDateFormat sdFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:dd");
//        return sdFormatter.format(date);
//    }
//
//
//}
