package com.sinosoft.easyrecord.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.dao.LDCodeDao;
import com.sinosoft.easyrecord.util.RegetUserInfo;
import com.sinosoft.easyrecord.util.RegetUtil;
import org.springframework.util.StringUtils;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


public class AppntForm implements Vo {
    private String appntNo;// 投保人id
    private String name;
    private String sex;
    private Date birthday;
    private String strBirthday;
    private String address;
    private String idType;
    private String idNo;
    private String operator;
    private String clientContNo;
    private String contNo;
    private String age;

    public String getStrBirthday() {
        return strBirthday;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getClientContNo() {
        return clientContNo;
    }

    public void setClientContNo(String clientContNo) {
        this.clientContNo = clientContNo;
    }

    public String getAppntNo() {
        return appntNo;
    }

    public void setAppntNo(String appntNo) {
        this.appntNo = appntNo;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setStrBirthday(String strBirthday) {
        this.strBirthday = strBirthday;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    private LDCodeDao ldCodeDao;

    public void setLdCodeDao(LDCodeDao ldCodeDao) {
        this.ldCodeDao = ldCodeDao;
    }

    @Override
    public ServiceResult<String, String[]> validate() {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);

        if (StringUtils.isEmpty(this.getClientContNo())) {
            return builder.createFailResult(new String[]{"请输入合同编号"});
        }

        List<String> msg = new ArrayList<>();

        // 投保人信息
        if (StringUtils.isEmpty(this.getName())) {
            msg.add("请输入投保人姓名");
        }
        /**
         * 验证姓名
         **/
        if (!RegetUtil.isName(this.getName())){
            msg.add("投保人姓名格式有误，请重新输入！");
        }
        if (StringUtils.isEmpty(this.getSex())) {
            msg.add("请输入投保人性别");
        }
        if (StringUtils.isEmpty(this.getAge())) {
            msg.add("请选择投保人年龄");
        }


        ////////////////////////////////////////////////////////////////////////////

        if (this.getBirthday() == null) { // 日期类型的 生日是否为空
            // 为空
            if (StringUtils.isEmpty(this.strBirthday)) {
                // 为空 给出提示，一切都结束了
                msg.add("请输入投保人生日");
            } else {
                // 不为空 尝试转换格式
                try {
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    java.util.Date d = format.parse(this.strBirthday);
                    java.sql.Date date = new java.sql.Date(d.getTime());
                    this.setBirthday(date);
                } catch (Exception e) {
                    // 格式有问题，给出提示，一切都结束了
                    msg.add("投保人生日的格式不正确");

                }
            }
        }


        ////////////////////////////////////////////////////////////////////////////
        if (StringUtils.isEmpty(this.getAddress())) {
            msg.add("请输入投保人地址");
        }
        if (StringUtils.isEmpty(this.getIdType())) {
            msg.add("请选择投保人证件类型");

        }
        if (StringUtils.isEmpty(this.getIdNo())) {
            msg.add("请选择投保人证件号");
        }


//        if (msg.size() == 0) {
//            //如果非空验证通过，进行业务逻辑验证
//            RegetUserInfo regetUserInfo = new RegetUserInfo();
//            regetUserInfo.setLdCodeDao(this.ldCodeDao);
//            if (!regetUserInfo.isSex(this.sex)) {
//                msg.add("投保人性别不符合校验规则");
//            }
//            if (!regetUserInfo.isDate(this.birthday)) {
//                msg.add("投保人出生日期不是日期格式");
//            }
//            if (!regetUserInfo.isAddress(this.address)) {
//                msg.add("投保人通讯地址不符合校验规则");
//            }
//            if (!regetUserInfo.isIDType(this.idType)) {
//                msg.add("投保人证件类型不合法");
//            } else {
//                if (this.idType.equals("4") && !regetUserInfo.isIDNo(this.idNo, this.sex, this.birthday, this.address)) {
//                    msg.add("投保人身份证号不符合校验规则");
//                } else if (this.idType.equals("14") && !regetUserInfo.isBirthdayNo(this.idNo, this.birthday, this.address)) {
//                    msg.add("投保人出生证明不符合校验规则");
//                } else if (!regetUserInfo.isIDType(idType)) {
//                    msg.add("投保人证件号不符合校验规则");
//                }
//            }
//            if (!regetUserInfo.isName(this.name)) {
//                msg.add("投保人姓名不符合校验规则");
//            }
//            if (msg.size() == 0) {
//                return builder.createSuccessResult("OK");
//            }
//
//        }
        if (msg.size() == 0){
            return builder.createSuccessResult("OK");
        }else {
            String[] returnMsg = new String[msg.size()];
            returnMsg = msg.toArray(returnMsg);
            return builder.createFailResult(returnMsg);
        }

    }

    @Override
    public String toString() {
        return "AppntForm{" +
                "appntNo='" + appntNo + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", birthday=" + birthday +
                ", strBirthday='" + strBirthday + '\'' +
                ", address='" + address + '\'' +
                ", idType='" + idType + '\'' +
                ", idNo='" + idNo + '\'' +
                ", operator='" + operator + '\'' +
                ", clientContNo='" + clientContNo + '\'' +
                ", contNo='" + contNo + '\'' +
                ", age='" + age + '\'' +
                '}';
    }
}
