package com.sinosoft.easyrecord.controller;


import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.dao.ComConfigDao;
import com.sinosoft.easyrecord.entity.LDComConfig;
import com.sinosoft.easyrecord.service.*;
import com.sinosoft.easyrecord.sso.CurrentUser;
import com.sinosoft.easyrecord.stroage.service.QCloudService;
import com.sinosoft.easyrecord.vo.QCloudCosSignForm;
import com.sinosoft.easyrecord.vo.QCloudLogSignForm;
import com.sinosoft.easyrecord.vo.UserBasicInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

@RestController
@RequestMapping("/api/qcloud")
public class  QCloudApiController {

    private static final Logger logger = LoggerFactory.getLogger(QCloudApiController.class);
    private static final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    @Autowired
    private QCloudService cloudService;

    @Autowired
    private ComConfigDao comconfigDao;

    @Autowired
    private VersionService versionService;

//    public void setVersionService(VersionService versionService) {
//        this.versionService = versionService;
//    }

    @Autowired
    private CheckService checkService;

//    public void setCheckService(CheckService checkService) {
//        this.checkService = checkService;
//    }

    private UploadTimeService uploadTimeService;

//    @Autowired
//    private CmsService cmsService;

    @Autowired
    public void setUploadTimeService(UploadTimeService uploadTimeService) {
        this.uploadTimeService = uploadTimeService;
    }

//    @Value("${self.busiNum}")
//    private String arr_busiNum;
//
//    @RequestMapping(value = "/sign", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
//    @ResponseBody
//    public RequestResult getSign( //
//                                  @RequestParam String contno,
//                                  @RequestParam String filename, //
//                                  @RequestParam String backetName,
//                                  @RequestParam String busiNum,
//                                  @RequestParam String eqInfor,
//                                  @RequestParam String versionNum,
//                                  @RequestParam String insurComCode,
//                                  @RequestParam(required = false) String riskType
//    ) {
//
//        return getSign(new QCloudCosSignForm(contno, filename, backetName, busiNum, eqInfor, versionNum, insurComCode, riskType));
//
//    }

//    @RequestMapping(value = "/sign", method = RequestMethod.POST, consumes = "application/json")
//    @ResponseBody
//    public RequestResult getSign(@RequestBody QCloudCosSignForm signForm) {
//        logger.info("sign form {}", signForm);
//        ServiceResult<String, String[]> serviceResult = null;
//        String comCode = CurrentUser.getUser().getComCode();
//        String userId = CurrentUser.getUser().getUserId();
//        String agentCode = CurrentUser.getUser().getAgentCode();
//        //验证版本号信息
//        if (StringUtils.isEmpty(signForm.getEqInfor()) || StringUtils.isEmpty(signForm.getVersionNum())) {
//            RequestResult requestResult = new RequestResult(false);
//            requestResult.setMessage("您的系统版本太低，请更新到最新版本。");
//            Hashtable<String, String> data = new Hashtable<>();
//            data.put("isMove", "false");
//            requestResult.setData(data);
//            return requestResult;
//        } else {
//            serviceResult = versionService.checkVersion(comCode, signForm.getEqInfor(), signForm.getVersionNum());
//            if (!serviceResult.isSuccess()) {
//                RequestResult requestResult = new RequestResult(false);
//                requestResult.setMessages(serviceResult.getFailResult());
//                Hashtable<String, String> data = new Hashtable<>();
//                data.put("isMove", "false");
//                requestResult.setData(data);
//                return requestResult;
//            }
//        }
//        logger.info("sign form {}", signForm);
//        serviceResult = signForm.validate();
//        if (!serviceResult.isSuccess()) {
//            RequestResult requestResult = new RequestResult(false);
//            requestResult.setMessages(serviceResult.getFailResult());
//            Hashtable<String, String> data = new Hashtable<>();
//            data.put("isMove", "false");
//            requestResult.setData(data);
//            return requestResult;
//        }
//
//        //本地验证投保单号
//        serviceResult = checkService.localCheckBusiNum(signForm.getContno(), comCode, signForm.getBusiNum(), signForm.getInsurComCode(), userId);
//        if (!serviceResult.isSuccess()) {
//            RequestResult requestResult = new RequestResult(false);
//            requestResult.setMessages(serviceResult.getFailResult());
//            Hashtable<String, String> data = new Hashtable<>();
//            data.put("isMove", "true");
//            requestResult.setData(data);
//            logger.info("businum {}  fileresult {}", signForm.getBusiNum(), serviceResult.getFailResult());
//            return requestResult;
//        }
//
//        if (signForm.getRiskType() == null) {
//            signForm.setRiskType("");
//        }
//        //验证投保单号
//        serviceResult = checkService.checkBusiNum(comCode, signForm.getBusiNum(), agentCode, signForm.getRiskType());
//        if (!serviceResult.isSuccess()) {
//            RequestResult requestResult = new RequestResult(false);
//            requestResult.setMessages(serviceResult.getFailResult());
//            logger.info("businum {}  fileresult {}", signForm.getBusiNum(), serviceResult.getFailResult());
//            Hashtable<String, String> data = new Hashtable<>();
//            data.put("isMove", "false");
//            requestResult.setData(data);
//            return requestResult;
//        }
//
//        logger.info("GET SIGN: contno={}, backetName={}", signForm.getContno(), signForm.getBacketName());
//
//        UserBasicInfo user = CurrentUser.getUser();
//        String path = format.format(new Date());
//        String dir = "/" + path + "/" + user.getComCode() + "/" + user.getOrgCode();
//        SecureRandom random1 = null;
//        try {
//            random1 = SecureRandom.getInstance("SHA1PRNG");
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        }
//
//        int random;
//        if (random1!=null){
//            random= Math.abs(random1.nextInt());
//        }else {
//            random = 123;
//        }
//
//        String filename = random + signForm.getFilename();
//        String filepath = dir + "/" + filename;
//
//        String sign = null;
//        try {
////            sign = cmsService.getToken();
//            sign = cloudService.getSign(filepath,"down",user.getComCode());
//        } catch (Exception e) {
//            logger.error(e.getMessage(), e);
//            RequestResult requestResult = new RequestResult(false);
//            requestResult.setMessages("获取签名失败！");
//            Hashtable<String, String> data = new Hashtable<>();
//            data.put("busiNum", signForm.getBusiNum());
//            data.put("contNo", signForm.getContno());
//            data.put("isMove", "false");
//            requestResult.setData(data);
//            return requestResult;
//        }
//
//        //添加上传时间
//        String serialNum = uploadTimeService.saveUploadTime(signForm.getBusiNum(), signForm.getEqInfor(), signForm.getVersionNum(), sign, user.getUserId());
//
//        LDComConfig ldComConfig = comconfigDao.findByComCode(user.getComCode());
//
//        RequestResult result = new RequestResult(true);
//
//        Hashtable<String, String> data = new Hashtable<>();
//        data.put("sign", sign);
//        data.put("dir", dir);
//        data.put("filename", filename);
//        data.put("backet", ldComConfig.getDownBucketName());
//        data.put("region", ldComConfig.getDownRegion());
//        data.put("path", filepath);
//        data.put("contno", signForm.getContno());
//        data.put("serialNum", serialNum);
////        data.put("delFile", "Y");
//        data.put("isMove", "false");
//        result.setData(data);
//
//        if (logger.isInfoEnabled()) {
//            logger.info("GET SIGN: contno=" + signForm.getContno() + ", backetName=" + ldComConfig.getDownBucketName() + " END ~~~~~~~~~~~ \n\tSIGN=" + sign + "\n\t" + data + "\n\tbusinum: " + signForm.getBusiNum());
//        }
//        return result;
//
//    }


    @RequestMapping(value = "/logSign", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult getLogSign(@RequestBody QCloudLogSignForm signForm) {
        logger.info("log signForm {}", signForm);
        ServiceResult<String, String[]> serviceResult = null;
        serviceResult = signForm.validate();
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            return requestResult;
        }
        UserBasicInfo user = CurrentUser.getUser();
        String path = format.format(new Date());
        String dir = "/" + path + "/" + user.getComCode() + "/" + user.getOrgCode();
        SecureRandom random1 = null;
        try {
            random1 = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        int random;
        if (random1!=null){
            random= Math.abs(random1.nextInt());
        }else {
            random = 123;
        }
        String filename = random + signForm.getFileName();
        String filepath = dir + "/" + filename;

        String sign = null;
        try {
//            sign = cmsService.getToken();
            sign = cloudService.getTemSign(filepath,"log",user.getComCode());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages("获取签名失败！");
            Hashtable<String, String> data = new Hashtable<>();
            data.put("busiNum", signForm.getBusiNum());
            data.put("contNo", signForm.getContNo());
            requestResult.setData(data);
            return requestResult;
        }
        LDComConfig ldComConfig = comconfigDao.findByComCode(user.getComCode());
        RequestResult result = new RequestResult(true);

        Hashtable<String, String> data = new Hashtable<>();
        data.put("sign", sign);
        data.put("dir", dir);
        data.put("filename", filename);
        data.put("backet", ldComConfig.getLogBucketName());
        data.put("region", ldComConfig.getLogRegion());
        data.put("path", filepath);
        data.put("contno", signForm.getContNo());
        result.setData(data);
        return result;

    }


    @RequestMapping(value = "/newSign", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult getNewSign( //
                                     @RequestParam String contno,
                                     @RequestParam String filename, //
                                     @RequestParam String backetName,
                                     @RequestParam String busiNum,
                                     @RequestParam String eqInfor,
                                     @RequestParam String versionNum,
                                     @RequestParam String insurComCode,
                                     @RequestParam String uploadTimes
    ) {

        return getNewSign(new QCloudCosSignForm(contno, filename, backetName, busiNum, eqInfor, versionNum, insurComCode, uploadTimes));

    }

    @RequestMapping(value = "/newSign", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult getNewSign(@RequestBody QCloudCosSignForm signForm) {
        logger.info("sign form {}", signForm);
        ServiceResult<String, String[]> serviceResult = null;
        String comCode = CurrentUser.getUser().getComCode();
        String userId = CurrentUser.getUser().getUserId();
        String agentCode = CurrentUser.getUser().getAgentCode();
        //验证版本号信息
        /*if (StringUtils.isEmpty(signForm.getEqInfor()) || StringUtils.isEmpty(signForm.getVersionNum())) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessage("您的系统版本太低，请更新到最新版本。");
            Hashtable<String, String> data = new Hashtable<>();
            data.put("isMove", "false");
            requestResult.setData(data);
            return requestResult;
        } else {
            serviceResult = versionService.checkVersion(comCode, signForm.getEqInfor(), signForm.getVersionNum());
            if (!serviceResult.isSuccess()) {
                RequestResult requestResult = new RequestResult(false);
                requestResult.setMessages(serviceResult.getFailResult());
                Hashtable<String, String> data = new Hashtable<>();
                data.put("isMove", "false");
                requestResult.setData(data);
                return requestResult;
            }
        }*/
        logger.info("sign form {}", signForm);
        serviceResult = signForm.validate();
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            Hashtable<String, String> data = new Hashtable<>();
            data.put("isMove", "false");
            requestResult.setData(data);
            return requestResult;
        }

        //本地验证投保单号
        serviceResult = checkService.localCheckBusiNum(signForm.getContno(), comCode, signForm.getBusiNum(), signForm.getInsurComCode(), userId);
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            Hashtable<String, String> data = new Hashtable<>();
            data.put("isMove", "true");
            requestResult.setData(data);
            logger.info("businum {}  fileresult {}", signForm.getBusiNum(), serviceResult.getFailResult());
            return requestResult;
        }

        if (signForm.getRiskType() == null) {
            signForm.setRiskType("");
        }

        //验证投保单号
        serviceResult = checkService.checkBusiNum(comCode, signForm.getBusiNum(), agentCode, signForm.getRiskType());
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            logger.info("businum {}  fileresult {}", signForm.getBusiNum(), serviceResult.getFailResult());
            Hashtable<String, String> data = new Hashtable<>();
            data.put("isMove", "false");
            requestResult.setData(data);
            return requestResult;
        }

        logger.info("GET SIGN: contno={}, backetName={}", signForm.getContno(), signForm.getBacketName());

        UserBasicInfo user = CurrentUser.getUser();
        Calendar cal = Calendar.getInstance();
//        String path = format.format(new Date());
        String dir = "/easyrecord/" + cal.get(Calendar.YEAR) + "/" + cal.get(Calendar.MONTH) + "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + user.getComCode() + "/" + user.getOrgCode();
        String filename = "";
        if (signForm.getUploadTimes() != null) {
            filename = signForm.getUploadTimes() + "-" + signForm.getFilename();
        } else {
            filename = "0" + "-" + signForm.getFilename();
        }

        String filepath = dir + "/" + filename;

        String sign = null;
        try {
//            sign = cmsService.getToken();
            sign = cloudService.getTemSign(filepath,"down",user.getComCode());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages("获取签名失败！");
            Hashtable<String, String> data = new Hashtable<>();
            data.put("busiNum", signForm.getBusiNum());
            data.put("contNo", signForm.getContno());
            data.put("isMove", "false");
            requestResult.setData(data);
            return requestResult;
        }

        //添加上传时间
        String serialNum = uploadTimeService.saveUploadTime(signForm.getBusiNum(), signForm.getEqInfor(), signForm.getVersionNum(), sign, user.getUserId());

        LDComConfig ldComConfig = comconfigDao.findByComCode(user.getComCode());

        RequestResult result = new RequestResult(true);

        Hashtable<String, String> data = new Hashtable<>();
        data.put("sign", sign);
        data.put("dir", dir);
        data.put("filename", filename);
        data.put("backet", ldComConfig.getDownBucketName()+"-"+ldComConfig.getCloudAppId());
        data.put("region", ldComConfig.getDownRegion());
        data.put("path", filepath);
        data.put("contno", signForm.getContno());
        data.put("serialNum", serialNum);
        data.put("isMove", "false");
        result.setData(data);

        if (logger.isInfoEnabled()) {
            logger.info("GET SIGN: contno=" + signForm.getContno() + ", backetName=" + ldComConfig.getDownBucketName() + " END ~~~~~~~~~~~ \n\tSIGN=" + sign + "\n\t" + data + "\n\tbusinum: " + signForm.getBusiNum());
        }
        return result;


    }


}
