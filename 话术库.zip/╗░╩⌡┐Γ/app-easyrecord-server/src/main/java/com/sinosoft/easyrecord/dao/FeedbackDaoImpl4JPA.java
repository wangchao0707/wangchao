package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSFeedbackRepository;

@Component
public class FeedbackDaoImpl4JPA implements FeedbackDao {

    @Autowired
    private LSFeedbackRepository feedbackRepository;

    public void setFeedbackRepository(LSFeedbackRepository feedbackRepository) {
        this.feedbackRepository = feedbackRepository;
    }

    public void saveFeedback(com.sinosoft.easyrecord.entity.LSFeedback lsFeedback) {

        feedbackRepository.saveAndFlush(lsFeedback);

    }

    ;
}
