//package com.sinosoft.easyrecord.service;
//
//import com.sinosoft.easyrecord.entity.LSCont;
//import com.sinosoft.easyrecord.entity.LSUser;
//import com.sinosoft.easyrecord.entity.LsContState;
//import com.yuancore.cms.client.exception.CMSException;
//
//import java.io.File;
//import java.util.Map;
//
///**
// * @author SunYu
// * @date 2019/3/20 15:10
// */
//public interface CmsService {
//    //获取cms的token
//    String getToken();
//
//    //获取图片的外链
//    String getPicture(String objectId, String type, int time);
//
//    //更新索引
//    String updateIndex(String objectId, Map<String, Object> meta);
//
//    //获取m3u8地址
//    String getM3u8(String objectId);
//
//    Map testUploadVideo(String path);
//
//    Map getIndex(String objectId) throws CMSException;
//
//    //上传头像
//    Map uploadPicture(String filePath, String userId);
//
//    String updateCmsIndex(String contNo, LSCont lsCont, LsContState lsContState, String cmsId, LSUser lsUser);
//
//    String updateCmsIndex(String contNo, LSCont lsCont, String cmsId, LSUser lsUser);
//}
