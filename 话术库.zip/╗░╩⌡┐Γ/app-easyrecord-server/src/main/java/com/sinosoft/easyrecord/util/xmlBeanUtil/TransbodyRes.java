package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;

/*
 * <TRANSRESULT>
	-				<RETURNCODE>000000</RETURNCODE> <!--000000-操作成功   100027-操作失败-->
	-				<MESSAGE>操作成功</MESSAGE>
	-		</ TRANSRESULT >
	000000-操作成功   100027-操作失败
 */
public class TransbodyRes implements Transbody, Serializable {

    private static final long serialVersionUID = 8269706495376495653L;

    private Transresult TRANSRESULT;

    public Transresult getTRANSRESULT() {
        return TRANSRESULT;
    }

    public void setTRANSRESULT(Transresult tRANSRESULT) {
        TRANSRESULT = tRANSRESULT;
    }

    public static class Transresult {
        public String RETURNCODE;
        public String MESSAGE;
    }
}
