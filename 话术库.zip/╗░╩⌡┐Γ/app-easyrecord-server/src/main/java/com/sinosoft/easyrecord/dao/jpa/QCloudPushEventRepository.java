package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.QCloudPushEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface QCloudPushEventRepository extends JpaRepository<QCloudPushEvent, QCloudPushEvent.QCloudPushEventPK> {

    List<QCloudPushEvent> findTop10ByDealNodeKeyIsNull();


    List<QCloudPushEvent> findByDealNodeKeyAndStatus(String dealNodeKey, char status);


    @Query(value = "update QCloudPushEvent set dealNodeKey = ?3 where comCode=?1 and msgHandle=?2 and event.dealNodeKey is null", nativeQuery = true)
    void assignEvent(String comCode, String msgHandle, String dealNodeKey);

    @Query(value = "update QCloudPushEvent set status = ?3 where comCode=?1 and msgHandle=?2 ", nativeQuery = true)
    void saveStatus(String comCode, String msgHandle, char status);


}
