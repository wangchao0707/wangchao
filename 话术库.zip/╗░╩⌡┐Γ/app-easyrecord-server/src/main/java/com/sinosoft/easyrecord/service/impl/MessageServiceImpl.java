package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.dao.MessageDao;
import com.sinosoft.easyrecord.dao.VideoDao;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSMessage;
import com.sinosoft.easyrecord.entity.LSVideo;
import com.sinosoft.easyrecord.service.MessageService;
import com.sinosoft.easyrecord.sso.CurrentUser;
import com.sinosoft.easyrecord.vo.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * Created by WinterLee on 2017/7/22.
 */
@Service
public class MessageServiceImpl implements MessageService {

    private Logger logger = LoggerFactory.getLogger(MessageServiceImpl.class);

    @Autowired
    private ContDao contDao;

    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }

    @Autowired
    private MessageDao messageDao;

    public MessageDao getMessageDao() {
        return messageDao;
    }

    @Value(value = "${message.enable}")
    private boolean messageEnable = false;

    @Autowired
    private VideoDao videoDao;

    public void setVideoDao(VideoDao videoDao) {
        this.videoDao = videoDao;
    }

    @Override
    public RequestResult getMessageList(QueryMessageForm messageQueryForm) {

        Page<LSMessage> messageList = messageDao.getMessageList(messageQueryForm);

        List<LSMessage> messages = messageList.getContent();

        Message[] arrMessage = messages.stream().map(Message::new).toArray(Message[]::new);

        RequestResult result = new RequestResult(true);
        result.setTotal(messageList.getTotalElements());
        result.setResult(arrMessage);

        return result;
    }


    @Override
    public ServiceResult<String, String[]> readMessage(ReadMessageForm readMessageForm) {

        LSMessage message = messageDao.getMessage(readMessageForm.getMessageNo());
        if (message.getUserNo().equals(readMessageForm.getUserNo())) {
            message.setState('Y');
            messageDao.save(message);

            return ServiceResult.BUILDER_Validate.createSuccessResult("OK");
        } else {

            return ServiceResult.BUILDER_Validate.createFailResult("您无权操作此数据");
        }

    }

    //查询全部消息列表
    @Override
    public RequestResult findMessage() {

        List<LSMessage> messages = messageDao.findByUserNoOrderByMakeDateDescAndMakeTimeDesc(CurrentUser.getUser().getUserId());
        return getRequestResult(messages);
    }

    @Value(value = "${com.code}")
    private String comCode;

    //根据消息集合封装返回结果
    private RequestResult getRequestResult(List<LSMessage> messages) {
        List<MessageForm> list = new ArrayList<MessageForm>();
        for (LSMessage message : messages) {
            //添加通知消息 太平独有需求
            if (messageEnable && comCode.equals("24002")) {
                //查询当前代理人处于整改中的单子
                String busiNum = message.getBusiNum();
                UserBasicInfo user = CurrentUser.getUser();
                LSCont cont = contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne(user.getComCode(), user.getComCode(), busiNum, 'Y');
                if (cont != null && cont.getInteractive().equals("L")) {
                    //获取质检时间
                    Date date = message.getMakeDate();
                    //获取毫秒 时间间距
                    Long spacing = System.currentTimeMillis() - date.getTime();
                    if (spacing >= 5 * 24 * 60 * 60 * 1000 && spacing <= 15 * 24 * 60 * 60 * 1000) {
                        MessageForm infor = new MessageForm();
                        infor.setContNo(message.getContNo());
                        infor.setBusiNum(busiNum);
                        infor.setMakeDate(sdf.format(message.getMakeDate()));
                        infor.setType("Notification");
                        infor.setTitle("通知");
                        infor.setMessage("您好，您投保单号为" + busiNum + "的保单双录质检不通过超过5天未整改，请及时处理。");
                        list.add(infor);
                    }
                }
            }
        }
        for (LSMessage message : messages) {
            MessageForm messageForm = new MessageForm();
            messageForm.setContNo(message.getContNo());
            //添加投保单号
            messageForm.setBusiNum(message.getBusiNum());
            messageForm.setTitle(message.getTitle());

            if (message.getType().equals("L")) {
                messageForm.setType("ExamineUpdate");
            } else if (message.getType().equals("S")) {
                messageForm.setType("ExamineTrue");
            } else if (message.getType().equals("R")) {
                messageForm.setType("ExamineFalse");
            }

            if (message.getType().equals("S")) {
                messageForm.setMessage("保单号为" + message.getBusiNum() + "：通过");
            }
            if (message.getType().equals("R")) {
                messageForm.setMessage("保单号为" + message.getBusiNum() + "：不通过。" + "\n" + message.getMessage() + "\n" + "请点击详情");
            }
            if (message.getType().equals("L")) {
                messageForm.setMessage("保单号为" + message.getBusiNum() + "：整改。" + "\n" + message.getMessage() + "\n" + "请点击详情");
            }

            messageForm.setMakeDate(sdf.format(message.getMakeDate()));
            logger.info("messageForm {}", messageForm);
            list.add(messageForm);
        }
        RequestResult result = new RequestResult(true);
        result.setResult(list);

        return result;
    }


    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    public RequestResult findByContNo(String contNo) {
        logger.info("message find by contNo {}", contNo);


        LSCont lsCont = contDao.findByClientContNoAndLastOne(contNo, 'Y');
        List<LSMessage> lsMessages =null;
        if(lsCont!=null && !StringUtils.isEmpty(lsCont.getContNo())){
            lsMessages=messageDao.findByContNo(lsCont.getContNo());
        }
        //List<LSMessage> lsMessages = messageDao.findByContNo(contNo);
        if (lsMessages == null || lsMessages.size() == 0 || lsCont == null) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessage("没有投保单信息");
            return requestResult;

        }
        List<MessageForm> list = new ArrayList<MessageForm>();
        for (LSMessage message : lsMessages) {

            MessageForm messageForm = new MessageForm();
            messageForm.setContNo(message.getContNo());
            //添加投保单号
            messageForm.setBusiNum(message.getBusiNum());
            messageForm.setTitle(message.getTitle());
            //返回投保单状态
            messageForm.setType(lsCont.getInteractive());
            if (message.getType().equals("S")) {
                messageForm.setMessage("保单号为" + message.getBusiNum() + "：通过");
            }
            if (message.getType().equals("L")) {
                messageForm.setMessage(message.getMessage());
            }
            if (message.getType().equals("R")) {
                messageForm.setMessage(message.getMessage());
            }
            messageForm.setMakeDate(sdf.format(message.getMakeDate()));
            list.add(messageForm);
        }
        RequestResult result = new RequestResult(true);
        result.setResult(list);
        // 添加 视频播放地址
        Hashtable<String, String> data = new Hashtable<>(1);
        LSVideo lsVideo = videoDao.findByContNo(lsCont.getContNo());
        if (lsVideo != null) {
            data.put("url", lsVideo.getURL());
        } else {
            data.put("url", "");
        }

        //添加业务类型
        String operation  = lsCont.getOperation();
        if (StringUtils.isEmpty(operation)){
            data.put("operation","I");
        }else {
            data.put("operation",operation);
        }

        result.setData(data);

        logger.info("message find by contNo {} requestResult {}", contNo, result);
        return result;
    }

    //分页参数  分页 行数
    @Value(value = "${self.pageSize}")
    private int pageSize;

    /**
     * @Author: weihao
     * @Date: 2018/1/31 11:15
     * @params: pageNo：分页参数 页号 sortTime：查询时间
     * @return: 返回消息分页列表 添加 消息总行数 添加通知消息（暂时太平上线）
     * 通知消息为 如果该代理人有质检时间超过五天 小于十五天的保单消息 则添加通知消息 通知代理人
     */
    //消息列表分页查询
    @Override
    public RequestResult findMessage(Integer pageNo, String sortTime) {
        //查分查询条件
        String[] times = sortTime.split(" ");
        //获取当前用户
        String userNo = CurrentUser.getUser().getUserId();
        logger.info("sortTime {} userNo {}", sortTime, userNo);
        //获取分页 条件
        String date = times[0];
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date makeDate = null;
        try {
            makeDate = new Date(sdf.parse(date).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Page<LSMessage> messages = messageDao.findByUserNo(userNo, makeDate, times[1], pageNo);
        List<LSMessage> list = messages.getContent();
        if (list == null || list.size() == 0) {
            return new RequestResult(true);
        }
        //修改 通知消息状态 只在第一页返回通知消息
        if (pageNo >= 1) {
            messageEnable = false;
        }
        //封装数据
        RequestResult requestResult = getRequestResult(list);
        //添加行数
        Long count = messageDao.countByUserNo(userNo);
        Hashtable<String, Long> data = new Hashtable<>();
        data.put("count", count);
        requestResult.setData(data);
        return requestResult;
    }
}
