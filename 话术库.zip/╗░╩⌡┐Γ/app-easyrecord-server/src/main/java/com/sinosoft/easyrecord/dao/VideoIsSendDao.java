package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.VideoIsSend;

public interface VideoIsSendDao {

    void insertOrUpdate(VideoIsSend videoIsSend);


    VideoIsSend findByCont(String contNo);
}
