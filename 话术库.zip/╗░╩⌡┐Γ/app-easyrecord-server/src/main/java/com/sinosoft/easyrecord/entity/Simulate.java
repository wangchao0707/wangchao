package com.sinosoft.easyrecord.entity;

import java.io.Serializable;
import java.util.HashMap;

import com.sinosoft.easyrecord.vo.AppntForm;
import com.sinosoft.easyrecord.vo.ContForm;
import com.sinosoft.easyrecord.vo.RegisterForm;

public class Simulate implements Serializable {
	private RegisterForm user;
	private ContForm cont;
	private String   jumpTermn;
	private String busiNum;
	public RegisterForm getUser() {
		return user;
	}
	public void setUser(RegisterForm user) {
		this.user = user;
	}
	public String getBusiNum() {
		return busiNum;
	}
	public void setBusiNum(String busiNum) {
		this.busiNum = busiNum;
	}
	public ContForm getCont() {
		return cont;
	}
	public void setCont(ContForm cont) {
		this.cont = cont;
	}
	public String getJumpTermn() {
		return jumpTermn;
	}
	public void setJumpTermn(String jumpTermn) {
		this.jumpTermn = jumpTermn;
	}
	
}
