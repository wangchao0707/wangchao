package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "LSHeadImg")
public class LSHeadImg implements Serializable {
    @Id
    @Column(name = "UserId")
    private String userId;
    @Column(name = "ImgPath")
    private String imgPath;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getImgPath() {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }

    public LSHeadImg() {
        super();
    }

    public LSHeadImg(String userId, String imgPath) {
        super();
        this.userId = userId;
        this.imgPath = imgPath;
    }


}
