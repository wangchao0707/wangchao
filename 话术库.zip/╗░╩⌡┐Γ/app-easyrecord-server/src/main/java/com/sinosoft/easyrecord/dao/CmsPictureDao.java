package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSCmsPicture;

import java.util.List;

/**
 * @author SunYu
 * @date 2019/3/8 18:38
 */
public interface CmsPictureDao {
    LSCmsPicture findByCmsId(String cmsId);

    List<LSCmsPicture> findByContNo(String contNo);

    void saveLSCmsPicture(LSCmsPicture lsCmsPicture);
}
