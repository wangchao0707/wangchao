package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;

public class TransbodyReq800011 implements Transbody, Serializable {

    public String TARGET;  //<!--手机号码-->
    public String MSGCONTENT; //短信内容-->

}
