package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.EsQcMain;

import java.util.Date;
import java.util.List;

public interface EsQcMainDao {

    EsQcMain findMinDateByBusinessNo(String businessNo);

    List<EsQcMain> findByBusinessNoOrderByInspectDate(String businessNo);

}
