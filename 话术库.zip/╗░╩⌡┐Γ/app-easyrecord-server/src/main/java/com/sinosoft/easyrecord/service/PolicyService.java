package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.almond.commons.transmit.vo.SelectItem;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.vo.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;


public interface PolicyService {

    ServiceResult<String, String[]> updateBusiNum(String operator, String clientContNo, String busiNum);

    List<SelectItem> findInsurCom(String comCode);

    ServiceResult<RiskForm[], String> showTypeName(QueryTypeForm queryTypeForm);

    ServiceResult<TalkForm[], String> showStepTalk(QueryTalkForm queryTalkForm);

    RequestResult showTalkRunTime(TalkRunTimeForm talkRunTimeForm);

    RequestResult savePolcy(PolcyForm polcyForm) throws ServiceResult.ServiceResultException;


    RequestResult saveUrlByQ(String contNo, String zipUrl);

    RequestResult uploadZip(MultipartFile zipFile, String contNo, String md5);

    RequestResult showState(StateForm stateForm);

    RequestResult showStateReject(StateForm stateForm);

    ServiceResult<PolcyForm, String[]> showPolicy(String contNo);

    RequestResult cosZip(String contNo, String zipUrl);

    List<LSCont> findAllCont();

    LSVideo findVideoByContNo(String contNo);

    LSPicture findByPicNameAndContNo(String picName, String contNo);

    List<LSPicture> findPictureByContNo(String contNo);

    LSAppnt findAppntByContNo(String contNo);

    LSInsured findInsuredByContNo(String contNo);

    void saveVideo(LSVideo lsVideo);

    void savePicture(LSPicture lsPicture);

    LSCont findContByClientContNoAndLastOne(String clientContNo);

    void saveCont(LSCont lsCont);

    List<LSCont> findByLastOneAndInteractive(char lastOne, String interactive);

    List<LSCont.LSContPK> queryPKByLastOneAndInteractive(char lastOne, String interactive);

    LSCont findByContNo(String contNo);

    RequestResult showMergeTalkRunTime(TalkRunTimeForm talkRunTimeForm);

    LSUser findUserByUserId(String userId);

    void saveUser(LSUser lsUser);

    //已上传列表获取
    RequestResult getPageUpload(int pageNo, String sortTime, String busiNum);

    //被驳回列表获取
    RequestResult getPageReject(int pageNo, String sortTime, String busiNum);

//    ServiceResult<RiskForm[], String> showProductTypeCode(QueryTypeForm queryTypeForm);

    //根据 产品编码获取 保险类型 和 产品类型
    RequestResult showProductTypeCode(Map reqMap);



    Map getHint(Map reqMap);

    Map getFileInfo();


    Map changeBusi(Map map);

    RequestResult generalBasicOce(BasicOCRForm basicOCRForm);

}
