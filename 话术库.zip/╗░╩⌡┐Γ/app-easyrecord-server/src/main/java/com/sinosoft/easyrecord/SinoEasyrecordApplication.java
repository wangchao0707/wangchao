package com.sinosoft.easyrecord;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.util.ResourceUtils;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.io.*;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Properties;

@SpringBootApplication(exclude = {
        DataSourceAutoConfiguration.class})
@EnableCaching
@EnableScheduling
public class SinoEasyrecordApplication extends WebMvcConfigurerAdapter {

    final private static Logger logger = LoggerFactory.getLogger(SinoEasyrecordApplication.class);

    @Value("${web.upload.path}")
    private String uploadPath;

    public static void main(String[] args) {
        try {
            initAjax2Xml();
        } catch (IOException e) {
            logger.error(e.getMessage(),e );
            throw new RuntimeException(e.getMessage(), e);
        }

        try {
            String basePath = new File(".").getCanonicalPath();

            // 对于windows 需要修正一下目录名
            if (!basePath.startsWith("/")) {
                basePath = "/" + basePath;
            }

            logger.info("base path: {}", basePath);
            System.setProperty("spring.app.home-path", basePath);

            String profile = basePath + "/app/datasource.properties";
            File proFile = new File(profile);
            if(proFile.exists()){
                Properties datasourceProps = new Properties();
                datasourceProps.load(new FileInputStream(proFile));
                Enumeration<?> keys = datasourceProps.propertyNames();
                while(keys.hasMoreElements()){
                    String key = (String) keys.nextElement();
                    String value = datasourceProps.getProperty(key);
                    //logger.info("add --- System.setProperty(key: {}, value: {})", key, value);
                    System.setProperty(key, value);
                }
            } else {
                logger.info("not found datasource config: {}", profile);
            }

            init();

        } catch (IOException ex) {
            logger.error(ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage(), ex);
        }


        SpringApplication.run(SinoEasyrecordApplication.class, args);
    }


    public static void initAjax2Xml() throws IOException {
        String basePath = new File(".").getCanonicalPath();
       logger.info("-----------当前jar 包所在的位置-"+basePath);
        String ajax2Directory="/appdata/tms"+"/resources/WEB-INF/services/ServerService/META-INF/";

        logger.info("-----------当前包所在的位置ajax2Directory-"+basePath);
        File fileDir=new File(ajax2Directory);
        if (!fileDir.exists()) {
            logger.info("-----------fileDir 不存在-"+ajax2Directory);
            fileDir.mkdirs();
        }
        File fileWrite=new File(ajax2Directory+"services.xml");
        if (!fileWrite.exists()) {
            try {
                logger.info("-----------ajax2Directory+services.xml 不存在-"+ajax2Directory+"services.xml");
                ClassPathResource classPathResource = new ClassPathResource("services/services.xml");
                InputStream is = classPathResource.getInputStream();
                OutputStream os = new FileOutputStream(fileWrite);
                int len = 8192;
                byte[] buffer = new byte[len];
                while ((len = is.read(buffer, 0, len)) != -1) {
                    os.write(buffer, 0, len);
                }
                os.close();
                is.close();

            } catch (IOException e) {
                logger.error("写文件报错"+e.getMessage());
                e.printStackTrace();
            }
        }
        logger.error("写文件成功");
    }
    /**
     *加上产品，机构，话术的访问地址
     * @param registry
     */

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        super.addResourceHandlers(registry);
        registry.addResourceHandler("/vue/**").addResourceLocations(
                "file:"+uploadPath);
        logger.info("自定义静态资源目录、此处功能用于文件映射");
    }
    private static void init() {

        try {
            InetAddress addr = getLocalHostLANAddress();
            String ip = addr.getHostAddress(); //获取本机ip
            String hostName = addr.getHostName(); //获取本机计算机名称
            System.out.println(ip);
            System.out.println(hostName);

            System.setProperty("sino-system.env.hostname", hostName);
            System.setProperty("sino-system.env.ip", ip);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

    }

    // 正确的IP拿法，即优先拿site-local地址
    private static InetAddress getLocalHostLANAddress() throws UnknownHostException {
        try {
            InetAddress candidateAddress = null;
            // 遍历所有的网络接口
            for (Enumeration ifaces = NetworkInterface.getNetworkInterfaces(); ifaces.hasMoreElements();) {
                NetworkInterface iface = (NetworkInterface) ifaces.nextElement();
                // 在所有的接口下再遍历IP
                for (Enumeration inetAddrs = iface.getInetAddresses(); inetAddrs.hasMoreElements();) {
                    InetAddress inetAddr = (InetAddress) inetAddrs.nextElement();
                    if (!inetAddr.isLoopbackAddress()) {// 排除loopback类型地址
                        if (inetAddr.isSiteLocalAddress()) {
                            // 如果是site-local地址，就是它了
                            return inetAddr;
                        } else if (candidateAddress == null) {
                            // site-local类型的地址未被发现，先记录候选地址
                            candidateAddress = inetAddr;
                        }
                    }
                }
            }
            if (candidateAddress != null) {
                return candidateAddress;
            }
            // 如果没有发现 non-loopback地址.只能用最次选的方案
            InetAddress jdkSuppliedAddress = InetAddress.getLocalHost();
            if (jdkSuppliedAddress == null) {
                throw new UnknownHostException("The JDK InetAddress.getLocalHost() method unexpectedly returned null.");
            }
            return jdkSuppliedAddress;
        } catch (Exception e) {
            UnknownHostException unknownHostException = new UnknownHostException(
                    "Failed to determine LAN address: " + e);
            unknownHostException.initCause(e);
            throw unknownHostException;
        }
    }
}
