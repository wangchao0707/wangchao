package com.sinosoft.easyrecord.server;

import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sinosoft.easyrecord.entity.LDCode.LDCodePk;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransBodyReq80008;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transbody;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyRes;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transdata;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transhead;
import com.thoughtworks.xstream.XStream;
/**
 * User: weihao
 * Date: 2018/5/14
 * Time: 17:49
 * 同步质检消息 和实时话术  已经废弃
 */
@Service
public class Req80008Impl implements Req80008 {

    private Logger logger = LoggerFactory.getLogger(Req80008Impl.class);

    private MessageDao messageDao;

    @Autowired
    public void setMessageDao(MessageDao messageDao) {
        this.messageDao = messageDao;
    }

    private CodeDao codeDao;

    @Autowired
    public void setCodeDao(CodeDao codeDao) {
        this.codeDao = codeDao;
    }

    private ContDao contDao;

    @Autowired
    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }

    private MessageBukDao messageBukDao;

    @Autowired
    public void setMessageBukDao(MessageBukDao messageBukDao) {
        this.messageBukDao = messageBukDao;
    }

    private TalkRunTimeDao talkRunTimeDao;

    @Autowired
    public void setTalkRunTimeDao(TalkRunTimeDao talkRunTimeDao) {
        this.talkRunTimeDao = talkRunTimeDao;
    }

    @Autowired
    private TalkNewDao talkDao;

    @Value("${save.filePath}")
    private String filePath;

    @Override
    public String getReq80008(String xml) {
        logger.info("req80008 start");
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransBodyReq80008.class);
        xs1.alias("QCFEEDBACKS", TransBodyReq80008.QCFEEDBACKS.class);
        xs1.alias("QCQUESTIONS", TransBodyReq80008.QCQUESTIONS.class);
        xs1.alias("QCFEEDBACK", TransBodyReq80008.QCFEEDBACK.class);
        xs1.alias("QCPOINTS", TransBodyReq80008.QCPOINTS.class);
        xs1.alias("VERBAL", TransBodyReq80008.VERBAL.class);
        xs1.addImplicitCollection(TransBodyReq80008.QCQUESTIONS.class, "QCFEEDBACK");
        xs1.addImplicitCollection(TransBodyReq80008.QCPOINTS.class, "VERBAL");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        TransBodyReq80008 body = (TransBodyReq80008) tmp.getTransbody();
        Transhead head = tmp.getTranshead();
        TransBodyReq80008.QCFEEDBACKS QCFEEDBACKS = body.getQCFEEDBACKS();
        // 获取基本信息
        String contNo = QCFEEDBACKS.BUSINESSNO;
        String userId = QCFEEDBACKS.AGENTID;
        String qcoperator = QCFEEDBACKS.QCOPERATOR;
        String busiNum = QCFEEDBACKS.DOCCODE;
        String updateTime = QCFEEDBACKS.QCRECORDCOUNT;
        String comCode = head.getCOMPANY();
        String ISFLAG = QCFEEDBACKS.ISFLAG;
        // String comCode = head.getCOMPANY();


        // 删除mp3文件
        // 删除文件
        String path = filePath + "/" + contNo;
        File dir = new File(path);
        if (dir.exists()) {
            File[] fileList = dir.listFiles();
            for (File file : fileList) {
                String ext = FilenameUtils.getExtension(file.getName());
                if (ext.equals("mp3")) {
                    Boolean boolean1 = file.delete();
                    logger.info("core success file delete result {}", boolean1);
                }

            }
        }
        List<TransBodyReq80008.QCFEEDBACK> list = QCFEEDBACKS.QCQUESTIONS.QCFEEDBACK;
        // 备份 删除
        // 根据业务流水号查询 保单 clientcontNo
        LSCont lsCont = contDao.findByContNo(contNo);
        if (lsCont.getOrginContNo() != null) {
            LSCont lastCont = contDao.findByContNo(lsCont.getOrginContNo());
            if (lastCont != null) {
                List<LSMessage> lsMessages = messageDao.findByContNo(lastCont.getClientContNo());

                if (lsMessages != null && lsMessages.size() != 0) {
                    logger.info("messagebak start");
                    for (LSMessage lsMessage : lsMessages) {
                        LSMessageBuk lsMessageBuk = new LSMessageBuk(UUID.randomUUID().toString(), lsMessage,
                                new Date(System.currentTimeMillis()), sdf.format(new java.util.Date()));
                        messageBukDao.save(lsMessageBuk);
                        messageDao.del(lsMessage);
                    }
                }
            }
        }
        // 获取质检结果
        // 根据字典表 查询类型

        LDCode ldCode = codeDao.findByCode(new LDCodePk("message_type", ISFLAG));
        String riskType = ldCode.getCodeRiskType();

        for (TransBodyReq80008.QCFEEDBACK back : list) {

            LSMessage lsMessage2 = new LSMessage();
            lsMessage2.setMessageNo(UUID.randomUUID().toString());
            lsMessage2.setUserNo(userId);
            lsMessage2.setTitle(back.ISSUETYPES);

            lsMessage2.setType(riskType);
            // 修改 保单 状态
            if (lsCont != null) {
                lsMessage2.setContNo(lsCont.getClientContNo());
                lsCont.setInteractive(ldCode.getCodeRiskType());
                contDao.save(lsCont);
            } else {
                lsMessage2.setContNo("");
            }

            lsMessage2.setMessage(back.ISSUEDESC);

            lsMessage2.setBusiNum(busiNum);
            lsMessage2.setOcopertor(qcoperator);
            lsMessage2.setMakeDate(new Date(System.currentTimeMillis()));
            lsMessage2.setMakeTime(sdf.format(new java.util.Date()));
            lsMessage2.setIssueDate(back.ISSUEDATE);
            lsMessage2.setSource("core");
            lsMessage2.setState('N');
            messageDao.save(lsMessage2);
        }

        String VERBALCOUNT = QCFEEDBACKS.QCPOINTS.VERBALCOUNT;
        if (!VERBALCOUNT.equals("0")) {
            List<TransBodyReq80008.VERBAL> verbals = QCFEEDBACKS.QCPOINTS.VERBAL;
            // 保存 实时 话述
            for (TransBodyReq80008.VERBAL verbal : verbals) {
                LSTalkRunTime lsTalkRunTime = new LSTalkRunTime();
                lsTalkRunTime.setId(UUID.randomUUID().toString());
                lsTalkRunTime.setBusiNum(busiNum);
                lsTalkRunTime.setComCode(comCode);
                lsTalkRunTime.setInsurComCode(verbal.COMPANY);
                lsTalkRunTime.setOperator(userId);
                lsTalkRunTime.setOrderNum(Integer.parseInt(verbal.ORDERNO));
                lsTalkRunTime.setOrgCode(verbal.COMCODE);
                lsTalkRunTime.setPkId(verbal.DESCRIBEID);
                lsTalkRunTime.setRiskType(verbal.RISKTYPECODE);
                lsTalkRunTime.setStep(verbal.QCPOINT);
                lsTalkRunTime.setTaleConent(verbal.QCTRICK);
                lsTalkRunTime.setUpdateTime(updateTime);
                lsTalkRunTime.setIsFlag(riskType);
                LSTalkNew lsTalk=talkDao.findOneByPkId(verbal.DESCRIBEID);
                if(lsTalk!=null){
                    lsTalkRunTime.setIsRead(lsTalk.getIsRead());
                }
                talkRunTimeDao.saveTalkRunTime(lsTalkRunTime);

            }
        }
        // 返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

}
