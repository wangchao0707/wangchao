package com.sinosoft.easyrecord.dao;

import java.util.List;

import com.sinosoft.easyrecord.entity.LsContState;

public interface ContStateDao {

    void save(LsContState lsContState);

    LsContState getContState(String contNo);

}
