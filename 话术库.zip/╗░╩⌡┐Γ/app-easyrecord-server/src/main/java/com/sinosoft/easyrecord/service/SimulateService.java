package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.vo.LoginForm;
import com.sinosoft.easyrecord.vo.RegisterForm;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
/**
 * Created by WinterLee on 2018/5/14
 */
public interface SimulateService {



    /**
     * 调整三大块页面
     * @return
     */
    RequestResult doKinescope(JSONObject jsonObject, String ot);

    /**
     * 跳转 待上传页面
     * @return
     */
    RequestResult  doWarrantyStatu(String data);

    /**
     * 跳转 保单详情 页面
     * @return
     */
    RequestResult  doWarrantyDetail(String data);

    RequestResult newLoginOrRegist(String data);
}
