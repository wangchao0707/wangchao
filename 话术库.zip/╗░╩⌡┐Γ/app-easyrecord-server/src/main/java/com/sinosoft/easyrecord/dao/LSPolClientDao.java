package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LspolClient;

public interface LSPolClientDao {

    public LspolClient findLspolClientByContnoAndRiskcode(String Contno, String Riskcode);
}
