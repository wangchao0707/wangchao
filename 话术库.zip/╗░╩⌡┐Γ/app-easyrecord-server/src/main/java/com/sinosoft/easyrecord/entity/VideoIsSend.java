package com.sinosoft.easyrecord.entity;


import javax.persistence.*;

@Entity
@Table(name = "videoissend")
public class VideoIsSend {



    @Id
    @Column(name="id")
    int id;

    @Column(name="contno")
    String contNo;//流水号

    @Column(name = "businum")
    String busiNum;//保单号

    @Column(name = "videoissend")
    char videoIsSend;

    @Column(name = "batchno")
    String batchNo;

    @Column(name = "errormessage")
    String errorMessage;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public char getVideoIsSend() {
        return videoIsSend;
    }

    public void setVideoIsSend(char videoIsSend) {
        this.videoIsSend = videoIsSend;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    @Override
    public String toString() {
        return "VideoIsSend{" +
                "id=" + id +
                ", contNo='" + contNo + '\'' +
                ", busiNum='" + busiNum + '\'' +
                ", videoIsSend=" + videoIsSend +
                ", batchNo='" + batchNo + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}
