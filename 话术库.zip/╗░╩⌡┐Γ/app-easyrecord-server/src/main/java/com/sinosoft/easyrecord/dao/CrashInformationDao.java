package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSCrashInformation;

public interface CrashInformationDao {
    void save(LSCrashInformation crashInformation);

}
