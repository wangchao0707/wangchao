package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSBusiNumChangesRepository;
import com.sinosoft.easyrecord.entity.LSBusiNumChanges;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by wh on 2018/1/5.
 */
@Component
public class BusiNumChangesDaoImpl4JPA implements BusiNumChangesDao {

    @Autowired
    private LSBusiNumChangesRepository busiNumChangesRepository;

    public void setBusiNumChangesRepository(LSBusiNumChangesRepository busiNumChangesRepository) {
        this.busiNumChangesRepository = busiNumChangesRepository;
    }

    @Override
    public void saveBusiNumChange(LSBusiNumChanges lsBusiNumChanges) {
        busiNumChangesRepository.save(lsBusiNumChanges);
    }
}
