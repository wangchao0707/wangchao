package com.sinosoft.easyrecord.util;

import org.springframework.stereotype.Component;

/**
 * User: weihao
 * Date: 2018/5/17
 * Time: 9:53
 * 遮掩 手机号 和 身份证号
 */

public class ShowStarUtils {
    public static String showPhoneStar(String phoneNo) {

        String phonem = phoneNo.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
        System.out.println(phonem);
        return phonem;
    }

    public static String showIdStar(String idNo) {
        String idNom = idNo.replaceAll("(\\d{4})\\d{10}(\\d{4})", "$1**********$2");
        System.out.println(idNom);
        return idNom;
    }

//    public static void main(String args[]) {
//        showPhoneStar("18771632488");
//        showIdStar("421302199208165464");
//    }
}
