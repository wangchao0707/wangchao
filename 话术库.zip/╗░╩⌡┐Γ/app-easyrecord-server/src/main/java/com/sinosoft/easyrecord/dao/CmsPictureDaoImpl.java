package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSCmsPictureRepository;
import com.sinosoft.easyrecord.entity.LSCmsPicture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author SunYu
 * @date 2019/3/8 18:39
 */
@Component
public class CmsPictureDaoImpl implements CmsPictureDao {

    @Autowired
    private LSCmsPictureRepository cmsPictureRepository;

    @Override
    public LSCmsPicture findByCmsId(String cmsId) {
        return cmsPictureRepository.findByCmsId(cmsId);
    }

    @Override
    public List<LSCmsPicture> findByContNo(String contNo) {
        return cmsPictureRepository.findByContNo(contNo);
    }

    @Override
    public void saveLSCmsPicture(LSCmsPicture lsCmsPicture) {
        cmsPictureRepository.saveAndFlush(lsCmsPicture);
    }
}
