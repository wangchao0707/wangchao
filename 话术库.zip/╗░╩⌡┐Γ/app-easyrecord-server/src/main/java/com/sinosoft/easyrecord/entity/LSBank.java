package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: weihao
 * Date: 2018-03-16
 * Time: 21:26
 */
@Entity
@Table(name = "LSBank")
public class LSBank {

    @Id
    @Column(name = "BankCode")
    private String bankCode;
    @Column(name = "BankName")
    private String bankName;
    @Column(name = "BankInitials")
    private String bankInitials;
    @Column(name = "BankCompleteSpelling")
    private String bankCompleteSpelling;

    public String getBankCompleteSpelling() {
        return bankCompleteSpelling;
    }

    public void setBankCompleteSpelling(String bankCompleteSpelling) {
        this.bankCompleteSpelling = bankCompleteSpelling;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankInitials() {
        return bankInitials;
    }

    public void setBankInitials(String bankInitials) {
        this.bankInitials = bankInitials;
    }

    @Override
    public String toString() {
        return "LSBank{" +
                "bankCode='" + bankCode + '\'' +
                ", bankName='" + bankName + '\'' +
                ", bankInitials='" + bankInitials + '\'' +
                ", bankCompleteSpelling='" + bankCompleteSpelling + '\'' +
                '}';
    }
}
