package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSOrganizationBackups;

/**
 * Created by LJW on 2017/8/9.
 */
public interface OrganizationBackupsDao {


    void save(LSOrganizationBackups backups);


}


