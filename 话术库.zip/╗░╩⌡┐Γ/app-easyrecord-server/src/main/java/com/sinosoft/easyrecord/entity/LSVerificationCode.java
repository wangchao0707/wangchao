package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSVerificationCode")
public class LSVerificationCode {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "VerificationCode")
    private String verificationCode;
    @Column(name = "VerificationTime")
    private String verificationTime;
    @Column(name = "PhoneNum")
    private String phoneNum;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public String getVerificationTime() {
        return verificationTime;
    }

    public void setVerificationTime(String verificationTime) {
        this.verificationTime = verificationTime;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    @Override
    public String toString() {
        return "LSVerificationCode{" +
                "id='" + id + '\'' +
                ", verificationCode='" + verificationCode + '\'' +
                ", verificationTime='" + verificationTime + '\'' +
                ", phoneNum='" + phoneNum + '\'' +
                '}';
    }
}
