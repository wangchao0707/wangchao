package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSDeviceInfor;

public interface DeviceInforDao {

    void saveDeviceInfor(LSDeviceInfor lsDeviceInfor);
}
