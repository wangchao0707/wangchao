package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.LDComConfig;
import com.sinosoft.easyrecord.service.NewTalkService;
import com.sinosoft.easyrecord.service.PolicyService;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



@Component
public class CoreInteractiveFactoryImpl implements CoreInteractiveFactory {

    private static final Logger logger = LoggerFactory.getLogger(CoreInteractiveFactoryImpl.class);

//    @Value("${self.baseUrl}/process/getScreen")
//    private String screenUrl;
//    @Value("${self.baseUrl}/process/picture")
//    private String picUrl;
//    @Value("${self.baseUrl}/process/videoToMp3")
//    private String videoToMp3Url;
//    @Value("${self.baseUrl}/process/video")
//    private String videoUrl;
//    @Value("${self.baseUrl}/process/MP3")
//    private String mp3Url;
    @Value("${self.baseUrl}/process/screenshoot")
    private String screenShotUrl;
    @Value("${self.baseUrl}/process/downloadZip")
    private String downloadZip;
    @Value("${self.baseUrl}/process/submitPolicy")
    private String submitPolicyUrl;
    @Value("${self.baseUrl}/process/updateVideo")
    private String updateVideoUrl;

//    @Value("${self.picTime}")
//    private long picTime;
//    @Value("${self.videoTime}")
//    private long videoTime;
//    @Value("${self.videoToMp3Time}")
//    private long videoToMp3Time;
//    @Value("${self.mp3Time}")
//    private long mp3Time;
    @Value("${self.downloadTime}")
    private long downloadTime;
    @Value("${self.screenShotTime}")
    private long screenShotTime;

    @Value("${save.filePath}")
    private String filePath;
    @Value("${save.zipPath}")
    private String zipPath;
    @Autowired
    private ComConfigDao comConfigDao;

    @Autowired
    private ContStateDao contStateDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private LSStateLocaDao lsStateLocaDao;

    @Autowired
    private AuthenticationDao authen;

    @Autowired
    private PolicyService policyService;

    @Autowired
    private ContTimeDao contTimeDao;

    @Autowired
    private OrganizationDao organizationDao;


    @Autowired
    private MessageDao messageDao;


    @Autowired
    private ContDao contDao;

    @Autowired
    private ReplaceTalkDao replaceTalkDao;

    @Autowired
    private TalkContentDao contentDao;

    @Autowired
    private NewTalkService newTalkService;

    @Autowired
    private BankDao bankDao;

    @Autowired
    private LSComDao lscomDao;

    public CoreInteractive getInstance(String comCode) {

        LDComConfig comConfig = comConfigDao.findByComCode(comCode);
        if (comConfig == null) {
            String message = "not found config, comcode=" + comCode;
            RuntimeException ex = new RuntimeException(message);
            logger.error(ex.getMessage(), ex);
            throw ex;
        }
        CoreInteractiveImpl coreInteractive = new CoreInteractiveImpl(comConfig);
        coreInteractive.setAuthen(authen);
        coreInteractive.setContTimeDao(contTimeDao);
        coreInteractive.setPolicyService(policyService);
        coreInteractive.setNewTalkService(newTalkService);
        coreInteractive.setBankDao(bankDao);
        coreInteractive.setUserDao(userDao);
        coreInteractive.setLsComDao(lscomDao);
        coreInteractive.setContStateDao(contStateDao);
        coreInteractive.setContDao(contDao);
//        coreInteractive.setPicTime(picTime);
//        coreInteractive.setPicUrl(picUrl);
//        coreInteractive.setMp3Time(mp3Time);
//        coreInteractive.setMp3Url(mp3Url);
//        coreInteractive.setVideoTime(videoTime);
//        coreInteractive.setVideoUrl(videoUrl);
//        coreInteractive.setVideoToMp3Time(videoToMp3Time);
//        coreInteractive.setVideoToMp3Url(videoToMp3Url);
        coreInteractive.setDownloadZip(downloadZip);
        coreInteractive.setDownloadTime(downloadTime);
        coreInteractive.setScreenShotTime(screenShotTime);
        coreInteractive.setScreenShotUrl(screenShotUrl);
        coreInteractive.setOrganizationDao(organizationDao);
        coreInteractive.setMessageDao(messageDao);
        coreInteractive.setFilePath(filePath);
        coreInteractive.setZipPath(zipPath);
        coreInteractive.setSubmitPolicyUrl(submitPolicyUrl);
        coreInteractive.setLsStateLocaDao(lsStateLocaDao);
        coreInteractive.setReplaceTalkDao(replaceTalkDao);
        coreInteractive.setTalkContentDao(contentDao);
//        coreInteractive.setScreenUrl(screenUrl);
        coreInteractive.setUpdateVideoUrl(updateVideoUrl);
        return coreInteractive;

    }

}
