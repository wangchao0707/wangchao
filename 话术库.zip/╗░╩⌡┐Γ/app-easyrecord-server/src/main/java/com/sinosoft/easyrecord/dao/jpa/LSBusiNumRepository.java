package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSBusiNum;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LSBusiNumRepository extends JpaRepository<LSBusiNum, String> {

    List<LSBusiNum> findByBusiNumIn(String[] busiNumArrs);

}
