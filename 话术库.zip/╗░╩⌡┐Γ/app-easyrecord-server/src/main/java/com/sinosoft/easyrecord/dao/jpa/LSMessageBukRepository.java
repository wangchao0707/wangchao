package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSMessageBuk;

public interface LSMessageBukRepository extends JpaRepository<LSMessageBuk, String> {

}
