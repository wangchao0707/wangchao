package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSHeadImg;

public interface HeadImgDao {

    LSHeadImg getHeadImg(String userId);

    void saveHeadImg(LSHeadImg lsHeadImg);
}
