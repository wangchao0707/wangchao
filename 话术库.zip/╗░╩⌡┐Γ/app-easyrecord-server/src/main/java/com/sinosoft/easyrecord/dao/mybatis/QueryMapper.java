package com.sinosoft.easyrecord.dao.mybatis;

import com.sinosoft.easyrecord.vo.QueryOrgForm;
import com.sinosoft.easyrecord.vo.ShowStateVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface QueryMapper {

    List<QueryOrgForm> selectQueryStatus(List<String> list);

    List<String> isExit(List<String> list);

    ShowStateVo selectForStateByContNo(String contNo);

    List<String> selectProductNameByCode(List<String> listRisk);
}
