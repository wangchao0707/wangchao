package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.util.MapToXml;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
@Component
public class OrganizeRequestXml {
    /**
     * 组织Transaction_Header中数据
     * @param map 传入数据map
     * @return
     */
    private Map<String,Object> organizeHeader_basemsg(Map map){
        Map<String,Object> header_basemsg = new HashMap<String,Object>();
        DateFormat dateFormat = new SimpleDateFormat("YYYYMMDD-HHmmss");
        String s = dateFormat.format(new Date());
       /* if(map == null){
            //测试数据
            header_basemsg.put("PlatCode","easyrecord");
            header_basemsg.put("PlatSeqNo", UUID.randomUUID().toString());
            header_basemsg.put("PartnerCode","easyrecord");
            header_basemsg.put("PartnerName","双录");
            header_basemsg.put("RequestCode","QuaCheck");
            header_basemsg.put("ChannelCode","");
            header_basemsg.put("BranchCode","0000242171");
            header_basemsg.put("SalesTerminal","");
            header_basemsg.put("AgentCode","0000242171");
            header_basemsg.put("AgentName","潘小丽");
            header_basemsg.put("RequestDate",s.split("-")[0]);
            header_basemsg.put("RequestTime",s.split("-")[1]);
        }else{*/
            header_basemsg.put("PlatCode",map.get("PlatCode"));
            header_basemsg.put("PlatSeqNo",map.get("sign")+"-"+UUID.randomUUID().toString());
            header_basemsg.put("PartnerCode",map.get("PartnerCode"));
            header_basemsg.put("PartnerName",map.get("PartnerName"));
            header_basemsg.put("RequestCode",map.get("RequestCode"));
            header_basemsg.put("ChannelCode",map.get("ChannelCode"));
            header_basemsg.put("BranchCode",map.get("BranchCode"));
            header_basemsg.put("SalesTerminal","");
            header_basemsg.put("AgentCode",map.get("AgentCode"));
            header_basemsg.put("AgentName",map.get("AgentName"));
            header_basemsg.put("RequestDate",s.split("-")[0]);
            header_basemsg.put("RequestTime",s.split("-")[1]);
//        }
        return header_basemsg;
    }

    /**
     * 组织Transaction_Body中数据
     * @param map 传入数据map
     * @return
     */
    private Map<String,Object> organizeBody_basemsg(Map map){
        Map<String,Object> body_basemsg = new HashMap<String,Object>();
        if(map == null){
            body_basemsg.put("UniqueNo","123458");
        }else{
            body_basemsg.put("UniqueNo",/*map.get("UniqueNo")*/map.get("UniqueNo"));
        }
        return body_basemsg;
    }

    /**
     * 将Transaction_Header数据组织完整
     * @param map
     * @return
     */
    private Map<String,Object> organizeHeader(Map map){
        Map<String,Object> header = new HashMap<String, Object>();
        header.put("Transaction_Header",organizeHeader_basemsg(map));
        return header;
    }

    /**
     * 组织资质校验完整数据
     * @return
     */
    public String organizeQualificationCheck(Map map,String encode){
        return transMapToXml(organizeHeader(map),encode);
    }

    /**
     *
     * @param map 传入数据map
     * @return
     */
    public String organizeInformationAcquisition(Map map,String encode){
        Map<String,Object> infomationAcquisitionMap = new HashMap<String,Object>();
        infomationAcquisitionMap.put("Transaction_Header",organizeHeader_basemsg(map));
        infomationAcquisitionMap.put("Transaction_Body",organizeBody_basemsg(map));
        return transMapToXml(infomationAcquisitionMap,encode);
    }

    private String transMapToXml(Map map,String encode){
        MapToXml mapToXml = new MapToXml();
        mapToXml.put("Transaction",map);
        return mapToXml.toXml(encode);
    }


    /**=================================组织短信接口数据=======================*/

    /**
     * 组织MessageDetail节点数据
     * @param map
     * @return
     */
    private Map<String,Object> organizeMessageDetail(Map map){
        Map<String,Object> messageDetailMap = new HashMap<String,Object>();
        messageDetailMap.put("smsType",map.get("smsType"));
        messageDetailMap.put("phone_no",map.get("phone_no"));
        messageDetailMap.put("smsContent",map.get("smsContent"));
        return messageDetailMap;
    }

    /**
     * 组织query节点数据
     * @param map
     * @return
     */
    private Map<String,Object> organizeQuery(Map map){
        Map<String,Object> queryMap = new HashMap<String,Object>();
        queryMap.put("systemCode","ESALES");
        queryMap.put("userName","ESALES");
        queryMap.put("password","ESALES");
        queryMap.put("MessageDetail",organizeMessageDetail(map));
        return queryMap;
    }

    /**
     * 组织system节点数据
     * @return
     */
    private Map<String,Object> organizeSystem(){
        Map<String,Object> systemMap = new HashMap<String, Object>();
        systemMap.put("sysid","APP_SMS_001");
        systemMap.put("uid","SMS001");
        systemMap.put("servicename","AEGON_WS_SMS_001");
        return systemMap;
    }

    /**
     * 组织短信接口完整数据
     * @param map
     * @return
     */
    private Map<String,Object> organizeHoleMessage(Map map){
        Map<String,Object> temp = new HashMap<String, Object>();
        temp.put("system",organizeSystem());
        temp.put("query",organizeQuery(map));
        return temp;
    }

    public String organizeMessageRequestXML(Map map,String encode){
        MapToXml mapToXml = new MapToXml();
        mapToXml.put("request",organizeHoleMessage(map));
        return mapToXml.toXml(encode);
    }
}
