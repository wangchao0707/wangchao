package com.sinosoft.easyrecord.controller;

import com.google.gson.Gson;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//import com.sinosoft.easyrecord.service.CmsService;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.server.CoreInteractiveFactory;
import com.sinosoft.easyrecord.service.OkhttpService;
import com.sinosoft.easyrecord.service.PolicyService;
/*import com.sinosoft.easyrecord.service.VideoUpload;*/
import com.sinosoft.easyrecord.stroage.service.QCloudService;
import com.sinosoft.easyrecord.util.*;
//import com.yuancore.cms.client.exception.CMSException;
import org.apache.commons.io.FilenameUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/process")
public class UploadController implements InitializingBean {
    private static final Logger logger = LoggerFactory.getLogger(UploadController.class);

    @Autowired
    private QCloudService cloudService;


  /*  @Autowired
    private VideoUpload.VideoUploadFactory videoUploadFactory;
*/
    @Autowired
    private PolicyService policyService;

    @Autowired
    private OkhttpService okhttpService;

    @Autowired
    private ContStateDao contStateDao;

    @Autowired
    private ContTimeDao contTimeDao;

    @Autowired
    private PictureDao pictureDao;

    @Autowired
    private MessageDao messageDao;

    @Autowired
    private CoreInteractiveFactory coreInteractiveFactory;
//    @Autowired
//    private CmsService cmsService;

    @Autowired
    private VideoDao videoDao;
    @Autowired
    private UserDao userDao;

//    @Value("${cms.resBucket}")
//    private String resBucket;  //抽帧+分片桶

    private SimpleDateFormat contSdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

    @Value("${save.filePath}")
    private String filePath;
    @Value("${save.zipPath}")
    private String zipPath;


//    @Value("${cms.notifyUrl}")
//    private String notifyUrl;
    @Value("${cms.outernet}")
    private String outerNet;

//    public enum VideoTransCodingStatusEnum {
//        TRANS_CODING, NO_TRANS_CODING
//    }

//    /**
//     * @param
//     * @return boolean
//     * 超时，主动去获取索引数据
//     * @Author SunYu
//     * @Date 11:38 2019/4/8
//     **/
//    @RequestMapping(value = "/updateVideo")
//    @Transactional
//    public boolean updateVideo(@RequestParam String contNo) {
//        LSContTime lsContTime = contTimeDao.findContTime(contNo);
//        LSVideo lsVideo = policyService.findVideoByContNo(contNo);
//        String cmsId = lsVideo.getCloudFileId();
//        logger.info("updateVideo cmsId :{}", cmsId);
//        try {
//            Map map = cmsService.getIndex(cmsId);
//            logger.info("updateVideo index : {}", map);
//            String status = map.get("isbs_transcoding_status").toString();
//            //如果转码结束，更新
//            if ("TRANS_CODING_FINISHED".equals(status)) {
//                LSCont lsCont = policyService.findByContNo(contNo);
//                LsContState lsContState = contStateDao.getContState(contNo);
//                if (lsContState == null) {
//                    logger.warn("lsContState == null  break");
//                    throw new RuntimeException();
//                }
//                if (!"H".equals(lsContState.getVideoState())) {
//                    logger.warn("!\"H\".equals(lsContState.getVideoState())  break \n {}", lsCont);
//                    throw new RuntimeException();
//                }
//                if (!"H".equals(lsContState.getScreenShotState())) {
//                    logger.warn("!\"H\".equals(lsContState.getScreenShotState())  break \n {}", lsCont);
//                    throw new RuntimeException();
//                }
//                lsContState.setVideoState("D");
//                lsContState.setScreenShotState("D");
//                contStateDao.save(lsContState);
//                lsCont.setInteractive("F");
//                policyService.saveCont(lsCont);
//            }
//
//        } catch (Exception e) {
//            logger.info(contNo + "getIndex failed: {}", e);
//        }
//        if (null == lsContTime.getCnt() || "".equals(lsContTime.getCnt())) {
//            lsContTime.setCnt(1);
//        } else {
//            lsContTime.setCnt(2);
//        }
//        lsContTime.setVideoBeginTime(contSdf.format(new java.util.Date()));
//        contTimeDao.saveContTime(lsContTime);
//        return true;
//
//    }

//    /**
//     * @param contNo
//     * @return boolean
//     * 获取抽帧图片的外链地址
//     * @Author SunYu
//     * @Date 17:13 2019/3/14
//     **/
//    @RequestMapping(value = "/getScreen")
//    @Transactional
//    public boolean getScreen(@RequestParam String contNo) {
//        LSCont lsCont = policyService.findByContNo(contNo);
//        LsContState lsContState = contStateDao.getContState(contNo);
//        LSVideo lsVideo = policyService.findVideoByContNo(contNo);
//        if (lsCont == null || lsContState == null || lsVideo == null) {
//            logger.warn("lsCont == null || lsContState == null || lsVideo == null break");
//            return false;
//        }
//
//        if (!"F".equals(lsCont.getInteractive())) {
//            logger.warn("!\"F\".equals(lsCont.getInteractive())  break \n {}", lsCont);
//            return false;
//        }
//
//        if (!"D".equals(lsContState.getScreenShotState())) {
//            logger.warn("!\"D\".equals(lsContState.getScreenShotState())  break \n {}", lsContState);
//            return false;
//        }
//        lsContState.setScreenShotTime(System.currentTimeMillis());
//        contStateDao.save(lsContState);
////        Thread thread = new Thread(){
////            @Override
////            public void run() {
//                //获取内容云的 objectId
//                String cmsId = lsVideo.getCloudFileId();
//                List<LSPicture> pictures = pictureDao.findByContNoAndBusiType(contNo, "ScreenShoot");
//                if (pictures != null && !pictures.isEmpty()) {
//                    for (LSPicture picture : pictures) {
//                        //获取抽帧图片的id
//                        String objectId = cmsId + "_" + picture.getTimeNode().split("\\.")[0] + ".jpeg";
//                        String screenShotUrl = cmsService.getPicture(objectId, "1", 3);
//                        if (StringUtils.isEmpty(screenShotUrl)) {
//                            logger.info("get screenShot url failed, contno = {}", contNo);
//                            picture.setURL("");
//                        }else {
//                            picture.setURL(outerNet + screenShotUrl);
//                        }
//                        pictureDao.save(picture);
//                    }
//                }
//                lsContState.setScreenShotState("F");
//                LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
//                java.util.Date date = new java.util.Date();
//                lsContTime.setScreenShotEndTime(contSdf.format(date));
//                contTimeDao.saveContTime(lsContTime);
////            }
////        };
////        thread.start();
//        return true;
//    }

    /**
     * //@param map 根据cms返回的contno更新状态
     * @return void
     * @Author SunYu
     * @Date 16:12 2019/3/14
     **/
    @RequestMapping(value = "/cmsCallBack")
    @Transactional
    public void cmsCallBack(@RequestParam(value = "CONT_NO")String contNo/*@RequestBody Map map*/,
                            @RequestParam(value = "map")String json) {
        logger.info("cms callBack map : {}", contNo);
        Map map = com.alibaba.fastjson.JSONObject.parseObject(json,Map.class);
        //String objectId = (String) map.get("objectId");
        //String contNo = (String) map.get("contNo");
        //获得回调，更新contstate状态
        String videoFilePath = (String)map.get("videoFilePath");// 转码后视频路径
        videoFilePath = outerNet +"accessPath" +File.separator +videoFilePath;
        String m3u8FilePath = (String) map.get("m3u8FilePath");// 切片后m3u8路径
        m3u8FilePath = outerNet +"accessVideo" + File.separator + m3u8FilePath;
        String sourcesDir = (String) map.get("sourcesDir");// 流媒体解压缩后文件路径
        sourcesDir = outerNet +"accessPath"+ File.separator + sourcesDir;
        Map<String,String> drawFrame = (Map<String, String>) map.get("DrawFrame");
        LSCont lsCont = policyService.findByContNo(contNo);
        LsContState lsContState = contStateDao.getContState(contNo);
        LSVideo lsVideo = videoDao.findByContNo(contNo);
        List<LSPicture> lsPicture = pictureDao.findByContNo(contNo);

        if (lsCont == null || lsContState == null) {
            logger.warn("lsCont == null || lsContState == null  break");
            throw new RuntimeException();
        }
       /* if (!"H".equals(lsContState.getVideoState())) {
            logger.warn("!\"H\".equals(lsContState.getVideoState())  break \n {} \n {}", lsCont, lsContState);
            throw new RuntimeException();
        }*/
        if (!"H".equals(lsContState.getScreenShotState())) {
            logger.warn("!\"H\".equals(lsContState.getScreenShotState())  break \n {} \n {}", lsCont, lsContState);
            throw new RuntimeException();
        }
//        LSVideo lsVideo = policyService.findVideoByContNo(contNo);
//        String cmsId = lsVideo.getCloudFileId();
//        if(!objectId.equals(cmsId)){
//            logger.info("! objectId .equals cmsId, objectId : {}, cmsId : ", objectId, cmsId);
//            lsVideo.setCloudFileId(objectId);
//            policyService.saveVideo(lsVideo);
//        }

        lsCont.setInteractive("A");
        policyService.saveCont(lsCont);
        lsVideo.setURL(m3u8FilePath);
        lsVideo.setVideoUrl(videoFilePath);
        videoDao.saveVideo(lsVideo);
        for (LSPicture picture : lsPicture) {
            if (picture.getBusiType().equals("IIDPic")){
                picture.setURL(sourcesDir+File.separator+picture.getPicName()+"."+picture.getPicType());
            }else if (picture.getBusiType().equals("AIDPic")){
                picture.setURL(sourcesDir+File.separator+picture.getPicName()+"."+picture.getPicType());
            }else {
                picture.setURL(outerNet +"accessVideo" + File.separator + drawFrame.get(picture.getTimeNode()));

            }
            pictureDao.savePicture(picture);
        }
        lsContState.setPicState("F");
        lsContState.setVideoState("F");
        lsContState.setScreenShotState("F");
        contStateDao.save(lsContState);


    }

//    /**
//     * User: weihao
//     * Date: 2018/4/25
//     * Time: 22:22
//     * 获取图片外链  上传的图片
//     */
//    @RequestMapping(value = "/picture")
//    @Transactional
//    public RequestResult uploadPicture(@RequestParam String contNo) {
//
//        LSCont lsCont = policyService.findByContNo(contNo);
//        LsContState lsContState = contStateDao.getContState(contNo);
//
//        if (lsCont == null || lsContState == null) {
//            logger.warn("lsCont == null || lsContState == null  break");
//            return new RequestResult(false);
//        }
//
//        if (!"F".equals(lsCont.getInteractive())) {
//            logger.warn("!\"F\".equals(lsCont.getInteractive())  break \n {}", lsCont);
//            return new RequestResult(false);
//        }
//
////		if(!"N".equals(lsContState.getPicState())){
////			return new RequestResult(false);
////		}
//
//        if ("F".equals(lsContState.getPicState())) {
//            logger.warn("\"F\".equals(lsContState.getPicState())  break \n {}", lsContState);
//            return new RequestResult(false);
//        }
//
////        if (!"F".equals(lsContState.getScreenShotState())) {
////            logger.warn("!\"F\".equals(lsContState.getScreenShotState())  break \n {}", lsContState);
////            return new RequestResult(false);
////        }
//
//        logger.info("contno {} picture start", contNo);
////        Thread thread = new Thread(){
////            @Override
////            public void run() {
//                Long time = System.currentTimeMillis();
//                lsContState.setPicState("H");
//                lsContState.setPicTime(time);
//                contStateDao.save(lsContState);
//                //获取图片外链
//                // 文件保存开始 时间节点
//                LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
//                java.util.Date date = new java.util.Date();
//                lsContTime.setPicBeginTime(contSdf.format(date));
//                contTimeDao.saveContTime(lsContTime);
//                //需要获取外链地址的图片
//                List<LSPicture> pictures = new ArrayList<>();
//                List<LSPicture> aidPic = pictureDao.findByContNoAndBusiType(contNo, "AIDPic");
//                List<LSPicture> iidPic = pictureDao.findByContNoAndBusiType(contNo, "IIDPic");
//                pictures.addAll(aidPic);
//                pictures.addAll(iidPic);
//                for (LSPicture picture : pictures) {
//                    String cmsId = picture.getTimeNode();
//                    logger.info("get picture cmsId = {}, contNo = {}, pictureName = {}",cmsId, contNo, picture.getPicName());
//                    String result = cmsService.getPicture(cmsId, "0", 3);
//                    if (StringUtils.isEmpty(result)) {
//                        logger.info("get ID picture failed, contNo = {}", contNo);
//                        picture.setURL("");
//                    }else {
//                        picture.setURL(outerNet + result);
//                    }
//                    policyService.savePicture(picture);
//                }
//                lsContState.setPicState("F");
//                contStateDao.save(lsContState);
//                logger.info("picstate F");
//                java.util.Date date1 = new java.util.Date();
//                lsContTime.setPicEndTime(contSdf.format(date1));
//                contTimeDao.saveContTime(lsContTime);
////            }
////        };
////        thread.start();
//        return new RequestResult(true);
//    }

    @Value("${self.videoExt}")
    private String arr_videoExtSet;

    private Set<String> videoExtSet;

//    /**
//     * User: weihao
//     * Date: 2018/4/25
//     * Time: 22:22
//     * 获取视频的m3u8地址
//     */
//    @RequestMapping(value = "/video")
//    @Transactional
//    public boolean uploadVideo(@RequestParam String contNo) {
//
//        logger.info("uploadVideo <<< contNo: {}",contNo);
//
//        LSCont lsCont = policyService.findByContNo(contNo);
//        LsContState lsContState = contStateDao.getContState(contNo);
//        LSVideo lsVideo = policyService.findVideoByContNo(contNo);
//        if (lsCont == null || lsContState == null || lsVideo == null) {
//            logger.warn("contNo:{} >>>> lsCont == null || lsContState == null || lsVideo == null break", contNo);
//            return false;
//        }
//
//        if (!"F".equals(lsCont.getInteractive())) {
//            logger.warn("contNo:{} >>>> !\"F\".equals(lsCont.getInteractive())  break \n {}",
//                    contNo, lsCont);
//            return false;
//        }
//
////        if (!"F".equals(lsContState.getVideoToMp3State())) {
////            logger.warn("!\"F\".equals(lsContState.getVideoToMp3State())  break \n {}", lsContState);
////            return false;
////        }
//
//        if (!"D".equals(lsContState.getVideoState())) {
//            logger.warn("!\"D\".equals(lsContState.getVideoState())  break \n {}", lsContState);
//            return false;
//        }
//
//
//        if (lsVideo.getURL() != null && !lsVideo.getURL().equals("")) {
//            lsContState.setVideoState("F");
//            contStateDao.save(lsContState);
//            return true;
//        }
////        Thread thread = new Thread(){
////            @Override
////            public void run() {
//                lsContState.setVideoTime(System.currentTimeMillis());
//                contStateDao.save(lsContState);
//                //内容云id
//                String cmsId = lsVideo.getCloudFileId();
//                //获取m3u8地址
//                String m3u8 = cmsService.getM3u8(cmsId);
//                if (StringUtils.isEmpty(m3u8)) {
//                    logger.info("getM3u8 failed, contno = {}", contNo);
//                    return false;
//                }
//                lsVideo.setURL(outerNet + m3u8);
//                policyService.saveVideo(lsVideo);
//                lsContState.setVideoState("F");
//                contStateDao.save(lsContState);
//                LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
//                java.util.Date date = new java.util.Date();
//                lsContTime.setVideoEndTime(contSdf.format(date));
//                contTimeDao.saveContTime(lsContTime);
////                return;
////            }
////        };
////        thread.start();
//        return true;
//    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:23
     * 视频抽音频
     */
    @RequestMapping(value = "/videoToMp3")
    public boolean videoToMp3(@RequestParam String contNo) {
        LSCont lsCont = policyService.findByContNo(contNo);
        LsContState lsContState = contStateDao.getContState(contNo);
        String path = filePath + "/" + lsCont.getContNo();
        File dir = new File(path);
        if (dir.exists()) {

            // 记录视频文件抽取音频 开始处理。

//            Thread tDealThread = new Thread() {
//
//                @Override
//                public void run() {

                    Long time = System.currentTimeMillis();
                    lsContState.setVideoToMp3State("H");
                    lsContState.setVideoToMp3Time(time);
                    contStateDao.save(lsContState);

                    // 文件保存开始 时间节点
                    LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
                    java.util.Date date = new java.util.Date();
                    lsContTime.setvTMp3BeginTime(contSdf.format(date));
                    contTimeDao.saveContTime(lsContTime);

                    File[] fileList = dir.listFiles();
                    for (File file : fileList) {
                        String ext = FilenameUtils.getExtension(file.getName());
                        if (videoExtSet.contains(ext)) {
                            String videoPath = file.getAbsolutePath();
                            String mp3Path = null;
                            if (videoPath.endsWith("mp4")) {
                                String s1 = videoPath.substring(0,
                                        videoPath.lastIndexOf("mp4"));
                                mp3Path = s1 + "mp3";
                            }
                            if (videoPath.endsWith("MOV")) {
                                String s1 = videoPath.substring(0,
                                        videoPath.lastIndexOf("MOV"));
                                mp3Path = s1 + "mp3";
                            }
                            FileDow.changeMp4ToMp3(videoPath, mp3Path);

                        } else {
                            continue;
                        }
                    }
                    // 记录抽取完毕。
                    lsContState.setVideoToMp3State("F");
                    contStateDao.save(lsContState);
                    java.util.Date date1 = new java.util.Date();
                    lsContTime.setvTMp3EndTime(contSdf.format(date1));
                    contTimeDao.saveContTime(lsContTime);
//                }
//
//            };
//
//            tDealThread.start();
            return true;
        } else {
            if (lsCont != null) {
                // 增加中间态
                lsCont.setInteractive("D");
                policyService.saveCont(lsCont);
            }
        }
        return false;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:23
     * 视频抽帧 更新索引
     */
    @RequestMapping(value = "/screenshoot")
    @ResponseBody
    @Transactional
    public boolean toScreenshoot(@RequestParam String contNo) {
        logger.info("toScretoScreenshootenshoot: contNo {}", contNo);
        LSCont lsCont = policyService.findByContNo(contNo);
        LsContState lsContState = contStateDao.getContState(contNo);

        logger.info("查询所得LSCont为 {}",lsCont);
        logger.info("查询所得LsContState为 {}",lsContState);
        logger.info("保单状态为 {}",lsCont.getInteractive());
        logger.info("抽帧状态为 {}",lsContState.getScreenShotState());
        logger.info("视频状态为 {}",lsContState.getVideoState());
        if (lsCont == null || lsContState == null) {
            logger.warn("lsCont == null || lsContState == null  break");
            return false;
        }
//        if (!("F".equals(lsContState.getPicState())||"N".equals(lsContState.getPicState()))) {
//            logger.warn("!\"F\".equals(lsCont.getInteractive())  break \n {}", lsCont);
//            return false;
//        }

//        if (!"F".equals(lsCont.getInteractive())) {
//            logger.warn("!\"F\".equals(lsCont.getInteractive())  break \n {}", lsCont);
//            return false;
//        }

        if (!"N".equals(lsContState.getScreenShotState())) {
            logger.warn("!\"N\".equals(lsContState.getScreenShotState())  break \n {}", lsContState);
            return false;
        }
        // okhttp的方法不需要获取到lsUser和内容云的id，所以下面的判断就不需要了

        /*//抽帧只需要更新索引，等回调
        LSVideo lsVideo = videoDao.findByContNo(contNo);
        //获取内容云的objectId
        String cmsId = lsVideo.getCloudFileId();
        logger.info("内容云cmsid {}",cmsId);
        if (StringUtils.isEmpty(cmsId)) {
            logger.warn("cmsId is null");
            return false;
        }
        LSUser lsUser = userDao.getUser(lsCont.getOperator());
        if (lsUser == null) {
            logger.warn("lsUser is null");
            return false;
        }*/
//        Thread thread = new Thread(){
//            @Override
//            public void run() {
                //组织索引信息
        //String result = cmsService.updateCmsIndex(contNo, lsCont, lsContState, cmsId, lsUser);
        RequestResult res = okhttpService.updateCmsIndex(contNo, lsCont, lsContState);
        if (res.isSuccess()) {
                    lsCont.setInteractive("D");
                    policyService.saveCont(lsCont);
                    logger.info("保存的保单状态为 Interactive {}",(policyService.findByContNo(contNo)).getInteractive());
                }
//            }
//        };
//        thread.start();
        return true;
    }

    @Value("${self.uploadUrl}")
    private String uploadUrl;

    @Value(value = "${mp3.callBackUrl}")
    private String callBackUrl;

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:23
     * 语音转文本
     */
    @RequestMapping(value = "/MP3")
    public boolean uploadMp3(@RequestParam String contNo) {

        LSCont lsCont = policyService.findByContNo(contNo);
        LsContState lsContState = contStateDao.getContState(contNo);
        if (!lsContState.getVideoToMp3State().equals("F")) {
            return false;
        }
        if (!lsContState.getVideoState().equals("F")) {
            return false;
        }
        String path = filePath + "/" + lsCont.getContNo();
        File dir = new File(path);
        logger.info("mp3 upload start");
        if (dir.exists()) {

//            // 记录音频文件 开始转码处理。
//            Thread tDealThread = new Thread() {
//
//                @Override
//                public void run() {

                    Long time = System.currentTimeMillis();
                    lsContState.setMp3State("H");
                    lsContState.setMp3Time(time);
                    contStateDao.save(lsContState);

                    // 文件保存开始 时间节点
                    LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
                    java.util.Date date = new java.util.Date();
                    lsContTime.setMp3BeginTime(contSdf.format(date));
                    contTimeDao.saveContTime(lsContTime);

                    File[] fileList = dir.listFiles();
                    for (File file : fileList) {
                        String ext = FilenameUtils.getExtension(file.getName());
                        if (ext.equals("mp3")) {
                            // String fileName = file.getName().substring(0,
                            // file.getName().lastIndexOf("."));
                            String requestId = null;
                            path = uploadUrl + contNo + "/" + file.getName();
                            String comCode = lsCont.getComCode();
                            String huiUrl = callBackUrl;
                            try {
                                requestId = RecVoiceService.getVoice(path, huiUrl);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            logger.info("Mp3 path {}", path);
                            logger.info("requestId:::: {}", requestId);
                            LSVideo lsVideo =
                                    policyService.findVideoByContNo(contNo);
                            lsVideo.setMp3URL(path);
                            lsVideo.setRequestId(requestId);

                            logger.info("lsVideo.requestId:::: {} ",
                                    lsVideo.getRequestId());
                            logger.info("lsvideo.Mp3url {}", lsVideo.getMp3URL());
                            System.out.println(lsVideo.getRequestId());
                            policyService.saveVideo(lsVideo);

                        } else {
                            continue;
                        }
                    }
                    // 记录音频文件 上传完毕。
                    lsContState.setMp3State("F");
                    contStateDao.save(lsContState);
                    logger.info("mp3 upload success");
                    java.util.Date date1 = new java.util.Date();
                    lsContTime.setMp3EndTime(contSdf.format(date1));
                    contTimeDao.saveContTime(lsContTime);
//                }
//
//            };
//
//            tDealThread.start();

            return true;
        }
        return false;

    }

    @Value("${bucket.b1.enable}")
    private boolean b1enable = true;

    @Value("${bucket.b2.enable}")
    private boolean b2enable = true;

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:23
     * 下载视频
     */
    @RequestMapping(value = "/downloadZip")
    public Boolean downloadZip(@RequestParam String contNo) {
        // 设置返回值
        Boolean boolean1 = true;
        LSCont lsCont = policyService.findByContNo(contNo);
        LsContState lsContState = contStateDao.getContState(contNo);

        if (lsCont == null || lsContState == null) {
            logger.warn("lsCont == null || lsContState == null  break");
            return false;
        }

        if (!"X".equals(lsCont.getInteractive())) {
            logger.warn("!\"X\".equals(lsCont.getInteractive())  break \n {}", lsCont);
            return false;
        }

        Thread tDealThread = new Thread() {
            @Override
            public void run() {

                Long time = System.currentTimeMillis();
                lsContState.setDownState("H");
                lsContState.setDownTime(time);
                contStateDao.save(lsContState);

                // 文件保存开始 时间节点
                LSContTime lsContTime = contTimeDao.findContTime(lsCont.getContNo());
                java.util.Date date = new java.util.Date();
                lsContTime.setFileBeginTime(contSdf.format(date));
                contTimeDao.saveContTime(lsContTime);
                // 获取 zip cos 路径
                String zipURL = lsContTime.getZipUrl();


                // 压缩包目录
                File dir = _createTmpDir(contNo, lsCont.getModifyDate());

                if (!dir.exists()) {
                    logger.info("dir don't exists dir {}", dir.getAbsolutePath());
                    return;
                }
                File file = null;
                if ("1".equals(lsCont.getResource())) {
                    LSVideo lsVideo = policyService.findVideoByContNo(contNo);
                    file = new File(dir, lsVideo.getVideoName() + "." + lsVideo.getVideoType());
                } else {
                    file = new File(dir, contNo + ".zip");
                }

                //添加报错标识
                Boolean isFailed = false;
                try {
                    // 拉取文件
                    String result = cloudService.download(lsCont.getComCode(), zipURL, file.getAbsolutePath(), "down");
                    logger.info("contNo {} cos zip result {}", lsCont.getContNo(), result);
                    JSONObject jsonObject = new JSONObject(result);
                    String message = jsonObject.getString("message");
                    logger.info("contNo {} cos download message {}", lsCont.getContNo(), message);
                    if (!message.equalsIgnoreCase("SUCCESS")) {
                        throw new Exception();
                    }
                } catch (JSONException e) {
                    isFailed = true;
                    e.printStackTrace();
                } catch (Exception e) {
                    isFailed = true;
                    e.printStackTrace();
                    logger.error("download zip exception {}", e.getMessage());
                }
                //如果拉取失败 直接返回
                if (isFailed) {
                    return;
                }


                // 文件目录
                File dealDir = _createDealDir(lsCont.getContNo());

                if (!dealDir.exists()) {
                    logger.info("dealDir don't exists dealDir {}", dealDir.getAbsolutePath());
                    return;
                }

                //银保接口来的是 视频文件没有 zip文件用解压缩 直接复制到 解压缩目录
                if (!"1".equals(lsCont.getResource())) {
                    // 文件 解压缩 开始时间节点
                    java.util.Date date3 = new java.util.Date();
                    lsContTime.setZipBeginTime(contSdf.format(date3));
                    contTimeDao.saveContTime(lsContTime);

                    ZipUtils.unZip(file.getAbsolutePath(), dealDir.getAbsolutePath());

                    // 保存 解压缩 结束时间 节点
                    java.util.Date date2 = new java.util.Date();
                    lsContTime.setZipEndTime(contSdf.format(date2));
                    contTimeDao.saveContTime(lsContTime);
                    logger.info("Cont[{}] zip接收文件解压完成", contNo);
                    //
                } else {
                    //直接复制文件到 解压缩目录
                    FileUtil fileUtil = new FileUtil();
                    File unZip = new File(dealDir.getAbsoluteFile(), file.getName());
                    try {
                        fileUtil.forChannel(file.getAbsoluteFile(), unZip);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                // 文件保存结束 时间节点
                // 记录文件下载完毕。
                java.util.Date date1 = new java.util.Date();
                lsContTime.setFileEndTime(contSdf.format(date1));
                contTimeDao.saveContTime(lsContTime);

                lsContState.setDownState("F");
                lsContState.setZipFile(file.getAbsolutePath());
                contStateDao.save(lsContState);
                logger.info(" zip download success");

                // 删除cos 源文件
                // String resultString =
                // cloudService.delCosFile(lsCont.getComCode(), zipURL, "down");
                // logger.info("download zip delete result {}", resultString);

                // 上传 永久 bucket 桶 并保存到 lscont表
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
                if (b1enable) {
                    String url1 = cloudService.uploadCloud(lsCont.getComCode(),
                            "/" + lsCont.getComCode() + "/" + lsCont.getChannel() + "/" + lsCont.getOrgCode() + "/"
                                    + sdf.format(lsCont.getMakeDate()) + "/" + lsCont.getContNo() + "/",
                            file.getAbsolutePath(), "zip1");
                    logger.info("contno {} upload zip url1 {}", lsCont.getContNo(), url1);
                    lsCont.setZipUrl(url1);
                }

                if (b2enable) {
                    String url2 = cloudService.uploadCloud(lsCont.getComCode(),
                            "/" + lsCont.getComCode() + "/" + lsCont.getChannel() + "/" + lsCont.getOrgCode() + "/"
                                    + sdf.format(lsCont.getMakeDate()) + "/" + lsCont.getContNo() + "/",
                            file.getAbsolutePath(), "zip2");
                    logger.info("contno {} upload zip url2 {}", lsCont.getContNo(), url2);
                    lsCont.setZipUrlTwo(url2);
                }

                String fileSize = file.length() + "";
                lsCont.setZipFileSize(fileSize);
                if(lsContState.getDownState()!=null&& lsContState.getDownState().equals("F")){
                    lsCont.setInteractive("F");
                }
                policyService.saveCont(lsCont);

                // // 删除文件
                // File parentFile = file.getParentFile();
                // Boolean boolean1 = file.delete();
                // if (parentFile.listFiles().length == 0) {
                // parentFile.delete();
                // }
                // logger.info("Cont[{}] file delete {}", contNo, boolean1);

                // 解密文件
                File[] files = dealDir.listFiles();
                for (File file2 : files) {
                    String ext = FilenameUtils.getExtension(file2.getName());
                    // 如果文件后缀为c，则去解密
                    if (ext.equalsIgnoreCase("d")) {
                        FileDesUtil.encrypt(file2.getAbsolutePath());
                    } else if (ext.equalsIgnoreCase("c")) {
                        FileDesUtil.encryptD(file2.getAbsolutePath());
                    }
                }
            }

        };
        try {
            tDealThread.start();
        } catch (Exception e) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm:ss");
            boolean1 = false;
            lsCont.setInteractive("L");
            policyService.saveCont(lsCont);
            // 保存错误消息
            LSMessage lsMessage = new LSMessage();

            lsMessage.setMessageNo(UUID.randomUUID().toString());
            lsMessage.setUserNo(lsCont.getOperator());
            lsMessage.setTitle("上传错误");
            lsMessage.setMessage("后台处理上传数据错误");
            lsMessage.setType("L");
            lsMessage.setMakeDate(new Date(System.currentTimeMillis()));
            lsMessage.setMakeTime(sdfTime.format(new Date(System.currentTimeMillis())));
            lsMessage.setSource("server");
            lsMessage.setState('N');
            lsMessage.setContNo(lsCont.getContNo());
            lsMessage.setBusiNum(lsCont.getBusiNum());
            lsMessage.setOcopertor("server");
            lsMessage.setIssueDate(contSdf.format(new java.util.Date()));
            messageDao.save(lsMessage);

        }

        return boolean1;

    }

    private File _createTmpDir(String contNo, java.util.Date makeDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // String path = System.getProperty("user.dir");
        // logger.info("base path: {}", path);
        String dateString = sdf.format(makeDate);
        String pathDate = dateString;
        // String uuid = UUID.randomUUID().toString();
        String savepath = zipPath + "/" + pathDate + "/" + contNo;
        File dir = _createDir(savepath);
        return dir;
    }

    private File _createDir(String savepath) {
        File dir = new File(savepath);
        if (!dir.exists()) {
            logger.info("dir is not exists!!! path={}", savepath);
            dir.mkdirs();
        } else {
            logger.info("dir is exists!!! path={}", savepath);
        }
        return dir;
    }

    private File _createDealDir(String contNo) {
        // String path = System.getProperty("user.dir");
        // logger.info("base path: {}", path);
        String dealPath = filePath + "/" + contNo + "/";
        File dir = _createDir(dealPath);
        return dir;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        videoExtSet = new TreeSet<>();
        videoExtSet.addAll(Arrays.asList(arr_videoExtSet.split(",")));
    }

    // 重命名文件
//    public void renameFile(String path, String oldname, String newname) {
//        if (!oldname.equals(newname)) {// 新的文件名和以前文件名不同时,才有必要进行重命名
//            File oldfile = new File(path + "/" + oldname);
//            File newfile = new File(path + "/" + newname);
//            if (!oldfile.exists()) {
//                logger.info("oldname don't exists oldname {}", oldname);
//                return;// 重命名文件不存在
//            }
//            if (newfile.exists())// 若在该目录下已经有一个文件和新文件名相同，则不允许重命名
//                logger.info(newname + "已经存在！");
//            else {
//                oldfile.renameTo(newfile);
//            }
//        } else {
//            logger.info("新文件名和旧文件名相同...");
//        }
//    }

//    // 获取视频文件长度
//    public long getVideoLength(String filePath) {
//        File source = new File(filePath);
//        Encoder encoder = new Encoder();
//        long sum = 0;
//        try {
//            MultimediaInfo m = encoder.getInfo(source);
//            long ls = m.getDuration() / 1000; // ls是获取到的秒数
//            sum += ls;
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        logger.info("filePath {} videolength {}", filePath, sum);
//        return sum;
//
//    }

    // 提交保单信息
    @RequestMapping(value = "/submitPolicy")
    public RequestResult submitPolicy(@RequestParam String contNo) {
        LSCont cont = policyService.findByContNo(contNo);

        if (!"A".equals(cont.getInteractive())) {
            logger.info("conNo {} break submit", cont);
            return new RequestResult(true);
        }
        Thread thread = new Thread() {
            @Override
            public void run() {
                coreInteractiveFactory.getInstance(cont.getComCode()).submitCont(cont);
            }
        };
        thread.start();

        return new RequestResult(true);
    }

}
