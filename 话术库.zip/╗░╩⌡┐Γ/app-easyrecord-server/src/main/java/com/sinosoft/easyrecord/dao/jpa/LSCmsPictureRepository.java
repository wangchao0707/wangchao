package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSCmsPicture;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author SunYu
 * @date 2019/3/8 18:35
 */
public interface LSCmsPictureRepository extends JpaRepository<LSCmsPicture, String> {
    LSCmsPicture findByCmsId(String cmsId);

    List<LSCmsPicture> findByContNo(String contNo);
}
