package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSAppnt;

public interface LSAppntRepository extends JpaRepository<LSAppnt, String> {

    LSAppnt findByContNo(String contNo);

    LSAppnt findTop1ByClientContNo(String clientContNo);
}
