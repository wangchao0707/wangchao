package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSFileDown;

import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-08
 * Time: 16:24
 */

public interface FileDownDao {

    /**
     * 查询全部 列表
     **/
    List<LSFileDown> findAll();
}
