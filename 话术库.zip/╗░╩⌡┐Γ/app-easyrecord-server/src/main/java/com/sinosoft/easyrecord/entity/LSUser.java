//package com.sinosoft.easyrecord.entity;
//
//import org.apache.commons.lang3.builder.ToStringBuilder;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//import java.io.Serializable;
//import java.sql.Date;
//import java.util.StringJoiner;
//
///**
// * Created by WinterLee on 2017/7/13.
// */
//@Entity
//@Table(name = "LSUser")
//public class LSUser implements Serializable {
//
//    @Id
//    @Column(name = "UserId")
//    private String userId;
//
//    @Column(name = "ComCode")
//    private String comCode;
//
//    @Column(name = "OrgCode")
//    private String orgCode;
//
//    @Column(name = "AgentCode")
//    private String agentCode;
//
//    @Column(name = "Name")
//    private String name;
//
//    @Column(name = "Sex")
//    private String sex;
//
//
//    @Column(name = "Brithday")
//    private String brithday;
//    ///证件号和类型
//    @Column(name = "IDNo")
//    private String idNo;
//    @Column(name = "idType")
//    private String idType;
//
//    @Column(name = "PhoneNo", unique = true)
//    private String phoneNo;
//
//	/**
//     * 执业证号
//     */
//    @Column(name = "CCIANo")
//    private String cciaNo;
//    /**
//     * 资格证有效期至
//     */
//    @Column(name = "ISECDate")
//    private String isecDate;
//    /**
//     * 资格证号
//     */
//    @Column(name = "ISECNo")
//    private String isecNo;
//    @Column(name = "HeadImg")
//    private String headImg;
//
//    @Column(name = "MakeDate")
//    private java.sql.Date makeDate;
//    @Column(name = "MakeTime")
//    private String makeTime;
//    @Column(name = "ModifyDate")
//    private java.sql.Date modifyDate;
//    @Column(name = "ModifyTime")
//    private String modifyTime;
//    @Column(name = "State")
//    private char state;
//    @Column(name = "CloudURL")
//    private String cloudURL;
//
//    /**
//     * s是否推送标识
//     **/
//    @Column(name = "IsPush")
//    private String isPush;
//    /**
//     * 渠道
//     **/
//    @Column(name = "Channel")
//    private String channel;
//
//
//    @Column(name = "UseFlag")
//    private String useFalg;
//
//    @Column(name = "WorkFlag")
//    private String workFlag;
//
//    @Column(name = "SaleComCode")
//    private String saleComCode;
//
//    @Column(name = "SaleComName")
//    private String saleComName;
//    /**
//     * 角色
//     * 营销员 S
//     * 客户经理 M
//     * 保险规划师 P
//     * 银行员工 B
//     */
//    @Column(name = "Role")
//    private String role;
//    /**
//     * 银行
//     */
//    @Column(name = "BankCode")
//    private String bankCode = "";
//    /**
//     * 网点
//     */
//    @Column(name = "DotCode")
//    private String dotCode = "";
//
//
//    public String getRole() {
//        return role;
//    }
//
//    public void setRole(String role) {
//        this.role = role;
//    }
//
//    public String getBankCode() {
//        return bankCode;
//    }
//
//    public void setBankCode(String bankCode) {
//        this.bankCode = bankCode;
//    }
//
//    public String getDotCode() {
//        return dotCode;
//    }
//
//    public void setDotCode(String dotCode) {
//        this.dotCode = dotCode;
//    }
//
//
//    public String getUserId() {
//        return userId;
//    }
//
//    public void setUserId(String userID) {
//        this.userId = userID;
//    }
//
//    public String getComCode() {
//        return comCode;
//    }
//
//    public void setComCode(String comCode) {
//        this.comCode = comCode;
//    }
//
//    public String getOrgCode() {
//        return orgCode;
//    }
//
//    public void setOrgCode(String orgCode) {
//        this.orgCode = orgCode;
//    }
//
//    public String getAgentCode() {
//        return agentCode;
//    }
//
//    public void setAgentCode(String agentCode) {
//        this.agentCode = agentCode;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getSex() {
//        return sex;
//    }
//
//    public void setSex(String sex) {
//        this.sex = sex;
//    }
//
//    public String getBrithday() {
//        return brithday;
//    }
//
//    public void setBrithday(String brithday) {
//        this.brithday = brithday;
//    }
//
//    public String getIdNo() {
//        return idNo;
//    }
//
//    public void setIdNo(String idNo) {
//        this.idNo = idNo;
//    }
//
//    public String getIdType() { return idType; }
//
//    public void setIdType(String idType) { this.idType = idType; }
//
//    public String getPhoneNo() {
//        return phoneNo;
//    }
//
//    public void setPhoneNo(String phoneNo) {
//        this.phoneNo = phoneNo;
//    }
//
//    public String getCciaNo() {
//        return cciaNo;
//    }
//
//    public void setCciaNo(String cciaNo) {
//        this.cciaNo = cciaNo;
//    }
//
//    public String getIsecDate() {
//        return isecDate;
//    }
//
//    public void setIsecDate(String isecDate) {
//        this.isecDate = isecDate;
//    }
//
//    public String getIsecNo() {
//        return isecNo;
//    }
//
//    public void setIsecNo(String isecNo) {
//        this.isecNo = isecNo;
//    }
//
//    public String getHeadImg() {
//        return headImg;
//    }
//
//    public void setHeadImg(String headImg) {
//        this.headImg = headImg;
//    }
//
//    public Date getMakeDate() {
//        return makeDate;
//    }
//
//    public void setMakeDate(Date makeDate) {
//        this.makeDate = makeDate;
//    }
//
//    public String getMakeTime() {
//        return makeTime;
//    }
//
//    public void setMakeTime(String makeTime) {
//        this.makeTime = makeTime;
//    }
//
//    public Date getModifyDate() {
//        return modifyDate;
//    }
//
//    public void setModifyDate(Date modifyDate) {
//        this.modifyDate = modifyDate;
//    }
//
//    public String getModifyTime() {
//        return modifyTime;
//    }
//
//    public void setModifyTime(String modifyTime) {
//        this.modifyTime = modifyTime;
//    }
//
//    public char getState() {
//        return state;
//    }
//
//    public void setState(char state) {
//        this.state = state;
//    }
//
//    public String getCloudURL() {
//        return cloudURL;
//    }
//
//    public void setCloudURL(String cloudURL) {
//        this.cloudURL = cloudURL;
//    }
//
//
//    public String getIsPush() {
//        return isPush;
//    }
//
//    public void setIsPush(String isPush) {
//        this.isPush = isPush;
//    }
//
//
//    public String getChannel() {
//        return channel;
//    }
//
//    public void setChannel(String channel) {
//        this.channel = channel;
//    }
//
//    public String getUseFalg() {
//        return useFalg;
//    }
//
//    public void setUseFalg(String useFalg) {
//        this.useFalg = useFalg;
//    }
//
//    public String getWorkFlag() {
//        return workFlag;
//    }
//
//    public void setWorkFlag(String workFlag) {
//        this.workFlag = workFlag;
//    }
//
//    public String getSaleComCode() {
//        return saleComCode;
//    }
//
//    public void setSaleComCode(String saleComCode) {
//        this.saleComCode = saleComCode;
//    }
//
//    public String getSaleComName() {
//        return saleComName;
//    }
//
//    public void setSaleComName(String saleComName) {
//        this.saleComName = saleComName;
//    }
//
//    @Override
//    public String toString() {
//        return new StringJoiner(", ", LSUser.class.getSimpleName() + "[", "]")
//                .add("userId='" + userId + "'")
//                .add("comCode='" + comCode + "'")
//                .add("orgCode='" + orgCode + "'")
//                .add("agentCode='" + agentCode + "'")
//                .add("name='" + name + "'")
//                .add("sex='" + sex + "'")
//                .add("brithday='" + brithday + "'")
//                .add("idNo='" + idNo + "'")
//                .add("idType='" + idType + "'")
//                .add("phoneNo='" + phoneNo + "'")
//                .add("cciaNo='" + cciaNo + "'")
//                .add("isecDate='" + isecDate + "'")
//                .add("isecNo='" + isecNo + "'")
//                .add("headImg='" + headImg + "'")
//                .add("makeDate=" + makeDate)
//                .add("makeTime='" + makeTime + "'")
//                .add("modifyDate=" + modifyDate)
//                .add("modifyTime='" + modifyTime + "'")
//                .add("state=" + state)
//                .add("cloudURL='" + cloudURL + "'")
//                .add("isPush='" + isPush + "'")
//                .add("channel='" + channel + "'")
//                .add("useFalg='" + useFalg + "'")
//                .add("workFlag='" + workFlag + "'")
//                .add("saleComCode='" + saleComCode + "'")
//                .add("saleComName='" + saleComName + "'")
//                .add("role='" + role + "'")
//                .add("bankCode='" + bankCode + "'")
//                .add("dotCode='" + dotCode + "'")
//                .toString();
//    }
//}
