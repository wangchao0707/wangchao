package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.entity.LSInforImg;
import com.sinosoft.easyrecord.vo.InforImgForm;

public interface InforImgService {


    ServiceResult<String, String[]> save(InforImgForm imgForm);
}
