package com.sinosoft.easyrecord.dao.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.sinosoft.easyrecord.entity.LSRiskType;
import org.springframework.transaction.annotation.Transactional;

public interface LSRiskTypeRepository extends JpaRepository<LSRiskType, String> {
    //根据代理人的comCode来查出第二个框的所有内容
    //如果代理人为保险公司，那么显示的typeName就是这个公司所有的保险产品
    //如果是保险公司，那么就默认自己代理自己所有的产品，也就是说，此时InsurComCode=ConCode
    // @Query("select * from LSRiskType where ComCode=?1 and InsurComCode=?2")
    List<LSRiskType> findByComCodeAndInsurComCodeAndOrgCodeOrderByRiskType(String comCode, String insurComCode, String orgCode);

    LSRiskType findByComCodeAndRiskTypeAndOrgCode(String comCode, String riskType, String orgCode);


    //因为有了备份的表，所以要先查下本地有没有数据
    List<LSRiskType> findByComCode(String comCode);

    //根据comCode删除
    @Modifying
    @Transactional
    @Query(value = "delete from lsrisktype where ComCode=?1", nativeQuery = true)
    void deleteByComCode(String comCode);

}
