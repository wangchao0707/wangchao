package com.sinosoft.easyrecord.server;

/**
 * Created by wds on 2018-3-17.
 */
public interface Req81015 {

    public String getReq81015(String xml);
}
