package com.sinosoft.easyrecord.controller;

import com.alibaba.fastjson.JSONObject;
import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.almond.commons.transmit.vo.SelectItem;
import com.sinosoft.easyrecord.dao.ComConfigDao;
import com.sinosoft.easyrecord.dao.LDCodeDao;
import com.sinosoft.easyrecord.dao.UserDao;
import com.sinosoft.easyrecord.entity.LDComConfig;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.service.PolicyService;
import com.sinosoft.easyrecord.service.UploadTimeService;
import com.sinosoft.easyrecord.sso.CurrentUser;
import com.sinosoft.easyrecord.vo.*;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import com.tencentcloudapi.common.Credential;
import com.tencentcloudapi.common.JsonResponseErrModel;
import com.tencentcloudapi.common.exception.TencentCloudSDKException;
import com.tencentcloudapi.common.profile.ClientProfile;
import com.tencentcloudapi.common.profile.HttpProfile;
import com.tencentcloudapi.iai.v20180301.IaiClient;
import com.tencentcloudapi.iai.v20180301.models.CompareFaceRequest;
import com.tencentcloudapi.iai.v20180301.models.CompareFaceResponse;
import com.tencentcloudapi.ocr.v20181119.OcrClient;
import com.tencentcloudapi.ocr.v20181119.models.GeneralBasicOCRRequest;
import com.tencentcloudapi.ocr.v20181119.models.GeneralBasicOCRResponse;
import com.tencentcloudapi.ocr.v20181119.models.TextDetection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.sql.Date;

@RestController
@RequestMapping("/api/policy")
public class PolicyController {
    @Autowired
    private PolicyService policyService;


    @Autowired
    private UploadTimeService uploadTimeService;

    final static private Logger logger = LoggerFactory.getLogger(PolicyController.class);

    @Autowired
    private LDCodeDao ldCodeDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private ComConfigDao comConfigDao;

    @Value("${compareFace.url}")
    private String compareUrl;


    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:17
     * app 上传保单信息接口
     */
    @RequestMapping(value = "/allByQ", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult savePolcyByQ(@RequestBody PolcyForm polcyForm) {
        logger.info("polcyForm [{}]", polcyForm);
        ContForm contForm = (ContForm) polcyForm;
        logger.info("contForm {}", contForm);
        //获取代理人信息
        logger.info("policy all save polcyForm {}", polcyForm.toString());
        logger.info("productName:{}",contForm.getProductName());
        String operator = contForm.getOperator();
        if(StringUtils.isEmpty(operator)){
            operator = CurrentUser.getUser().getUserId();
            contForm.setOperator(operator);
        }
        polcyForm.setOperator(operator);

        LSUser lsUser = userDao.findByUserId(operator);

        String operatorName = lsUser.getName();
        polcyForm.setOpeartorName(operatorName);



        polcyForm.setInsurComCode(polcyForm.getComCode());
        String comCode = lsUser.getComCode();
        polcyForm.setComCode(comCode);

        //非空校验
        polcyForm.setLdCodeDao(ldCodeDao);
        ServiceResult<String, String[]> validateRes = polcyForm.validate();
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            return res;
        }
        //保存上传时间
        if (polcyForm.getSerialNum() != null) {
            uploadTimeService.saveUploadTime(polcyForm.getSerialNum());
        }


        try {
            return policyService.savePolcy(polcyForm);
        } catch (ServiceResult.ServiceResultException ex) {
            validateRes = ex.getServiceResult();
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            return res;
        }

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:18
     * 查询保单 详情接口
     */
    @RequestMapping(value = "/showAll", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    public RequestResult showAll(@RequestParam String contNo) {

        return showAll(new PolicyAllForm(contNo));

    }

    @RequestMapping(value = "/showAll", method = RequestMethod.POST, consumes = "application/json")
    public RequestResult showAll(@RequestBody PolicyAllForm policyAllForm) {
        ServiceResult<String, String[]> validateResult = policyAllForm.validate();
        if (!validateResult.isSuccess()) {
            // return new RequestResult(false,
            // validateResult.getFailResult()[0]);
            RequestResult result = new RequestResult(false);
            result.setMessages(validateResult.getFailResult());

            return result;
        }

        ServiceResult<PolcyForm, String[]> result = policyService.showPolicy(policyAllForm.getContNo());

        if (!result.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages("没有该保单信息");
            return res;
        } else {
            RequestResult res = new RequestResult(true);
            res.setData(result.getSuccessResult());
            return res;
        }
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:18
     * 更新投保保单号接口
     */
    @RequestMapping(value = "/updateBusi", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    public RequestResult updateBusiNum(String clientContNo, String busiNum) {
        String operator = CurrentUser.getUser().getUserId();
        ServiceResult<String, String[]> validateRes = policyService.updateBusiNum(operator, clientContNo, busiNum);
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            logger.info("clientContNo[{}] validate faild", clientContNo);
            return res;
        } else {
            RequestResult res = new RequestResult(true);
            Hashtable<String, String> data = new Hashtable<>(1);
            data.put("clientContNo", validateRes.getSuccessResult());
            res.setData(data);
            logger.info("clientContNo[{}] success [{}]", validateRes.getSuccessResult());
            return res;
        }

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:19
     * 查询经代公司编码接口
     */
    @RequestMapping(value = "/findinsurcom", method = RequestMethod.POST)
    @ResponseBody
    public RequestResult findInsurCom() {

        String comCode = CurrentUser.getUser().getComCode();
        // 返回所在公司的列表
        List<SelectItem> coms = policyService.findInsurCom(comCode);

        RequestResult res = new RequestResult(true);

        res.setResult(coms);

        return res;

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:19
     * 获取险种列表接口
     */
    @RequestMapping(value = "/typename", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult showTypeName(@RequestParam String comCode, //
                                      @RequestParam String insurComCode,
                                      @RequestParam(required = false) String findMessage//
    ) {// 增加
        // 获取机构编码
        String orgCode = CurrentUser.getUser().getOrgCode();
        if (StringUtils.isEmpty(findMessage)) {
            return showTypeName(new QueryTypeForm(comCode, insurComCode, orgCode));
        } else {
            return showTypeName(new QueryTypeForm(comCode, insurComCode, orgCode, findMessage));
        }

    }

    @RequestMapping(value = "/typename", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult showTypeName(@RequestBody QueryTypeForm queryTypeForm) {// 增加
        String comCode = CurrentUser.getUser().getComCode();
        queryTypeForm.setComCode(comCode);
        queryTypeForm.setOrgCode(CurrentUser.getUser().getOrgCode());
        ServiceResult<String, String[]> validateRes = queryTypeForm.validate();
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
//			logger.info("showTypeName[{}] validate faild", queryTypeForm);
            return res;
        }

        ServiceResult<RiskForm[], String> serviceRes = policyService.showTypeName(queryTypeForm);
        if (!serviceRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(serviceRes.getFailResult());
            logger.info("showTypeName[{}] showTypeName faild", queryTypeForm);
            return res;
        }

        RequestResult res = new RequestResult(true);
        res.setResult(serviceRes.getSuccessResult());
        logger.info("QueryTypeForm[{}] success [{}]", queryTypeForm, res);
        return res;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:20
     * 查询话术接口
     */
    @RequestMapping(value = "/talkRunTime", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult showTalkRunTime(String busiNum, String riskType, String insurComCode) {
        return showTalkRunTime(new TalkRunTimeForm(busiNum, riskType, insurComCode));
    }

    @RequestMapping(value = "/talkRunTime", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult showTalkRunTime(@RequestBody TalkRunTimeForm talkRunTimeForm) {

        ServiceResult<String, String[]> validateRes = talkRunTimeForm.validate();
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            //logger.info("talkRunTimeForm[{}] validate faild", talkRunTimeForm);
            return res;
        }
        return policyService.showTalkRunTime(talkRunTimeForm);
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:20
     * 已废弃
     * 查询话术接口
     */
    @RequestMapping(value = "/talks", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult showTalk(String insurComCode, //
                                  String riskType//
    ) {// 增加
        String comCode = CurrentUser.getUser().getComCode();
        logger.info("comCode", comCode);
        String orgCode = CurrentUser.getUser().getOrgCode();
        return showTalk(new QueryTalkForm(orgCode, comCode, insurComCode, riskType));
    }

    @RequestMapping(value = "/talks", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult showTalk(@RequestBody QueryTalkForm queryTalkForm) {
        // 因为没有传comCode进来
        queryTalkForm.setComCode(CurrentUser.getUser().getComCode());
        queryTalkForm.setOrgCode(CurrentUser.getUser().getOrgCode());
        ServiceResult<String, String[]> validateRes = queryTalkForm.validate();
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
//			logger.info("showTypeName[{}] validate faild", queryTalkForm);
            return res;
        }
        ServiceResult<TalkForm[], String> sr = policyService.showStepTalk(queryTalkForm);

        if (sr.isSuccess()) {
            // 如果成功，将传出来的数组封装到RequestResult
            RequestResult res = new RequestResult(true);
            res.setResult(sr.getSuccessResult());
            logger.info(sr.getFailResult());
            return res;
        } else {
            RequestResult res = new RequestResult(false);

            res.setMessage(sr.getFailResult());
            logger.info("ok");
            return res;
        }

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:20
     * 查询保单状态接口
     */
    @RequestMapping(value = "/state", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult showState(@RequestBody StateForm stateForm) {

        ServiceResult<String, String[]> validateRes = stateForm.validate();
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            logger.info("stateForm[{}] validate faild", stateForm);
            return res;
        } else {
            return policyService.showState(stateForm);
        }
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:21
     * 客户端 h5上传接口
     */
    @RequestMapping(value = "/zip", method = RequestMethod.POST)
    @ResponseBody
    public RequestResult uploadZip(@RequestParam(value = "zipFile") MultipartFile zipFile, String contNo, String md5) {
        logger.info("h5 zip upload start");
        return policyService.uploadZip(zipFile, contNo, md5);

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:21
     * 查询实时话术接口
     */
    @RequestMapping(value = "/mergeTalkRunTime", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult showMergeTalkRunTime(String busiNum, String riskType, String insurComCode,
                                              @RequestParam(value = "userName", required = false) String userName,
                                              @RequestParam(value = "gender", required = false) String gender,
                                              @RequestParam(value = "insuredName", required = false) String insuredName,
                                              @RequestParam(value="appntBirthday",required = false) Data appntBirthday,
                                              @RequestParam(value="insuredBirthday",required = false) Data insuredBirthday,
                                              @RequestParam(value="insuredRelationship",required = false) String insuredRelationship) {
        if (userName == null) {
            return showMergeTalkRunTime(new TalkRunTimeForm(busiNum, riskType, insurComCode,appntBirthday,insuredBirthday,insuredRelationship));
        }
        return showMergeTalkRunTime(new TalkRunTimeForm(busiNum, riskType, insurComCode, userName, gender, insuredName,appntBirthday,insuredBirthday,insuredRelationship));
    }

    @RequestMapping(value = "/mergeTalkRunTime", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult showMergeTalkRunTime(@RequestBody TalkRunTimeForm talkRunTimeForm) {
        talkRunTimeForm.setInsurComCode(talkRunTimeForm.getComCode());
        ServiceResult<String, String[]> validateRes = talkRunTimeForm.validate();
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            logger.info("talkRunTimeForm[{}] validate faild", talkRunTimeForm);
            return res;
        }


        return policyService.showMergeTalkRunTime(talkRunTimeForm);
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:21
     * 已上传列表 分页查询
     */
    @RequestMapping(value = "/pageUpload", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult getPageUploadByForm(@RequestParam int pageNo, @RequestParam String sortTime, @RequestParam(required = false) String busiNum) {

        if(busiNum == null || busiNum.isEmpty()){
            return getPageUpload(new PageUploadForm(pageNo, sortTime));
        }
        return getPageUpload(new PageUploadForm(pageNo, sortTime, busiNum));
    }

    @RequestMapping(value = "/pageUpload", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult getPageUpload(@RequestBody PageUploadForm pageUploadForm) {
        ServiceResult<String, String[]> request = pageUploadForm.validate();
        if (!request.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(request.getFailResult());
            return requestResult;
        }
        return policyService.getPageUpload(pageUploadForm.getPageNo(), pageUploadForm.getSortTime(), pageUploadForm.getBusiNum());
    }

    /**
     * Date:2020/02/07
     * Time:16:16
     * Create by zbl
     * 被驳回列表回显
     */
    @RequestMapping(value = "/pageReject", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult getPageRejectByForm(@RequestParam int pageNo, @RequestParam String sortTime, @RequestParam(required = false) String busiNum) {

        if(busiNum == null || busiNum.isEmpty()){
            return getPageRejectByForm(new PageUploadForm(pageNo, sortTime));
        }
        return getPageRejectByForm(new PageUploadForm(pageNo, sortTime, busiNum));
    }

    @RequestMapping(value = "/pageReject", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult getPageRejectByForm(@RequestBody PageUploadForm pageUploadForm) {
        ServiceResult<String, String[]> request = pageUploadForm.validate();
        if (!request.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(request.getFailResult());
            return requestResult;
        }
        return policyService.getPageReject(pageUploadForm.getPageNo(), pageUploadForm.getSortTime(), pageUploadForm.getBusiNum());
    }



    /**
     * Created by Feng on   2018/9/18  14:31
     * <p>
     * 根据产品 编码获取  保险 类型 和产品类型
     */
    @RequestMapping(value = "/productList", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult showProductTypeCode(@RequestParam(required = false) String riskType) {// 增加
        if (StringUtils.isEmpty(riskType)) {
            riskType = "";
        }
        Map map = new HashMap();
        map.put("riskType", riskType);
        return showProductTypeCode(map);
    }

    @RequestMapping(value = "/productList", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult showProductTypeCode(@RequestBody Map reqMap) {// 增加
        return policyService.showProductTypeCode(reqMap);
    }


    /**
     * 根据产品信息 返回 提示信息
     **/
    @RequestMapping(value = "/hint", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public Map getHint(@RequestBody Map reqMap) {
        logger.info("getHint reqMap {}", reqMap);
        Map<String, Object> resMap = new HashMap<>();
        //非空校验
        if (StringUtils.isEmpty(reqMap.get("products"))) {
            resMap.put("success", false);
            resMap.put("message", "参数不能为空");
        } else {
            resMap = policyService.getHint(reqMap);
            logger.info("getHint resMap {}", resMap.toString());
        }
        return resMap;
    }

    /**
     * 获取资料链接
     **/
    @RequestMapping(value = "/getFileInfo")
    public Map getFileInfo() {
        return policyService.getFileInfo();
    }


    /**
     * 修改 保单号
     **/
    @RequestMapping(value = "/changeBusinum", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public Map changeBusinum(@RequestBody Map reqMap) {
        logger.info("changeBusinum reqMap {}", reqMap);
        Map<String, Object> resMap = new HashMap<>();
        //非空校验
        if (StringUtils.isEmpty(reqMap.get("newBusi")) || StringUtils.isEmpty(reqMap.get("oldBusi"))) {
            resMap.put("success", false);
            resMap.put("message", "参数不能为空");
        } else {
            resMap = policyService.changeBusi(reqMap);
            logger.info("changeBusinum resMap {}", resMap.toString());
        }
        return resMap;
    }

    @RequestMapping(value = "/changeBusinum", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public Map changeBusinum(@RequestParam String newBusi, @RequestParam String oldBusi) {// 增加
        Map<String, Object> reqMap = new HashMap<>();
        reqMap.put("newBusi", newBusi);
        reqMap.put("oldBusi", oldBusi);
        return changeBusinum(reqMap);

    }

    /**
     * 新增人脸对比接口  王跃威  2020/07/10
     * @param compareFaceForm
     * @return
     */

    @RequestMapping(value = "/compareface",method = RequestMethod.POST,consumes = "application/json")
    @ResponseBody
    public CompareFaceResponse compareFace(@RequestBody CompareFaceForm compareFaceForm){
        CompareFaceResponse resp = null;
        try {
            LDComConfig ldComConfig = comConfigDao.findByComCode("24001");
            Map<String,String> map = new HashMap<String,String>();
            map.put("ImageA",compareFaceForm.getUrlA());
            map.put("ImageB",compareFaceForm.getUrlB());
            map.put("FaceModelVersion","3.0");
            String params = JSONObject.toJSONString(map);
            Credential cred = new Credential(ldComConfig.getCloudSecretId(), ldComConfig.getCloudSecretKey());
            HttpProfile httpProfile = new HttpProfile();
            /*httpProfile.setEndpoint("iai.tencentcloudapi.com");*/
            httpProfile.setEndpoint(compareUrl);
            ClientProfile clientProfile = new ClientProfile();
            clientProfile.setHttpProfile(httpProfile);
            IaiClient client = new IaiClient(cred, "ap-shanghai", clientProfile);
            logger.info("请求地址："+compareUrl);
            CompareFaceRequest req = CompareFaceRequest.fromJsonString(params, CompareFaceRequest.class);
            resp =  client.CompareFace(req);
            logger.info("人脸识别结果："+resp.getScore());
            return resp;
        } catch (TencentCloudSDKException e) {
            e.printStackTrace();
            return resp;
        }
    }


    /**
     * 新增单证识别对比接口  wangchao  2020/07/10
     * @param basicOCRForm
     * @return
     */

    @RequestMapping("/generalBasicOCR")
    @ResponseBody
    public RequestResult GeneralBasicOCR(@RequestBody BasicOCRForm basicOCRForm) throws TencentCloudSDKException {
        return policyService.generalBasicOce(basicOCRForm);
    }
}
