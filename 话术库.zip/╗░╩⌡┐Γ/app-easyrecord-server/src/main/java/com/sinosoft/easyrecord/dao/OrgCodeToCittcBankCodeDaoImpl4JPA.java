package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.OrgCodeToCittcBankCodeRepository;
import com.sinosoft.easyrecord.entity.OrgCodeToCittcBankCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class OrgCodeToCittcBankCodeDaoImpl4JPA implements OrgCodeToCittcBankCodeDao {

    @Autowired
    OrgCodeToCittcBankCodeRepository orgCodeToCittcBankCodeRepository;


    @Override
    public OrgCodeToCittcBankCode findByAreaCode(String areaCode) {
        return orgCodeToCittcBankCodeRepository.findByAreaCode(areaCode);
    }
}
