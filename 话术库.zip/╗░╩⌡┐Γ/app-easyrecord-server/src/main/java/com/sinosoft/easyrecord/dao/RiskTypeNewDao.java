package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LsRiskTypeNew;

import java.util.List;

public interface RiskTypeNewDao {

    void saveRiskTypeNew(LsRiskTypeNew lsRiskTypeNew);

    List<LsRiskTypeNew> findByContNo(String contNo);


}
