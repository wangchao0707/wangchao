package com.sinosoft.easyrecord.entity;

import javax.persistence.*;

@Entity
@Table(name = "LSTalkNew")
public class LSTalkNew {

    @Column(name = "PKID")
    private String pkid;
    @Id
    @Column(name = "TalkPkId")
    private String talkPkId;

    @Column(name = "InsurComCode")
    private String insurComCode;

    @Column(name = "RiskType")
    private String riskType;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "Step")
    private String step;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "TalkContent")
    private String talkContent;

    @Column(name = "OrderNum")
    private int orderNum;

    @Column(name = "ComCode")
    private String comCode;

    @Column(name = "OrgCode")
    private String orgCode;

    @Column(name = "TalkPointCode")
    private String talkPointCode;
    @Column(name = "isRead")
    private String isRead;

    /**
     * 是否 合并
     **/
    @Column(name = "isMerge")
    private String isMerge;

    public String getIsMerge() {
        return isMerge;
    }

    public void setIsMerge(String isMerge) {
        this.isMerge = isMerge;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getPkid() {
        return pkid;
    }

    public void setPkid(String pkid) {
        this.pkid = pkid;
    }

    public String getInsurComCode() {
        return insurComCode;
    }

    public void setInsurComCode(String insurComCode) {
        this.insurComCode = insurComCode;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getTalkContent() {
        return talkContent;
    }

    public void setTalkContent(String talkContent) {
        this.talkContent = talkContent;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getTalkPkId() {
        return talkPkId;
    }

    public void setTalkPkId(String talkPkId) {
        this.talkPkId = talkPkId;
    }

    public String getTalkPointCode() {
        return talkPointCode;
    }

    public void setTalkPointCode(String talkPointCode) {
        this.talkPointCode = talkPointCode;
    }

    public String getIsRead() {
        return this.isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead;
    }
}
