package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.VideoIsSendRepository;
import com.sinosoft.easyrecord.entity.VideoIsSend;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class VideoIsSendDaoImpl4JPA implements VideoIsSendDao {
    @Autowired
    VideoIsSendRepository videoIsSendRepository;

    @Override
    public void insertOrUpdate(VideoIsSend videoIsSend) {
        videoIsSendRepository.save(videoIsSend);
    }



    @Override
    public VideoIsSend findByCont(String contNo) {
        return videoIsSendRepository.findByContNo(contNo);
    }

}
