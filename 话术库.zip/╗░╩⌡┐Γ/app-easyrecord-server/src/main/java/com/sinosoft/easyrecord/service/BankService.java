package com.sinosoft.easyrecord.service;


import com.sinosoft.easyrecord.vo.BankForm;

import java.util.List;

/**
 * Created by Administrator on 2018-3-19.
 */
public interface BankService {

    List<BankForm> getBankList();
}
