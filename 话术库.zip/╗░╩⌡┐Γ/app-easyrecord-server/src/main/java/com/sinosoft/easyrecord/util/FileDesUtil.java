package com.sinosoft.easyrecord.util;


import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
/**
 * User: weihao
 * Date: 2018/5/17
 * Time: 9:42
 *  字符串加密 工具类
 */

public class FileDesUtil {

    /**
     * 视频加解密
     *
     * @param strFile 源文件绝对路径
     * @return
     */
    public static boolean encrypt(String strFile) {
        int len = 100;// 加密字节数
        try {
            File f = new File(strFile);
            if (!f.exists()) {
                f = new File(strFile + ".d");
                if (!f.exists()) {
                    return false;
                }
            }
            boolean flag = false;
            // 将文件后缀名做标记处理，以区分是加密状态还是解密状态
            String fileName = f.getName();
            String suffixName = fileName.substring(fileName.lastIndexOf(".") + 1);
            String newFileName = "";
            if (suffixName.equals("d")) {
                newFileName = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf("."));
                flag = f.renameTo(new File(newFileName));
            } else {
                newFileName = f.getAbsolutePath() + ".d";
                flag = f.renameTo(new File(newFileName));
            }
            // 如果没有重命名成功，则不做加密或解密处理
            if (!flag) {
                return false;
            }
            f = new File(newFileName);// 将要操作的文件绑定到新的文件名
            if (!f.exists()) {
                return false;// 如果不存在 ，继续返回
            }
//            RandomAccessFile raf = new RandomAccessFile(f, "rw");
//            long totalLen = raf.length();
//
//            if (totalLen < 100) len = (int) totalLen;
//
//            FileChannel channel = raf.getChannel();
//            MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, 100);
//            byte tmp;
//            for (int i = 0; i < len; ++i) {
//                byte rawByte = buffer.get(i);
////                System.out.print(rawByte+"\t");
//                tmp = (byte) (rawByte ^ i);
////                System.out.println(tmp);
////                System.out.println("---");
//                buffer.put(i, tmp);
//            }
//            buffer.force();
//            buffer.clear();
//            channel.close();
//            raf.close();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean encryptD(String strFile) {
        int len = 100;// 加密字节数
        RandomAccessFile raf = null;
        try {
            File f = new File(strFile);
            if (!f.exists()) {
                f = new File(strFile + ".c");
                if (!f.exists()) {
                    return false;
                }
            }
            boolean flag = false;
            // 将文件后缀名做标记处理，以区分是加密状态还是解密状态
            String fileName = f.getName();
            String suffixName = fileName.substring(fileName.lastIndexOf(".") + 1);
            String newFileName = "";
            if (suffixName.equals("c")) {
                newFileName = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf("."));
                flag = f.renameTo(new File(newFileName));
            } else {
                newFileName = f.getAbsolutePath() + ".c";
                flag = f.renameTo(new File(newFileName));
            }
            // 如果没有重命名成功，则不做加密或解密处理
            if (!flag) {
                return false;
            }
            f = new File(newFileName);// 将要操作的文件绑定到新的文件名
            if (!f.exists()) {
                return false;// 如果不存在 ，继续返回
            }
            raf = new RandomAccessFile(f, "rw");
            long totalLen = raf.length();

            if (totalLen < 100) len = (int) totalLen;

            FileChannel channel = raf.getChannel();
            MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, 100);
            byte tmp;
            for (int i = 0; i < len; ++i) {
                byte rawByte = buffer.get(i);
//                System.out.print(rawByte+"\t");
                tmp = (byte) (rawByte ^ i);
//                System.out.println(tmp);
//                System.out.println("---");
                buffer.put(i, tmp);
            }
            buffer.force();
            buffer.clear();
            channel.close();
            raf.close();

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (raf != null) {
                try {
                    raf.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

//	/**
//     * 视频加解密
//     *
//     * @param strFile 源文件绝对路径
//     * @return
//     */
//    public static boolean encrypt(String strFile) {
//        int len = 100;// 加密字节数
//        RandomAccessFile raf = null;
//        try {
//            File f = new File(strFile);
//            if (!f.exists()) {
//                f = new File(strFile + ".c");
//            }
//            raf = new RandomAccessFile(f, "rw");
//            long totalLen = raf.length();
//
//            if (totalLen < 100) len = (int) totalLen;
//
//            FileChannel channel = raf.getChannel();
//            MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, 100);
//            byte tmp;
//            for (int i = 0; i < len; ++i) {
//                byte rawByte = buffer.get(i);
//                tmp = (byte) (rawByte ^ i);
//                buffer.put(i, tmp);
//            }
//            buffer.force();
//            buffer.clear();
//            channel.close();
//            
//            // 将文件后缀名做标记处理，以区分是加密状态还是解密状态
//            String fileName = f.getName();
//            String suffixName = fileName.substring(fileName.lastIndexOf(".") + 1);
//            if (suffixName.equals("c")) {
//                String newFileName = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf("."));
//                f.renameTo(new File(newFileName));
//            } else {
//                String newFileName = "d:/"+f.getName() + ".c";
//                File file = new File(newFileName);
//                f.renameTo(file);
//            }
//            return true;
//        } catch (Exception e) {
//            e.printStackTrace();
//            return false;
//        } finally {
//			if (raf != null) {
//				try {
//					raf.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//		}
//    }
//    public static void main(String[] args) {
//    	String path = "D:\\xm\\文档\\国寿视频\\23df3ba1-35fd-4f63-8460-42186e33c0b0--1132661010189963-1132661010189962-1132661010189961\\96980.9576661840354d077b0-2635-4a0a-bcc6-6776ea473b8e\\a25fbd44-d43d-4c32-9a1e-5a68e10db50d.jpg.c";
//    	Boolean boolean1 = encryptD(path);
//    	System.out.println(boolean1);
//	}
}
