package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSAppnt;

import java.util.List;

public interface AppntDao {

    LSAppnt findByAppntNo(String appntNo);

    void save(LSAppnt appnt);

    LSAppnt findByContNo(String contNo);

    LSAppnt findByClientContNo(String clientContno);

}
