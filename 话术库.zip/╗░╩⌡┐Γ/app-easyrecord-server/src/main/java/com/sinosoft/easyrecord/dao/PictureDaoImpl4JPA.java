package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSPictureRepository;
import com.sinosoft.easyrecord.entity.LSPicture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component("pictureDao")
public class PictureDaoImpl4JPA implements PictureDao {

    @Autowired
    private LSPictureRepository lsPictureRepository;

    public void setLsPictureRepository(LSPictureRepository lsPictureRepository) {
        this.lsPictureRepository = lsPictureRepository;
    }

    @Override
    public void save(LSPicture lsPicture) {
        lsPictureRepository.saveAndFlush(lsPicture);
    }

    @Override
    public List<LSPicture> findByContNo(String contNo) {
        return lsPictureRepository.findByContNo(contNo);
    }

    @Override
    public LSPicture findByPicNameAndContNo(String picName, String contNo) {
        return lsPictureRepository.findByPicNameAndContNo(picName, contNo);
    }

    @Override
    public List<LSPicture> findByContNoAndBusiType(String contNo, String busiType) {
        return lsPictureRepository.findByContNoAndBusiType(contNo, busiType);
    }
    @Override
    public void savePicture(LSPicture lsPicture) {
        lsPictureRepository.saveAndFlush(lsPicture);
    }
    @Override
    public LSPicture findByPid(String pid) {
        Optional<LSPicture> res = lsPictureRepository.findById(pid);
        return res.orElse(null);
    }

    @Override
    public List<LSPicture> findPictureByContnoOrderByTimeNode(String contno){
        return lsPictureRepository.findPictureByContnoOrderByTimeNode(contno);
    }

    @Override
    public LSPicture findByPkIdAndContNo(String pkId,String contNo){
        return lsPictureRepository.findByPKIdAndContNo(pkId,contNo);
    }

    @Override
    public LSPicture findByPicNo(String picNo) {
        return lsPictureRepository.findByPicNo(picNo);
    }

}
