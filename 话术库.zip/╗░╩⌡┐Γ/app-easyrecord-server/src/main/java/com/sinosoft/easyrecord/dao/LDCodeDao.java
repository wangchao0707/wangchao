package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LDCode;

public interface LDCodeDao {

      LDCode findLDCodeByCodeName(String codeName);
}
