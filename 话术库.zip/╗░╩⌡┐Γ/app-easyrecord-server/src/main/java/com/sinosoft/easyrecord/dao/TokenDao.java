package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LDToken;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/18.
 */
public interface TokenDao {

    void save(LDToken token);

    LDToken getToken(String accessToken);

    LDToken getTokenByRefreshToken(String refreshToken);

    void disable(String accessToken);

    LDToken getTokenByUserId(String userId);

    List<LDToken> findByUserId(String userId);

    void delToken(LDToken ldToken);

}
