package com.sinosoft.easyrecord.controller;

import org.springframework.web.bind.annotation.*;


/**
 * Created by WinterLee on 2017/7/19.
 */
@RestController
@RequestMapping("/api/com")
public class ComController {

//    @Autowired
//    private ComManager comManager;

//    @RequestMapping(value = "/currcomlist", method = {RequestMethod.POST, RequestMethod.GET})
//    @ResponseBody
//    public RequestResult getComList() {
//        return _getComList();
//    }
//
//
//    @Cacheable(value = "SelectItems", key = "'ComList'")
//    public RequestResult _getComList() {
//
//        SelectItem[] comList = comManager.getCurrentComList();
//
//        RequestResult result = new RequestResult(true);
//        result.setResult(comList);
//
//        return result;
//    }


    /*
    @RequestMapping(value = "/currorglist", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public RequestResult getOrgList(@RequestParam String comCode) {
        return _getOrgList(comCode);
    }


    @Cacheable(value = "SelectItems", key = "'OrgList_' + #comCode")
    public RequestResult _getOrgList(String comCode) {
        ServiceResult<SelectItem[], String> serviceResult = comManager.getOrgList(comCode);

        if (serviceResult.isSuccess()) {
            RequestResult result = new RequestResult(true);
            result.setResult(serviceResult.getSuccessResult());
            return result;
        } else {
            return new RequestResult(false, serviceResult.getFailResult());
        }

    }
    */

}
