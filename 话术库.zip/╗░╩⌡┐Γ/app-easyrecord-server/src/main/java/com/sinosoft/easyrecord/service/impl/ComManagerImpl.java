package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.SelectItem;
import com.sinosoft.easyrecord.dao.ChannelDao;
import com.sinosoft.easyrecord.dao.ComDao;
import com.sinosoft.easyrecord.dao.OrganizationDao;
import com.sinosoft.easyrecord.entity.LSChannel;
import com.sinosoft.easyrecord.entity.LSCom;
import com.sinosoft.easyrecord.entity4afc.LSOrganization;
import com.sinosoft.easyrecord.service.ComManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by WinterLee on 2017/7/19.
 */
@Service
public class ComManagerImpl implements ComManager {

    private static final Logger logger = LoggerFactory.getLogger(ComManagerImpl.class);


    @Autowired
    private ComDao comDao;

    public void setComDao(ComDao comDao) {
        this.comDao = comDao;
    }

    @Autowired
    private ChannelDao channelDao;

    public void setChannelDao(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    @Autowired
    private OrganizationDao organizationDao;

    public void setOrganizationDao(OrganizationDao organizationDao) {
        this.organizationDao = organizationDao;
    }

    @Override
    public SelectItem[] getComList() {

        logger.info("getComList");

        List<LSCom> comList = comDao.getComList();;

        SelectItem[] items = comList.stream().map(com -> {
            return new SelectItem(com.getComName(), com.getComCode());
        }).toArray(SelectItem[]::new);

        logger.info("getComList ==>>> [{}]", items);

        return items;
    }

    @Override
    public SelectItem[] getChannelList() {

        logger.info("getChannelList");

        List<LSChannel> list = channelDao.findAll();
        // 剔除前台获取银行渠道
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getChannelCode().equals("A16")) {
                list.remove(i);
            }
        }
        SelectItem[] items = list.stream().map(channel -> {
            return new SelectItem(channel.getChannelName(), channel.getChannelCode());
        }).toArray(SelectItem[]::new);
        logger.info("getChannelList ==>>> [{}]", items);

        return items;
    }

    @Override
    public ServiceResult<SelectItem[], String> getOrgList(String comCode) {

        logger.info("getOrgList <<== [{}]", comCode);

        ServiceResult.Builder<SelectItem[], String> builder = ServiceResult.build(SelectItem[].class, String.class);

        if (StringUtils.isEmpty(comCode)) {
            logger.warn("comCode is empty!!!!!!!!");
            return builder.createFailResult("请输入公司代码");
        }


        List<LSOrganization> orgList = organizationDao.getOrgList(comCode);

        SelectItem[] items = orgList.stream().map(org -> {
            return new SelectItem(org.getOrgName(), org.getOrgCode());
        }).toArray(SelectItem[]::new);


        return builder.createSuccessResult(items);
    }

    //一级二级加宁波
    @Override
    public ServiceResult<SelectItem[], String> getOrgListByNew(String comCode) {


        logger.info("getOrgList <<== [{}]", comCode);

        ServiceResult.Builder<SelectItem[], String> builder = ServiceResult.build(SelectItem[].class, String.class);

        if (StringUtils.isEmpty(comCode)) {
            logger.warn("comCode is empty!!!!!!!!");
            return builder.createFailResult("请输入公司代码");
        }


        List<LSOrganization> orgList = organizationDao.getOrgList(comCode);
        SelectItem[] items=null;
        if(!CollectionUtils.isEmpty(orgList)){
            List<LSOrganization> orgListEnd =orgList.stream().filter(org -> {
                        if(null!=org.getOrgCode()&& org.getOrgCode().trim()!="" ){
                            if(org.getOrgCode().length()==3 || org.getOrgCode().length()==6){
                              return true;
                            }
                            if(null!=org.getOrgName() && org.getOrgName().trim().equals("宁波")){
                               return true;
                            }
                            return false;
                        }
                        return false;
                    }).collect(Collectors.toList());

            if(!CollectionUtils.isEmpty(orgList)){
                items = orgListEnd.stream().map(org -> {
                    return new SelectItem(org.getOrgName(), org.getOrgCode());
                }).toArray(SelectItem[]::new);
            }


        }
        return builder.createSuccessResult(items);
    }


    @Override
    public ServiceResult<SelectItem[], String> getCurrentComList() {
        return null;
    }
}
