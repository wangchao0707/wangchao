package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.BankDao;
import com.sinosoft.easyrecord.entity.LSBank;
import com.sinosoft.easyrecord.util.InitialsUtil;
import com.sinosoft.easyrecord.util.PinYin4jUtils;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by wds on 2018-3-17.、
 *
 * 同步银行信息
 */
@Service("req81015")
public class Req81015Impl implements Req81015 {

    private static final Logger logger = LoggerFactory.getLogger(Req81015Impl.class);

    @Autowired
    private BankDao bankDao;

    public void setBankDao(BankDao bankDao) {
        this.bankDao = bankDao;
    }

    public String getReq81015(String xml) {
        logger.info("req81015 start {}", xml);
        XStream xs = new XStream();
        xs.alias("TRANSDATA", Transdata.class);
        xs.alias("TRANSBODY", Transbody.class, TransBodyReq81015.class);
        xs.alias("BANKS", TransBodyReq81015.BANKS.class);
        xs.alias("BANK", TransBodyReq81015.BANK.class);
        xs.addImplicitCollection(TransBodyReq81015.BANKS.class, "BANK");
        Transdata tmp = (Transdata) xs.fromXML(xml);
        Transhead head = tmp.getTranshead();
        TransBodyReq81015 body = (TransBodyReq81015) tmp.getTransbody();
        TransBodyReq81015.BANKS banks = body.getBANKS();
        List<TransBodyReq81015.BANK> list = banks.BANK;
        if (list != null && list.size() != 0) {
            bankDao.delete();
            for (TransBodyReq81015.BANK bank : list) {
                LSBank bank1 = new LSBank();
                bank1.setBankCode(bank.BANKCODE);
                bank1.setBankName(bank.BANKNAME);
                bank1.setBankInitials(InitialsUtil.getAllFirstLetter(bank.BANKNAME));
                bank1.setBankCompleteSpelling(PinYin4jUtils.hanziToPinyin(bank.BANKNAME));
                bankDao.save(bank1);
            }
        }
        // 返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }


}
