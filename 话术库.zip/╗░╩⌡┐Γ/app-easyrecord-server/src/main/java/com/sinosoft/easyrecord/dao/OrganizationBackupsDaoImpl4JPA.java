package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSOrganizationBackupsRepository;
import com.sinosoft.easyrecord.entity.LSOrganizationBackups;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * Created by WinterLee on 2017/7/19.
 */
@Component
public class OrganizationBackupsDaoImpl4JPA implements OrganizationBackupsDao {

    @Autowired
    private LSOrganizationBackupsRepository organizationBackupsRepository;

    public void setOrganizationBackupsRepository(LSOrganizationBackupsRepository organizationBackupsRepository) {
        this.organizationBackupsRepository = organizationBackupsRepository;
    }

    @Override
    public void save(LSOrganizationBackups lSOrganizationBackups) {
        organizationBackupsRepository.save(lSOrganizationBackups);
    }

}
