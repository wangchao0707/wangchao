package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSUserRepository;
import com.sinosoft.easyrecord.entity.LSUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Created by WinterLee on 2017/7/14.
 */
@Component
public class UserDaoImpl4JPA implements UserDao {

    @Autowired
    private LSUserRepository userRepository;

    public void setUserRepository(LSUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    private static final SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");

    @Override
    public LSUser getByIDNoOrPhoneNo(String no) {
        return userRepository.findTop1ByIdNoOrPhoneNo(no, no);
    }

    @Override
    public LSUser getByIDNo(String idno) {
        return userRepository.findTop1ByIdNo(idno);
    }

    @Override
    public LSUser getByPhoneNo(String phoneNo) {
        return userRepository.findTop1ByPhoneNo(phoneNo);
    }


    @Override
    public LSUser getByComInfo(String company, String agentCode) {
        return userRepository.findTop1ByComCodeAndAgentCode(company, agentCode);
    }

    @Override
    public LSUser getUser(String userid) {
        Optional<LSUser> res = userRepository.findById(userid);
        return res.orElse(null);
    }

    @Override
    public void save(LSUser user) {
        if (StringUtils.isEmpty(user.getUserId())) {
            user.setUserId(UUID.randomUUID().toString());
        }

        if(StringUtils.isEmpty(user.getPhoneNo())){
            DecimalFormat df = new DecimalFormat("0000000000");
            String x = df.format(UUID.randomUUID().getMostSignificantBits());
            user.setPhoneNo("X" + x);
        }

        java.sql.Date currDate = new java.sql.Date(System.currentTimeMillis());
        String currTime = format.format(currDate);

        user.setModifyDate(currDate);
        user.setModifyTime(currTime);

        userRepository.saveAndFlush(user);
    }

    @Override
    public List<LSUser> findByIsPush(String isPush) {
        return userRepository.findByIsPush(isPush);
    }

    @Override
    public List<LSUser> findAll(String comCode) {
        return userRepository.findByComCode(comCode);
    }

    @Override
    public LSUser findByAgentCode(String propersonCode) {
        return userRepository.findTop1ByAgentCode(propersonCode);
    }

	@Override
	public boolean findUserByAgentCode(String agentCode) {
		return userRepository.findUserByAgentCode(agentCode)>0?true:false;
	}

	@Override
    public LSUser findByUserId(String userId){
        return userRepository.findByUserId(userId);
    }




/*@Override
    public void updateUserbyIdNo(String newPhoneNum, String idNo,String comCode) {
        userRepository.updateUserbyIdNo(newPhoneNum,idNo,comCode);
    }*/

//    @Override
//    public LSUser update(LSUser user) {
//        return userRepository.update(user);
//    }


}
