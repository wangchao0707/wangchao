//package com.sinosoft.easyrecord.service;
//
//import com.sinosoft.almond.commons.transmit.data.ServiceResult;
//import com.sinosoft.easyrecord.entity.LSHeadImg;
//import com.sinosoft.easyrecord.vo.HeadImgForm;
//
//public interface HeadImgService {
//
//
//    ServiceResult<String, String[]> saveHeadImg(HeadImgForm headImgForm);
//
//}
