package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by wds on 2018-3-20.
 */
@Entity
@Table(name = "LSProperson")
public class LSProperson {

    @Id
    @Column(name = "Id")
    private String id;

    @Column(name = "PropersonCode")
    private String propersonCode;

    @Column(name = "PropersonName")
    private String propersonName;

    @Column(name = "BankNetWordCode")
    private String bankNetWordCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPropersonCode() {
        return propersonCode;
    }

    public void setPropersonCode(String propersonCode) {
        this.propersonCode = propersonCode;
    }

    public String getPropersonName() {
        return propersonName;
    }

    public void setPropersonName(String propersonName) {
        this.propersonName = propersonName;
    }

    public String getBankNetWordCode() {
        return bankNetWordCode;
    }

    public void setBankNetWordCode(String bankNetWordCode) {
        this.bankNetWordCode = bankNetWordCode;
    }

    @Override
    public String toString() {
        return "LSProperson{" +
                "id='" + id + '\'' +
                ", propersonCode='" + propersonCode + '\'' +
                ", propersonName='" + propersonName + '\'' +
                ", bankNetWordCode='" + bankNetWordCode + '\'' +
                '}';
    }
}
