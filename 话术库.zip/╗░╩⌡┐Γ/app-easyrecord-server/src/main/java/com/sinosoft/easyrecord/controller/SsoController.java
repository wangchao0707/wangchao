package com.sinosoft.easyrecord.controller;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;
import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.almond.commons.transmit.vo.SelectItem;
import com.sinosoft.easyrecord.dao.AuthenticationDao;
import com.sinosoft.easyrecord.dao.ComConfigDao;
import com.sinosoft.easyrecord.dao.UserDao;
import com.sinosoft.easyrecord.entity.LSAuthentication;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.service.*;
import com.sinosoft.easyrecord.sso.SinoAuthenticationException;
import com.sinosoft.easyrecord.utils.StringUtils;
import com.sinosoft.easyrecord.vo.*;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by WinterLee on 2017/7/13.
 */
@RestController
@RequestMapping("/sso")
public class SsoController {

    final static private Logger logger = LoggerFactory.getLogger(SsoController.class);

    private static final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
//    @Autowired
//    private CloudService cloudService;

    @Autowired
    private UserService userService;

    @Autowired
    private TokenManager tokenManager;

    @Autowired
    private ComManager comManager;

    @Autowired
    private UserDao userDao;

    @Autowired
    private PolicyService policyService;

    @Autowired
    private ComConfigDao comconfigDao;

    @Autowired
    private AuthenticationDao authenticationDao;

    @Autowired
    private CheckService checkService;

    @Autowired
    private BankService bankService;

    @Autowired
    private PropersonService propersonService;

    @Autowired
    private QuaCheckAndQryPolicyInter quaCheckAndQryPolicyInter;

    public void setAuthenticationDao(AuthenticationDao authenticationDao) {
        this.authenticationDao = authenticationDao;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:17
     *  登录接口
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult submitLogin( //
                                      String usercode, //
                                      String password, String deviceInfor, String randomCode//
    ) {
        return submitLogin(new LoginForm(usercode, password, deviceInfor, randomCode));
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult submitLogin( //
                                      @RequestBody LoginForm loginForm //
    ) {

        ServiceResult<String, String[]> validateResult = loginForm.validate();
        if (!validateResult.isSuccess()) {
            RequestResult result = new RequestResult(false);
            result.setMessages(validateResult.getFailResult());
            return result;
        }
        //新增登录时资质校验
        JSONObject jsonObject = new JSONObject();
        Map<String,String> map = new HashMap<>();
        LSUser lsUserByPhoneNo = userService.findByPhoneNo(loginForm.getUsercode());
        if (!StringUtils.isEmpty(lsUserByPhoneNo)){
            if(lsUserByPhoneNo.getChannel().equals("210")){
                map.put("agentCode",lsUserByPhoneNo.getAgentCode());
                map.put("agentName",lsUserByPhoneNo.getName());
                map.put("branchCode",lsUserByPhoneNo.getAgentCode());
                /*map.put("agentCode","0000001304");
                map.put("agentName","测试专用");
                map.put("branchCode","0000001304");*/
                jsonObject = JSONObject.parseObject(quaCheckAndQryPolicyInter.doQuaCheck(JSONObject.toJSONString(map)));
                if (jsonObject.get("ReturnCode").equals("S")){
                    try {
                        String password = loginForm.getPassword();
                        if (password.length() == 31) {
                            password = "0" + password;
                        }
                        loginForm.setPassword(password);
                        logger.info("userCode {} random {} password {}", loginForm.getUsercode(), loginForm.getRandomCode(),
                                loginForm.getPassword());
                        UsernamePasswordToken upt = new UsernamePasswordToken(
                                loginForm.getUsercode() + "<,>" + loginForm.getRandomCode(), loginForm.getPassword());
                        upt.setRememberMe(true);
                        SecurityUtils.getSubject().login(upt);
                        logger.info("User[loginForm: {}, userid: {}] logined", loginForm,
                                SecurityUtils.getSubject().getPrincipal());
                        //判断首次登陆
                        String userId = (String) SecurityUtils.getSubject().getPrincipal();
                        LSAuthentication lsAuthentication = authenticationDao.getAuthentication(userId);
                        String defaultpwd = lsAuthentication.getIsDefaultPWD();
                        if("Y".equals(defaultpwd)){
                            RequestResult result = new RequestResult(false,"首次登录，修改密码。");
                            Hashtable<String, String> date = new Hashtable<>();
                            date.put("phoneNum",loginForm.getUsercode());
                            date.put("operation","ChangePwd");
                            result.setData(date);
                            return result;
                        }else{
                            //登录后会删除之前的token 保证只能 一个人登录
                            tokenManager.delToken(userId);
                            Token token = tokenManager.createToken(userId);

                            RequestResult result = new RequestResult(true);
                            result.setData(token);

                            // 设备信息保存
                            if (loginForm.getDeviceInfor() != null) {
                                // 改
//                    String userCode[] = loginForm.getUsercode().split("<,>");
                                userService.saveDeviceInfor(userId, loginForm.getDeviceInfor(), token.getAccessToken());
                            }

                            return result;
                        }
                    } catch (SinoAuthenticationException ex) {
                        logger.info("User[{}] login faild: [{}]", loginForm, ex.getCause().getMessage(), ex);

                        return new RequestResult(false, ex.getMessage());

                    } catch (Exception ex) {

                        logger.info("User[{}] login faild: [{}]", loginForm, ex.getMessage(), ex);

                        return new RequestResult(false, "用户名或密码错误！");
                    }
                }else{
                    return new RequestResult(false,"资质校验不通过,"+jsonObject.get("ReturnMsg").toString());
                }
            }else{
                try {
                    String password = loginForm.getPassword();
                    if (password.length() == 31) {
                        password = "0" + password;
                    }
                    loginForm.setPassword(password);
                    logger.info("userCode {} random {} password {}", loginForm.getUsercode(), loginForm.getRandomCode(),
                            loginForm.getPassword());
                    UsernamePasswordToken upt = new UsernamePasswordToken(
                            loginForm.getUsercode() + "<,>" + loginForm.getRandomCode(), loginForm.getPassword());
                    upt.setRememberMe(true);
                    SecurityUtils.getSubject().login(upt);
                    logger.info("User[loginForm: {}, userid: {}] logined", loginForm,
                            SecurityUtils.getSubject().getPrincipal());
                    //判断首次登陆
                    String userId = (String) SecurityUtils.getSubject().getPrincipal();
                    LSAuthentication lsAuthentication = authenticationDao.getAuthentication(userId);
                    String defaultpwd = lsAuthentication.getIsDefaultPWD();
                    if("Y".equals(defaultpwd)){
                        RequestResult result = new RequestResult(false,"首次登录，修改密码。");
                        Hashtable<String, String> date = new Hashtable<>();
                        date.put("phoneNum",loginForm.getUsercode());
                        date.put("operation","ChangePwd");
                        result.setData(date);
                        return result;
                    }else{
                        //登录后会删除之前的token 保证只能 一个人登录
                        tokenManager.delToken(userId);
                        Token token = tokenManager.createToken(userId);

                        RequestResult result = new RequestResult(true);
                        result.setData(token);

                        // 设备信息保存
                        if (loginForm.getDeviceInfor() != null) {
                            // 改
//                    String userCode[] = loginForm.getUsercode().split("<,>");
                            userService.saveDeviceInfor(userId, loginForm.getDeviceInfor(), token.getAccessToken());
                        }

                        return result;
                    }
                } catch (SinoAuthenticationException ex) {
                    logger.info("User[{}] login faild: [{}]", loginForm, ex.getCause().getMessage(), ex);

                    return new RequestResult(false, ex.getMessage());

                } catch (Exception ex) {

                    logger.info("User[{}] login faild: [{}]", loginForm, ex.getMessage(), ex);

                    return new RequestResult(false, "用户名或密码错误！");
                }
            }
        }else{
            return new RequestResult(false,"当前用户未注册，请重新输入用户名！");
        }
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:16
     *  登录 短信接口
     */
    @RequestMapping(value = "/loginVerification", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult loginVerification(@RequestParam String phoneNum, @RequestParam String comCode) {
        return loginVerification(new VerificationForm(comCode, phoneNum));
    }

    @RequestMapping(value = "/loginVerification", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult loginVerification(@RequestBody VerificationForm verificationForm) {
        ServiceResult<String, String[]> result = verificationForm.validate();
        if (!result.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(result.getFailResult());
            return requestResult;
        }
        ServiceResult<String, String[]> serviceResult = userService.loginVerification(verificationForm.getPhoneNum(),
                verificationForm.getComCode());
        return getRequestResult(serviceResult);
    }

    private RequestResult getRequestResult(ServiceResult<String, String[]> serviceResult) {
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            logger.info("sso message {}", serviceResult.getFailResult());
            requestResult.setMessages(serviceResult.getFailResult());
            return requestResult;
        } else {
            RequestResult requestResult = new RequestResult(true);
            return requestResult;
        }
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:16
     *  发送短信 接口
     */
    @RequestMapping(value = "/verification", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult getVerification(@RequestParam String phoneNum, @RequestParam String comCode) {
        return getVerification(new VerificationForm(comCode, phoneNum));
    }

    @RequestMapping(value = "/verification", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult getVerification(@RequestBody VerificationForm verificationForm) {
        ServiceResult<String, String[]> result = verificationForm.validate();
        if (!result.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(result.getFailResult());
            return requestResult;
        }
        ServiceResult<String, String[]> serviceResult = userService.getVerification(verificationForm.getPhoneNum(),
                verificationForm.getComCode());
        return getRequestResult(serviceResult);

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:16
     *  刷新 token 接口
     */
    @RequestMapping(value = "/refresh", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult refresh( //
                                  @RequestParam String refreshToken //
    ) {

        return refresh(new RefreshTokenForm(refreshToken));

    }

    @RequestMapping(value = "/refresh", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult refresh( //
                                  @RequestBody RefreshTokenForm refreshTokenForm //
    ) {

        ServiceResult<String, String[]> validateResult = refreshTokenForm.validate();
        if (!validateResult.isSuccess()) {
            RequestResult result = new RequestResult(false);
            result.setMessages(validateResult.getFailResult());

            return result;
        }

        ServiceResult<Token, String> tokenResult = tokenManager.refresh(refreshTokenForm.getRefreshToken());
        if (tokenResult.isSuccess()) {
            RequestResult result = new RequestResult(true);
            result.setData(tokenResult.getSuccessResult());

            return result;
        } else {
            RequestResult result = new RequestResult(false);
            result.setMessages(tokenResult.getFailResult());

            return result;
        }

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:15
     *  代理人注册接口
     */
    @RequestMapping(value = "/register", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult submitRegister( //
                                         String comCode, //
                                         String orgCode, //
                                         String agentCode, //
                                         String name, //
                                         String sex, String brithday, //
                                         String idNo, //
                                         String phoneNo, //
                                         String vcode, //
                                         String password, //
                                         String channel,
                                         String randomCode,
                                         String role,
                                         String bankCode,
                                         String dotCode,
                                         String distributor,
                                         String manageCode,
                                         String manageName) {

        RegisterForm registerForm = new RegisterForm();
        registerForm.setComCode(comCode);
        registerForm.setOrgCode(orgCode);
        registerForm.setAgentCode(agentCode);
        registerForm.setName(name);
        registerForm.setSex(sex);
        registerForm.setBrithday(brithday);
        registerForm.setIdNo(idNo);
        registerForm.setPhoneNo(phoneNo);
        registerForm.setVcode(vcode);
        registerForm.setPassword(password);
        registerForm.setChannel(channel);
        registerForm.setRandomCode(randomCode);
        registerForm.setRole(role);
        registerForm.setBankCode(bankCode);
        registerForm.setDotCode(dotCode);
        registerForm.setDistributor(distributor);
        registerForm.setManageCode(manageCode);
        registerForm.setManageName(manageName);
        return this.submitRegister(registerForm);

    }
    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:15
     *  代理人注册接口
     */
    @RequestMapping(value = "/register", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult submitRegister( //
                                         @RequestBody RegisterForm registerForm //
    ) {
        {
            ServiceResult<String, String[]> validateRes = registerForm.validate();

            if (!validateRes.isSuccess()) {
                RequestResult res = new RequestResult(false);
                res.setMessages(validateRes.getFailResult());
                logger.info("RegisterForm[{}] validate faild", registerForm);
                return res;
            }
            if (registerForm.getChannel().equals("210")){
                JSONObject jsonObject = null;
                Map<String,String> map = new HashMap<>();
                map.put("agentCode",registerForm.getAgentCode());
                map.put("agentName",registerForm.getName());
                map.put("branchCode",registerForm.getAgentCode());
                jsonObject = JSONObject.parseObject(quaCheckAndQryPolicyInter.doQuaCheck(JSONObject.toJSONString(map)));
                if (!jsonObject.get("ReturnCode").equals("S")){
                    RequestResult res = new RequestResult(false);
                    res.setMessages("注册失败，资质校验不成功！未查询到该业务员信息！");
                    logger.info("业务员信息：", registerForm.getAgentCode()+"--"+registerForm.getName());
                    return res;
                }
            }
        }
        String password = registerForm.getPassword();
        if (password.length() == 31) {
            password = "0" + password;
        }
        registerForm.setPassword(password);
        ServiceResult<LSUser, String[]> serviceRes = userService.saveRegisterInfo(registerForm);

        if (!serviceRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(serviceRes.getFailResult());
            logger.info("RegisterForm[{}] validate faild", registerForm);
            return res;
        }

        RequestResult res = new RequestResult(true);
        Hashtable<String, Serializable> data = new Hashtable<>(1);
        LSUser user = serviceRes.getSuccessResult();
        data.put("userId", user.getUserId());
        data.put("makeDate", user.getMakeDate());
        data.put("makeTime", user.getMakeTime());
        data.put("state", user.getUseFalg());
        data.put("infor", "审核通过");
        res.setData(data);
        logger.info("RegisterForm[{}] success [{}]", registerForm, user);
        return res;

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:14
     *  获取公司列表
     */
    @RequestMapping(value = "/comlist", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public RequestResult getComList() {
        return _getComList();
    }

    // @Cacheable(value = "SelectItems", key = "'ComList'")
    public RequestResult _getComList() {

        SelectItem[] comList = comManager.getComList();

        RequestResult result = new RequestResult(true);
        result.setResult(comList);

        return result;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:14
     *  获取渠道列表
     */
    @RequestMapping(value = "/channel", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public RequestResult getChannelList() {
        SelectItem[] list = comManager.getChannelList();
        RequestResult requestResult = new RequestResult(true);
        requestResult.setResult(list);
        return requestResult;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:14
     * 获取银行列表
     */
    @RequestMapping(value = "/bank", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public RequestResult getBankList() {
        List<BankForm> list = bankService.getBankList();
        RequestResult requestResult = new RequestResult(true);
        logger.info("size{}", list.size());
        requestResult.setResult(list);
        return requestResult;
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:14
     * 根据网点编码查询客户经理
     */
    @RequestMapping(value = "/properson", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    public RequestResult getProperson(@RequestParam String bankNetWorkCode) {

        return getProperson(new PropersonReqForm(bankNetWorkCode));
    }

    @RequestMapping(value = "/properson", method = RequestMethod.POST, consumes = "application/json")
    public RequestResult getProperson(@RequestBody PropersonReqForm propersonForm) {
        ServiceResult<String, String[]> result = propersonForm.validate();
        if (!result.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(result.getFailResult());
            return requestResult;
        }
        List<PropersonForm> list = propersonService.findPropersonBybankNetWork(propersonForm.getBankNetWorkCode());
        if (list == null || list.isEmpty()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages("您的网点编码信息有误！");
            return requestResult;
        }else {
            RequestResult requestResult = new RequestResult(true);
            requestResult.setResult(list);
            return requestResult;
        }
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:13
     *  获取机构编码
     */
    @RequestMapping(value = "/orglist", method = {RequestMethod.POST,
            RequestMethod.GET}, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult getOrgList(@RequestParam String comCode) {
        return getOrgList(new QueryOrgForm(comCode));
    }


    @RequestMapping(value = "/orglist", method = {RequestMethod.POST, RequestMethod.GET}, consumes = "application/json")
    @ResponseBody
    public RequestResult getOrgList(@RequestBody QueryOrgForm orgForm) {
        ServiceResult<String, String[]> validateResult = orgForm.validate();
        if (!validateResult.isSuccess()) {
            RequestResult result = new RequestResult(false);
            result.setMessages(validateResult.getFailResult());
            return result;
        }
        return _getOrgListNew(orgForm.getComCode());
    }
    public RequestResult _getOrgListNew(String comCode) {
        ServiceResult<SelectItem[], String> serviceResult = comManager.getOrgListByNew(comCode);

        if (serviceResult.isSuccess()) {
            RequestResult result = new RequestResult(true);
            result.setResult(serviceResult.getSuccessResult());
            return result;
        } else {
            return new RequestResult(false, serviceResult.getFailResult());
        }

    }



    // @Cacheable(value = "SelectItems", key = "'OrgList_' + #comCode")
    public RequestResult _getOrgList(String comCode) {
        ServiceResult<SelectItem[], String> serviceResult = comManager.getOrgList(comCode);

        if (serviceResult.isSuccess()) {
            RequestResult result = new RequestResult(true);
            result.setResult(serviceResult.getSuccessResult());
            return result;
        } else {
            return new RequestResult(false, serviceResult.getFailResult());
        }

    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:13
     *  忘记密码 发送短信接口
     */
    @RequestMapping(value = "/foreignVerification", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult foreignVerification(@RequestParam String phoneNum, @RequestParam String comCode) {
        return foreignVerification(new VerificationForm(comCode, phoneNum));
    }

    @RequestMapping(value = "/foreignVerification", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult foreignVerification(@RequestBody VerificationForm verificationForm) {
        ServiceResult<String, String[]> result = verificationForm.validate();
        if (!result.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(result.getFailResult());
            return requestResult;
        }
        ServiceResult<String, String[]> serviceResult = userService.foreignVerification(verificationForm.getPhoneNum(),
                verificationForm.getComCode());
        return getRequestResult(serviceResult);
    }
    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:12
     * 忘记密码接口
     */
    @RequestMapping(value = "/foreign", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult foreignPassword(@RequestParam String phoneNum, @RequestParam String valicode,
                                         @RequestParam String newPassword, @RequestParam String randomCode) {
        return foreignPassword(new UserForeignPwdForm(phoneNum, newPassword, valicode, randomCode));
    }

    @RequestMapping(value = "/foreign", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult foreignPassword(@RequestBody UserForeignPwdForm userForeignPwdForm) {

        ServiceResult<String, String[]> serviceResult = userForeignPwdForm.validate();
        if (!serviceResult.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(serviceResult.getFailResult());
            return requestResult;
        }

        String password = userForeignPwdForm.getNewPassword();
        if (password.length() == 31) {
            password = "0" + password;
        }
        userForeignPwdForm.setNewPassword(password);
        ServiceResult<String, String[]> serviceResult2 = userService.foreignPassword(userForeignPwdForm.getPhoneNum(),
                userForeignPwdForm.getNewPassword(), userForeignPwdForm.getValicode(),
                userForeignPwdForm.getRandomCode());
        return getRequestResult(serviceResult2);
    }

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:12
     *  银保上传保单信息接口
     */
    @RequestMapping(value = "/savePolicy", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult savePolcyByQ(@RequestBody PolicyCoreForm polcyForm) {
        logger.info("policyCoreForm [{}]", polcyForm);
        //添加业务类型 为银保
        polcyForm.setOperation("Y");
        //银保数据非空校验
        ServiceResult<String, String[]> request = polcyForm.validateCore();
        if (!request.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(request.getFailResult());
            return requestResult;
        }
        //保单数据非空校验
        ServiceResult<String, String[]> validateRes = polcyForm.validate();
        if (!validateRes.isSuccess()) {
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            logger.info("savePolcy[{}] validate faild", polcyForm);
            return res;
        }
        //校验投保单号
        String busiNum = polcyForm.getBusiNum();
		request = checkService.checkBusiNum(polcyForm.getComCode(),busiNum,polcyForm.getAgentCode(),polcyForm.getRiskType());
        if (!request.isSuccess()) {
            RequestResult requestResult = new RequestResult(false);
            requestResult.setMessages(request.getFailResult());
            return requestResult;
        }
        //确认注册过 直接查询
        LSUser lsUser = userDao.getByComInfo(polcyForm.getComCode(), polcyForm.getAgentCode());
        if (lsUser == null) {
            lsUser = userService.saveUserByBank(polcyForm);
        }
        logger.info("policy all save polcyForm {}", polcyForm.toString());
        String opterator = lsUser.getUserId();
        polcyForm.setOperator(opterator);
        String opteratorName = lsUser.getName();
        polcyForm.setOpeartorName(opteratorName);
        String orgCode = lsUser.getOrgCode();
        polcyForm.setOrgCode(orgCode);
        polcyForm.setInsurComCode(polcyForm.getComCode());
        String channel = lsUser.getChannel();
        polcyForm.setChannel(channel);
        //如果银保接口没有双录文件 添加 视频虚拟路径
        polcyForm.getVideo().setURL("");
        if (polcyForm.getDataType() != null && polcyForm.getDataType().equals("1")) {
            polcyForm.getVideo().setURL("https://easyrecord.sinosoft.com");
        }
        try {
            return policyService.savePolcy(polcyForm);
        } catch (ServiceResult.ServiceResultException ex) {
            validateRes = ex.getServiceResult();
            RequestResult res = new RequestResult(false);
            res.setMessages(validateRes.getFailResult());
            logger.info("savePolcy[{}] faild", polcyForm);
            return res;
        }
    }
    /**
     * User: h
     * Date: 。。。。
     *  用户信息导入
     */
    @RequestMapping(value = "/importUserInfo", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult importUserInfo(@RequestBody RegisterForm4Import[] registerForms ){
        RequestResult registerResult = new RequestResult(true);
        List<Map> returnData = new ArrayList<>();
        for (int i = 0; i < registerForms.length; i++){
            Map<String, Object> map = new HashMap<>();
            RegisterForm regForm = registerForms[i];
            //对传进来的信息进行校验
            ServiceResult<String, String[]> validateRes = regForm.validate();
            if (!validateRes.isSuccess()) {
                logger.error("RegisterForm[{}] validate faild", regForm);
                map.put("result:","000111");
                map.put("messages:", validateRes.getFailResult());
                map.put("data:",regForm);
                returnData.add(map);
                continue;
            }
            //保存数据
            ServiceResult<LSUser, String[]> serviceRes = userService.saveRegisterInfoOutCheckVerCode(regForm);
            if (!serviceRes.isSuccess()) {
                logger.info("RegisterForm[{}] saveRegisterInfo faild", regForm);
                map.put("result","111111");
                map.put("message",serviceRes.getFailResult());
                map.put("data",serviceRes);
                returnData.add(map);
                continue;
            }

            LSUser user = serviceRes.getSuccessResult();
            logger.info("saveRegisterInfo[{}] success [{}]", regForm, user);
            map.put("result","000000");
            map.put("message",new String[]{"代理人保存成功"});
            map.put("data",serviceRes);
            returnData.add(map);
        }
        registerResult.setData((Serializable) returnData);
        return registerResult;
    }

}
