package com.sinosoft.easyrecord.server.impl;

import com.sinosoft.easyrecord.server.CallRemoteAfcServiceUtilFactory;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transbody;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyReq81001;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyRes;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transdata;
import com.thoughtworks.xstream.XStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("CallAfcService81001Api")
public class CallAfcServiceImpl81001 extends AbstractCallRemoteAfcService<Transdata, Transdata> {

    public CallAfcServiceImpl81001(@Autowired CallRemoteAfcServiceUtilFactory callAfcServiceFactory) {
        super("81001", callAfcServiceFactory);
    }

    @Override
    XStream buildRequestConverter() {

        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("VIDEO", TransbodyReq81001.VIDEO.class);
        xstream.alias("PAGES", TransbodyReq81001.PAGES.class);
        xstream.alias("PAGE", TransbodyReq81001.PAGE.class);
        xstream.addImplicitCollection(TransbodyReq81001.PAGES.class, "PAGE");

        return xstream;
    }

    @Override
    XStream buildResponseConverter() {

        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyRes.class);

        return xs1;
    }
}
