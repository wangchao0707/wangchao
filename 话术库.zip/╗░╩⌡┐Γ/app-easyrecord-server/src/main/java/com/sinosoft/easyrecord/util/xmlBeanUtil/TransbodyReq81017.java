package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: weihao
 * Date: 2018-05-14
 * Time: 17:31
 * 核心前置发送报文  同步状态
 */
public class TransbodyReq81017 implements Serializable,Transbody{


    private EASYRECORDINFOS EASYRECORDINFOS;

    public EASYRECORDINFOS getEASYRECORDINFOS() {
        return EASYRECORDINFOS;
    }

    public void setEASYRECORDINFOS(EASYRECORDINFOS EASYRECORDINFOS) {
        this.EASYRECORDINFOS = EASYRECORDINFOS;
    }


  public static class EASYRECORDINFOS{
        private String EASYRECORDINFOCOUNT;
        private List<EASYRECORDINFO> EASYRECORDINFOLIST;

        public String getEASYRECORDINFOCOUNT() {
            return EASYRECORDINFOCOUNT;
        }

        public void setEASYRECORDINFOCOUNT(String EASYRECORDINFOCOUNT) {
            this.EASYRECORDINFOCOUNT = EASYRECORDINFOCOUNT;
        }

      public List<EASYRECORDINFO> getEASYRECORDINFOLIST() {
          return EASYRECORDINFOLIST;
      }

      public void setEASYRECORDINFOLIST(List<EASYRECORDINFO> EASYRECORDINFOLIST) {
          this.EASYRECORDINFOLIST = EASYRECORDINFOLIST;
      }
  }

   public static class EASYRECORDINFO{
        public String PRTNO; //--投保单号-->
       public String UPLOADDATEFIRST;//--第一次上传日期 YYYY-MM-dd-->
       public String UPLOADTIMEFIRST;//--第一次上传时间 HH:mm:ss-->
       public String QCRECORDCOUNT;//!--质检次数-->
       public String UPLOADDATESECOND;//<!--第二次上传日期 YYYY-MM-dd-->
       public String UPLOADTIMESECOND;//-第二次上传时间 HH:mm:ss-->
       public String UPLOADDATETHIRD;//第三次上传日期 YYYY-MM-dd-->
       public String UPLOADTIMETHIRD;//第三次上传时间 HH:mm:ss-->
       public String QCCONCLUSION; //-质检状态-->
       public String RESOURCE; //<!--来源  app或银保通-->
       public String INSPECTDATE; //<!--质检日期-->
       public String INSPECTTIME; //<!--质检时间-->
    }
}
