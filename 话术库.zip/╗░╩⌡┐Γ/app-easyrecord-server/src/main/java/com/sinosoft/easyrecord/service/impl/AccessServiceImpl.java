package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSLookFile;
import com.sinosoft.easyrecord.entity.LSTransferInfo;
import com.sinosoft.easyrecord.entity.LSVideo;
import com.sinosoft.easyrecord.service.*;
import com.sinosoft.easyrecord.util.FileDesUtil;
import com.sinosoft.easyrecord.util.FileUtil;
import com.sinosoft.easyrecord.util.ZipUtils;
import it.sauronsoftware.jave.*;
import org.apache.commons.io.FilenameUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by  lijunming
 * on  date 2018-11-06
 * time 15:10
 */
@Service
public class AccessServiceImpl implements AccessService {
    private final Logger logger = LoggerFactory.getLogger(AccessServiceImpl.class);

    @Autowired
    private ContDao contDao;

    @Autowired
    private TransferInfoDao transferInfoDao;

    @Autowired
    private VideoDao videoDao;


    @Override
    public Map RequestAccess(Map param) {
        String contNo = param.get("contNo").toString();
        logger.info("contNo:"+contNo);
        Map responeData = new HashMap();
        responeData.put("contNo",contNo);
        LSTransferInfo Info = new LSTransferInfo();
        LSCont lsCont = contDao.findByContNo(contNo);
        if (lsCont == null) {
            logger.info("contNo {} dont't exist", contNo);
            responeData.put("success", "false");
            responeData.put("message", "流水号(contNo)不存在");
            return responeData;
        }
        try{
            LSTransferInfo lsTransferInfo =  transferInfoDao.findByContNo(contNo);
            LSVideo lsVideo = videoDao.findByContNo(contNo);
            if (lsTransferInfo == null) {
                logger.info("lsTransferInfo迁移回迁表无此条数据");
                Info.setContNo(contNo);
                if (lsVideo != null && !StringUtils.isEmpty(lsVideo.getCloudFileId())) {
                    Info.setCmsId(lsVideo.getCloudFileId());
                }
                if(!StringUtils.isEmpty(lsCont.getOrgCode())){
                    Info.setOrgCode(lsCont.getOrgCode());
                }
                Info.setStatus("E");
                transferInfoDao.saveTransferInfo(Info);
            }else{
                lsTransferInfo.setStatus("E");
                transferInfoDao.saveTransferInfo(lsTransferInfo);
            }
            responeData.put("success","true");
        }catch(Exception e){
            logger.info(" update lsTransferInfo  exception, {}", e);
        }
        return responeData;
        //更新数据
//        String zipUrl = lsCont.getZipUrl();
//        if (StringUtils.isEmpty(zipUrl)) {
//            logger.info("contNo={}  zipUrl  is  null", contNo);
//            responeData.put("success", "false");
//            responeData.put("message", "视频不存在");
//            return responeData;
//        }
//        String videoUrl = downZip(lsCont);
//        if (videoUrl == null) {
//            responeData.put("success", "false");
//            responeData.put("message", "download  zip error");
//            return responeData;
//        }
//        LSLookFile lsLookFile = new LSLookFile();
//        lsLookFile.setId(UUID.randomUUID().toString());
//        lsLookFile.setContNo(contNo);
//        //设置处理状态初始值
//        lsLookFile.setContState("X");
//        lsLookFile.setDownState("N");
//        lsLookFile.setPicState("N");
//        lsLookFile.setVideoState("N");
//        lsLookFile.setScreenShorState("N");
//        lsLookFile.setVideoState("N");
//        lsLookFile.setMessageState("N");
//        //增加创建时间
//        lsLookFile.setMakeDate(dateSdf.format(new Date()));
//        lsLookFile.setMakeTime(timeSdf.format(new Date()));
//        //保存调阅状态表
//        lookFileDao.saveLookFile(lsLookFile);
//        responeData.put("success", "true");
//        responeData.put("videoUrl", videoUrl);
//        return responeData;
    }

//    @Value("${self.videoExt}")
//    private String arr_videoExtSet;
//
//    /**
//     * 创建压缩目录
//     */
//    private File _createTmpDir(String contNo, java.util.Date makeDate) {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        String dateString = sdf.format(makeDate);
//        String pathDate = dateString;
//        suffixDir = pathDate + "/" + contNo;
//        String savepath = videoPath + suffixDir;
//        File dir = new File(savepath);
//        if (!dir.exists()) {
//            logger.info("dir is not exists!!! path={}", savepath);
//            dir.mkdirs();
//        } else {
//            logger.info("dir is exists!!! path={}", savepath);
//        }
//        return dir;
//    }
//
//    /**
//     * 下载zip,并且解压解密
//     */
//    private String downZip(LSCont lsCont) {
//        // 压缩包目录
//        File dir = _createTmpDir(lsCont.getContNo(), lsCont.getModifyDate());
//
//        if (!dir.exists()) {
//            logger.info("dir don't exists dir {}", dir.getAbsolutePath());
//            return null;
//        }
//        File file = null;
//        boolean isZip = false;
//        LSVideo lsVideo = null;
//        if ("1".equals(lsCont.getResource())) {
//            lsVideo = policyService.findVideoByContNo(lsCont.getContNo());
//            file = new File(dir, lsVideo.getVideoName() + "." + lsVideo.getVideoType());
//        } else {
//            file = new File(dir, lsCont.getContNo() + ".zip");
//            isZip = true;
//        }
//
//        //添加报错标识
//        Boolean isFailed = false;
//        String zipUrl = lsCont.getZipUrl();
//        zipUrl = zipUrl.substring(zipUrl.indexOf("com") + 4);
//        try {
//            String result = cloudService.download(lsCont.getComCode(), zipUrl, file.getAbsolutePath(), "zip1");
//            logger.info("contNo {} cos zip result {}", lsCont.getContNo(), result);
//            JSONObject jsonObject = new JSONObject(result);
//            String message = jsonObject.getString("message");
//            logger.info("contNo {} cos download message {}", lsCont.getContNo(), message);
//            if (!message.equalsIgnoreCase("SUCCESS")) {
//                throw new Exception();
//            }
//        } catch (JSONException e) {
//            isFailed = true;
//            e.printStackTrace();
//        } catch (Exception e) {
//            isFailed = true;
//            e.printStackTrace();
//            logger.error("download zip exception {}", e.getMessage());
//        }
//        //如果拉取失败 直接返回
//        if (isFailed) {
//            return null;
//        }
//
//        //如果下载的是视频文件，直接返回拼接后的路径
//        if ("1".equals(lsCont.getResource())) {
//            return prefix + suffixDir + "/" + lsVideo.getVideoName() + "." + lsVideo.getVideoType();
//        }
//        String parentPath = file.getParentFile().getAbsolutePath();
//        File parentFile = new File(parentPath);
//        //银保接口来的是 视频文件没有 zip文件用解压缩 直接复制到 解压缩目录
//        if (!"1".equals(lsCont.getResource())) {
//            ZipUtils.unZip(file.getAbsolutePath(), parentPath);
//        } else {
//            //直接复制文件到 解压缩目录
//            FileUtil fileUtil = new FileUtil();
//            File unZip = new File(parentPath, file.getName());
//            try {
//                fileUtil.forChannel(file.getAbsoluteFile(), unZip);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//        if (isZip) {
//            file.delete();
//        }
//        logger.info(" zip download success");
//        // 解密文件
//        File[] files = parentFile.listFiles();
//        for (File file2 : files) {
//            String ext = FilenameUtils.getExtension(file2.getName());
//            // 如果文件后缀为c，则去解密
//            if (ext.equalsIgnoreCase("d")) {
//                FileDesUtil.encrypt(file2.getAbsolutePath());
//            } else if (ext.equalsIgnoreCase("c")) {
//                FileDesUtil.encryptD(file2.getAbsolutePath());
//            }
//        }
//        //遍历解密的后的，动态拼接视频文件虚拟路径映射地址
//        String videoUrl = "";
//        String tempName;
//        lsVideo = videoDao.findByContNo(lsCont.getContNo());
//        File[] files2 = parentFile.listFiles();
//        for (File file2 : files2) {
//            tempName = file2.getName();
//            String ext = FilenameUtils.getExtension(file2.getName());
//            String fileName = file2.getName().substring(0, file2.getName().lastIndexOf("."));
//            logger.info("filename {} ext {}",fileName,ext);
//            if (arr_videoExtSet.contains(ext) && lsVideo.getVideoName().equals(fileName)){
//                //其他格式 文件 转为 mp4 文件返回
//                if (!ext.equalsIgnoreCase("mp4")){
//                    tempName = updateFile(file2);
//                }
//
//                videoUrl = suffixDir + "/" + tempName;
//                break;
//            }
//        }
//        //解密后,拼接视频虚拟映射地址
//        String videoHttpUrl = prefix + videoUrl;
//        logger.info("video  dummy url={}", videoHttpUrl);
//        return videoHttpUrl;
//    }
//
//    /**
//     * 转换视频格式 mov 转为MP4
//     **/
//    public String updateFile(File file){
//
//        File source =file;
//        String fileName = file.getName().substring(0, file.getName().lastIndexOf("."));
//        File dirFile = file.getParentFile();
//        File target = new File(dirFile,fileName+".mp4");
//        AudioAttributes audio = new AudioAttributes();
//        audio.setCodec("libfaac");
//        audio.setBitRate(new Integer(96000));
//        audio.setChannels(new Integer(1));
//        audio.setSamplingRate(new Integer(22050));
//        VideoAttributes video = new VideoAttributes();
//        video.setCodec("mpeg4");//mpeg4
//        video.setBitRate(new Integer(512000));
//        video.setFrameRate(new Integer(15));
//        video.setSize(new VideoSize(1280, 720));
//        EncodingAttributes attrs = new EncodingAttributes();
//        attrs.setFormat("mp4");//mpegvideo
//        attrs.setAudioAttributes(audio);
//        attrs.setVideoAttributes(video);
//        Encoder encoder = new Encoder();
//        try {
//            encoder.encode(source, target, attrs);
//        } catch (EncoderException e) {
//            e.printStackTrace();
//        }
//
//        return target.getName();
//    }

}
