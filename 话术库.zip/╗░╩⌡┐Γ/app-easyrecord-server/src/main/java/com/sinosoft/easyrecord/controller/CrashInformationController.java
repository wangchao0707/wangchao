package com.sinosoft.easyrecord.controller;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.entity.LSCrashInformation;
import com.sinosoft.easyrecord.service.CrashInformationService;
import com.sinosoft.easyrecord.vo.CrashInformationForm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sinosoft.easyrecord.service.CrashInformationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;


@RestController
@RequestMapping("/")
public class CrashInformationController {


    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    @Autowired
    private CrashInformationService crashInformationService;


    @RequestMapping(value = "/crashInformation", method = RequestMethod.POST, consumes = "application/x-www-form-urlencoded")
    @ResponseBody
    public RequestResult crashInformationHandler(@RequestParam(value = "crashInformation") String crashInformation, String equipmentInformation) {
        logger.info("aaaaaaaaaaaaaaaaaaaaaaaaa",crashInformation,"xxxxxxxxxxxxxxxxxxx",equipmentInformation);
        return crashInformationHandler(new CrashInformationForm(crashInformation, equipmentInformation));
    }

    @RequestMapping(value = "/crashInformation", method = RequestMethod.POST, consumes = "application/json")
    @ResponseBody
    public RequestResult crashInformationHandler(@RequestBody CrashInformationForm crashInformationForm) {
        logger.info("crashInformation start  crashInformation {}", crashInformationForm.getCrashInformation());
        RequestResult res = null;
        try {
            res = crashInformationService.saveCrashInformation(crashInformationForm.getCrashInformation(), crashInformationForm.getEquipmentInformation());
            logger.info("RES RESULT{}",res);
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("fail");
        }
        return res;
    }
}
