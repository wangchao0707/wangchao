package com.sinosoft.easyrecord.util;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.util.*;
import java.util.Map.Entry;

//@Service("recVoiceService")
public class RecVoiceService {

    private static final String MAC_NAME = "HmacSHA1";
    private static final String ENCODING = "UTF-8";

    public static String getVoice(String path, String huiUrl) throws Exception {
        String url = "aai.qcloud.com/asr/v1/1254260866";
        String times = Long.toString(System.currentTimeMillis());
        long timestamp = System.currentTimeMillis() / 1000;
        long expired = timestamp + 864000;
        SecureRandom random1 = null;
        try {
            random1 = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        int random;
        if (random1!=null){
            random= Math.abs(random1.nextInt());
        }else {
            random = 123;
        }
        String rdm = Integer.toString(random);
        System.out.println(timestamp);
        String params = "callback_url=" + huiUrl + "&channel_num=1"
                + "&engine_model_type=1&expired=" + expired + "&nonce=" + rdm + "&projectid=0"
                + "&res_text_format=0&res_type=1&secretid=AKIDjPwKag1U1URHwTR8Q7krs02u6DFNsB4R"
                + "&source_type=0&sub_service_type=0&timestamp=" + timestamp + "&url=" + path;
        String str = "POST" + url + "?" + params;
        String pwd = "OwGQkHiz42prE32wiO0YuTLZyCPWaY34";
        System.out.println(str);// http://123.207.138.89:8081/afc2/filevideo/111.mp3
        // System.out.println(new String(HmacSHA1Encrypt(str, pwd),"utf-8"));

        String b64 = new String(Base64.encodeBase64(HmacSHA1Encrypt(str, pwd)));
        System.out.println(b64);// OUL3choIj7DE5BiEqyYJ7Lq3Pg4=
        String line = "";
        String purl = "http://" + url + "?" + params;
        // String purl="http://"+url ;
        Map<String, String> map = new HashMap<String, String>();
        String body = send(purl, map, "utf-8", b64);
        System.out.println("交易响应结果：");
        System.out.println(body);
        JSONObject obj = JSONObject.parseObject(body);
        String requestid = obj.get("requestId").toString();
        System.out.println("requestid----------" + requestid + "----------");
        System.out.println("-----------------------------------");

        return requestid;
    }

//	public static void main(String[] args) throws Exception {
//		//
////		String request = getVoice(
////				"d:/未单身.mp4");
////		System.out.println("----");
////		System.out.println(request);
//
//	}

    private static String computeSignature(String baseString, String keyString) throws Exception {
        SecretKey secretKey = null;
        byte[] keyBytes = keyString.getBytes();
        secretKey = new SecretKeySpec(keyBytes, "HmacSHA1");
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(secretKey);
        byte[] text = baseString.getBytes();
        return new String(Base64.encodeBase64(mac.doFinal(text))).trim();
    }

    public static String hmac_sha1(String value, String key) {
        try {
            // Get an hmac_sha1 key from the raw key bytes
            byte[] keyBytes = key.getBytes();
            SecretKeySpec signingKey = new SecretKeySpec(keyBytes, "HmacSHA1");

            // Get an hmac_sha1 Mac instance and initialize with the signing key
            Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(signingKey);

            // Compute the hmac on input data bytes
            byte[] rawHmac = mac.doFinal(value.getBytes());

            // Convert raw bytes to Hex
            String hexBytes = byte2hex(rawHmac);
            return hexBytes;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String byte2hex(final byte[] b) {
        String hs = "";
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (java.lang.Integer.toHexString(b[n] & 0xFF));
            if (stmp.length() == 1)
                hs = hs + "0" + stmp;
            else
                hs = hs + stmp;
        }
        return hs;
    }

    private static String appendEqualSign(String s) {
        int len = s.length();
        int appendNum = 8 - (int) (len / 8);
        for (int n = 0; n < appendNum; n++) {
            s += "%3D";
        }
        return s;
    }

    /**
     * 模拟请求
     *
     * @param url      资源地址
     * @param map      参数列表
     * @param encoding 编码
     * @return
     * @throws ParseException
     * @throws IOException
     */
    public static String send(String url, Map<String, String> map, String encoding, String Authorization)
            throws ParseException, IOException {
        String body = "";

        // 创建httpclient对象
        CloseableHttpClient client = HttpClients.createDefault();
        // 创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);

        // 装填参数
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        if (map != null) {
            for (Entry<String, String> entry : map.entrySet()) {
                nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
        }
        // 设置参数到请求对象中
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, encoding));

        System.out.println("请求地址：" + url);
        System.out.println("请求参数：" + nvps.toString());

        // 设置header信息
        // 指定报文头【Content-type】、【User-Agent】
        httpPost.setHeader("Content-type", "application/octet-stream");
        httpPost.setHeader("authorization", Authorization);

        // 执行请求操作，并拿到结果（同步阻塞）
        CloseableHttpResponse response = client.execute(httpPost);
        // 获取结果实体
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            // 按指定编码转换结果实体为String类型
            body = EntityUtils.toString(entity, encoding);
        }
        EntityUtils.consume(entity);
        // 释放链接
        response.close();
        return body;
    }

    /*
     * 展示了一个生成指定算法密钥的过程 初始化HMAC密钥
     *
     * @return
     *
     * @throws Exception
     *
     * public static String initMacKey() throws Exception { //得到一个 指定算法密钥的密钥生成器
     * KeyGenerator KeyGenerator keyGenerator
     * =KeyGenerator.getInstance(MAC_NAME); //生成一个密钥 SecretKey secretKey
     * =keyGenerator.generateKey(); return null; }
     */

    /**
     * 使用 HMAC-SHA1 签名方法对对encryptText进行签名
     *
     * @param encryptText 被签名的字符串
     * @param encryptKey  密钥
     * @return
     * @throws Exception
     */
    public static byte[] HmacSHA1Encrypt(String encryptText, String encryptKey) throws Exception {
        byte[] data = encryptKey.getBytes(ENCODING);
        // 根据给定的字节数组构造一个密钥,第二参数指定一个密钥算法的名称
        SecretKey secretKey = new SecretKeySpec(data, MAC_NAME);
        // 生成一个指定 Mac 算法 的 Mac 对象
        Mac mac = Mac.getInstance(MAC_NAME);
        // 用给定密钥初始化 Mac 对象
        mac.init(secretKey);

        byte[] text = encryptText.getBytes(ENCODING);
        // 完成 Mac 操作
        return mac.doFinal(text);
    }
    // aai.qcloud.com/asr/v1/2000001?callback_url=http://test.qq.com/rec_callback
    // &engine_model_type=1&expired=1473752807&nonce=44925&projectid=0
    // &res_text_format=0&res_type=1&secretid=AKIDUfLUEUigQiXqm7CVSspKJnuaiIKtxqAv
    // &source_type=0&sub_service_type=0&timestamp=1473752207
    // &url=http://test.qq.com/voice_url

}