package com.sinosoft.easyrecord.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "lsinsured_client")
public class LsinsuredClient implements Serializable{
  @Id
  @Column(name = "CONTNO")
  private String contno;
  @Column(name = "INSUREDNO")
  private String insuredno;
  @Column(name = "PRTNO")
  private String prtno;
  @Column(name = "APPNTNO")
  private String appntno;
  @Column(name = "RELATIONTOAPPNT")
  private String relationtoappnt;
  @Column(name = "ADDRESS")
  private String address;
  @Column(name = "NAME")
  private String name;
  @Column(name = "SEX")
  private String sex;
  @Column(name = "BIRTHDAY")
  private java.sql.Date birthday;
  @Column(name = "AGE")
  private long age;
  @Column(name = "IDTYPE")
  private String idtype;
  @Column(name = "IDNO")
  private String idno;
  @Column(name = "OPERATOR")
  private String operator;
  @Column(name = "MAKEDATE")
  private java.sql.Date makedate;
  @Column(name = "MAKETIME")
  private String maketime;
  @Column(name = "MODIFYDATE")
  private java.sql.Date modifydate;
  @Column(name = "MODIFYTIME")
  private String modifytime;


  public String getContno() {
    return contno;
  }

  public void setContno(String contno) {
    this.contno = contno;
  }


  public String getInsuredno() {
    return insuredno;
  }

  public void setInsuredno(String insuredno) {
    this.insuredno = insuredno;
  }


  public String getPrtno() {
    return prtno;
  }

  public void setPrtno(String prtno) {
    this.prtno = prtno;
  }


  public String getAppntno() {
    return appntno;
  }

  public void setAppntno(String appntno) {
    this.appntno = appntno;
  }


  public String getRelationtoappnt() {
    return relationtoappnt;
  }

  public void setRelationtoappnt(String relationtoappnt) {
    this.relationtoappnt = relationtoappnt;
  }


  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  public String getSex() {
    return sex;
  }

  public void setSex(String sex) {
    this.sex = sex;
  }


  public java.sql.Date getBirthday() {
    return birthday;
  }

  public void setBirthday(java.sql.Date birthday) {
    this.birthday = birthday;
  }


  public long getAge() {
    return age;
  }

  public void setAge(long age) {
    this.age = age;
  }


  public String getIdtype() {
    return idtype;
  }

  public void setIdtype(String idtype) {
    this.idtype = idtype;
  }


  public String getIdno() {
    return idno;
  }

  public void setIdno(String idno) {
    this.idno = idno;
  }


  public String getOperator() {
    return operator;
  }

  public void setOperator(String operator) {
    this.operator = operator;
  }


  public java.sql.Date getMakedate() {
    return makedate;
  }

  public void setMakedate(java.sql.Date makedate) {
    this.makedate = makedate;
  }


  public String getMaketime() {
    return maketime;
  }

  public void setMaketime(String maketime) {
    this.maketime = maketime;
  }


  public java.sql.Date getModifydate() {
    return modifydate;
  }

  public void setModifydate(java.sql.Date modifydate) {
    this.modifydate = modifydate;
  }


  public String getModifytime() {
    return modifytime;
  }

  public void setModifytime(String modifytime) {
    this.modifytime = modifytime;
  }

  @Override
  public String toString() {
    return "LsinsuredClient{" +
            "contno='" + contno + '\'' +
            ", insuredno='" + insuredno + '\'' +
            ", prtno='" + prtno + '\'' +
            ", appntno='" + appntno + '\'' +
            ", relationtoappnt='" + relationtoappnt + '\'' +
            ", address='" + address + '\'' +
            ", name='" + name + '\'' +
            ", sex='" + sex + '\'' +
            ", birthday=" + birthday +
            ", age=" + age +
            ", idtype='" + idtype + '\'' +
            ", idno='" + idno + '\'' +
            ", operator='" + operator + '\'' +
            ", makedate=" + makedate +
            ", maketime='" + maketime + '\'' +
            ", modifydate=" + modifydate +
            ", modifytime='" + modifytime + '\'' +
            '}';
  }
}
