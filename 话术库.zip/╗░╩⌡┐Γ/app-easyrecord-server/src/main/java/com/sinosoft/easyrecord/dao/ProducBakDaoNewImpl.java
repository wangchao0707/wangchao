package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSProductBakNewRepository;
import com.sinosoft.easyrecord.entity.LSProductNewBak;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProducBakDaoNewImpl implements ProductBakDaoNew {
    @Autowired
    private LSProductBakNewRepository lsProductBakNewRepository;

    @Override
    public void saveLSProductBakNew(LSProductNewBak lsProductNewBak) {
        lsProductBakNewRepository.saveAndFlush(lsProductNewBak);

    }

}
