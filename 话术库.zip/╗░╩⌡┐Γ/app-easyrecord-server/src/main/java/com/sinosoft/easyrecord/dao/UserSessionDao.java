package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity4afc.UserSession;

import java.util.List;

public interface UserSessionDao {

    List<UserSession> getUserSession(String publicId);
}
