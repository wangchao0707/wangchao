package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

/**
 * Created by WinterLee on 2017/7/18.
 */

@Entity
@Table(name = "LDToken")
public class LDToken implements Serializable {

    @Id
    @Column(name = "AccessToken")
    private String accessToken;

    @Column(name = "CreateTime")
    private long createTime = -1;

    @Column(name = "Valid")
    private char valid = 'N';

    @Column(name = "UserId")
    private String userId;

    @Column(name = "ExpiresIn")
    private int expiresIn = -1;

    @Column(name = "RefreshToken", unique = true)
    private String refreshToken;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public char getValid() {
        return valid;
    }

    public void setValid(char valid) {
        this.valid = valid;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(int expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public void createToken() {
        this.accessToken = UUID.randomUUID().toString();
        this.refreshToken = UUID.randomUUID().toString();
        this.createTime = System.currentTimeMillis() / 1000;
        this.valid = 'Y';
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("LDToken{");
        sb.append("accessToken='").append(accessToken).append('\'');
        sb.append(", createTime=").append(createTime);
        sb.append(", valid=").append(valid);
        sb.append(", userId='").append(userId).append('\'');
        sb.append(", expiresIn=").append(expiresIn);
        sb.append(", refreshToken='").append(refreshToken).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
