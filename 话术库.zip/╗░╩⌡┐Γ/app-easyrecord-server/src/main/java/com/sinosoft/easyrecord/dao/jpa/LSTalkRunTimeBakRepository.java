package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSTalkRunTimeBak;

public interface LSTalkRunTimeBakRepository extends JpaRepository<LSTalkRunTimeBak, String> {

}
