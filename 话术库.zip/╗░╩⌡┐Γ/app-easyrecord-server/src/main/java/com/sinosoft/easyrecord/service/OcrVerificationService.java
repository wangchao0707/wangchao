package com.sinosoft.easyrecord.service;

//import com.qcloud.Utilities.Json.JSONObject;
import com.alibaba.fastjson.JSONObject;
//import net.minidev.json.JSONObject;
/**
 * Created by  yulong
 * on  date 2020-05-11
 * time 12:00
 */
public interface OcrVerificationService {
	//JSONObject httpClientPost(JSONObject enctyptStr);
	JSONObject httpClientPost(JSONObject enctyptStr);
}
