package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.IdTypeToCustomerCardType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IdTypeToCustomerCardTypeRepository extends JpaRepository<IdTypeToCustomerCardType, Integer> {

    IdTypeToCustomerCardType findByIdType(String idType);

}
