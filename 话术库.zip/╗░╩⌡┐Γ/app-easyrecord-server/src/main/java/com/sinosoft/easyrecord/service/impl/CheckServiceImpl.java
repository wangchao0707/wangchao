package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.dao.ComConfigDao;
import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.entity.LDComConfig;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.service.CheckService;
import com.sinosoft.easyrecord.util.StringSortUtil;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.namespace.QName;


/*
 * 投保单号校验
 * */
@Service
public class CheckServiceImpl implements CheckService {

    private Logger logger = LoggerFactory.getLogger(CheckServiceImpl.class);

    private ComConfigDao comconfigDao;

    @Autowired
    public void setComconfigDao(ComConfigDao comconfigDao) {
        this.comconfigDao = comconfigDao;
    }

    private ContDao contDao;

    @Autowired
    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }



    //中台校验投保单号  发现该保单号 存在 并 还没有上传到核心 则直接让前台将该投保单号 移动到已上传列表
    @Override
    public ServiceResult<String, String[]> localCheckBusiNum(String clientContNo, String comCode, String busiNum,
                                                             String insurComCode, String operator) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        LSCont lsCont = contDao.findByComCodeAndInsurComCodeAndBusiNumAndLastOne(comCode, insurComCode, busiNum, 'Y');
        if (lsCont == null) {
            return builder.createSuccessResult("OK");
        }
        if (!lsCont.getOperator().equals(operator)) {
            return builder.createSuccessResult("Ok");
        }
        if (!lsCont.getClientContNo().equals(clientContNo)) {
            return builder.createSuccessResult("OK");
        }
        if (lsCont.getInteractive().equals("L") || lsCont.getInteractive().equals("Z")) {
            return builder.createSuccessResult("OK");
        }

        if (lsCont.getInteractive().equals("R") && lsCont.getOperation().equals("Y")){
            return builder.createSuccessResult("OK");
        }

        return builder.createFailResult(new String[]{"该单已经上传，无需上传"});
    }


    /*
     *
     * */
    @Override
    public ServiceResult<String, String[]> checkBusiNum(String comCode, String busiNum, String agentCode, String riskType) {
        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        return builder.createSuccessResult("OK");

//        return getReq(comCode, busiNum, agentCode, riskType);
    }

    public ServiceResult<String, String[]> getReq(String comCode, String busiNum, String agentCode, String riskType) {

        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
        String inputXml = getReq81010(comCode, StringSortUtil.getArrayStringSort(busiNum), agentCode, StringSortUtil.getArrayStringSort(riskType));
        logger.info("busiNum {} req81010 inputXml {}", busiNum, inputXml);

        //获取地址
        LDComConfig comConfig = comconfigDao.findByComCode(comCode);
        String appUrl = comConfig.getServiceBusiURL();
//        String appUrl = "http://localhost:8080/services/EasyRecord?wsdl";
        String method = comConfig.getServiceKey();
        String result = "";
        String returncode = "";
        String message = "";
        try {

            result = sendService(inputXml, appUrl, method);
            logger.info("businum {} req81010 resultXml {}", busiNum, result);
            // 解析核心报文
            XStream xs1 = new XStream();
            xs1.alias("TRANSDATA", Transdata.class);
            xs1.alias("TRANSBODY", Transbody.class, TransbodyRes.class);
            Transdata tmp = (Transdata) xs1.fromXML(result);
            TransbodyRes transbodyRes = (TransbodyRes) tmp.getTransbody();
            returncode = transbodyRes.getTRANSRESULT().RETURNCODE;
            message = transbodyRes.getTRANSRESULT().MESSAGE;
            logger.info("req81010 returncode {} message {}", returncode, message);


        } catch (Exception e) {
            e.printStackTrace();
        }

        if (returncode.equals("81010000")) {
            return builder.createSuccessResult(message);
        } else {
            return builder.createFailResult(new String[]{message});
        }
    }


    public String getReq81010(String comCode, String busiNum, String agentCode, String riskType) {
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransbodyReq81010 tb = new TransbodyReq81010();

        th.setCOMPANY(comCode);
        th.setTRANSCODE("81010");

        td.setTranshead(th);

        tb.setDOCCODE(busiNum);
        tb.setAGENTCODE(agentCode);
        tb.setRISKTYPECODE(riskType);
        td.setTransbody(tb);
        XStream xs1 = new XStream();
        xs1.aliasSystemAttribute(null, "class");
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq81010.class);
        String xmlString = xs1.toXML(td);

        return xmlString;
    }

    /**
     * 发送请求
     *
     * @param xmlStr
     * @param url
     * @param method
     * @return
     * @throws Exception
     */
    private String sendService(String xmlStr, String url, String method) throws Exception {

        String xml = null;

        RPCServiceClient serviceClient = new RPCServiceClient();

        Options options = serviceClient.getOptions();

        EndpointReference targetEPR = new EndpointReference(url);

        options.setTo(targetEPR);
        options.setAction(method);
        options.setManageSession(true);
        options.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, true);

        QName opAddEntry = new QName("http://infservice.webservice.platform.sinosoft", method);


        Object[] opAddEntryArgs = new Object[]{xmlStr};


        Class[] classes = new Class[]{String.class};

        xml = (String) serviceClient.invokeBlocking(opAddEntry, opAddEntryArgs, classes)[0];
        serviceClient.cleanupTransport();

        logger.info("check busiNum xml {}", xml);
        return xml;

    }

}
