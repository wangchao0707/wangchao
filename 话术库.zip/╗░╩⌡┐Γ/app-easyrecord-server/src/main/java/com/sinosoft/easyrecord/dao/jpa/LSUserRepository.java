package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * Created by WinterLee on 2017/7/14.
 */
public interface LSUserRepository extends JpaRepository<LSUser, String> {

    LSUser findTop1ByIdNoOrPhoneNo(String idno, String phoneNo);

    LSUser findTop1ByIdNo(String idno);

    LSUser findTop1ByPhoneNo(String phoneNo);

    //    LSUser findTop1ByComCodeAndOrgCodeAndAgentCode(String comCode, String orgCode, String agentCode);
    LSUser findTop1ByComCodeAndAgentCode(String comCode, String agentCode);

    List<LSUser> findByIsPush(String isPush);

    List<LSUser> findByComCode(String comCode);

    LSUser findTop1ByAgentCode(String propersonCode);
    @Query("select count(u.agentCode) from LSUser u  where u.agentCode=?1 ")
	int findUserByAgentCode(String agentCode);

    LSUser findByUserId(String userId);


//    @Query(value = "update lsuser u set u.comCode =?1,u.orgCode=?2,u.agentCode=?3,u.name=?4,u.sex=?5,u.birthday=?6,u.idNo=?7,u.phoneNo=?8," +
//            "u.modifyDate=?9,u.modifyTime=?10 ,u.channel=?11,u.useFlag=?12,u.workFlag=?13,u.saleComCode=?14,u.saleComeName=?15 where u.comeCode = ?16 and u.orgCode=?17 and u.agentCode=?18",nativeQuery = true)
//
   /* //LSUser update(LSUser lsUser);
    @Transactional
    @Query(value = "update lsuser u set u.PhoneNo =?1 where u.idNo = ?2 and u.ComCode = ?3 ",nativeQuery = true)
    void updateUserbyIdNo(String newPhoneNum, String idNo,String comCode);*/
}
