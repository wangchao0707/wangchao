package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSTransferInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-21
 * Time: 19:39
 */
public interface LSTransferInfoRepository extends JpaRepository<LSTransferInfo,String>{

    LSTransferInfo findTop1ByStatusOrderByMakeDateDescMakeTimeDesc(String status);

    LSTransferInfo findTop1ByStatusAndOrgCodeInOrderByMakeDateDescMakeTimeDesc(String status, String[] orgCode);

    List<LSTransferInfo> findTop10ByStatusAndOrgCodeInOrderByMakeDateDescMakeTimeDesc(String status, String[] orgCode);

    int countByStatusAndBatchNode(String status, String batchNode);

    List<LSTransferInfo> findByOrgCodeAndModifydateAndAndStatus(String orgCode, Date modifyDate, String status);
    List<LSTransferInfo> findByOrgCodeAndModifydate(String orgCode, Date modifyDate);

    LSTransferInfo findByContNo(String contNo);
}
