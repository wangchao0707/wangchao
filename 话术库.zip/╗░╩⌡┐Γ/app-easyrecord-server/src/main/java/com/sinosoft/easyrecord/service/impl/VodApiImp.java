//package com.sinosoft.easyrecord.service.impl;
//
//import java.io.IOException;
//import java.util.Random;
//import java.util.TreeMap;
//
//import com.qcloud.Common.Sign;
//import com.qcloud.Module.Vod;
//import com.qcloud.QcloudApiModuleCenter;
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//
//public class VodApiImp {
//
//
//	public static final String SECRET_ID = "AKIDjPwKag1U1URHwTR8Q7krs02u6DFNsB4R";
//	public static final String SECRET_KEY = "OwGQkHiz42prE32wiO0YuTLZyCPWaY34";
//	public static final String API_URL = "https://vod.api.qcloud.com/v2/index.php";
//	public static final String HOST = "vod.api.qcloud.com";
//	public static final String HOST_PATH = "/v2/index.php";
//
//	public static final String REGION = "gz";
//	public static final String ACTION = "DescribeVodPlayUrls";
//
//	// public static String fileid = "9896587163612718253";
//
//	// 点播地址
//	// rtmp://4219.liveplay.myqcloud.com/live/4219_8888
//	// http://4219.liveplay.myqcloud.com/live/4219_8888.flv
//	// http://4219.liveplay.myqcloud.com/live/4219_8888.m3u8
//
//	/**
//	 *  公共参数列表
//	 *  Action 	DescribeVodPlayUrls  获取视频的详细信息
//	 *  Region  bj   区域参数  默认北京
//	 *  Timestamp   时间戳
//	 *  Nonce  随机正整数
//	 *  SecretId  秘钥id，与key生成 sign
//	 *  Signature 签名
//	 * @throws IOException
//	 */
//
//
//	/**
//	 *
//	 * @param params
//	 * @param secretId
//	 * @param secretKey
//	 * @param requestMethod
//	 * @param requestHost
//	 * @param requestPath
//	 * @return
//	 */
//	public static String generateUrl(TreeMap<String, Object> params,
//									 String secretId, String secretKey, String requestMethod,
//									 String requestHost, String requestPath) {
//		if (!params.containsKey("SecretId"))
//			params.put("SecretId", secretId);
//
//		if (!params.containsKey("Nonce"))
//			params.put("Nonce",
//					new Random().nextInt(Integer.MAX_VALUE));
//
//		if (!params.containsKey("Timestamp"))
//			params.put("Timestamp", System.currentTimeMillis() / 1000);
//
//		//params.put("RequestClient", version);
//
//		String plainText = Sign.makeSignPlainText(params, requestMethod,
//				requestHost, requestPath);
//
//		try {
//			params.put("Signature", Sign.sign(plainText, secretKey,"HmacSHA1"));
//			//System.out.println("Signature--->" + Sign.sign(plainText, secretKey,"HmacSHA1") );
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		if (params.get("Action").toString().equals("MultipartUploadVodFile")) {
//			String url = "http://" + requestHost + requestPath;
//			url += buildParamStr(params,requestMethod);
//			return url;
//		}
//
//		String url = "https://" + requestHost + requestPath;
//		if (requestMethod.equals("GET")) {
//			url += buildParamStr(params,requestMethod);
//		}
//
//		return url;
//	}
//	protected static String buildParamStr1(TreeMap<String, Object> requestParams, String requestMethod) {
//		return buildParamStr(requestParams, requestMethod);
//	}
//
//	protected static String buildParamStr(TreeMap<String, Object> requestParams, String requestMethod) {
//
//		String retStr = "";
//		for(String key: requestParams.keySet()) {
//			//排除上传文件的参数
//			if(requestMethod == "POST" && requestParams.get(key).toString().substring(0, 1).equals("@")){
//				continue;
//			}
//			if (retStr.length()==0) {
//				retStr += '?';
//			} else {
//				retStr += '&';
//			}
//			retStr += key.replace("_", ".") + '=' + requestParams.get(key).toString();
//
//		}
//		return retStr;
//	}
//	// 获取视频文件详细地址
//	public String createURL_getVideoURL(String fileid) throws Exception{
//		TreeMap<String, Object> config = new TreeMap<String, Object>();
//		config.put("SecretId", SECRET_ID);
//		config.put("SecretKey", SECRET_KEY);
//		config.put("RequestMethod", "GET");
//		config.put("DefaultRegion", REGION);
//		config.put("Action", ACTION);
//		config.put("fileId",fileid);
//		QcloudApiModuleCenter module = new QcloudApiModuleCenter(new Vod(), config);
//		TreeMap<String, Object> params = new TreeMap<String, Object>();
//		//params.put("fileId", fileid);
//
//		//return  module.call(ACTION, params);
//		return generateUrl(config,SECRET_ID, SECRET_KEY, "GET", HOST, HOST_PATH);
//	}
//
//
//
//
//
//}
