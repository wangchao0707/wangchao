//package com.sinosoft.easyrecord.controller;
//
//import java.io.UnsupportedEncodingException;
//import java.util.Base64;
//import java.util.Map;
//
//import com.sinosoft.almond.commons.transmit.data.ServiceResult;
//import com.sinosoft.easyrecord.dao.UserDao;
//import com.sinosoft.easyrecord.entity.LSUser;
//import com.sinosoft.easyrecord.service.SimulateService;
//import com.sinosoft.easyrecord.service.TokenManager;
//import com.sinosoft.easyrecord.util.HttpUtil;
//import com.sinosoft.easyrecord.util.SM4Util;
//import org.json.JSONArray;
//import org.json.JSONObject;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.web.bind.annotation.*;
//import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//
//
///**
// * Created by WinterLee on 2018/5/3
// */
//@RestController
//@RequestMapping("/sl")
//public class SimulateController {
//
//    final static private Logger logger = LoggerFactory.getLogger(SimulateController.class);
//
//    @Autowired
//    private SimulateService simulateService;
//
//    @Autowired
//    private TokenManager tokenManager;
//
//    @Autowired
//    private UserDao userDao;
//
//    //    @Value("")
//    private String secretKey = "JeF8U9wHFOMfs2Y8";
//
//    @Value("${e-shop.serviceURL}")
//    private String  eshopBaseUrl = "http://10.20.30.102:80";
//
//    private static final String ENCODING = "UTF-8";
//
//    /**
//     * User: weihao
//     * Date: 2018/5/14
//     * Time: 18:54
//     * 接收e店消息 并判断跳转页面
//     */
//    @RequestMapping(value = "/login", method = RequestMethod.POST)
//    @ResponseBody
//    public RequestResult doLogin(@RequestBody Map datas) {
//        RequestResult req = new RequestResult(false);
//        logger.info("map res {}", datas);
//        if (!datas.containsKey("data")) {
//            req.setMessage("参数类型不能为空");
//            return req;
//        }
//        String data = (String) datas.get("data");
//        logger.info("data ：{}", data);
//        JSONObject jsonObject = null;
//        // ////////////////////////////////////////////////////
//        // 增加 二维码方式代入，
//        // 需求来源：2019年6月 的政治任务
//        // ////////////////////////////////////////////////////
//        // 操作类型，QR：使用二维码，CL：app直接调用跳转（默认）
//        String ot = (String) datas.get("OT");
//        logger.info("OT: {}", ot);
//       /* if ("QR".equalsIgnoreCase(ot))*/ /*{
//            // 此时 data 是个E店可以识别的 唯一码
//            // TODO 调用E店接口（HTTP的）
//            HttpUtil HttpUtil = new HttpUtil();
//            try {
//                String s = HttpUtil.doGet(eshopBaseUrl + "/nopaper/sign/getRecall.serv?params=" + data);
//                logger.info("e店返回的消息是：{}",s);
//                JSONObject jsonS = new JSONObject(s);
//
//                if (!jsonS.getBoolean("success")) {
//                    String message = jsonS.getString("message");
//                    logger.info("Call EShop faild！！！！ {}", message);
//                    return new RequestResult(false, message + "[E-0001]");
//                }
//                data = jsonS.getString("data");
//            } catch (Exception e){
//                logger.info("e店信息解析失败",e);
//                return new RequestResult(false, "信息解析失败,请您再试一次。[E-0002]");
//            }
//            // 返回的数据
//            // 使用 SM4 ECB 方式解密信息。
//            byte[] byteData = Base64.getDecoder().decode(data);
//            try {
//                byte[] keyData = secretKey.getBytes(ENCODING);
//                byteData = SM4Util.decrypt_Ecb_Padding(keyData, byteData);
//
//            } catch (UnsupportedEncodingException e) {
//                logger.error("secretKey: {}", secretKey, e);
//                return new RequestResult(false, "秘钥错误无法解密数据！！！");
//            } catch (Exception e) {
//                logger.error("decrypt_Ecb_Padding failed！！！！！", secretKey, e);
//                return new RequestResult(false, "数据解密失败！！！");
//            }
//
//            try {
//                data = new String(byteData, "GBK");
//            } catch (UnsupportedEncodingException e) {
//                logger.info("new String failed！！！", e);
//                return new RequestResult(false, "数据解密失败！！！");
//            }
//            logger.info("data: {}", data);
//            // 利用 TOKEN 验证用户有效性
//            String token = (String) datas.get("token");
//            logger.info("token {}", token);
//            ServiceResult<String, String> tokenRes = tokenManager.findUser(token);
//            if (!tokenRes.isSuccess()) {
////                tokenRes.getFailResult();
//                jsonObject = new JSONObject(tokenRes.getFailResult());
//                JSONArray messages = jsonObject.getJSONArray("messages");
//                String[] _messages = new String[messages.length()];
//                for (int i = 0; i < _messages.length; i++) {
//                    _messages[i] = messages.getString(i);
//                }
//                req.setMessages(_messages);
//                req.put("code", jsonObject.getInt("code"));
//                return req;
//            }
//
//            String userId = tokenRes.getSuccessResult();
//            LSUser user = userDao.getUser(userId);
//
//            if(user == null ){
//                // 理论上 用户不会出现这个情况。
//                req.setMessages("此单业务不属于当前用户，请联系营销员！[E-006]");
//                return req;
//            }
//
//            jsonObject = new JSONObject(data);
//            String agentCode = jsonObject.getJSONObject("user").getString("agentCode");
//            if(!user.getAgentCode().equalsIgnoreCase(agentCode)){
//                logger.info("!userId.equalsIgnoreCase(agentCode) >> userId: {}, agentCode: {} \n data: {}", user.getAgentCode(), agentCode, data);
//                req.setMessages("此单业务不属于当前用户，请联系营销员！[E-003 > AC: " + agentCode + ", CU: " + user.getAgentCode() + "]");
//                return req;
//            }
//        }*/
//
//        // ////////////////////////////////////////////////////
//        // 增加 二维码方式代入   END
//        // ////////////////////////////////////////////////////
//        /*else {*/
//            jsonObject = new JSONObject(data);
//        /*}*/
//        String jumpTermn = jsonObject.getString("jumpTermn");
//
//        //跳转到三大块
//        if (jumpTermn.equals("kinescope")) {//保单录入页面
//            req = simulateService.doKinescope(jsonObject, ot);
//        } else if (jumpTermn.equals("warrantyStatu")) { //跳转到 待上传列表
//            req = simulateService.doWarrantyStatu(data);
//        } else if (jumpTermn.equals("warrantyDetail")) { //调整到 详情页面
//            req = simulateService.doWarrantyDetail(data);
//        } else if (jumpTermn.equals("newLoginOrRegist")){
//            req = simulateService.newLoginOrRegist(data);
//        } else {
//            req.setMessage("参数类型不对");
//        }
//        return req;
//    }
//}
