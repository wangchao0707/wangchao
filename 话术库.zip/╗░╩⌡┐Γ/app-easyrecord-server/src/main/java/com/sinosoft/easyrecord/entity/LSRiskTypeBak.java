package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Date;

/**
 * Created by zf on 2017/8/8.
 */
@Entity
@Table(name = "LSRiskTypeBak")
public class LSRiskTypeBak {
    @Id
    @Column(name = "Id")
    private String id;

    @Column(name = "PPKID")
    private String ppkid;

    @Column(name = "InsurComCode")
    private String insurComCode;

    @Column(name = "RiskType")
    private String riskType;

    @Column(name = "TypeName")
    private String typeName;

    @Column(name = "ComCode")
    private String comCode;

    @Column(name = "BackDate")
    private Date backDate;

    @Column(name = "BackTime")
    private String backTime;


    @Column(name = "OrgCode")
    private String orgCode;

    @Column(name = "Type")
    private String type;


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }


    public LSRiskTypeBak() {
        super();
    }

    public LSRiskTypeBak(String id, LSRiskType lsRiskType, Date backDate, String backTime) {
        this.id = id;
        this.ppkid = lsRiskType.getPpkid();
        this.insurComCode = lsRiskType.getInsurComCode();
        this.riskType = lsRiskType.getRiskType();
        this.typeName = lsRiskType.getTypeName();
        this.comCode = lsRiskType.getComCode();
        this.type = lsRiskType.getType();
        this.backDate = backDate;
        this.backTime = backTime;
    }

    public String getBackTime() {
        return backTime;
    }

    public void setBackTime(String backTime) {
        this.backTime = backTime;
    }

    public void setBackDate(Date backDate) {
        this.backDate = backDate;
    }

    public Date getBackDate() {
        return backDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPpkid() {
        return ppkid;
    }

    public void setPpkid(String ppkid) {
        this.ppkid = ppkid;
    }

    public String getInsurComCode() {
        return insurComCode;
    }

    public void setInsurComCode(String insurComCode) {
        this.insurComCode = insurComCode;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

}
