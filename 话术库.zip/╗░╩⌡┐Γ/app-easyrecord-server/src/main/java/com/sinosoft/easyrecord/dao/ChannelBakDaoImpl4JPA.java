package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSChannelBakRepository;
import com.sinosoft.easyrecord.entity.LSChannelBak;

@Component
public class ChannelBakDaoImpl4JPA implements ChannelBakDao {

    @Autowired
    private LSChannelBakRepository channelBakRepository;

    public void setChannelBakRepository(LSChannelBakRepository channelBakRepository) {
        this.channelBakRepository = channelBakRepository;
    }

    @Override
    public void save(LSChannelBak lsChannelBak) {
        channelBakRepository.saveAndFlush(lsChannelBak);
    }
}
