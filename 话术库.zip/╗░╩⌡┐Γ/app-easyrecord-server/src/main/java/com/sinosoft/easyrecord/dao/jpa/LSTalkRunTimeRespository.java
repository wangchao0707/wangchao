package com.sinosoft.easyrecord.dao.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSTalkRunTime;

public interface LSTalkRunTimeRespository extends JpaRepository<LSTalkRunTime, String> {

    //根据保单号查询 是否有 整改话述
    List<LSTalkRunTime> findByBusiNumAndOperatorAndComCodeAndInsurComCode(String busiNum, String operator, String comCode, String insurComCode);


    List<LSTalkRunTime> findByBusiNum(String busiNum);

    List<LSTalkRunTime> findByContNo(String contNo);
}
