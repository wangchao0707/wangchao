package com.sinosoft.easyrecord.controller;

import com.sinosoft.easyrecord.util.HttpUtil;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by  lijunming
 * on  date 2018-12-11
 * time 18:11
 */
@RestController
@RequestMapping("/sendMessages")
public class TestController {

    @Value(value = "${message.url}")
    private String messageUrl;

    Logger logger=LoggerFactory.getLogger(TestController.class);
    @RequestMapping("/test")
    public String test(){
        // 组织发送 质检消息
        //组织封装数据
        logger.info("start 消息");
        JSONObject sendMap = new JSONObject();
        sendMap.put("sendType","1");
        sendMap.put("sendTo","12010600000621");
        sendMap.put("dataSource","sl");
        sendMap.put("message","亲爱的销售伙伴，您的客户王王编号为1132122500077275投保单需要重新进行双录，请前往【全部订单】【问题件】模块进行操作。");
        sendMap.put("title","质检消息");
        sendMap.put("msgType","sl01");
        sendMap.put("topMsgType","01");
        String result = "";
        //把质检消息发送给e店
        logger.info("xiaoxi {}",sendMap.toString());
        try {
            result = HttpUtil.doPost(messageUrl,sendMap.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("结束");

        return result;
    }
    @RequestMapping("/test1")
    public String test1(){
        // 组织发送 质检消息
        //组织封装数据
        logger.info("start 消息");
        JSONObject sendMap = new JSONObject();
        sendMap.put("sendType","1");
        sendMap.put("sendTo","12010600000621");
        sendMap.put("dataSource","sl");
        sendMap.put("message","亲爱的销售伙伴，您的客户小草编号为1132122500077272投保单需要重新进行双录，请前往【全部订单】【问题件】模块进行操作。");
        sendMap.put("title","质检消息");
        sendMap.put("msgType","sl01");
        sendMap.put("topMsgType","01");
        String result = "";
        //把质检消息发送给e店
        logger.info("xiaoxi {}",sendMap.toString());
        try {
            result = HttpUtil.doPost("http://127.0.0.1:8080/preEasyRecord/forword/sendMessage.html",sendMap.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("结束");

        return result;
    }
    @RequestMapping("/test2")
    public String test2(){
        // 组织发送 质检消息
        //组织封装数据
        logger.info("start 消息");
        JSONObject sendMap = new JSONObject();
        sendMap.put("sendType","1");
        sendMap.put("sendTo","12010600000621");
        sendMap.put("dataSource","sl");
        sendMap.put("message","亲爱的销售伙伴，您的客户小花编号为1132122500077199投保单录音录像文件质检不通过，请您及时联系客户。");
        sendMap.put("title","质检消息");
        sendMap.put("msgType","sl01");
        sendMap.put("topMsgType","01");
        String result = "";
        //把质检消息发送给e店
        logger.info("xiaoxi {}",sendMap.toString());
        try {
            result = HttpUtil.doPost("http://127.0.0.1:8080/preEasyRecord/forword/sendMessage.html",sendMap.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("结束");

        return result;
    }


    public static void main(String[] args) {
        JSONObject sendMap = new JSONObject();
        sendMap.put("sendType","1");
        sendMap.put("sendTo","12010600000621");
        sendMap.put("dataSource","sl");
        sendMap.put("message","亲爱的销售伙伴，您的客户王王编号为1132122500077275投保单需要重新进行双录，请前往【全部订单】【问题件】模块进行操作。");
        sendMap.put("title","质检消息");
        sendMap.put("msgType","sl01");
        sendMap.put("topMsgType","01");
        String result = "";
        //把质检消息发送给e店
        try {
            result = HttpUtil.doPost("http://219.142.53.67/preEasyRecord/forword/sendMessageTest.html",sendMap.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
