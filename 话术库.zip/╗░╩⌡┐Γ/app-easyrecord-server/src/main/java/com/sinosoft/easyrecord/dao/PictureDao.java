package com.sinosoft.easyrecord.dao;

import java.util.List;

import com.sinosoft.easyrecord.entity.LSPicture;
import com.sinosoft.easyrecord.entity.LsContState;

public interface PictureDao {

    void save(LSPicture lsPicture);

    List<LSPicture> findByContNo(String contNo);


    LSPicture findByPicNameAndContNo(String picName, String contNo);

    List<LSPicture> findByContNoAndBusiType(String contNo, String busiType);
    LSPicture findByPid(String pid);
    void  savePicture(LSPicture lsPicture);


    List<LSPicture> findPictureByContnoOrderByTimeNode(String contno);

    LSPicture findByPkIdAndContNo(String pkId,String contNo);

    LSPicture findByPicNo(String picNo);
}
