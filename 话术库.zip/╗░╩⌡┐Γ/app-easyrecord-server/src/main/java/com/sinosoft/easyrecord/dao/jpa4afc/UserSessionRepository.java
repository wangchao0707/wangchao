package com.sinosoft.easyrecord.dao.jpa4afc;

import com.sinosoft.easyrecord.entity4afc.UserSession;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserSessionRepository extends JpaRepository<UserSession,String> {

    List<UserSession> findAllByPublicId(String publicId);
}
