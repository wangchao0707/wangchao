package com.sinosoft.easyrecord.service;

import com.sinosoft.easyrecord.entity.LSFile;

public interface FileService {
    LSFile findByContNo(String contNo);

    void saveFileLog(LSFile fileLog);

    void del(String fileID);
}
