//package com.sinosoft.easyrecord.test;
//
//import com.sinosoft.easyrecord.server.Req800011Impl;
//
///**
// * Description:
// * User: weihao
// * Date: 2018-06-28
// * Time: 11:06
// */
//public class CodeTest {
//
//    public static void main(String[] args) {
//
//        Req800011Impl req800011 = new Req800011Impl();
//        req800011.getReq800011("18733505618","测试内容");
//
//    }
//
//}
