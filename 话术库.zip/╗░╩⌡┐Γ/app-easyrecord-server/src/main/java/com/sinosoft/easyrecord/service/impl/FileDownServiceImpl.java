package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.dao.FileDownDao;
import com.sinosoft.easyrecord.entity.LSFileDown;
import com.sinosoft.easyrecord.service.FileDownService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-08
 * Time: 16:27
 * 产品文件下载 处理
 */
@Service
public class FileDownServiceImpl implements FileDownService{

    @Autowired
    private FileDownDao fileDownDao;

    /**
     * 查询全部 产品文件列表
     **/
    @Override
    public Map findAll() {

        Map<String,Object> resMap = new HashMap<>();

        List<LSFileDown> fileDowns = fileDownDao.findAll();
        if (fileDowns == null || fileDowns.isEmpty()){
            resMap.put("success",false);
            resMap.put("message","产品文件信息为空");
        }else {
            resMap.put("success",true);
            resMap.put("result",fileDowns);
        }

        return resMap;
    }
}
