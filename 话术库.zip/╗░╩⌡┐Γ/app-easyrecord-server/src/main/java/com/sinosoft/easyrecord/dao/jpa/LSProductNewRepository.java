package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSProductNew;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LSProductNewRepository extends JpaRepository<LSProductNew, String> {



    LSProductNew findByProductCode(String productCode);

    List<LSProductNew> findByType(String type);
    void deleteLSProductNewById(String id);
    /**
     * 产品信息和 产品编码 模糊查询
     **/

    List<LSProductNew> findByProductCodeLikeOrProductNameLike(String productCode,String productName);


    List<LSProductNew> findByProductTypeCode(String productTypeCode);


    @Query(value = "select * from LSProductNew where (productCode like ?1 or productName like ?2) and productTypeCode = ?3",nativeQuery = true)
    List<LSProductNew> findByProductCodeLikeOrProductNameLikeAndProductTypeCode(String productCode,String productName,String productTypeCode);


    List<LSProductNew> findByIsDeath(String isDeath);

    List<LSProductNew> findByIsHealth(String isHealth);

    @Query(value = "select * from LSProductNew where (productCode like ?1 or productName like ?2) and isDeath = ?3 ",nativeQuery = true)
    List<LSProductNew> findByProductCodeLikeOrProductNameLikeAndIsDeath(String productName,String produchCode,String isDeath);

    @Query(value = "select * from LSProductNew  where (productCode like ?1 or productName like ?2) and isHealth = ?3",nativeQuery = true)
    List<LSProductNew> findByProductCodeLikeOrProductNameLikeAndIsHealth(String productName,String produchCode,String isHealth);

    @Query(value = "select distinct p.productTypeCode,p.productTypeName from LSProductNew p")
    List<Object[]> findByCode();
}
