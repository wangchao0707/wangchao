package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSVersion;

public interface VersionDao {

    LSVersion findByIsNew(String isNew);

    void saveVision(LSVersion lsVision);

    LSVersion findByIsNewAndComCode(String isNew, String comCode);

}
