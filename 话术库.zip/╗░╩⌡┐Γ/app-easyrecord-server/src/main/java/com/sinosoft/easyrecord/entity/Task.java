package com.sinosoft.easyrecord.entity;

public class Task {
	
	String counterid;// 销售人员工号 (如果为银保业务)此处为银行柜员（客户经理）工号，(如果为保险公司业务)此处为营销员工号，(如果为非银行中介机构业务)此处为营销员工号
	String counterName;// 销售人员姓名
	String counterPhone;// 销售人员电话
	String bankCode;// 销售人员所属机构编码 (如果为银保业务)此处为银行编码,(如果为非银行中介机构业务)中介机构编码
	String subBankCode;// 销售人员所属机构分行编码 (如果为银保业务)此处为银行分行编码
	String nodeBankCode;// 销售人员所属机构网点编码(如果为银保业务)此处为银行网点编码
	int taskSource;// 业务来源 1-银行，2-保险公司，3-非银行中介机构
	String subInsurerCode;// 保险公司代码（省级分公司）
	String product_name;// 产品名称
	String product_code;// 产品代码
	String businessType;//业务识别号类型
	String businessNo;// 业务识别号
	String customerName;// 客户姓名
	int customerCardType;// 客户证件类型
	String customerCardNo;// 客户证件号码
	String customerBirthday;// 客户出生日期
	String videoName;// 视频文件名
	String videoType;// 视频格式类型
	String businessSerialNo;// 业务流水号
	String batchNo;// 批次号
	String content_MD5;// 文件签名
	int payment_term;//交费方式,1-趸缴,2-期缴,3-不定期,4-未指定
	String insurerCode;//保险公司代码
	String record_time;// 录制时间 yyyy-MM-dd HH:mm:ss
	long file_time;// 录制时长/秒
	long file_length;// 文件长度/KB
	String fileLocalPath;//文件本地地址
	String taskType;//任务类型100-承保,	200-理赔,	300-财务（收付）,	400-产品,	500-保全,	999-其他
	String insuranceperiod;//保障期限1-一年期以下，2-一年期以上3-不限
	long payment_year;//缴费年限
	double premium;//保费
	String branchUnitCode;//支公司编码

	public String getBranchUnitCode() {
		return branchUnitCode;
	}

	public void setBranchUnitCode(String branchUnitCode) {
		this.branchUnitCode = branchUnitCode;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getInsuranceperiod() {
		return insuranceperiod;
	}

	public void setInsuranceperiod(String insuranceperiod) {
		this.insuranceperiod = insuranceperiod;
	}

	public long getPayment_year() {
		return payment_year;
	}

	public void setPayment_year(long payment_year) {
		this.payment_year = payment_year;
	}

	public double getPremium() {
		return premium;
	}

	public void setPremium(double premium) {
		this.premium = premium;
	}

	public String getFileLocalPath() {
		return fileLocalPath;
	}

	public void setFileLocalPath(String fileLocalPath) {
		this.fileLocalPath = fileLocalPath;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getRecord_time() {
		return record_time;
	}

	public void setRecord_time(String record_time) {
		this.record_time = record_time;
	}

	public long getFile_time() {
		return file_time;
	}

	public void setFile_time(long file_time) {
		this.file_time = file_time;
	}

	public long getFile_length() {
		return file_length;
	}

	public void setFile_length(long file_length) {
		this.file_length = file_length;
	}

	public String getInsurerCode() {
		return insurerCode;
	}

	public void setInsurerCode(String insurerCode) {
		this.insurerCode = insurerCode;
	}

	public int getPayment_term() {
		return payment_term;
	}

	public void setPayment_term(int payment_term) {
		this.payment_term = payment_term;
	}

	public String getCounterName() {
		return counterName;
	}

	public void setCounterName(String counterName) {
		this.counterName = counterName;
	}

	public String getCounterPhone() {
		return counterPhone;
	}

	public void setCounterPhone(String counterPhone) {
		this.counterPhone = counterPhone;
	}

	public int getTaskSource() {
		return taskSource;
	}

	public void setTaskSource(int taskSource) {
		this.taskSource = taskSource;
	}

	public String getVideoType() {
		return videoType;
	}

	public void setVideoType(String videoType) {
		this.videoType = videoType;
	}

	public String getBusinessSerialNo() {
		return businessSerialNo;
	}

	public void setBusinessSerialNo(String businessSerialNo) {
		this.businessSerialNo = businessSerialNo;
	}

	public String getCounterid() {
		return counterid;
	}

	public void setCounterid(String counterid) {
		this.counterid = counterid;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getSubBankCode() {
		return subBankCode;
	}

	public void setSubBankCode(String subBankCode) {
		this.subBankCode = subBankCode;
	}

	public String getNodeBankCode() {
		return nodeBankCode;
	}

	public void setNodeBankCode(String nodeBankCode) {
		this.nodeBankCode = nodeBankCode;
	}

	public String getSubInsurerCode() {
		return subInsurerCode;
	}

	public void setSubInsurerCode(String subInsurerCode) {
		this.subInsurerCode = subInsurerCode;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_code() {
		return product_code;
	}

	public void setProduct_code(String product_code) {
		this.product_code = product_code;
	}

	public String getBusinessNo() {
		return businessNo;
	}

	public void setBusinessNo(String businessNo) {
		this.businessNo = businessNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerCardType() {
		return customerCardType;
	}

	public void setCustomerCardType(int customerCardType) {
		this.customerCardType = customerCardType;
	}

	public String getCustomerCardNo() {
		return customerCardNo;
	}

	public void setCustomerCardNo(String customerCardNo) {
		this.customerCardNo = customerCardNo;
	}

	public String getCustomerBirthday() {
		return customerBirthday;
	}

	public void setCustomerBirthday(String customerBirthday) {
		this.customerBirthday = customerBirthday;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getContent_MD5() {
		return content_MD5;
	}

	public void setContent_MD5(String content_MD5) {
		this.content_MD5 = content_MD5;
	}
	
	public Task() {}

	public Task(String counterid,String counterName,String counterPhone, String bankCode, String subBankCode, String nodeBankCode, int taskSource,
			String subInsurerCode, String product_name, String product_code, String businessNo, String customerName,
			int customerCardType, String customerCardNo, String customerBirthday, String videoName, String videoType,
			String businessSerialNo, String batchNo, String content_MD5,int payment_term) {
		this.counterid = counterid;
		this.counterName=counterName;
		this.counterPhone=counterPhone;
		this.bankCode = bankCode;
		this.taskSource=taskSource;
		this.subBankCode = subBankCode;
		this.nodeBankCode = nodeBankCode;
		this.subInsurerCode = subInsurerCode;
		this.product_name = product_name;
		this.product_code = product_code;
		this.businessNo = businessNo;
		this.customerName = customerName;
		this.customerCardType = customerCardType;
		this.customerCardNo = customerCardNo;
		this.customerBirthday = customerBirthday;
		this.videoName = videoName;
		this.videoType = videoType;
		this.businessSerialNo = businessSerialNo;
		this.batchNo = batchNo;
		this.content_MD5 = content_MD5;
		this.payment_term=payment_term;
	}

	@Override
	public String toString() {
		return "Task{" +
				"counterid='" + counterid + '\'' +
				", counterName='" + counterName + '\'' +
				", counterPhone='" + counterPhone + '\'' +
				", bankCode='" + bankCode + '\'' +
				", subBankCode='" + subBankCode + '\'' +
				", nodeBankCode='" + nodeBankCode + '\'' +
				", taskSource=" + taskSource +
				", subInsurerCode='" + subInsurerCode + '\'' +
				", product_name='" + product_name + '\'' +
				", product_code='" + product_code + '\'' +
				", businessType='" + businessType + '\'' +
				", businessNo='" + businessNo + '\'' +
				", customerName='" + customerName + '\'' +
				", customerCardType=" + customerCardType +
				", customerCardNo='" + customerCardNo + '\'' +
				", customerBirthday='" + customerBirthday + '\'' +
				", videoName='" + videoName + '\'' +
				", videoType='" + videoType + '\'' +
				", businessSerialNo='" + businessSerialNo + '\'' +
				", batchNo='" + batchNo + '\'' +
				", content_MD5='" + content_MD5 + '\'' +
				", payment_term=" + payment_term +
				", insurerCode='" + insurerCode + '\'' +
				", record_time='" + record_time + '\'' +
				", file_time=" + file_time +
				", file_length=" + file_length +
				", fileLocalPath='" + fileLocalPath + '\'' +
				", taskType='" + taskType + '\'' +
				", insuranceperiod='" + insuranceperiod + '\'' +
				", payment_year=" + payment_year +
				", premium=" + premium +
				", branchUnitCode='" + branchUnitCode + '\'' +
				'}';
	}
}

