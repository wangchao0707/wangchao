package com.sinosoft.easyrecord.service.impl;

import java.io.IOException;
import java.net.URLDecoder;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.json.JSONObject;
//import com.qcloud.Utilities.Json.JSONObject;
import com.alibaba.fastjson.JSONObject;

//import net.minidev.json.JSONObject;
import com.sinosoft.easyrecord.service.OcrVerificationService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public  class OcrVerificationServiceImpl implements OcrVerificationService {
    private final Logger logger = LoggerFactory.getLogger(OcrVerificationServiceImpl.class);
    @Value("${ocr.url}")
    private String url;

    /*public JSONObject httpClientPost(JSONObject enctyptStr){
        //post请求返回结果
    	CloseableHttpClient client = HttpClients.createDefault();
        JSONObject jsonResult = null;
        String url ="https://tfface.aegonthtf.com/tffacerecognize/api/faceRecognize/checkFace";
        logger.error("URL that calls the face interface:"+url);
        HttpPost method = new HttpPost(url);
    	JSONObject reqObject = new JSONObject();
        reqObject.put("request",enctyptStr);
        CloseableHttpResponse result = null;
        try {
            if (null != enctyptStr.get("body")) {
                //解决中文乱码问题
                StringEntity entity = new StringEntity(reqObject.toString(), "utf-8");
                entity.setContentEncoding("UTF-8");
                entity.setContentType("application/json");
                method.setEntity(entity);
            }
            result = client.execute(method);
            url = URLDecoder.decode(url, "UTF-8");
            *//**请求发送成功，并得到响应**//*
            if (result.getStatusLine().getStatusCode() == 200) {
                String str = "";
                try {
                    *//**读取服务器返回过来的json字符串数据**//*
                    str = EntityUtils.toString(result.getEntity());
                    
                    *//**把json字符串转换成json对象
     * @return**//*
                    jsonResult = JSONObject.parseObject(str);
                } catch (Exception e) {
                    logger.error("post请求提交失败:" + url, e);
                }
            }else{
                logger.error("==Wzeus FaceServerImpl httpClientPostpost 请求提交失败:" + url+"==");
            }
        } catch (IOException e) {
            logger.error("==Wzeus FaceServerImpl httpClientPost 请求提交出错:" + url+"==", e);
        } finally {
        	if(result != null){
                try {
                	result.close();
                } catch (IOException e) {
                	logger.error("==Wzeus OcrVerificationServiceImpl httpClientPost CloseableHttpResponse_close_error==",e);
                }
            }
            if(client != null){
                try {
                	client.close();
                } catch (IOException e) {
                    logger.error("==Wzeus OcrVerificationServiceImpl httpClientPost CloseableHttpClient_close_error==",e);
                }
            }
        }
        return jsonResult;
	}*/

    public JSONObject httpClientPost(JSONObject enctyptStr) {

        //post请求返回结果
        CloseableHttpClient client = HttpClients.createDefault();
        JSONObject jsonResult = null;
        logger.debug("URL that calls the face interface:"+url);
        HttpPost method = new HttpPost(url);
        //JSONObject reqObject = new JSONObject();
        //reqObject.put("request",enctyptStr);
        CloseableHttpResponse result = null;
        try {
            if (null != enctyptStr.get("request")) {
                //解决中文乱码问题
                StringEntity entity = new StringEntity(enctyptStr.toString(), "utf-8");
                entity.setContentEncoding("UTF-8");
                entity.setContentType("application/json");
                method.setEntity(entity);
            }
            result = client.execute(method);
            url = URLDecoder.decode(url, "UTF-8");
            /**请求发送成功，并得到响应**/
            if (result.getStatusLine().getStatusCode() == 200) {
                String str = "";
                try {
                    /**读取服务器返回过来的json字符串数据**/
                    str = EntityUtils.toString(result.getEntity());

                    /**把json字符串转换成json对象**/
                    jsonResult = JSONObject.parseObject(str);
                } catch (Exception e) {
                    logger.error("post请求提交失败:" + url, e);
                }
            }else{
                logger.error("==Wzeus FaceServerImpl httpClientPostpost 请求提交失败:" + url+"==");
            }
        } catch (IOException e) {
            logger.error("==Wzeus FaceServerImpl httpClientPost 请求提交出错:" + url+"==", e);
        } finally {
            if(result != null){
                try {
                    result.close();
                } catch (IOException e) {
                    logger.error("==Wzeus OcrVerificationServiceImpl httpClientPost CloseableHttpResponse_close_error==",e);
                }
            }
            if(client != null){
                try {
                    client.close();
                } catch (IOException e) {
                    logger.error("==Wzeus OcrVerificationServiceImpl httpClientPost CloseableHttpClient_close_error==",e);
                }
            }
        }
        return jsonResult;

    }



}
