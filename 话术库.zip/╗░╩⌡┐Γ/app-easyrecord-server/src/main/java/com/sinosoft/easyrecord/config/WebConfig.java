package com.sinosoft.easyrecord.config;

import com.sinosoft.easyrecord.service.TokenManager;
import com.sinosoft.easyrecord.service.UserService;
import com.sinosoft.easyrecord.service.UserSessionService;
import com.sinosoft.easyrecord.sso.SSOFilter;

import org.apache.axis2.transport.http.AxisServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by WinterLee on 2017/7/14.
 */
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

    static private final Logger logger = LoggerFactory.getLogger(WebConfig.class);

    private String baseDir;

    @Value("${axis2.serverPath}")
    private String serverPath;

//	private String resourcesDir;
//
//	private String uploadDir;

    @Value("${save.filePath}")
    private String filePath;
    @Value("${save.zipPath}")
    private String zipPath;
    @Value("${save.configPath}")
    private String configPath;


    public WebConfig(@Value("#{T(System).getProperty('user.dir')}") String baseDir) {

        logger.info("baseDir:: {}", baseDir);
        this.baseDir = baseDir;

    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String resourcesDir = configPath;
        logger.info("configPath {}", configPath);
        String uploadDir = filePath;
        registry.addResourceHandler("/public/**").addResourceLocations("file:" + resourcesDir + "/");
        logger.info("configPath{}", configPath);
        registry.addResourceHandler("/upload/**").addResourceLocations("file:" + uploadDir + "/");
        registry.addResourceHandler("/private/**").addResourceLocations("classpath:/static/private/");
        registry.addResourceHandler("/**").addResourceLocations("classpath:/static/");
        logger.info("resourceDir:: {}", resourcesDir);
        super.addResourceHandlers(registry);
    }

    @Bean
    public FilterRegistrationBean getDelegatingFilterProxy() {
        DelegatingFilterProxy delegatingFilterProxy = new DelegatingFilterProxy("shiroFilter");

        FilterRegistrationBean frb = new FilterRegistrationBean();
        // frb.setName("shiroFilter");
        frb.setFilter(delegatingFilterProxy);
        frb.addUrlPatterns("/*");

        return frb;
    }

    /*@Bean
    public FilterRegistrationBean getSSOFilter(@Value("${sso.token.httpHeadKey}") String keyToken,
                                               TokenManager tokenManager, UserService userService, UserSessionService userSessionService) {

        SSOFilter ssoFilter = new SSOFilter();
        ssoFilter.setTokenManager(tokenManager);
        ssoFilter.setUserService(userService);
        ssoFilter.setUserSessionService(userSessionService);

        ssoFilter.setKeyToken(keyToken);

        FilterRegistrationBean frb = new FilterRegistrationBean();
        // frb.setName("sso-filter");
        frb.setFilter(ssoFilter);
        frb.addUrlPatterns("/api/*");

        return frb;
    }*/
    @Bean
    public FilterRegistrationBean getSSOFilter(@Value("${sso.token.httpHeadKey}") String keyToken,
                                               TokenManager tokenManager,
                                               UserService userService,
                                               @Autowired UserSessionService userSessionService) {

        SSOFilter ssoFilter = new SSOFilter();
        ssoFilter.setTokenManager(tokenManager);
        ssoFilter.setUserSessionService(userSessionService);
        ssoFilter.setUserService(userService);
        ssoFilter.setKeyToken(keyToken);

        FilterRegistrationBean frb = new FilterRegistrationBean();
        // frb.setName("sso-filter");
        frb.setFilter(ssoFilter);
        frb.addUrlPatterns("/api/*");
        frb.setOrder(15);

        return frb;
    }
    //
    // @Bean
    // HttpMessageConverter<?> getStringHttpMessageConverter() {
    // return new StringHttpMessageConverter();
    // }
    // @Bean
    // HttpMessageConverter<?> getFastJsonHttpMessageConverter() {
    // com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter
    // jsonHttpMessageConverter = new
    // com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter();
    //
    //// Arrays.asList(MediaType.APPLICATION_JSON,MediaType.TEXT_J)
    //// jsonHttpMessageConverter.setSupportedMediaTypes();
    //
    //
    // jsonHttpMessageConverter.setSupportedMediaTypes(Collections.singletonList(MediaType.APPLICATION_JSON));
    // return jsonHttpMessageConverter;
    // }
    //
    // @Override
    // public void extendMessageConverters(List<HttpMessageConverter<?>>
    // converters) {
    // converters.add(getStringHttpMessageConverter());
    // converters.add(getFastJsonHttpMessageConverter());
    // // converters.add(getMarshallingHttpMessageConverter());
    // super.configureMessageConverters(converters);
    // }

//    @Bean
//    public ServletListenerRegistrationBean uploadListener(@Value("${upload.port}") int socketPort, @Value("${save.filePath}") String filePath, @Value("${save.zipPath}") String zipPath) {
//        UploadListener uploadListener = new UploadListener();
//        uploadListener.setPort(socketPort);
//        uploadListener.setUploadTmp(zipPath);
//        uploadListener.setUnZipPathTmp(filePath);
//        ServletListenerRegistrationBean servletListenerRegistrationBean = new ServletListenerRegistrationBean();
//        servletListenerRegistrationBean.setListener(uploadListener);
//        return servletListenerRegistrationBean;
//    }

    @Bean
    public ServletRegistrationBean axisServlet() {
        String resourcesDir = configPath;
        logger.info("configPath {}", configPath);

        AxisServlet axisServlet = new AxisServlet();
        ServletRegistrationBean registration = new ServletRegistrationBean(axisServlet);
        List<String> list = new ArrayList<>();
        list.add("/services/*");
        registration.setUrlMappings(list);
        // registration.addInitParameter("axis2.xml.path",
        // this.baseDir+"/src/main/resources/static/axis2.xml");

        //registration.addInitParameter("axis2.repository.path", resourcesDir + "/WEB-INF/");
  /*      String path=resourcesDir+"/WEB-INF/services/ServerService/META-INF/services.xml";
        logger.info(path);
        registration.addInitParameter("axis2.repository.path", path);*/
        //registration.addInitParameter("axis2.repository.path", resourcesDir + "/WEB-INF/");
        String ajax2Directory="/appdata/tms"+"/resources/WEB-INF/services/ServerService/META-INF/services.xml";
        registration.addInitParameter("axis2.repository.path", serverPath);
        return registration;
    }

    /*
     * <!--<init-param>--> <!--<param-name>axis2.xml.path</param-name>-->
     * <!--<param-value>/WEB-INF/conf/axis2.xml</param-value>-->
     * <!--<param-name>axis2.xml.url</param-name>-->
     * <!--<param-value>http://localhost/myrepo/axis2.xml</param-value>-->
     * <!--<param-name>axis2.repository.path</param-name>-->
     * <!--<param-value>/WEB-INF</param-value>-->
     * <!--<param-name>axis2.repository.url</param-name>-->
     * <!--<param-value>http://localhost/myrepo</param-value>-->
     * <!--</init-param>-->
     */

    /**
     * 文件上传配置
     *
     * @return
     */
    @Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        //单个文件最大  
        factory.setMaxFileSize("10240MB"); //KB,MB  
        /// 设置总上传数据总大小  
        factory.setMaxRequestSize("102400MB");
        return factory.createMultipartConfig();
    }

    @Component
    public static class CorsConfig implements Filter {

        final static org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CorsFilter.class);



        public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
            HttpServletResponse response = (HttpServletResponse) res;

            HttpServletRequest reqs = (HttpServletRequest) req;

            response.setHeader("Access-Control-Allow-Origin","*");
            response.setHeader("Access-Control-Allow-Credentials", "true");
            response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
            response.setHeader("Access-Control-Max-Age", "3600");
            response.setHeader("Access-Control-Allow-Headers", "*");
            chain.doFilter(req, res);
        }
        public void init(FilterConfig filterConfig) {}
        public void destroy() {}
    }
}
