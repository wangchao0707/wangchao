package com.sinosoft.easyrecord.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LSAppnt")
public class LSAppnt {

    @Id
    @Column(name = "ContNo")
    private String contNo;

    @Column(name = "AppntNo")
    private String appntNo;
    @Column(name = "ClientContNo")
    private String clientContNo;

    @Column(name = "Name")
    private String name;//投保人姓名

    @Column(name = "Sex")
    private String sex;

    @Column(name = "Birthday")
    private Date birthday;

    @Column(name = "Address")
    private String address;

    @Column(name = "IDType")
    private String idType;

    @Column(name = "IDNo")
    private String idNo;

    @Column(name = "Operator")
    private String operator;

    @Column(name = "MakeDate")
    private Date makeDate;

    @Column(name = "MakeTime")
    private String makeTime;

    @Column(name = "ModifyDate")
    private Date modifyDate;

    @Column(name = "ModifyTime")
    private String modifyTime;

    @Column(name = "Age")
    private String age;

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getAppntNo() {
        return appntNo;
    }

    public void setAppntNo(String appntNo) {
        this.appntNo = appntNo;
    }

    public String getClientContNo() {
        return clientContNo;
    }

    public void setClientContNo(String clientContNo) {
        this.clientContNo = clientContNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public Date getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(Date makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }


    @Override
    public String toString() {
        return "LSAppnt{" +
                "contNo='" + contNo + '\'' +
                ", appntNo='" + appntNo + '\'' +
                ", clientContNo='" + clientContNo + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", birthday=" + birthday +
                ", address='" + address + '\'' +
                ", idType='" + idType + '\'' +
                ", idNo='" + idNo + '\'' +
                ", operator='" + operator + '\'' +
                ", makeDate=" + makeDate +
                ", makeTime='" + makeTime + '\'' +
                ", modifyDate=" + modifyDate +
                ", modifyTime='" + modifyTime + '\'' +
                ", age='" + age + '\'' +
                '}';
    }
}
