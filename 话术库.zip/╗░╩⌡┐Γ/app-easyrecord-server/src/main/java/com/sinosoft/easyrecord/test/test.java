package com.sinosoft.easyrecord.test;

import it.sauronsoftware.jave.*;
import org.springframework.util.StringUtils;

import java.io.File;

/**
 * Description:
 * User: weihao
 * Date: 2018-06-26
 * Time: 10:59
 */
public class test {

    public static void main(String[] args) {

////        String a = "a?replace?b?replace?c";
//        String b = "##replace##b##replace##c##replace##b##replace##c";
//        String[] as = b.split("##replace##");
//
//        System.out.println("b".contains("1"));
//
//        String begin = as[0];
//        if (StringUtils.isEmpty(begin)){
//            begin = "begin";
//        }
//        String end = as[as.length-1];
//        String home = "";
//        for (String str :as ){
//            if (str.contains(begin) || str.contains(end)){
//
//            } else {
//                home +=str;
//            }
//        }
//        if (begin.equals("begin")){
//            begin = "";
//        }
//        String c = begin+home+end;
//        System.out.println(c);

        try {
            changeToMp4(new File("D:/123.avi"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

        public static void changeToMp4(File file) {
			File source =file;
			String fileName = file.getName().substring(0, file.getName().lastIndexOf("."));
			File dirFile = file.getParentFile();
			File target = new File(dirFile,fileName+".mp4");
			AudioAttributes audio = new AudioAttributes();
			audio.setCodec("libfaac");
			audio.setBitRate(new Integer(96000));
			audio.setChannels(new Integer(1));
			audio.setSamplingRate(new Integer(22050));
			VideoAttributes video = new VideoAttributes();
			video.setCodec("mpeg4");//mpeg4
			video.setBitRate(new Integer(512000));
			video.setFrameRate(new Integer(15));
			video.setSize(new VideoSize(1280, 720));
			EncodingAttributes attrs = new EncodingAttributes();
			attrs.setFormat("mp4");//mpegvideo
			attrs.setAudioAttributes(audio);
			attrs.setVideoAttributes(video);
			Encoder encoder = new Encoder();
			try {
				encoder.encode(source, target, attrs);
			} catch (EncoderException e) {
				e.printStackTrace();
			}
			System.out.println(target.getName());
		}

}
