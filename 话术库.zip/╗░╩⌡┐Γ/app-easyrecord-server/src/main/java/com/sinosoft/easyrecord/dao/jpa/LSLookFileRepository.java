package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSLookFile;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by wh on 2018/3/3.
 */
public interface LSLookFileRepository extends JpaRepository<LSLookFile,String>{


    LSLookFile findTop1ByContState(String contState);

    LSLookFile findTop1ByContStateAndContNo(String contState,String contNo);

}
