package com.sinosoft.easyrecord.server;

public interface CoreInteractiveFactory {

    CoreInteractive getInstance(String comCode);
}
