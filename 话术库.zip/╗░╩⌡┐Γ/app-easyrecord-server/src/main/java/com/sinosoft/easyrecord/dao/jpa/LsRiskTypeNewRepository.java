package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LsRiskTypeNew;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LsRiskTypeNewRepository extends JpaRepository<LsRiskTypeNew,String> {
}
