package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.VideoUploadCloud;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

public interface VideoUploadCloudDao {

    void insertOrUpdate(VideoUploadCloud videoUploadCloud);
    VideoUploadCloud getUploadStatus(String uploadStatus);
}

