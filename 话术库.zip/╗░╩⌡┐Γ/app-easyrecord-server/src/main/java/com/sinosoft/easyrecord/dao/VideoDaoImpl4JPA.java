package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSVieoRepository;
import com.sinosoft.easyrecord.entity.LSVideo;

@Component("videoDao")
public class VideoDaoImpl4JPA implements VideoDao {
    @Autowired
    private LSVieoRepository lsVieoRepository;

    public void setLsVieoRepository(LSVieoRepository lsVieoRepository) {
        this.lsVieoRepository = lsVieoRepository;
    }

    @Override
    public void save(LSVideo lsVideo) {
        lsVieoRepository.saveAndFlush(lsVideo);
    }


    @Override
    public LSVideo findByContNoAndClientContNo(String contNo, String clientContNo) {
        return lsVieoRepository.findByContNoAndClientContNo(contNo, clientContNo);
    }

    @Override
    public LSVideo findByContNo(String contNo) {
        return lsVieoRepository.findByContNo(contNo);
    }

//	@Override
//	public LSVideo findByVideoNameAndContNo(String videoName, String ContNo) {
//		return lsVieoRepository.findByVideoNameAndContNo(videoName, ContNo);
//	}


    @Override
    public LSVideo getVideoStateByCloudFileId(String cloudFileId) {
        return lsVieoRepository.findTop1ByCloudFileId(cloudFileId);
    }

    @Override
    public void saveVideo(LSVideo lsVideo) {
        lsVieoRepository.saveAndFlush(lsVideo);

    }
}
