package com.sinosoft.easyrecord.entity;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "QCloudPushEvent")
public class QCloudPushEvent implements Serializable {

    @EmbeddedId
    protected QCloudPushEventPK pk;

    @Column(name = "EventContent")
    private String eventContent;

    @Column(name = "Status")
    private char status = '0';

    @Column(name = "DealBeginTIme")
    private String dealBeginTIme;

    @Column(name = "MakeTime")
    private String makeTime;

    @Column(name = "DealNodeKey")
    private String dealNodeKey;

    public QCloudPushEvent(QCloudPushEventPK pk) {
        this.pk = pk;
    }

    public QCloudPushEvent() {
        this(new QCloudPushEventPK());
    }

    public QCloudPushEvent(String comCode, String msgHandle) {
        this(new QCloudPushEventPK(comCode, msgHandle));
    }

    public QCloudPushEventPK getPk() {
        return pk;
    }

    public void setPk(QCloudPushEventPK pk) {
        this.pk = pk;
    }

    public String getComCode() {
        return pk.getComCode();
    }

    public void setComCode(String comCode) {
        pk.setComCode(comCode);
    }

    public String getMsgHandle() {
        return pk.getMsgHandle();
    }

    public void setMsgHandle(String msgHandle) {
        pk.setMsgHandle(msgHandle);
    }

    public String getEventContent() {
        return eventContent;
    }

    public void setEventContent(String eventContent) {
        this.eventContent = eventContent;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public String getDealBeginTIme() {
        return dealBeginTIme;
    }

    public void setDealBeginTIme(String dealBeginTIme) {
        this.dealBeginTIme = dealBeginTIme;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getDealNodeKey() {
        return dealNodeKey;
    }

    public void setDealNodeKey(String dealNodeKey) {
        this.dealNodeKey = dealNodeKey;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("pk", pk)
                .append("eventContent", eventContent)
                .append("status", status)
                .append("dealBeginTIme", dealBeginTIme)
                .append("makeTime", makeTime)
                .append("dealNodeKey", dealNodeKey)
                .toString();
    }

    ///////////////////////////////////////////////////////////////

    @Embeddable
    public static class QCloudPushEventPK implements Serializable {

        @Column(name = "ComCode")
        private String comCode;
        @Column(name = "MsgHandle")
        private String MsgHandle;

        public QCloudPushEventPK() {
        }

        public QCloudPushEventPK(String comCode, String msgHandle) {
            this.comCode = comCode;
            MsgHandle = msgHandle;
        }

        public String getComCode() {
            return comCode;
        }

        public void setComCode(String comCode) {
            this.comCode = comCode;
        }

        public String getMsgHandle() {
            return MsgHandle;
        }

        public void setMsgHandle(String msgHandle) {
            MsgHandle = msgHandle;
        }


        @Override
        public boolean equals(Object o) {
            if (this == o) return true;

            if (o == null || getClass() != o.getClass()) return false;

            QCloudPushEventPK that = (QCloudPushEventPK) o;

            return new EqualsBuilder()
                    .append(getComCode(), that.getComCode())
                    .append(getMsgHandle(), that.getMsgHandle())
                    .isEquals();
        }

        @Override
        public int hashCode() {
            return new HashCodeBuilder(17, 37)
                    .append(getComCode())
                    .append(getMsgHandle())
                    .toHashCode();
        }

        @Override
        public String toString() {
            return new ToStringBuilder(this)
                    .append("comCode", comCode)
                    .append("MsgHandle", MsgHandle)
                    .toString();
        }
    }

}
