package com.sinosoft.easyrecord.sso;

import com.sinosoft.easyrecord.dao.AuthenticationDao;
import com.sinosoft.easyrecord.dao.UserDao;
import com.sinosoft.easyrecord.entity.LSAuthentication;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.util.MD5;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by WinterLee on 2017/7/14.
 */
@Component("UserPwdAuthorizingRealm")
public class UserPwdAuthorizingRealm extends AuthorizingRealm {

    final static private Logger logger = LoggerFactory.getLogger(UserPwdAuthorizingRealm.class);


    private AuthenticationDao authenticationDao;

    private UserDao userDao;

    public UserPwdAuthorizingRealm() {
        logger.info("UserPwdAuthorizingRealm()");
    }


    @Autowired
    public void setAuthenticationDao(AuthenticationDao authenticationDao) {
        this.authenticationDao = authenticationDao;
    }

    @Autowired
    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    /**
     * 这里没有想清楚 角色的问题，所以硬代码所有用户都给 user 的权限。
     *
     * @param principalCollection
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {

        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        Set<String> roleSet = new HashSet<>(1);
        roleSet.add("user");

        info.setRoles(roleSet);

        return info;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        String loginName = (String) authenticationToken.getPrincipal();
        String loginNames[] = loginName.split("<,>");
        String randomCode = loginNames[1];
        LSUser user = userDao.getByPhoneNo(loginNames[0]);
        logger.info("loginName {} userId {}", loginName, loginNames[0]);
        if (user == null) {
            AuthenticationException ex = new AuthenticationException("user[loginName: " + loginNames[0] + "] is not found!!!");
            throw new SinoAuthenticationException("用户名或密码错误", ex);
        }

 /*       if ("1".equals(user.getUseFalg())) {
            AuthenticationException ex = new AuthenticationException("user[userId: " + user.getUserId() + ",loginName: " + loginName + "] UseFalg is " + user.getUseFalg());
            throw new SinoAuthenticationException("当前用户正在注册审核，请稍候。", ex);
        }*/

        if ("1".equals(user.getWorkFlag())) {
            AuthenticationException ex = new AuthenticationException("user[userId: " + user.getUserId() + ",loginName: " + loginName + "] WorkFlag is " + user.getWorkFlag());
            throw new SinoAuthenticationException("当前用户已离职!", ex);
        }

        LSAuthentication authobj = authenticationDao.getAuthentication(user.getUserId());
        String password = null;
        if(authobj == null ) {
            try {
                String agentCode = user.getAgentCode();
                String _password = null;
                if (agentCode.length() > 6) {
                    _password = agentCode.substring(agentCode.length() - 6, agentCode.length());
                } else {
                    _password = agentCode;
                }
                password = MD5.stringToMD5(_password);
                logger.info("agentCode ::{},password :: {} >> {}", agentCode, _password, password);
                LSAuthentication authentication = new LSAuthentication();
                authentication.setUserId(user.getUserId());
                authentication.setIsDefaultPWD("Y");
                authentication.setPassword(password);
                authenticationDao.save(authentication);
            }catch (Exception ex) {
                RuntimeException _ex = new RuntimeException("用户的密码初始化失败", ex);
                logger.info("agentCode ::{} passwd check failled !!!!!", user.getAgentCode(), ex);
                throw _ex;
            }
        } else {
            password = authobj.getPassword();
        }
        if (password.length() == 31) {
            password = "0" + password;
        }
        logger.error("***********************************************************////////////////////////=========================");
        String passwordM5 = MD5.stringToMD5(password + randomCode).toUpperCase();
        if (StringUtils.isEmpty(password)) {
            AuthenticationException ex = new AuthenticationException("authentication[userId: " + user.getUserId() + ",loginName: " + loginName + "] is not found!!!");
            throw new SinoAuthenticationException("用户名或密码错误", ex);
        }

        AuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user.getUserId(), passwordM5, getName());

        return authenticationInfo;

    }


}


