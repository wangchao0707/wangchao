package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSTalkBak;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Administrator on 2017/8/8.
 */
public interface LSTalkBakRepository extends JpaRepository<LSTalkBak, String> {

}
