package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.ChannelDao;
import com.sinosoft.easyrecord.dao.LMProductDao;
import com.sinosoft.easyrecord.dao.LSComDao;
import com.sinosoft.easyrecord.dao.jpa.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.entity4afc.LMProduct;
import com.sinosoft.easyrecord.entity4afc.LSCom;
import com.sinosoft.easyrecord.service.PolicyService;
import com.sinosoft.easyrecord.util.HttpUtil;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.xml.namespace.QName;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class CoreTimerService {


    private static Logger log = LoggerFactory.getLogger(CoreTimer.class);
    @Value("${core.url}")
    private String url;


    @Autowired
    EsMessageSinkRepository esMessageSinkRepository;
    @Autowired
    private LSContRespository contRespository;
    @Autowired
    private LSAppntRepository appntRepository;
    @Autowired
    private LSComDao lsComDao;
    @Autowired
    private ChannelDao channelDao;
    @Autowired
    private LMProductDao lmProductDao;
    @Autowired
    private PolicyService policyService;
    @Autowired
    private EsVideoMainRepository esVideoMainRepository;
    @Autowired
    private LSMessageRepository messageRepository;


    public void sendMsgToCore(String date) throws Exception {
        //查询待推送数据
        List<EsMessageSink> list =getSendAll(date);
       /* List<EsMessageSink> list =new ArrayList<>();
        EsMessageSink esMessageSink=new EsMessageSink();
        esMessageSink.setPrtno("1");
        list.add(esMessageSink);*/
       /* EsMessageSink esMessageSink1=new EsMessageSink();
        esMessageSink1.setPrtno("2");
        list.add(esMessageSink1);*/
        if(null==list || list.size()==0){
            log.info("没有要推送的数据");
            return;
        }
        log.info("查询到待推送有:"+list.size());
        //封装xml
        String xmlStr = xmlToString(list);
        log.info("xml 报文"+xmlStr);

        if(StringUtils.isEmpty(xmlStr)){
            log.info("xml 组装数据为空");
            return;
        }
      /*  String method="process";
        String nameSpace = "http://plis-uat1.internal.aegonthtf.com/services/InterfaceAdapterPortal";*/
        //推送数据
        sendService(xmlStr, url);
        /*result.replace("&lt;","<").replace("&gt;",">");
        log.info("result:{}"+result);
        JSONObject jsonObject = stringToJSONObject(result);
        log.info("jsonObject:{}"+jsonObject.toString());
        log.info("returnFlag:{}"+jsonObject.getString("returnFlag"));*/
    }

    public List<EsMessageSink> getSendAll(String date){
        //TODO
        return  esMessageSinkRepository.getAllByTime(date);
    }


    public String xmlToString(List<EsMessageSink> list) {
        String xmlStr = "";
        if (null != list && list.size() > 0) {
            Document xmlDoc = DocumentHelper.createDocument();
            Element root = xmlDoc.addElement("LisCallRequest");
            Element RequestHead = root.addElement("RequestHead");
            RequestHead.addElement("ServiceID").setText("DoubleRecord");
            RequestHead.addElement("ClientID").setText("ZKR");
            RequestHead.addElement("TransCode").setText("");
            RequestHead.addElement("TransType").setText("");
            RequestHead.addElement("TransDate").setText("");
            RequestHead.addElement("SignMsg").setText("");
            Element RequestBody = root.addElement("RequestBody");
            Element TaskMsgList = RequestBody.addElement("TaskMsgList");
            for (EsMessageSink esMessageSink : list) {
                Element TaskMsg = TaskMsgList.addElement("TaskMsg");
                List<LSCont> lsConts = contRespository.findByBusiNum(esMessageSink.getPrtno());
                LSCont lsCont = null;
                if (lsConts.size()!=0){
                    lsCont = lsConts.get(0);
                }
                LSCom lsCom = null;
                LSChannel channel = null;
                LSAppnt lsAppnt = null;
                String riskType = "";
                LSUser lsUser = null;
                LSMessage lsMessage = null;
                if (lsCont!=null){
                    lsCom = lsComDao.findByComcode(lsCont.getComCode());
                    channel = channelDao.findChannel(lsCont.getChannel());
                    lsAppnt = appntRepository.findByContNo(lsCont.getContNo());
                    riskType = lsCont.getRiskType();
                    lsUser = policyService.findUserByUserId(lsCont.getOperator());
                }
                String productName = "";
                if (null!=riskType && !"".equals(riskType)) {
                    if (riskType.contains(",")) {
                        String[] riskTypes = riskType.split(",");
                        if (riskTypes.length != 0) {
                            for (int i = 0; i < riskTypes.length; i++) {
                                LMProduct product = lmProductDao.findByProductCode(riskTypes[i]);
                                productName = productName + product.getProductName() + "  ";
                            }
                        }
                    } else {
                        LMProduct byProductCode = lmProductDao.findByProductCode(riskType);
                        if (null!=byProductCode && !"".equals(byProductCode)){
                            productName = byProductCode.getProductName();
                        }
                    }
                }
                EsVideoMain esVideoMain = esVideoMainRepository.findUpLoadCountByDocCode(esMessageSink.getPrtno());
                List<LSCont> l = contRespository.findByBusiNumAndInteractive(esMessageSink.getPrtno(), "L");
                Integer rejectionNumber = l.size();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                //投保单号
                if (null!=esMessageSink.getPrtno() && !"".equals(esMessageSink.getPrtno())){
                    TaskMsg.addElement("PolicyNo").setText(esMessageSink.getPrtno());
                }
                //机构名称
                if (lsCom!=null){
                    if (null!=lsCom.getComname() && !"".equals(lsCom.getComname())){
                        TaskMsg.addElement("ComName").setText(lsCom.getComname());
                    }else{
                        TaskMsg.addElement("ComName").setText("");
                    }
                }else{
                    TaskMsg.addElement("ComName").setText("");
                }
                //渠道名称
                if (channel!=null){
                    if (null!=channel.getChannelName() && !"".equals(channel.getChannelName())){
                        TaskMsg.addElement("ChannelName").setText(channel.getChannelName());//
                    }else{
                        TaskMsg.addElement("ChannelName").setText("");
                    }
                }else{
                    TaskMsg.addElement("ChannelName").setText("");
                }
                //业务识别号
                if (null!=esMessageSink.getPrtno() && !"".equals(esMessageSink.getPrtno())){
                    TaskMsg.addElement("IdentificationNo").setText(esMessageSink.getPrtno());
                }
                //双录编号
                if (null!=esMessageSink.getPrtno() && !"".equals(esMessageSink.getPrtno())){
                    TaskMsg.addElement("TaskId").setText(esMessageSink.getPrtno());
                }
                //销售人员姓名
                if (lsCont!=null){
                    if (null!=lsCont.getOperatorName() && !"".equals(lsCont.getOperatorName())){
                        TaskMsg.addElement("SalePersonName").setText(lsCont.getOperatorName());
                    }else{
                        TaskMsg.addElement("SalePersonName").setText("");
                    }
                }else{
                    TaskMsg.addElement("SalePersonName").setText("");
                }
                //销售人员编码
                if (lsUser!=null){
                    if (null!=lsUser.getAgentCode() && !"".equals(lsUser.getAgentCode())){
                        TaskMsg.addElement("SalePersonCode").setText(lsUser.getAgentCode());
                    }else{
                        TaskMsg.addElement("SalePersonCode").setText("");
                    }
                }else{
                    TaskMsg.addElement("SalePersonCode").setText("");
                }
                //投保人姓名
               if (lsAppnt!=null){
                   if (null!=lsAppnt.getName() && !"".equals(lsAppnt.getName())){
                       TaskMsg.addElement("AppntName").setText(lsAppnt.getName());
                   }else{
                       TaskMsg.addElement("AppntName").setText("");
                   }
               }else{
                   TaskMsg.addElement("AppntName").setText("");
               }
               //产品名称
                if (null!=productName && !"".equals(productName)){
                    TaskMsg.addElement("ProductName").setText(productName);
                }else{
                    TaskMsg.addElement("ProductName").setText("");
                }
                //是否质检
                if (null!=esMessageSink.getPrtno() && !"".equals(esMessageSink.getPrtno())){
                    TaskMsg.addElement("IsAutomatically").setText("0");
                }
                //质检结果
                if (esVideoMain!=null){
                    if (null!=esVideoMain.getStatus()){
                        if (esVideoMain.getStatus().equals("0")){
                            TaskMsg.addElement("QualityResult").setText("0"); //
                            TaskMsg.addElement("QualityDescribe").setText("未质检");
                        }else{
                            List<LSMessage> LSMessages = messageRepository.findByContNo(esVideoMain.getBusinessNo());
                            if (null!=LSMessages && LSMessages.size()!=0){
                                lsMessage = LSMessages.get(0);
                            }
                            if (null!=esVideoMain.getVerdict()){
                                if (null!=lsMessage.getTitle()){
                                    if (esVideoMain.getStatus().equals("1")&&esVideoMain.getVerdict().equals("0")){
                                        TaskMsg.addElement("QualityResult").setText("1"); //
                                        TaskMsg.addElement("QualityDescribe").setText(lsMessage.getTitle());
                                    }
                                    if (esVideoMain.getStatus().equals("1")&&esVideoMain.getVerdict().equals("1")){
                                        TaskMsg.addElement("QualityResult").setText(""); //
                                        TaskMsg.addElement("QualityDescribe").setText("质检不通过："+lsMessage.getTitle());
                                    }
                                    if (esVideoMain.getStatus().equals("1")&&esVideoMain.getVerdict().equals("2")){
                                        TaskMsg.addElement("QualityResult").setText("2"); //
                                        TaskMsg.addElement("QualityDescribe").setText(lsMessage.getTitle());
                                    }
                                }
                            }else{
                                if (esVideoMain.getStatus().equals("2")){
                                    TaskMsg.addElement("QualityResult").setText(""); //
                                    TaskMsg.addElement("QualityDescribe").setText("正在质检中");
                                }
                            }
                        }
                    }
                }else{
                    TaskMsg.addElement("QualityResult").setText("");
                    TaskMsg.addElement("QualityDescribe").setText("");
                }
                //被驳回次数
                if (null!=rejectionNumber && !"".equals(rejectionNumber)){
                    TaskMsg.addElement("RejectionNumber").setText(rejectionNumber+"");
                }else{
                    TaskMsg.addElement("RejectionNumber").setText("");
                }
                //质检次数
                if (null!=esVideoMain.getQcRecordCount() && !"".equals(esVideoMain.getQcRecordCount())){
                    TaskMsg.addElement("QualityNumber").setText(esVideoMain.getQcRecordCount());
                }else{
                    TaskMsg.addElement("QualityNumber").setText("");
                }
                //最后一次质检日期
                if (null!=esVideoMain){
                    if (esVideoMain.getStatus().equals("0")){
                        TaskMsg.addElement("QualityDate").setText("");
                    }else{
                        if (null!=esVideoMain.getModifyDate() && !"".equals(esVideoMain.getModifyDate())){
                            TaskMsg.addElement("QualityDate").setText(simpleDateFormat.format(esVideoMain.getModifyDate()));
                        }else{
                            TaskMsg.addElement("QualityDate").setText("");
                        }
                    }
                }
                //上传时间
                if (null!=esVideoMain.getUploadDate() && !"".equals(esVideoMain.getUploadDate())){
                    TaskMsg.addElement("UploadTime").setText(esVideoMain.getUploadDate()+" "+esVideoMain.getUploadTime());
                }else{
                    TaskMsg.addElement("UploadTime").setText("");
                }
                //状态码   待确定
                if (lsCont!=null){
                    if (null!=lsCont.getInteractive() && !"".equals(lsCont.getInteractive())){
                        TaskMsg.addElement("Status").setText(lsCont.getInteractive());
                    }else{
                        TaskMsg.addElement("Status").setText("");
                    }
                }else{
                    TaskMsg.addElement("Status").setText("");
                }
                //新单/保全区分标记
                TaskMsg.addElement("ModuleType").setText("NB");

                //TaskMsg.addElement("SaleName").setText("");     //待处理
                //TaskMsg.addElement("SaleCode").setText("");     //待处理
            }

            xmlStr = xmlDoc.getRootElement().asXML();
            log.info("xml 报文"+xmlStr);
           /* OutputFormat format = OutputFormat.createPrettyPrint();
            format.setEncoding("UTF-8");    // 指定XML编码
            StringWriter writerStr = new StringWriter();
            XMLWriter xmlw = new XMLWriter(writerStr, format);
            try {
                xmlw.write(xmlDoc);
                xmlw.close();
            } catch (IOException e) {
            }
            xmlStr = writerStr.getBuffer().toString();*/
        }
        if(StringUtils.isNotEmpty(xmlStr)){
            xmlStr=xmlStr.replaceAll("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","");
            xmlStr="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://webservice.aegon_cnooc.com\">\n" +
                    "    <soapenv:Header/>\n" +
                    "    <soapenv:Body>\n" +
                    "        <web:process>\n" +
                    "            <web:requestStr>\n" +
                    "                <![CDATA["
                    +xmlStr
                    +"]]></web:requestStr>\n" +
                    "</web:process>\n" +
                    "</soapenv:Body>\n" +
                    "</soapenv:Envelope>";
        }
        log.info("xml 报文"+xmlStr);
        return xmlStr;
    }

    private void sendService(String xmlStr, String url) throws Exception {
       /* String result = "";
        ServiceClient serviceClient = new ServiceClient();*/
        String result = HttpUtil.doPostTo(url, xmlStr);
        log.info("result:"+result);
    }

    /*private JSONObject stringToJSONObject(String xmlStr){
        JSONObject jsonObject = new JSONObject();
        try{
            Document xmlDocument = DocumentHelper.parseText(xmlStr);
            OutputFormat outputFormat = new OutputFormat();
            outputFormat.setEncoding("UTF-8");
            outputFormat.setExpandEmptyElements(true);
            StringWriter stringWriter = new StringWriter();
            XMLWriter xmlWriter = new XMLWriter(stringWriter,outputFormat);
            try{
                xmlWriter.write(xmlDocument);
                xmlWriter.flush();
            }catch (IOException e){
                e.printStackTrace();
            }
            jsonObject = XML.toJSONObject(stringWriter.toString());
        }catch (DocumentException e){
            e.printStackTrace();
        }catch (JSONException e){
            e.printStackTrace();
        }
        return jsonObject;
    }*/

}
