package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSTalk;
import com.sinosoft.easyrecord.entity.LSTalkNew;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface LSTalkNewRepository extends JpaRepository<LSTalkNew, String> {
    //查询对应的步骤和话术
    //  @Query("select * from LSTalk where ComCode=?1 and InsurComCode=?2 and RiskType=?3 order by OrderNum")
    List<LSTalkNew> findByComCodeAndInsurComCodeAndRiskTypeOrderByOrderNumAsc(String comCode, String insurComCode, String riskType);

    List<LSTalkNew> findByComCode(String comCode);

    //删除方法
    @Modifying
    @Transactional
    @Query(value = "delete from LSTalkNew where ComCode=?1", nativeQuery = true)
    void deleteByComCode(String comCode);

    List<LSTalkNew> findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(String comCode, String insurComCode, String orgCode, String riskType);

    LSTalkNew findByPkid(String pkId);

    LSTalkNew findTop1ByTalkPointCode(String talkPointCode);
}