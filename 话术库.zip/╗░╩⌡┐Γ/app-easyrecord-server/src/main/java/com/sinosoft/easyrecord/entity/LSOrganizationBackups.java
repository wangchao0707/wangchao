package com.sinosoft.easyrecord.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by LJW on 2017/8/9.
 */
@Entity
@Table(name = "LSOrganizationBackups")
public class LSOrganizationBackups implements Serializable {

    @Id
    @Column(name = "Id")
    private String id;

    @Column(name = "ComCode")
    private String comCode;

    @Column(name = "OrgCode")
    private String orgCode;

    @Column(name = "OrgName")
    private String orgName;

    @Column(name = "ModifyDate")
    private Date modifyDate;

    @Column(name = "ModifyTime")
    private String modifyTime;
    @Column(name = "UpComCode")
    private String upComCode;
    @Column(name = "UpComName")
    private String upComName;


    public String getUpComCode() {
        return upComCode;
    }

    public void setUpComCode(String upComCode) {
        this.upComCode = upComCode;
    }

    public String getUpComName() {
        return upComName;
    }

    public void setUpComName(String upComName) {
        this.upComName = upComName;
    }

    public String getComCode() {
        return comCode;
    }

    public void setComCode(String comCode) {
        this.comCode = comCode;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("LSOrganizationBackUps{");
        sb.append("id='").append(id).append('\'');
        sb.append(",comCode='").append(comCode).append('\'');
        sb.append(", orgCode='").append(orgCode).append('\'');
        sb.append(", orgName='").append(orgName).append('\'');
        sb.append(", modifyDate='").append(modifyDate).append('\'');
        sb.append(", modifyTime='").append(modifyTime).append('\'');
        sb.append('}');
        return sb.toString();
    }


}
