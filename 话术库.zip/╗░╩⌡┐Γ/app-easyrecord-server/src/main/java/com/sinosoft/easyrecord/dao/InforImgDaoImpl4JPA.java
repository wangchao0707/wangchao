package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSInforImgRepository;
import com.sinosoft.easyrecord.entity.LSInforImg;

@Component
public class InforImgDaoImpl4JPA implements InforImgDao {

    @Autowired
    private LSInforImgRepository lsInforImgRepository;

    public void setLsInforImgRepository(LSInforImgRepository lsInforImgRepository) {
        this.lsInforImgRepository = lsInforImgRepository;
    }

    @Override
    public void save(LSInforImg lsInforImg) {
        lsInforImgRepository.saveAndFlush(lsInforImg);
    }
}
