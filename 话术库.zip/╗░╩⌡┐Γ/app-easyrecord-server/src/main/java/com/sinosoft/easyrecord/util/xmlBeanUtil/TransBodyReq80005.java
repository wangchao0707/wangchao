package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransBodyReq80005 implements Transbody, Serializable {

    private static final long serialVersionUID = -5124637531596248243L;

    private QCFEEDBACKS QCFEEDBACKS;


    public QCFEEDBACKS getQCFEEDBACKS() {
        return QCFEEDBACKS;
    }


    public void setQCFEEDBACKS(QCFEEDBACKS qCFEEDBACKS) {
        QCFEEDBACKS = qCFEEDBACKS;
    }

    public static class QCFEEDBACKS {
        public String QCFEEDBACKCOUNT;  //<!--数据条数-->
        public String ISFLAG;  //判断是否质检通过
        public String BUSINESSNO;//<!-- 业务流水号 -->
        public List<QCFEEDBACK> QCFEEDBACK = new ArrayList<QCFEEDBACK>();
    }


    public static class QCFEEDBACK {
        public String DOCCODE;//<!-- 投保单号码 -->
        public String ISSUETYPES;//<!-- 问题类型 -->
        public String ISSUEDESC;//<!-- 问题描述 -->
        public String ISSUEDATE;//<!-- 问题下发时间 -->
        public String QCOPERATOR;//<!-- 质检人 -->
        public String AGENTID;//<!-- 代理人 -->
    }


}
