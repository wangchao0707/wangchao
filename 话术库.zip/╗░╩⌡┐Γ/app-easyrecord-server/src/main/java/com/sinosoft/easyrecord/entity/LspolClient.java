package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "lspol_client")
public class LspolClient implements Serializable{
  @Column(name = "CONTNO")
  private String contno;
  @Id
  @Column(name = "POLNO")
  private String polno;
  @Column(name = "RISKCODE")
  private String riskcode;
  @Column(name = "RISKNAME")
  private String riskname;
  @Column(name = "SALECHNL")
  private String salechnl;
  @Column(name = "INSUREDNO")
  private String insuredno;
  @Column(name = "APPNTNO")
  private String appntno;
  @Column(name = "PAYENDYEAR")
  private String payendyear;//缴费期间
  @Column(name = "INSUYEAR")
  private String insuyear;//保险期间
  @Column(name = "PAYINTV")
  private String payintv;//缴费类别
  @Column(name = "PREM")
  private double prem;//保费
  @Column(name = "MAKEDATE")
  private java.sql.Date makedate;
  @Column(name = "MAKETIME")
  private String maketime;
  @Column(name = "MODIFYDATE")
  private java.sql.Date modifydate;
  @Column(name = "MODIFYTIME")
  private String modifytime;


  public String getContno() {
    return contno;
  }

  public void setContno(String contno) {
    this.contno = contno;
  }


  public String getPolno() {
    return polno;
  }

  public void setPolno(String polno) {
    this.polno = polno;
  }

  public String getRiskcode() {
    return riskcode;
  }

  public void setRiskcode(String riskcode) {
    this.riskcode = riskcode;
  }

    public String getRiskname() {
        return riskname;
    }

    public void setRiskname(String riskname) {
        this.riskname = riskname;
    }

    public String getSalechnl() {
    return salechnl;
  }

  public void setSalechnl(String salechnl) {
    this.salechnl = salechnl;
  }


  public String getInsuredno() {
    return insuredno;
  }

  public void setInsuredno(String insuredno) {
    this.insuredno = insuredno;
  }

  public String getAppntno() {
    return appntno;
  }

  public void setAppntno(String appntno) {
    this.appntno = appntno;
  }

  public String getPayendyear() {
    return payendyear;
  }

  public void setPayendyear(String payendyear) {
    this.payendyear = payendyear;
  }

  public String getInsuyear() {
    return insuyear;
  }

  public void setInsuyear(String insuyear) {
    this.insuyear = insuyear;
  }


  public String getPayintv() {
    return payintv;
  }

  public void setPayintv(String payintv) {
    this.payintv = payintv;
  }


  public double getPrem() {
    return prem;
  }

  public void setPrem(double prem) {
    this.prem = prem;
  }


  public java.sql.Date getMakedate() {
    return makedate;
  }

  public void setMakedate(java.sql.Date makedate) {
    this.makedate = makedate;
  }


  public String getMaketime() {
    return maketime;
  }

  public void setMaketime(String maketime) {
    this.maketime = maketime;
  }


  public java.sql.Date getModifydate() {
    return modifydate;
  }

  public void setModifydate(java.sql.Date modifydate) {
    this.modifydate = modifydate;
  }


  public String getModifytime() {
    return modifytime;
  }

  public void setModifytime(String modifytime) {
    this.modifytime = modifytime;
  }

    @Override
    public String toString() {
        return "LspolClient{" +
                "contno='" + contno + '\'' +
                ", polno='" + polno + '\'' +
                ", riskcode='" + riskcode + '\'' +
                ", riskname='" + riskname + '\'' +
                ", salechnl='" + salechnl + '\'' +
                ", insuredno='" + insuredno + '\'' +
                ", appntno='" + appntno + '\'' +
                ", payendyear='" + payendyear + '\'' +
                ", insuyear=" + insuyear +
                ", payintv='" + payintv + '\'' +
                ", prem=" + prem +
                ", makedate=" + makedate +
                ", maketime='" + maketime + '\'' +
                ", modifydate=" + modifydate +
                ", modifytime='" + modifytime + '\'' +
                '}';
    }
}
