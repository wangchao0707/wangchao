//package com.sinosoft.easyrecord.service.impl;
//
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import com.sinosoft.almond.commons.transmit.data.ServiceResult;
//import com.sinosoft.easyrecord.dao.UserDao;
//import com.sinosoft.easyrecord.entity.LSUser;
//import com.sinosoft.easyrecord.service.HeadImgService;
//import com.sinosoft.easyrecord.vo.HeadImgForm;
//import org.springframework.util.StringUtils;
//
//@Service
//public class HeadImgServiceImpl implements HeadImgService {
//
////    @Autowired
////    private CmsServiceImpl cmsService;
//
//    @Autowired
//    private UserDao userDao;
//    @Value("${cms.outernet}")
//    private String outernet;
//
//    public void setUserDao(UserDao userDao) {
//        this.userDao = userDao;
//    }
//
//    @Override
//    public ServiceResult<String, String[]> saveHeadImg(HeadImgForm headImgForm) {
//        ServiceResult.Builder<String, String[]> builder = ServiceResult.build(String.class, String[].class);
//        //如何使更新操作 删除原来的文件
//        String userId = headImgForm.getUserID();
//        LSUser user = userDao.getUser(userId);
//        if (user == null) {
//            return builder.createFailResult(new String[]{"您的工作信息没有注册过"});
//        }
//        String imgPath = headImgForm.getImgPath();
//        Map resMap = cmsService.uploadPicture(imgPath,userId);
//        Boolean success = (Boolean) resMap.get("success");
//        if (!success){
//            return builder.createFailResult(new String[]{"上传失败"});
//        }
//        String objectId = (String) resMap.get("objectId");
//        //获取外链地址
//
//        String headurl = cmsService.getPicture(objectId,"0",30);
//        if(!StringUtils.isEmpty(headurl)) {
//            user.setHeadImg(outernet + headurl);
//        }else{
//            user.setHeadImg("");
//        }
//        userDao.save(user);
//
//        return builder.createSuccessResult(headurl);
//    }
//
//}
