package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "es_video_main")
public class EsVideoMain {

    @Id
    @Column(name = "docid")
    private String docId;

    @Column(name = "doccode")
    private String docCode;

    @Column(name = "businessno")
    private String businessNo;

    @Column(name = "uploadcount")
    private String upLoadCount;

    @Column(name = "status")
    private String status;

    @Column(name = "verdict")
    private String verdict;

    @Column(name = "qcrecordcount")
    private String qcRecordCount;

    @Column(name = "modify_date")
    private Date modifyDate;

    @Column(name = "uploaddate")
    private String uploadDate;

    @Column(name = "uploadtime")
    private String uploadTime;



    public String getDocId(){return docId;}

    public void setDocId(String docId){this.docId = docId;}

    public String getDocCode(){return docCode;}

    public void setDocCode(String docCode){this.docCode = docCode;}

    public String getUpLoadCount(){return upLoadCount;}

    public void setUpLoadCount(String upLoadCount){this.upLoadCount = upLoadCount;}

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVerdict() {
        return verdict;
    }

    public void setVerdict(String verdict) {
        this.verdict = verdict;
    }

    public String getQcRecordCount() {
        return qcRecordCount;
    }

    public void setQcRecordCount(String qcRecordCount) {
        this.qcRecordCount = qcRecordCount;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(String uploadDate) {
        this.uploadDate = uploadDate;
    }

    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getBusinessNo() {
        return businessNo;
    }

    public void setBusinessNo(String businessNo) {
        this.businessNo = businessNo;
    }
}
