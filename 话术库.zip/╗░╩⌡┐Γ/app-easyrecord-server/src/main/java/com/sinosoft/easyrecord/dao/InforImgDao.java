package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSInforImg;

public interface InforImgDao {

    void save(LSInforImg lsInforImg);


}
