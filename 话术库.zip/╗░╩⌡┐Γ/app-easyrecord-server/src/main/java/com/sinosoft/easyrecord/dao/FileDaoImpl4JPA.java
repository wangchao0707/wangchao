package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSFileRepository;
import com.sinosoft.easyrecord.entity.LSFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.UUID;


@Component
public class FileDaoImpl4JPA implements FileDao {

    @Autowired

    public void setFileLogRepository(LSFileRepository fileLogRepository) {
        this.fileLogRepository = fileLogRepository;
    }

    private LSFileRepository fileLogRepository;


    @Override
    public void saveFileLog(LSFile fileLog) {
        if (StringUtils.isEmpty(fileLog.getFileId())) {
            fileLog.setFileId(UUID.randomUUID().toString());
        }
        fileLogRepository.saveAndFlush(fileLog);
    }


    @Override
    public LSFile findByContNo(String contNo) {
        return fileLogRepository.findTop1ByContNo(contNo);
    }


    @Override
    public void del(String fileID) {
        fileLogRepository.deleteById(fileID);
    }

}
