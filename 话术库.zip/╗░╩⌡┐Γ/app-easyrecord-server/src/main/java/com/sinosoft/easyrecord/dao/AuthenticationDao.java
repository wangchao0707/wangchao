package com.sinosoft.easyrecord.dao;

import java.util.List;

import com.sinosoft.easyrecord.entity.LSAuthentication;

/**
 * Created by WinterLee on 2017/7/14.
 */
public interface AuthenticationDao {

    String getPassword(String userid);

    void save(LSAuthentication authentication);

    LSAuthentication getAuthentication(String userid);

    List<LSAuthentication> findAll();

}
