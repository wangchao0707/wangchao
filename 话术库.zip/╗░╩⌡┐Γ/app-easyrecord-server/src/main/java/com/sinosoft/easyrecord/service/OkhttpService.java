package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.entity.LsContState;

public interface OkhttpService {
    RequestResult addVideo(LSCont cont, String address, String trans_type,String zipUrl,String name, LsContState lsContState);

    RequestResult updateCmsIndex(String contNo, LSCont lsCont, LsContState lsContState);

    RequestResult updateCmsIndex(String contNo, LSCont lsCont, String cmsId, LSUser lsUser);
}
