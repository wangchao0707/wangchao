package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LsinsuredClient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LSInsuredClientRepository extends JpaRepository<LsinsuredClient,String> {
}
