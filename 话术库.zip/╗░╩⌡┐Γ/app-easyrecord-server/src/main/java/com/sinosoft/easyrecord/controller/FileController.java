package com.sinosoft.easyrecord.controller;

import com.sinosoft.easyrecord.entity.LSFileDown;
import com.sinosoft.easyrecord.service.FileDownService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2018-09-08
 * Time: 16:13
 *
 * 提供 文件下载 内容
 */
@RestController
public class FileController {


    @Autowired
    private FileDownService fileDownService;


    /**
     * 查询 产品文件列表
     **/
    @RequestMapping(value = "/fileList",method = {RequestMethod.POST,RequestMethod.GET})
    @ResponseBody
    public Map getFileList(){
        Map<String,Object> resMap = new HashMap<>();
        resMap = fileDownService.findAll();
        return resMap;
    }


}
