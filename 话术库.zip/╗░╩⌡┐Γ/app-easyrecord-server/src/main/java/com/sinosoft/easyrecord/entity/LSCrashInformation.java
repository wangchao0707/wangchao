package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "LSCrashInformation")
public class LSCrashInformation {
    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "UploadTime")
    private String uploadTime;
    @Column(name = "CrashInformation")
    private String crashInformation;
    @Column(name = "EquipmentInformation")
    private String equipmentInformation;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(String uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getCrashInformation() {
        return crashInformation;
    }

    public void setCrashInformation(String crashInformation) {
        this.crashInformation = crashInformation;
    }

    public String getEquipmentInformation() {
        return equipmentInformation;
    }

    public void setEquipmentInformation(String equipmentInformation) {
        this.equipmentInformation = equipmentInformation;
    }
}
