package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wh on 2018/2/27.
 */
public class TransbodyReq81013 implements Transbody,Serializable{


    private static final long serialVersionUID = -5516454465L;

    private FILEBUSINESSNOS FILEBUSINESSNOS;//文件流水号

    public TransbodyReq81013.FILEBUSINESSNOS getFILEBUSINESSNOS() {
        return FILEBUSINESSNOS;
    }

    public void setFILEBUSINESSNOS(TransbodyReq81013.FILEBUSINESSNOS FILEBUSINESSNOS) {
        this.FILEBUSINESSNOS = FILEBUSINESSNOS;
    }

    public static class FILEBUSINESSNOS{
        private String TYPE;  //<!-- 操作类型  DELETE-删除  LOOK-调阅 -->
        private String FILEBUSINESSNOCOUNT;
        private List<FILEBUSINESSNO> FILEBUSINESSNO;

        public String getTYPE() {
            return TYPE;
        }

        public void setTYPE(String TYPE) {
            this.TYPE = TYPE;
        }

        public String getFILEBUSINESSNOCOUNT() {
            return FILEBUSINESSNOCOUNT;
        }

        public void setFILEBUSINESSNOCOUNT(String FILEBUSINESSNOCOUNT) {
            this.FILEBUSINESSNOCOUNT = FILEBUSINESSNOCOUNT;
        }

        public List<TransbodyReq81013.FILEBUSINESSNO> getFILEBUSINESSNO() {
            return FILEBUSINESSNO;
        }

        public void setFILEBUSINESSNO(List<TransbodyReq81013.FILEBUSINESSNO> FILEBUSINESSNO) {
            this.FILEBUSINESSNO = FILEBUSINESSNO;
        }
    }

    public static class FILEBUSINESSNO{
        private String BUSINESSNO; //- 流水号 -->
        private String DOCCODES; // 投保单号，多个以","号隔开  排序算法跟之前一样 -->

        public String getBUSINESSNO() {
            return BUSINESSNO;
        }

        public void setBUSINESSNO(String BUSINESSNO) {
            this.BUSINESSNO = BUSINESSNO;
        }

        public String getDOCCODES() {
            return DOCCODES;
        }

        public void setDOCCODES(String DOCCODES) {
            this.DOCCODES = DOCCODES;
        }
    }

}
