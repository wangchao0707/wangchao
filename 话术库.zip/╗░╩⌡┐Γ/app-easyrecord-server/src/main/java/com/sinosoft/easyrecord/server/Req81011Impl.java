package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.BusiNumChangesDao;
import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.dao.MessageDao;
import com.sinosoft.easyrecord.dao.TalkRunTimeDao;
import com.sinosoft.easyrecord.entity.LSBusiNumChanges;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSMessage;
import com.sinosoft.easyrecord.entity.LSTalkRunTime;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/*
 * 修改投保单号
 * */
@Service
public class Req81011Impl implements Req81011 {

    private Logger logger = LoggerFactory.getLogger(Req81011Impl.class);
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private ContDao contDao;

    @Autowired
    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }

    @Autowired
    private BusiNumChangesDao busiNumChangesDao;

    public void setBusiNumChangesDao(BusiNumChangesDao busiNumChangesDao) {
        this.busiNumChangesDao = busiNumChangesDao;
    }

    private MessageDao messageDao;

    @Autowired
    public void setMessageDao(MessageDao messageDao) {
        this.messageDao = messageDao;
    }


    @Autowired
    private TalkRunTimeDao talkRunTimeDao;

    public void setTalkRunTimeDao(TalkRunTimeDao talkRunTimeDao) {
        this.talkRunTimeDao = talkRunTimeDao;
    }

    @Override
    public String getReq81011(String xml) {

        logger.info("req 81011 xml {}", xml);

        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq81011.class);
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        Transhead head = tmp.getTranshead();
        TransbodyReq81011 body = (TransbodyReq81011) tmp.getTransbody();

        String type = body.TYPE;
        String oldBusiNum = body.BEFOREDOCCODE;
        int oldCount = Integer.parseInt(body.BEFOREDOCCODECOUNT);
        String newBusiNUm = body.NEWDOCCODE;
        String contNo = body.BUSINESSNO;

        LSCont lsCont = contDao.findByContNo(contNo);
        List<LSMessage> messages = messageDao.findByContNo(lsCont.getClientContNo());

        if (lsCont == null || !lsCont.getBusiNum().equals(oldBusiNum)) {
            return result(head, "100027", "没有该流水号");
        }
        List<LSTalkRunTime> talkRunTimes = talkRunTimeDao.findByBusiNumAndOperatorAndComCodeAndInsurComCode(lsCont.getBusiNum(), lsCont.getOperator(), lsCont.getComCode(), lsCont.getInsurComCode());


        // 如果投保单为一个 然后 触发的是 删除操作 则 删除保单
        if (type.equalsIgnoreCase("DELETE")) {
            if (oldCount == 1) {
                // 逻辑删除 投保单 将投保单状态 改为 C 代表删除
                logger.info("businum {} del", oldBusiNum);
                lsCont.setLastOne('C');
                contDao.save(lsCont);
                // 删除消息
                if (messages != null && messages.size() != 0) {
                    for (LSMessage lsMessage : messages) {
                        logger.info("contno {} delete messsage title {}", lsCont.getContNo(), lsMessage.getTitle());
                        messageDao.del(lsMessage);

                    }
                }
                //删除实时话术
                if (talkRunTimes != null && talkRunTimes.size() != 0) {
                    for (LSTalkRunTime lsTalkRunTime : talkRunTimes) {
                        logger.info("contno{} busiNum {} delete talkruntime step {}", lsCont.getContNo(), lsCont.getBusiNum(), lsTalkRunTime.getStep());
                        talkRunTimeDao.deleteTalkRunTime(lsTalkRunTime);
                    }
                }
            } else {
                logger.info("businum {} type {} update businum {}", oldBusiNum, type, newBusiNUm);
                lsCont.setBusiNum(newBusiNUm);
                contDao.save(lsCont);
                if (messages != null && messages.size() != 0) {
                    for (LSMessage lsMessage : messages) {
                        logger.info("businum {} del newbusinum {} lsmessageno {}", oldBusiNum, newBusiNUm,
                                lsMessage.getContNo());

                        messageDao.del(lsMessage);
                    }
                }
                if (talkRunTimes != null && talkRunTimes.size() != 0) {
                    for (LSTalkRunTime lsTalkRunTime : talkRunTimes) {
                        logger.info("contno{} busiNum {} update talkruntime step {}", lsCont.getContNo(), lsCont.getBusiNum(), lsTalkRunTime.getStep());
                        talkRunTimeDao.deleteTalkRunTime(lsTalkRunTime);
                    }
                }
            }

        } else {
            logger.info("businum {} type {} update businum {}", oldBusiNum, type, newBusiNUm);
            lsCont.setBusiNum(newBusiNUm);
            contDao.save(lsCont);
            if (messages != null && messages.size() != 0) {
                for (LSMessage lsMessage : messages) {
                    logger.info("businum {} update newbusinum {} lsmessageno {}", oldBusiNum, newBusiNUm,
                            lsMessage.getContNo());
                    lsMessage.setBusiNum(newBusiNUm);
                    messageDao.save(lsMessage);
                }
            }
            if (talkRunTimes != null && talkRunTimes.size() != 0) {
                for (LSTalkRunTime lsTalkRunTime : talkRunTimes) {
                    logger.info("contno{} busiNum {} update talkruntime step {}", lsCont.getContNo(), newBusiNUm, lsTalkRunTime.getStep());
                    lsTalkRunTime.setBusiNum(newBusiNUm);
                    talkRunTimeDao.saveTalkRunTime(lsTalkRunTime);
                }
            }
        }


        // 保存修改信息
        LSBusiNumChanges lsBusiNumChanges = new LSBusiNumChanges();
        lsBusiNumChanges.setId(UUID.randomUUID().toString());
        lsBusiNumChanges.setBusiNum(oldBusiNum);
        lsBusiNumChanges.setNewBusiNum(newBusiNUm);
        lsBusiNumChanges.setContNo(contNo);
        lsBusiNumChanges.setModifyDate(sdf.format(new Date()));
        busiNumChangesDao.saveBusiNumChange(lsBusiNumChanges);

        return result(head, "000000", "操作成功");
    }

    // 返回xml
    public String result(Transhead head, String returnCode, String message) {
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = returnCode;
        result.MESSAGE = message;

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        logger.info("req81011 return xml {}", xstream.toXML(td));
        return xstream.toXML(td);
    }

}
