package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by wh on 2018/1/5.
 */
@Entity
@Table(name = "LSBusiNumChanges")
public class LSBusiNumChanges {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "ContNo")
    private String contNo;
    @Column(name = "BusiNum")
    private String busiNum;
    @Column(name = "NewBusiNum")
    private String newBusiNum;
    @Column(name = "ModifyDate")
    private String modifyDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getNewBusiNum() {
        return newBusiNum;
    }

    public void setNewBusiNum(String newBusiNum) {
        this.newBusiNum = newBusiNum;
    }

    public String getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }

    @Override
    public String toString() {
        return "LSBusiNumChanges{" +
                "id='" + id + '\'' +
                ", contNo='" + contNo + '\'' +
                ", busiNum='" + busiNum + '\'' +
                ", newBusiNum='" + newBusiNum + '\'' +
                ", modifyDate='" + modifyDate + '\'' +
                '}';
    }
}
