package com.sinosoft.easyrecord.controller;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.service.QueryService;
import com.sinosoft.easyrecord.vo.QueryExitForm;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;

@RestController
@RequestMapping("/Query")
public class QueryController {

    @Resource
    private QueryService queryService;

    @RequestMapping(value = "/status", method = RequestMethod.POST)
    @ResponseBody
    public RequestResult status(
            @RequestBody
                    QueryExitForm queryExitForm) {

        RequestResult result = queryService.status(queryExitForm);

        return result;
    }

    @RequestMapping(value = "/exit", method = RequestMethod.POST)
    @ResponseBody
    public RequestResult exit (
            @RequestBody
                         QueryExitForm queryExitForm){
        RequestResult result = queryService.isExit(queryExitForm);


        return  result;
    }

}
