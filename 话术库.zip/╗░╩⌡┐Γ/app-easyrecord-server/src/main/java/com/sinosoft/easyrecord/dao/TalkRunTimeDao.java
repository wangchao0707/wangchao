package com.sinosoft.easyrecord.dao;

import java.util.List;

import com.sinosoft.easyrecord.entity.LSTalkRunTime;

public interface TalkRunTimeDao {

    void saveTalkRunTime(LSTalkRunTime lsTalkRunTime);

    List<LSTalkRunTime> findByBusiNumAndOperatorAndComCodeAndInsurComCode(String busiNum, String operator, String comCode, String insurComCode);

    void deleteTalkRunTime(LSTalkRunTime lsTalkRunTime);

    List<LSTalkRunTime> findByBusiNum(String busiNum);

    List<LSTalkRunTime> findByContNo(String contNo);
}
