package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LspolClient;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LSPolClientRepository extends JpaRepository<LspolClient,String> {
//    @Query(value = "select m from lspol_client m where contno = (:contNo)",nativeQuery = true)
//    List<LspolClient> findAllByContno(@Param(value = "contNo") String contNo);
    List<LspolClient> findLspolClientByContno(String Contno);
    void deleteLspolClientByContno(String Contno);
    LspolClient findByContnoAndRiskcode(String Contno,String Riskcode);
}
