package com.sinosoft.easyrecord.server;

public interface Req80004 {

    public String req80004(String xml);
}
