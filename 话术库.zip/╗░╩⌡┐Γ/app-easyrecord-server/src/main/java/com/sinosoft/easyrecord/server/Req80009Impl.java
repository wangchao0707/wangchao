package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.AuthenticationDao;
import com.sinosoft.easyrecord.dao.UserDao;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.service.UserActionLogService;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.text.ParseException;
import java.sql.Date;
import java.text.SimpleDateFormat;


@Service("req80009")
public class Req80009Impl implements Req80009 {

    private Logger logger = LoggerFactory.getLogger(Req80009Impl.class);

    @Autowired
    private UserActionLogService userActionLogService;

    @Autowired
    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    private AuthenticationDao authen;

    public void setAuthen(AuthenticationDao authen) {
        this.authen = authen;
    }

    @Override
    public String getReq80009(String xml) {
        logger.info("req80009 xml {}", xml);
        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransBodyReq80009.class);
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        TransBodyReq80009 body = (TransBodyReq80009) tmp.getTransbody();
        Transhead head = tmp.getTranshead();
        String comCode = head.getCOMPANY();
        String agentCode = body.AGENTCODE;
        String orgCode = body.COMCODE;
        LSUser user = userDao.getByComInfo(comCode, agentCode);
        String useflag = body.USEFLAG;
        if ((user != null)) {

            user.setAgentCode(agentCode);
            user.setComCode(comCode);
            user.setOrgCode(body.COMCODE);
            user.setName(body.NAME);
            user.setSex(body.SEX);
            user.setBrithday(body.BIRTHDAY);
            user.setIdNo(body.IDNO);
            user.setPhoneNo(body.PHONE);
            user.setChannel(body.CHANNEL);
            user.setUseFalg(body.USEFLAG);
            user.setWorkFlag(body.WORKFLAG);
            user.setSaleComCode(body.SALECOMCODE);
            user.setSaleComName(body.SALECOMNAME);
            user.setChannel(body.CHANNEL);
//			user.setRole(body.ROLE);
//			user.setBankCode(body.BANKCODE);
//			user.setDotCode(body.BANKNETWORK);
//			user.setManagerCode(body.PROPERSON);
            userDao.save(user);
        } else {
            LSUser userNew = new LSUser();
            String registTime = body.REGISTERTIME;
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date date = null;
            try {
                date = dateFormat.parse(registTime);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if (date != null) {
                Date date1 = new Date(date.getTime());
                userNew.setMakeDate(date1);

            }
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            java.util.Date date2 = new java.util.Date();
            try {
                date2 = sdf.parse(registTime);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if (date2 != null) {
                userNew.setMakeTime(sdf.format(date2));
            }

            userNew.setAgentCode(agentCode);
            userNew.setComCode(comCode);
            userNew.setOrgCode(body.COMCODE);
            userNew.setName(body.NAME);
            userNew.setSex(body.SEX);
            userNew.setBrithday(body.BIRTHDAY);
            userNew.setIdNo(body.IDNO);
            userNew.setPhoneNo(body.PHONE);
            userNew.setChannel(body.CHANNEL);
            userNew.setUseFalg(body.USEFLAG);
            userNew.setWorkFlag(body.WORKFLAG);
            userNew.setSaleComCode(body.SALECOMCODE);
            userNew.setSaleComName(body.SALECOMNAME);
            userNew.setChannel(body.CHANNEL);
//			userNew.setRole(body.ROLE);
//			userNew.setBankCode(body.BANKCODE);
//			userNew.setDotCode(body.BANKNETWORK);
//			userNew.setManagerCode(body.PROPERSON);

            userActionLogService.info("SYSTEM", "create_lsuser", "Req80009Impl > getReq80009 \n user: " + userNew, new Exception());
            userDao.save(userNew);


        }
        //返回
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";
        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

}
