package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSOperationLog;

public interface OperationLogDao {

    void saveOperationLog(LSOperationLog lsOperationLog);
}
