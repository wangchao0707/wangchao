package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.LSRiskType;
import com.sinosoft.easyrecord.entity.LSRiskTypeBak;
import com.sinosoft.easyrecord.entity.LSTalkBak;
import com.sinosoft.easyrecord.entity.LSTalkNew;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
/**
 * User: weihao
 * Date: 2019/1/16
 * Time: 9:00
 *  同步话术内容
 */
@Service("req81003")
public class Req81003Impl implements Req81003 {

    private static Logger logger = LoggerFactory.getLogger(Req81003.class);

    @Autowired
    private TalkNewDao talkNewDao;

    @Override
    public String getReq81003(String xml) {
        logger.info("req81003 start {}", xml);
        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransBodyReq81003.class);
        xs1.alias("VERBALS", TransBodyReq81003.VERBALS.class);
        xs1.alias("VERBAL", TransBodyReq81003.VERBAL.class);
        xs1.addImplicitCollection(TransBodyReq81003.VERBALS.class, "VERBAL");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        TransBodyReq81003 body = (TransBodyReq81003) tmp.getTransbody();
        Transhead head = tmp.getTranshead();
        String comCode = head.getCOMPANY();//这里的getCOMPANY()指的就是InsurComCode
        TransBodyReq81003.VERBALS VERBALS = body.getVERBALS();
        List<TransBodyReq81003.VERBAL> list = VERBALS.VERBAL;

        if (logger.isInfoEnabled()) {
            logger.info("VERBALS.count： {}, VERBALS.VERBAL.size: {}", VERBALS.VERBALCOUNT, list.size());
        }

        if ("0".equals(VERBALS.VERBALCOUNT)) {
            logger.warn("Do empty LSRiskType and LSTalk for {} ?????。VERBALS.VERBALCOUNT is '0', I will break！！！！！", comCode);
            return buildFailMessage("VERBALS.VERBALCOUNT 为 0", head);
        }

        if (list.size() == 0) {
            logger.warn("Do empty LSRiskType and LSTalk for {} ?????。VERBALS.VERBAL is empty, I will break！！！！！", comCode);
            return buildFailMessage("VERBALS.VERBAL 没有数据", head);
        }

        //备份数据

        //数据库操作,备份，删除，增加
        //根据comCode查数据，查到数据就备份
//        List<LSRiskType> riskTypeList = riskTypeDao.findByComCode(comCode);
        List<LSTalkNew> talkList = talkNewDao.findByComCode(comCode);

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        Date bakDate = new Date(System.currentTimeMillis());
        String bakTime = sdf.format(bakDate);
//        if (!riskTypeList.isEmpty()) {
////            for (LSRiskType item : riskTypeList) {
////                LSRiskTypeBak riskType_bak = new LSRiskTypeBak(UUID.randomUUID().toString(), item, bakDate, bakTime);
////                riskTypeBakDao.save(riskType_bak);
////            }
//            riskTypeDao.deleteByComCode(comCode);
//        }
        if (!talkList.isEmpty() && talkList != null) {
//            for (LSTalkNew item : talkList) {
//                LSTalkBak talk_bak = new LSTalkBak(UUID.randomUUID().toString(), item, bakDate, bakTime);
//                talkBakDao.save(talk_bak);
//            }
            talkNewDao.deleteByComCode(comCode);
        }
        // 备份数据过程完毕。


        Set<String> distinctKeySet = new TreeSet<String>();
        // List<String> dataList=new ArrayList<String>();

        //插入
        for (TransBodyReq81003.VERBAL verbalItem : list) {
            String orgCode = verbalItem.COMCODE;
            //保存之前再做一次排除重复的数据
//            String s = comCode + verbalItem.COMPANY + verbalItem.RISKCODE + verbalItem.COMCODE;

//            if (!distinctKeySet.contains(s)) {
//                distinctKeySet.add(s);
//                LSRiskType lsriskType = new LSRiskType();
//                lsriskType.setComCode(comCode);
//                lsriskType.setPpkid(UUID.randomUUID().toString());//主键id随机生成
//                lsriskType.setInsurComCode(verbalItem.COMPANY);//
//                lsriskType.setRiskType(verbalItem.RISKCODE);
//                lsriskType.setTypeName(verbalItem.RISKNAME);
//                lsriskType.setType(verbalItem.RISKTYPE);
//                lsriskType.setOrgCode(verbalItem.COMCODE);
//                riskTypeDao.save(lsriskType);
//            }

            LSTalkNew lsTalkNew = new LSTalkNew();
            lsTalkNew.setTalkPkId(UUID.randomUUID().toString());
            lsTalkNew.setPkid(verbalItem.DESCRIBEID);
            lsTalkNew.setInsurComCode(verbalItem.COMPANY);
            lsTalkNew.setRiskType(verbalItem.RISKCODE);
            lsTalkNew.setStep(verbalItem.QCPOINT);
            lsTalkNew.setTalkContent(verbalItem.QCTRICK);
            lsTalkNew.setOrderNum(Integer.parseInt(verbalItem.ORDERNO));
            lsTalkNew.setComCode(comCode);
            lsTalkNew.setOrgCode(verbalItem.COMCODE);
            lsTalkNew.setTalkPointCode(verbalItem.QCPOINTCODE);
            if (verbalItem.ISREAD.equalsIgnoreCase("是")){   lsTalkNew.setIsRead("Y");    }
            if (verbalItem.ISREAD.equalsIgnoreCase("否")){   lsTalkNew.setIsRead("N");    }

            //是否合并
            String isMerge = "N";
            if (verbalItem.ISMERGE.equals("是")){
                isMerge = "Y";
            }
            lsTalkNew.setIsMerge(isMerge);


            talkNewDao.save(lsTalkNew);
        }
        //返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();


        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        logger.info("返回报文 {}",td);
        return xstream.toXML(td);
    }

    private String buildFailMessage(String message, Transhead head) {
        //返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "100027";
        result.MESSAGE = message;

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

}
