package com.sinosoft.easyrecord.service;


public interface UploadTimeService {

    String saveUploadTime(String busiNum, String eqInfor, String versionNum, String sign, String userId);

    void saveUploadTime(String serialNum);

}
