package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by wds on 2018-3-20.
 * 客户经理信息
 */
@Entity
@Table(name = "LSBankNetAndProperson")
public class LSBankNetWork {

    @Id
    @Column(name = "Id")
    private String id;

    @Column(name = "BankNetWorkCode")
    private String bankNetWorkCode;

    @Column(name = "BankNetWorkName")
    private String bankNetWorkName;

    @Column(name = "PropersonCode")
    private String propersonCode;

    @Column(name = "PropersonName")
    private String propersonName;

    public String getPropersonCode() {
        return propersonCode;
    }

    public void setPropersonCode(String propersonCode) {
        this.propersonCode = propersonCode;
    }

    public String getPropersonName() {
        return propersonName;
    }

    public void setPropersonName(String propersonName) {
        this.propersonName = propersonName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBankNetWorkCode() {
        return bankNetWorkCode;
    }

    public void setBankNetWorkCode(String bankNetWorkCode) {
        this.bankNetWorkCode = bankNetWorkCode;
    }

    public String getBankNetWorkName() {
        return bankNetWorkName;
    }

    public void setBankNetWorkName(String bankNetWorkName) {
        this.bankNetWorkName = bankNetWorkName;
    }

    @Override
    public String toString() {
        return "LSBankNetWork{" +
                "id='" + id + '\'' +
                ", bankNetWorkCode='" + bankNetWorkCode + '\'' +
                ", bankNetWorkName='" + bankNetWorkName + '\'' +
                ", propersonCode='" + propersonCode + '\'' +
                ", propersonName='" + propersonName + '\'' +
                '}';
    }
}
