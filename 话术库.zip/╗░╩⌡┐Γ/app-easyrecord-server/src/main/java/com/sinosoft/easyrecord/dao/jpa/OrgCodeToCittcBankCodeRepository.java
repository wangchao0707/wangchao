package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.OrgCodeToCittcBankCode;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrgCodeToCittcBankCodeRepository extends JpaRepository<OrgCodeToCittcBankCode,String> {

    OrgCodeToCittcBankCode findByAreaCode(String areaCode);

}
