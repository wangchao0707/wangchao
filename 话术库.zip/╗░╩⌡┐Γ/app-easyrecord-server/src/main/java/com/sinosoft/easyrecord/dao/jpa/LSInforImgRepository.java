package com.sinosoft.easyrecord.dao.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sinosoft.easyrecord.entity.LSInforImg;
import com.sinosoft.easyrecord.entity.LSInforImgComp;

public interface LSInforImgRepository extends JpaRepository<LSInforImg, LSInforImgComp> {

}
