package com.sinosoft.easyrecord.controller;

import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2018-05-14
 * Time: 11:09
 * 转发 质检消息给统一 消息平台
 */
@RestController
//@RequestMapping(value = "/forword")
public class ForwardController {

    private Logger logger = LoggerFactory.getLogger(ForwardController.class);



    @Value(value = "${message.messageUrl}")
    private String url;

    @RequestMapping(value = "/sendMessageTest",method = RequestMethod.POST,consumes = "application/json")
    @ResponseBody
    public Object forwaordMessageTest(@RequestBody Map map){
        if (map.isEmpty()){
            logger.info("map isEmpty");
            return false;
        }
        //转发服务
        logger.info("map {}",map);

        JSONArray jsonArray = new JSONArray();
        jsonArray.put(map);
        System.out.println(jsonArray.toString());
        logger.info("MESSAGE {}",jsonArray.toString());
        //转发请求
        logger.info("forward controller  forward url {}",url);
        Object o = sendMessage(url,jsonArray.toString());
        return o;
    }


    @RequestMapping(value = "/sendMessage",method = RequestMethod.POST,consumes = "application/json")
    @ResponseBody
    public Object forwaordMessage(@RequestBody Map map){
        //转发服务
        logger.info("map {}",map);
//        List data = (ArrayList) map.get("data");
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(map);
        System.out.println(jsonArray.toString());
        logger.info("MESSAGE {}",jsonArray.toString());
        //转发请求
        Object o = sendMessage(url,jsonArray.toString());
        return o;
    }


//    @Autowired
//    private RestTemplate restTemplate;

    public Object sendMessage(String url,String value) {
        RestTemplate restTemplate = new RestTemplate(); //SimpleRestClient.getClient();
        Map<String, String> map = new HashMap<String, String>();
        try {
            value = URLEncoder.encode(String.valueOf(value),"UTF-8");
            logger.info("url {} value {}",url,value);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        map.put("data", value);
        Object obj = restTemplate.getForObject(url + "{data}", String.class,map );
        logger.info("result {}",obj);
        return  obj;
    }

}
