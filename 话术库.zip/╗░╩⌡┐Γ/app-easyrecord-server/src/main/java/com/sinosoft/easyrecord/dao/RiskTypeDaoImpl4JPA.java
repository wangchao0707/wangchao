package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSRiskTypeRepository;
import com.sinosoft.easyrecord.entity.LSRiskType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zf on 2017/7/27.
 */
@Component
public class RiskTypeDaoImpl4JPA implements RiskTypeDao {
    @Autowired
    private LSRiskTypeRepository riskTypeRepository;

    public void setRiskTypeRepository(LSRiskTypeRepository riskTypeRepository) {
        this.riskTypeRepository = riskTypeRepository;
    }

    @Override
    public List<LSRiskType> findByComCodeAndInsurComCode(String comCode, String insurComCode, String orgCode) {
        return riskTypeRepository.findByComCodeAndInsurComCodeAndOrgCodeOrderByRiskType(comCode, insurComCode, orgCode);
    }

    @Override
    public List<LSRiskType> findByComCode(String comCode) {
        return riskTypeRepository.findByComCode(comCode);
    }

    @Override
    public void deleteByComCode(String comCode) {
        riskTypeRepository.deleteByComCode(comCode);
        riskTypeRepository.flush();
    }

    @Override
    public void save(LSRiskType lsRiskType) {
        riskTypeRepository.saveAndFlush(lsRiskType);
    }

    @Override
    public LSRiskType findByComCodeAndRiskType(String comCode, String riskType, String orgCode) {
        return riskTypeRepository.findByComCodeAndRiskTypeAndOrgCode(comCode, riskType, orgCode);
    }
}
