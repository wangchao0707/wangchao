package com.sinosoft.easyrecord.server;


import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import javax.xml.namespace.QName;

public class ClientTest1 {

    public static void main(String[] args) {

        String inputXml = getRes81013();
        System.out.println(inputXml);
        //String appUrl ="http://118.89.240.152:10082/easyrecord/services/serverService?wsdl";
        String appUrl ="http://localhost:8081/easyrecord/services/serverService?wsdl";
        try {
            String res = easyScanInterface(inputXml, appUrl);
            System.out.println(res);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String easyScanInterface(String inputXml, String appUrl) throws Exception {
        String url = appUrl;
        String method = "easyScanInterface";
        String result = sendService(inputXml, url, method);
        return result;
    }

    /**
     * 发送请求
     *
     * @param xmlStr
     * @param url
     * @param method
     * @return
     * @throws Exception
     */
    private static String sendService(String xmlStr, String url, String method) throws Exception {

        String xml = null;

        RPCServiceClient serviceClient = new RPCServiceClient();

        Options options = serviceClient.getOptions();

        EndpointReference targetEPR = new EndpointReference(url);

        options.setTo(targetEPR);
        options.setAction(method);
        options.setManageSession(true);
        options.setProperty(HTTPConstants.REUSE_HTTP_CLIENT, true);
        // 在创建QName对象时，QName类的构造方法的第一个参数表示WSDL文件的命名空间名，也就是<wsdl:definitions>元素的targetNamespace属性值

        QName opAddEntry = new QName("http://server.easyrecord.sinosoft.com",method);

        // 参数，如果有多个，继续往后面增加即可，不用指定参数的名称

        Object[] opAddEntryArgs = new Object[] { xmlStr };

        // 返回参数类型，这个和axis1有点区别

        // invokeBlocking方法有三个参数，其中第一个参数的类型是QName对象，表示要调用的方法名；

        // 第二个参数表示要调用的WebService方法的参数值，参数类型为Object[]；

        // 第三个参数表示WebService方法的返回值类型的Class对象，参数类型为Class[]。

        // 当方法没有参数时，invokeBlocking方法的第二个参数值不能是null，而要使用new Object[]{}

        // 如果被调用的WebService方法没有返回值，应使用RPCServiceClient类的invokeRobust方法，

        // 该方法只有两个参数，它们的含义与invokeBlocking方法的前两个参数的含义相同

        Class[] classes = new Class[] { String.class };

        xml = (String) serviceClient.invokeBlocking(opAddEntry, opAddEntryArgs, classes)[0];
        serviceClient.cleanupTransport();
        return xml;

    }


    public static String getRes81013(){
        Transdata td = new Transdata();
        Transhead th = new Transhead();
        TransbodyReq81013 tb = new TransbodyReq81013();

        th.setTRANSCODE("81013");
        th.setCOMPANY("24001");
        TransbodyReq81013.FILEBUSINESSNOS filebusinessnos = new TransbodyReq81013.FILEBUSINESSNOS();
        TransbodyReq81013.FILEBUSINESSNO filebusinessno = new TransbodyReq81013.FILEBUSINESSNO();
        //List<TransbodyReq81013.FILEBUSINESSNO> list = new ArrayList<TransbodyReq81013.FILEBUSINESSNO>();
        filebusinessno.setDOCCODES("1508111111111111");//保单号
        filebusinessno.setBUSINESSNO("03e31627-7afb-460b-b7ab-542d65561a1c");//流水号

        //list.add(filebusinessno);
        filebusinessnos.setTYPE("LOOK");
        filebusinessnos.setFILEBUSINESSNOCOUNT("1");
        tb.setFILEBUSINESSNOS(filebusinessnos);
        td.setTranshead(th);
        td.setTransbody(tb);


        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("FILEBUSINESSNOS", TransbodyReq81013.FILEBUSINESSNOS.class);
        xstream.alias("FILEBUSINESSNO", TransbodyReq81013.FILEBUSINESSNO.class);
        xstream.addImplicitCollection(TransbodyReq81013.FILEBUSINESSNOS.class, "FILEBUSINESSNO");
        return xstream.toXML(td);
    }

//	public static String getResult(){//此处有接收质检端结果，和返回结果给质检端
//		Transdata td = new Transdata();
//		Transhead th = new Transhead();
//		TransbodyRes tr = new TransbodyRes();
//		TransbodyRes.Transresult result = new TransbodyRes.Transresult();
//		result.RETURNCODE="000000";
//		result.MESSAGE = "操作成功";
//
//		tr.setTRANSRESULT(result);
//		td.setTranshead(th);
//		td.setTransbody(tr);
//		XStream xstream = new XStream();
////		xstream.aliasSystemAttribute(null, "class");
//		xstream.alias("TRANSDATA", Transdata.class);
//		xstream.alias("TRANSBODY", TransbodyRes.class);
//		xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
//		return xstream.toXML(td);
//	}


}
