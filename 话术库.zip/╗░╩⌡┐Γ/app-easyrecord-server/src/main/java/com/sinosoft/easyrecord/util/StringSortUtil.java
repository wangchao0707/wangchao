package com.sinosoft.easyrecord.util;

import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * Created by wh on 2018/1/30.
 */

public class StringSortUtil {

    public static String getArrayStringSort(String str) {
        if (str == null || str.isEmpty())
            return null;
        if (!str.contains(","))
            return str;
        if (str.replaceAll(",", "").trim().isEmpty())
            return str;
        if (str.endsWith(","))
            str = str.substring(0, str.length() - 1);
        String[] arrStr = str.split(",");
        Arrays.sort(arrStr);
        StringBuilder res = new StringBuilder("");
        for (String s : arrStr) {
            if (s != null && !s.isEmpty()) {
                if (res.length() < 1)
                    res.append(s);
                else {
                    res.append(",");
                    res.append(s);
                }
            }
        }
        return res.toString();
    }


}
