package com.sinosoft.easyrecord.server;


public interface Req80009 {

    public String getReq80009(String xml);

}
