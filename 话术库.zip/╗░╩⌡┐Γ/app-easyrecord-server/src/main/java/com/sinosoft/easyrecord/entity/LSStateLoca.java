package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "lsstateloca")
public class LSStateLoca {
    @Id
    @Column(name = "id")
    private String id;//唯一标识

    @Column(name = "contNo")
    private String  contNo;//流水单号

    @Column(name = "busiNum")
    private String busiNum;//保险单号

    @Column(name = "makeDate")
    private Date makeDate;//创建日期

    @Column(name = "makeTime")
    private String  makeTime;//创建时间

    @Column(name = "contState")
    private String contState;//保单状态

    @Column(name = "stateName")
    private String stateName;//状态名称

    @Column(name = "isSend")
    private String isSend;//是否推送异步信息

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public Date getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(Date makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getContState() {
        return contState;
    }

    public void setContState(String contState) {
        this.contState = contState;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getIsSend() {
        return isSend;
    }

    public void setIsSend(String isSend) {
        this.isSend = isSend;
    }

    @Override
    public String toString() {
        final StringBuffer sb=new StringBuffer("LSStateLoca{");
        sb.append("id='").append(id).append('\'');
        sb.append("contNo='").append(contNo).append('\'');
        sb.append("busiNum='").append(busiNum).append('\'');
        sb.append("makeDate='").append(makeDate).append('\'');
        sb.append("makeTime='").append(makeTime).append('\'');
        sb.append("contState='").append(contState).append('\'');
        sb.append("stateName='").append(stateName).append('\'');
        sb.append("isSend='").append(isSend).append('\'');
        return sb.toString();
    }
}
