package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LDComConfigRepository;
import com.sinosoft.easyrecord.dao.jpa.LSCrashInformationRepository;
import com.sinosoft.easyrecord.entity.LDComConfig;
import com.sinosoft.easyrecord.entity.LSCrashInformation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class CrashInformationDaoImpl4JPA implements CrashInformationDao {
    @Autowired
    private LSCrashInformationRepository crashInformationRepository;

    public void setCrashInformationRepository(LSCrashInformationRepository crashInformationRepository) {
        this.crashInformationRepository = crashInformationRepository;
    }

    @Override
    public void save(LSCrashInformation crashInformation) {
        crashInformationRepository.saveAndFlush(crashInformation);
    }

    @Autowired
    private LDComConfigRepository comConfigRepository;

    public void setComConfigRepository(LDComConfigRepository comConfigRepository) {
        this.comConfigRepository = comConfigRepository;
    }

    public LDComConfig findByComCode(String comCode) {
        Optional<LDComConfig> res = comConfigRepository.findById(comCode);
        return res.orElse(null);
    }

}
