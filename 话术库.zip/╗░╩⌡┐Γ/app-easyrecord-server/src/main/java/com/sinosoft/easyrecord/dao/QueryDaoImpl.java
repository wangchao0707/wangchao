package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.mybatis.QueryMapper;
import com.sinosoft.easyrecord.vo.QueryOrgForm;
import com.sinosoft.easyrecord.vo.ShowStateVo;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
@Component
public class QueryDaoImpl implements QueryDao{

    @Resource
    private QueryMapper queryMapper;

    @Override
    public List<QueryOrgForm> selectQueryStatus(List<String> list) {

        List<QueryOrgForm> data = queryMapper.selectQueryStatus(list);
        return data;
    }

    @Override
    public List<String> isExit(List<String> list) {

        List<String> data = queryMapper.isExit(list);
        return data;
    }

    @Override
    public ShowStateVo selectForStateByContNo(String contNo) {

        ShowStateVo data = queryMapper.selectForStateByContNo(contNo);
        
        return data;
    }

    @Override
    public List<String> selectProductNameByCode(List<String> listRisk) {
        List<String> data = queryMapper.selectProductNameByCode(listRisk);
        return data;
    }
}
