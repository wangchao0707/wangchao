/*
package com.sinosoft.easyrecord.service.impl;

*/
/*import com.qcloud.Module.Vod;
import com.qcloud.QcloudApiModuleCenter;
import com.qcloud.Utilities.Json.JSONObject;*//*

import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
*/
/*import com.qcloud.cos.sign.Credentials;
import com.qcloud.cos.meta.InsertOnly;
import com.qcloud.cos.request.UploadFileRequest;*//*

import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.dao.ContStateDao;
import com.sinosoft.easyrecord.dao.PictureDao;
import com.sinosoft.easyrecord.dao.VideoDao;
import com.sinosoft.easyrecord.entity.LSVideo;
import com.sinosoft.easyrecord.entity.LsContState;
import com.sinosoft.easyrecord.service.VideoUpload;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TreeMap;

*/
/**
 * Created by Administrator on 2017/8/31.
 *//*

public class VideoUploadImpl4QCloud implements VideoUpload {

    private static final Logger logger = LoggerFactory.getLogger(VideoUploadImpl4QCloud.class);

    // @Autowired
    // private ComConfigDao comConfigDao;
    // public void setComConfigDao(ComConfigDao comConfigDao) {
    // this.comConfigDao = comConfigDao;
    // }

    private PictureDao pictureDao;

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }

*/
/*    private QcloudApiModuleCenter module = null;*//*


    private String secretId;

    private String secretKey;

    private String region;

    private String storageRegion;

    public void setStorageRegion(String storageRegion) {
        this.storageRegion = storageRegion;
    }

    private ContStateDao contStateDao;

    public void setContStateDao(ContStateDao contStateDao) {
        this.contStateDao = contStateDao;
    }

    private VideoDao videoDao;

    public void setVideoDao(VideoDao videoDao) {
        this.videoDao = videoDao;
    }

    private ContDao contDao;

    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }

    public VideoUploadImpl4QCloud() {
    }

    public VideoUploadImpl4QCloud(String SecretId, String SecretKey) {

        this.secretId = SecretId;
        this.secretKey = SecretKey;

        TreeMap<String, Object> config = new TreeMap<String, Object>();

        config.put("SecretId", SecretId);
        config.put("SecretKey", SecretKey);
        config.put("RequestMethod", "POST");
        config.put("DefaultRegion", "sh");
        */
/*module = new QcloudApiModuleCenter(new Vod(), config);*//*

    }


    public VideoUploadImpl4QCloud(String secretId, String secretKey, String region) {
        super();
        this.secretId = secretId;
        this.secretKey = secretKey;
        this.region = region;

        TreeMap<String, Object> config = new TreeMap<String, Object>();

        config.put("SecretId", secretId);
        config.put("SecretKey", secretKey);
        config.put("RequestMethod", "POST");
        config.put("DefaultRegion", region);
        logger.info("VideoUploadImpl4QCloud secretId {} region {}", secretId, region);
       */
/* module = new QcloudApiModuleCenter(new Vod(), config);*//*

    }

    @Override
    public void uploadCloud(String contNo, File file) {
        upload(contNo, file);
    }


    private void upload(String contNo, File file) {
        upload(contNo, file, null);
    }

    private void upload(String contNo, File videofile, String coverPath) {

        LSVideo video = videoDao.findByContNo(contNo);
        if (video == null) {
            String message = "LSVideo is not extis by contNo[" + contNo + "]";
            IllegalArgumentException ex = new IllegalArgumentException(message);
            logger.error(message, ex);

            throw ex;
        }

        String videoPath = videofile.getAbsolutePath();
        // 第一步，发起上传
        TreeMap<String, Object> params = new TreeMap<String, Object>();
        String[] videoPathSplit = videoPath.split("\\.");
        params.put("videoType", videoPathSplit[videoPathSplit.length - 1]);
        //添加转码请求
        params.put("procedure", "QCVB_SimpleProcessFile({220},0,0,0)");
        //指定上传地址
        params.put("storageRegion", storageRegion);

        if (coverPath != null) {
            String[] coverPathSplit = coverPath.split("\\.");
            params.put("coverType", coverPathSplit[coverPathSplit.length - 1]);
        }
        String result = null;
        try {
            result = module.call("ApplyUpload", params);
        } catch (Exception e) {
            String message = "error..." + e.getMessage();
            RuntimeException ex = new RuntimeException(message, e);
            logger.error(message, ex);

            throw ex;

        }

        JSONObject json_result = new JSONObject(result);
        logger.info("ApplyUpload|recv: {}", json_result);

        String bucket = json_result.getString("storageBucket");
        String region = json_result.getString("storageRegion");
        String vodSessionKey = json_result.getString("vodSessionKey");
        String videoDst = json_result.getJSONObject("video").getString("storagePath");
        String coverDst = null;
        if (coverPath != null) {
            coverDst = json_result.getJSONObject("cover").getString("storagePath");
        }

        // 第二步，上传文件到COS
        long appId = 10022853;
        ClientConfig clientConfig = new ClientConfig();
        clientConfig.setRegion(region);
        clientConfig.setSignExpired(24 * 3600);
        Credentials cred = new Credentials(appId, secretId, secretKey);
        COSClient cosClient = new COSClient(clientConfig, cred);

        UploadFileRequest uploadFileRequest = new UploadFileRequest(bucket, videoDst, videoPath);
        uploadFileRequest.setInsertOnly(InsertOnly.OVER_WRITE);
        String uploadFileRet = cosClient.uploadFile(uploadFileRequest);
        logger.info("upload video to cos|recv: {}", uploadFileRet);

        if (coverDst != null) {
            uploadFileRequest = new UploadFileRequest(bucket, coverDst, coverPath);
            uploadFileRequest.setInsertOnly(InsertOnly.OVER_WRITE);
            uploadFileRet = cosClient.uploadFile(uploadFileRequest);
            System.out.print("upload cover to cos|recv:");
            System.out.println(uploadFileRet);
            logger.info("upload cover to cos|recv: {}", uploadFileRet);
        }

        // 第三步，确认上传
        params = new TreeMap<String, Object>();
        params.put("vodSessionKey", vodSessionKey);
        result = null;
        try {
            result = module.call("CommitUpload", params);
        } catch (Exception e) {
            String message = "error..." + e.getMessage();
            RuntimeException ex = new RuntimeException(message, e);
            logger.error(message, ex);

            throw ex;
        }

        json_result = new JSONObject(result);
        System.out.print("CommitUpload|recv:");
        System.out.println(json_result);
        logger.info("CommitUpload|recv: {}", json_result);

        String srcFileID = json_result.getString("fileId");
        String fileUrl = json_result.getJSONObject("video").getString("url");
        logger.info("fileUrl {}", fileUrl);
        video.setVideoUrl(fileUrl);
        video.setFileSize(videofile.length() + "");
        video.setCloudFileId(srcFileID);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        video.setStartTime(sdf.format(date));
        videoDao.save(video);

//        decodeVod(contNo, srcFileID);


    }


    private void decodeVod(String contNo, String srcFileId) {

        LsContState contState = contStateDao.getContState(contNo);
        if (contState == null) {
            String message = "LsContState is not extis by contNo[" + contNo + "]";
            IllegalArgumentException ex = new IllegalArgumentException(message);
            logger.error(message, ex);

            throw ex;
        }

        logger.info("decodeVod start fileId {}", srcFileId);
        TreeMap<String, Object> params = new TreeMap<String, Object>();
        params.put("fileId", srcFileId);
        params.put("procedure", "QCVB_SimpleProcessFile({220},0,0,0)");

        String result = null;
        try {
            result = module.call("ProcessFileByProcedure", params);
        } catch (Exception e) {
            String message = "error..." + e.getMessage();
            RuntimeException ex = new RuntimeException(message, e);
            logger.error(message, ex);

            throw ex;
        }
        JSONObject json_result = new JSONObject(result);
        System.out.print("procedure|recv:");
        System.out.println(json_result);
        logger.info("procedure|recv: {}", json_result);

        contState.setProdusId(json_result.getString("procedureTaskId"));
        contStateDao.save(contState);

    }

    //


}
*/
