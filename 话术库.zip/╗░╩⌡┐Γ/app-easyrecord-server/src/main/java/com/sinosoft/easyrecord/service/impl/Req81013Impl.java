package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.dao.DelFileDao;
import com.sinosoft.easyrecord.dao.LookFileDao;
import com.sinosoft.easyrecord.dao.PictureDao;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSDelFile;
import com.sinosoft.easyrecord.entity.LSLookFile;
import com.sinosoft.easyrecord.entity.LSPicture;
//import com.sinosoft.easyrecord.service.CloudService;
import com.sinosoft.easyrecord.service.Req81013;

import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.transaction.annotation.*;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * 文件操作接口 涉及双录文件的 删除和 再次调阅
 * Created by wh on 2018/2/27.
 */
@Service
public class Req81013Impl implements Req81013 {

    private Logger logger = LoggerFactory.getLogger(Req81013Impl.class);

//    @Autowired
//    private CloudService cloudService;
//
//    public void setCloudService(CloudService cloudService) {
//        this.cloudService = cloudService;
//    }

    @Autowired
    private PictureDao pictureDao;

    public void setPictureDao(PictureDao pictureDao) {
        this.pictureDao = pictureDao;
    }

    @Autowired
    private ContDao contDao;

    public void setContDao(ContDao contDao) {
        this.contDao = contDao;
    }

    @Autowired
    private DelFileDao delFileDao;

    public void setDelFileDao(DelFileDao delFileDao) {
        this.delFileDao = delFileDao;
    }

    @Autowired
    private LookFileDao lookFileDao;

    public void setLookFileDao(LookFileDao lookFileDao) {
        this.lookFileDao = lookFileDao;
    }


    private SimpleDateFormat dateSdf = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat timeSdf = new SimpleDateFormat("HH:mm:ss");
    @Transactional
    @Override
    public String req81013(String xml) {
        logger.info("xml ::::{}",xml);
        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq81013.class);
        xs1.alias("FILEBUSINESSNOS", TransbodyReq81013.FILEBUSINESSNOS.class);
        xs1.alias("FILEBUSINESSNO" , TransbodyReq81013.FILEBUSINESSNO.class);
        xs1.addImplicitCollection(TransbodyReq81013.FILEBUSINESSNOS.class, "FILEBUSINESSNO");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        Transhead head = tmp.getTranshead();
        //获取公司编码
        String comCode = head.getCOMPANY();

        TransbodyReq81013 body = (TransbodyReq81013) tmp.getTransbody();

        TransbodyReq81013.FILEBUSINESSNOS filebusinessnos = body.getFILEBUSINESSNOS();

        //获取操作类型
        String type = filebusinessnos.getTYPE();
        if (StringUtils.isEmpty(type)){
            logger.info("type is null");
            return  XmlResult.result(head,"100027", "类型为空");
        }
        //获取流水号
        List<TransbodyReq81013.FILEBUSINESSNO> list  = filebusinessnos.getFILEBUSINESSNO();
        List<String> contNos = new ArrayList<>();
        for (TransbodyReq81013.FILEBUSINESSNO filebusinessno:list){
            String contNo = filebusinessno.getBUSINESSNO();
            contNos.add(contNo);
        }

        //删除操作
        if (type.equalsIgnoreCase("DELETE")){

            for (String contNo:contNos){
                //删除图片 保存图片信息
                List<LSPicture> pictures = pictureDao.findByContNo(contNo);
                if (pictures !=null && !pictures.isEmpty()){
                    for (LSPicture lsPicture:pictures){
                        if(lsPicture.getBusiType().equals("IIDPic") || lsPicture.getBusiType().equals("AIDPic")){
                            continue;
                        }
                        LSDelFile lsDelFile = new LSDelFile();
                        lsDelFile.setId(UUID.randomUUID().toString());
                        lsDelFile.setContNo(contNo);
                        lsDelFile.setIsDelPic("N");
                        lsDelFile.setPicId(lsPicture.getPictureId());
                        delFileDao.saveDelFile(lsDelFile);
                    }
                }
                LSDelFile lsDelFile = new LSDelFile();
                //删除视频  保存视频信息
                lsDelFile.setId(UUID.randomUUID().toString());
                lsDelFile.setContNo(contNo);
                lsDelFile.setIsDelVideo("N");
                lsDelFile.setVideoId(contNo);
                //增加创建时间
                lsDelFile.setMakeDate(dateSdf.format(new Date()));
                lsDelFile.setMakeTime(timeSdf.format(new Date()));
                delFileDao.saveDelFile(lsDelFile);
            }
        }
        return XmlResult.result(head,"000000","操作成功");
    }



}
