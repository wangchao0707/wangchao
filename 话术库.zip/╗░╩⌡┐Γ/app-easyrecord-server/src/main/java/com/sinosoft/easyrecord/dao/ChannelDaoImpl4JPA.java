package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSChannelRepository;
import com.sinosoft.easyrecord.entity.LSChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class ChannelDaoImpl4JPA implements ChannelDao {


    @Autowired
    private LSChannelRepository channelRepository;

    public void setChannelRepository(LSChannelRepository channelRepository) {
        this.channelRepository = channelRepository;
    }

    @Override
    public void saveChannel(LSChannel lsChannel) {
        channelRepository.saveAndFlush(lsChannel);
    }

    @Override
    public LSChannel findChannel(String channelCode) {
        Optional<LSChannel> res = channelRepository.findById(channelCode);
        return res.orElse(null);
    }

    @Override
    public List<LSChannel> findAll() {
        return channelRepository.findAll();
    }

    @Override
    public void delChannel(LSChannel lsChannel) {
        channelRepository.delete(lsChannel);
    }

    @Override
    public LSChannel findByChannelName(String channer) {
        return channelRepository.findByChannelName(channer);
    }
}
