package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSTransferControl;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-22
 * Time: 10:17
 */
public interface LSTransferControlRepository extends JpaRepository<LSTransferControl,LSTransferControl.TransferControlId> {

    LSTransferControl findTop1ByEnableOrderByOrderNumAsc(char enable);
}