package com.sinosoft.easyrecord.dao;

public interface LSInsuredClientDao {
}
