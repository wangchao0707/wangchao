package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSBankNetWorkRepository;
import com.sinosoft.easyrecord.entity.LSBankNetWork;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * Created by wds on 2018-3-20.
 */
@Component
public class BankNetWorkImpl4JPA implements BankNetWorkDao {

    @Autowired
    private LSBankNetWorkRepository lsBankNetWorkRepository;

    @Override
    public void save(LSBankNetWork lsBankNetWork) {
        lsBankNetWorkRepository.saveAndFlush(lsBankNetWork);
    }


    @Override
    public List<LSBankNetWork> findAllByBankNetWorkCode(String bankNetWorkCode) {
        return lsBankNetWorkRepository.findByBankNetWorkCode(bankNetWorkCode);
    }

    @Override
    public void delete(String id) {
        lsBankNetWorkRepository.deleteById(id);
    }
}
