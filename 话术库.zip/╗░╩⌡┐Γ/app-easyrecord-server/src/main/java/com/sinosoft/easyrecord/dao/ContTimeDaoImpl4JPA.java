package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSContTimeRepository;
import com.sinosoft.easyrecord.entity.LSContTime;

import java.util.List;
import java.util.Optional;

@Component("contTime")
public class ContTimeDaoImpl4JPA implements ContTimeDao {

    @Autowired
    private LSContTimeRepository contTimeRepository;

    public void setContTimeRepository(LSContTimeRepository contTimeRepository) {
        this.contTimeRepository = contTimeRepository;
    }

    @Override
    public void saveContTime(LSContTime lsContTime) {
        contTimeRepository.saveAndFlush(lsContTime);
    }

    @Override
    public LSContTime findContTime(String contNo) {
        Optional<LSContTime> res = contTimeRepository.findById(contNo);
        return res.orElse(null);
    }

    @Override
    public LSContTime findByContNo(String contNo) {
        return contTimeRepository.findByContNo(contNo);
    }

    @Override
    public List<String> findByBusiNum(String busiNum) {
        return contTimeRepository.findByBusiNum(busiNum);
    }
}
