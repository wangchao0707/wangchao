package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.List;

/**
 * Created by wh on 2018/2/27.
 */
public class TransbodyReq81014 implements  Transbody,Serializable{

    private static final long serialVersionUID = 16564943213L;

    private PAGES PAGES;

    public TransbodyReq81014.PAGES getPAGES() {
        return PAGES;
    }

    public void setPAGES(TransbodyReq81014.PAGES PAGES) {
        this.PAGES = PAGES;
    }

    public static class PAGES{
        private String PAGECOUNT;
        private List<PAGE> PAGE;

        public String getPAGECOUNT() {
            return PAGECOUNT;
        }

        public void setPAGECOUNT(String PAGECOUNT) {
            this.PAGECOUNT = PAGECOUNT;
        }

        public List<TransbodyReq81014.PAGE> getPAGE() {
            return PAGE;
        }

        public void setPAGE(List<TransbodyReq81014.PAGE> PAGE) {
            this.PAGE = PAGE;
        }
    }

    public static class PAGE{
        private String BUSINESSNO;  //!-- 流水号 -->
        private String FILETYPE; //文件类型 -->
        private String URL; //视频或图片地址 -->
        private String DESCRIBEID; //要点id
        private String RECORDER; //- 图片顺序 -->
        private String IMGTIMEPOINT; //图片时点 -->

        public String getBUSINESSNO() {
            return BUSINESSNO;
        }

        public void setBUSINESSNO(String BUSINESSNO) {
            this.BUSINESSNO = BUSINESSNO;
        }

        public String getFILETYPE() {
            return FILETYPE;
        }

        public void setFILETYPE(String FILETYPE) {
            this.FILETYPE = FILETYPE;
        }

        public String getURL() {
            return URL;
        }

        public void setURL(String URL) {
            this.URL = URL;
        }

        public String getRECORDER() {
            return RECORDER;
        }

        public void setRECORDER(String RECORDER) {
            this.RECORDER = RECORDER;
        }

        public String getIMGTIMEPOINT() {
            return IMGTIMEPOINT;
        }

        public void setIMGTIMEPOINT(String IMGTIMEPOINT) {
            this.IMGTIMEPOINT = IMGTIMEPOINT;
        }

        public String getDESCRIBEID() {
            return DESCRIBEID;
        }

        public void setDESCRIBEID(String DESCRIBEID) {
            this.DESCRIBEID = DESCRIBEID;
        }
    }

}
