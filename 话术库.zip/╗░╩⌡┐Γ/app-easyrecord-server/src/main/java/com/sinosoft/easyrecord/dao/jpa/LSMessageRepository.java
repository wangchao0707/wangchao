package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSMessage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.sql.Date;
import java.util.List;


/**
 * Created by WinterLee on 2017/7/22.
 */
public interface LSMessageRepository extends JpaRepository<LSMessage, String> {

    Page<LSMessage> findByUserNoOrderByMakeDateDesc(String userNo, Pageable pageable);

    List<LSMessage> findByContNo(String contNo);

    List<LSMessage> findByUserNo(String userNo);

    List<LSMessage> findByUserNoOrderByMakeDateDescMakeTimeDesc(String userNo);

    Long countByUserNo(String userNo);


    @Query(value = "select m from LSMessage m where m.userNo=?1 and (m.makeDate<?2 or m.makeDate=?3 and m.makeTime<=?4) order by m.makeDate desc, m.makeTime desc",
            countQuery = "select count(m) from LSMessage m where m.userNo=?1 and (m.makeDate<?2 or m.makeDate=?3 and m.makeTime<=?4)")
    Page<LSMessage> findByUserNoAndMakeDateLessThanOrMakeDateAndMakeTimeLessThanEqualOrderByMakeDateDescMakeTimeDesc(String userNo, Date makeDate1, Date makeDate2, String maketime, Pageable pageable);

    Page<LSMessage> findByUserNoOrderByMakeDateDescMakeTimeDesc(String userNo, Pageable pageable);


    List<LSMessage> findTop20ByState(char state);

    List<LSMessage> findByBusiNum(String businum);
}
