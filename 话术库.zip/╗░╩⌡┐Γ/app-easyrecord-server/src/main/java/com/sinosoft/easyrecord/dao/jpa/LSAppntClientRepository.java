package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LsappntClient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LSAppntClientRepository extends JpaRepository<LsappntClient,String> {
}
