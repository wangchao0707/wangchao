package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransBodyReq81003 implements Transbody, Serializable {

    private VERBALS VERBALS;

    public VERBALS getVERBALS() {
        return VERBALS;
    }

    public void setVERBALS(VERBALS VERBALS) {
        this.VERBALS = VERBALS;
    }

    public static class VERBALS {
        public String VERBALCOUNT;// <!--数据条数-->
        public List<VERBAL> VERBAL = new ArrayList<VERBAL>();

    }

    public static class VERBAL {
        public String COMPANY;// <!-- 保险公司代码 -->
        public String COMCODE;// 公司机构编码
        public String DESCRIBEID;// <!-- 话术id -->
        public String RISKCODE;// <!-- 产品编码 -->
        public String RISKNAME;// <!-- 产品名称 -->
        public String RISKTYPE;//!-- 产品类型 普通型、分红型、健康型等-->
        public String QCPOINTCODE;//-- 质检要点编码 -->
        public String QCPOINT;// <!-- 质检要点 -->
        public String QCTRICK;// <!-- 质检话术 -->
        public String ORDERNO;// <!-- 顺序号 -->s
        public String ISREAD;//是否可读

        public String ISMERGE; //是否合并
    }
}
