package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "idtype_to_customercardtype")
@Entity
public class IdTypeToCustomerCardType {

    @Id
    @Column(name = "id")
    int id;

    @Column(name = "idtype")
    String idType;

    @Column(name = "customercardtype")
    int cardType;

    @Column(name = "typename")
    String typeName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public int getCardType() {
        return cardType;
    }

    public void setCardType(int cardType) {
        this.cardType = cardType;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    @Override
    public String toString() {
        return "IdTypeToCustomerCardType{" +
                "id=" + id +
                ", idType='" + idType + '\'' +
                ", cardType='" + cardType + '\'' +
                ", typeName='" + typeName + '\'' +
                '}';
    }
}

