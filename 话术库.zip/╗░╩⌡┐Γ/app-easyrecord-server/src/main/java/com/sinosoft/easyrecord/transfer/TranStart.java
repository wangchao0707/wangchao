//package com.sinosoft.easyrecord.transfer;
//
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
//import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//import com.sinosoft.easyrecord.controller.UploadController;
//import com.sinosoft.easyrecord.dao.*;
//import com.sinosoft.easyrecord.entity.*;
//import com.sinosoft.easyrecord.service.CmsService;
//import com.sinosoft.easyrecord.service.OkhttpService;
//import com.sinosoft.easyrecord.service.PolicyService;
//import com.sinosoft.easyrecord.util.HttpUtil;
//import com.sinosoft.easyrecord.vo.FreshVo;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//import org.springframework.util.StringUtils;
//
//import javax.transaction.Transactional;
//import java.sql.Date;
//import java.util.*;
//
///**
// * @author SunYu
// * @date 2019/3/26 15:11
// */
//@Component
//public class TranStart {
//    private Logger logger = LoggerFactory.getLogger(TranStart.class);
//    @Autowired
//    private TransferInfoDao transferInfoDao;
//    @Autowired
//    private TransferControlDao transferControlDao;
//    @Value(value = "${cms.controlEnable}")
//    private Boolean controlEnable = false;
//    @Value(value = "${cms.batchNode}")
//    private String batchNode;
//
//    @Value(value = "${cms.size}")
//    private int size;
//    @Value("${cms.resBucket}")
//    private String resBucket;  //抽帧+分片桶
//    @Value("${cms.callback}")
//    private String callBack;
//    @Autowired
//    private ContDao contDao;
//    @Autowired
//    private UserDao userDao;
//    @Autowired
//    private PictureDao pictureDao;
//    @Autowired
//    private OkhttpService okhttpService;
//    @Autowired
//    private CmsService cmsService;
//    @Autowired
//    private CmsPictureDao cmsPictureDao;
//    @Autowired
//    private PolicyService policyService;
//    @Value("${cms.management}")
//    private String management;
//    @Value("${cms.outernet}")
//    private String outerNet;
//    @Value("${cms.indexEnable}")
//    private Boolean indexEnable;
//    @Value("${cms.updateEnable}")
//    private Boolean updateEnable;
//    @Value("${cms.sendEnable}")
//    private Boolean sendEnable;
//    @Value("${cms.orgCodes}")
//    private String orgCodes;
//    @Value("${cms.transferSize}")
//    private int transferSize;
//
//    /**
//     * @param
//     * @return void
//     * 将上传完的transferinfo中的状态改为E，准备更新索引
//     * @Author SunYu
//     * @Date 15:18 2019/3/26
//     **/
//    @Scheduled(initialDelay = 1000, fixedDelay = 10000)
//    public void transferControlStart() {
//        if (!indexEnable) {
//            logger.info("transferStart::: {},break!!!!!", indexEnable);
//            return;
//        }
//        transControl();
//    }
//
//    //更新索引的主体任务
//    @Scheduled(initialDelay = 1000, fixedDelay = 1000)
//    public void transferStart() {
//        if (!updateEnable) {
//            logger.info("cmsStart::: {},break!!!!!", updateEnable);
//            return;
//        }
//        transStart();
//    }
//    //获取外链
//    @Scheduled(initialDelay = 1000, fixedDelay = 1000)
//    public void getLinkStart() {
//        if (!controlEnable) {
//            logger.info("cmsStart::: {},break!!!!!", controlEnable);
//            return;
//        }
//        getLink();
//    }
//    //发送信息给质检端，更新链接
//    @Scheduled(initialDelay = 1000, fixedDelay = 1000)
//    public void sendMessage(){
//        if (!sendEnable) {
//            logger.info("sendMessage::: {},break!!!!!", sendEnable);
//            return;
//        }
//        sendTo();
//    }
//    @Transactional
//    public void sendTo(){
//        String[] orgs = orgCodes.split(",");
//        LSTransferInfo lsTransferInfo = transferInfoDao.findByStatusAndOrgCode("W", orgs);
//        if (lsTransferInfo == null) {
//            logger.info("lsTransferInfo == null, sendTo return");
//            return;
//        }
//        lsTransferInfo.setStatus("P");
//        lsTransferInfo.setBatchNode(batchNode);
//        transferInfoDao.saveTransferInfo(lsTransferInfo);
//        String contNo = lsTransferInfo.getContNo();
//        List<FreshVo> message = new ArrayList<>();
//        //获取图片的信息
//        List<LSPicture> pictures = pictureDao.findByContNo(contNo);
//        if(pictures != null && !pictures.isEmpty()){
//            for(LSPicture lsPicture : pictures){
//                FreshVo picture = new FreshVo();
//                picture.setBusinessno(contNo);
//                picture.setDescribeid(lsPicture.getpKId());
//                picture.setFiletype(lsPicture.getBusiType());
//                picture.setUrl(lsPicture.getURL());
//                message.add(picture);
//            }
//        }
//        //获取m3u8信息
//        LSVideo lsVideo = policyService.findVideoByContNo(contNo);
//        if(lsVideo != null){
//            FreshVo video = new FreshVo();
//            video.setBusinessno(contNo);
//            video.setFiletype("video");
//            video.setUrl(lsVideo.getURL());
//            message.add(video);
//        }
//        Map map = new HashMap();
//        map.put("file", message);
//        logger.info("sendTo message : {}", map);
//        try {
//            String result = HttpUtil.doPost(management,JSONObject.toJSONString(map));
//            logger.info("sendTo message result: {}",result);
//            if("true".equals(result)){
//                lsTransferInfo.setStatus("O");
//                lsTransferInfo.setBatchNode(batchNode);
//                transferInfoDao.saveTransferInfo(lsTransferInfo);
//            }else {
//                lsTransferInfo.setStatus("R");
//                lsTransferInfo.setBatchNode(batchNode);
//                transferInfoDao.saveTransferInfo(lsTransferInfo);
//            }
//        } catch (Exception e) {
//            logger.info("sent to failed:{}",e);
//            lsTransferInfo.setStatus("R");
//            lsTransferInfo.setBatchNode(batchNode);
//            transferInfoDao.saveTransferInfo(lsTransferInfo);
//        }
//    }
//
//
//    @Transactional
//    public void getLink() {
//        LSTransferInfo lsTransferInfo = transferInfoDao.findByStatus("U");
//        if (lsTransferInfo == null) {
//            logger.info("lsTransferInfo == null, getLink return");
//            return;
//        }
//        String cmsId = lsTransferInfo.getCmsId();
//        String contNo = lsTransferInfo.getContNo();
//        lsTransferInfo.setStatus("M");
//        lsTransferInfo.setBatchNode(batchNode);
//        transferInfoDao.saveTransferInfo(lsTransferInfo);
//        //是否失败
//        boolean isFailed = false;
//        //获取上传图片的外链
//        List<LSCmsPicture> cmsPictures = cmsPictureDao.findByContNo(contNo);
//        for (LSCmsPicture cmsPicture : cmsPictures) {
//            //获取picture
//            LSPicture lsPicture = pictureDao.findByPicNameAndContNo(cmsPicture.getPicName(), contNo);
//            if (lsPicture != null) {
//                String result = cmsService.getPicture(cmsPicture.getCmsId(), "0",3);
//                if (StringUtils.isEmpty(result)) {
//                    logger.info("transfer get ID picture failed, contNo = {}", contNo);
//                    isFailed = true;
//                } else {
//                    lsPicture.setURL(outerNet + result);
//                }
//                lsPicture.setTimeNode(cmsPicture.getCmsId());
//                pictureDao.save(lsPicture);
//            }
//        }
//        //获取抽帧图片的外链
//        List<LSPicture> pictures = pictureDao.findByContNoAndBusiType(contNo, "ScreenShoot");
//        for (LSPicture picture : pictures) {
//            //获取抽帧图片的id
//            String objectId = cmsId + "_" + picture.getTimeNode().split("\\.")[0] + ".jpeg";
//            String screenShotUrl = cmsService.getPicture(objectId, "1",3);
//            if (StringUtils.isEmpty(screenShotUrl)) {
//                logger.info("transfer get screenShot url failed, contno = {}", contNo);
//                isFailed = true;
//            } else {
//                picture.setURL(outerNet + screenShotUrl);
//            }
//            pictureDao.save(picture);
//        }
//        //获取m3u8
//        LSVideo lsVideo = policyService.findVideoByContNo(contNo);
//        lsVideo.setCloudFileId(cmsId);
//        String m3u8 = cmsService.getM3u8(cmsId);
//        if (StringUtils.isEmpty(m3u8)) {
//            logger.info("transfer getM3u8 failed, contno = {}", contNo);
//            isFailed = true;
//        } else {
//            lsVideo.setURL(outerNet + m3u8);
//        }
//        policyService.saveVideo(lsVideo);
//        if(isFailed){
//            lsTransferInfo.setStatus("X");
//            lsTransferInfo.setBatchNode(batchNode);
//            transferInfoDao.saveTransferInfo(lsTransferInfo);
//            return;
//        }
//        lsTransferInfo.setStatus("W");
//        lsTransferInfo.setBatchNode(batchNode);
//        transferInfoDao.saveTransferInfo(lsTransferInfo);
//    }
//
//    public void transStart() {
//        //查询未处理的数据，一次处理一单
//        //首先查询是否有处理中的单子 有两单则不处理直接返回
//        int countH = transferInfoDao.findByStatusAndBatchNode("I", batchNode);
//        if (countH >= size) {
//            logger.info("transStart transinfo size > = 2 return");
//            return;
//        }
//        LSTransferInfo lsTransferInfo = transferInfoDao.findByStatus("E");
//        if (lsTransferInfo == null) {
//            logger.info("transStart transinfo E size==0");
//            return;
//        }
//        //判断正在转码的任务数量，超过则不更新索引
//        int countG = transferInfoDao.findByStatusAndBatchNode("G", batchNode);
//        if(countG >= transferSize){
//            logger.info("transStart transinfo G size >= " + transferSize + " return");
//            return;
//        }
//        Thread thread = new Thread() {
//            @Override
//            public void run() {
//
//                update(lsTransferInfo);
//            }
//        };
//        thread.start();
//    }
//    @Transactional
//    public void update(LSTransferInfo lsTransferInfo) {
//        lsTransferInfo.setStatus("I");
//        lsTransferInfo.setBatchNode(batchNode);
//        transferInfoDao.saveTransferInfo(lsTransferInfo);
//        String contNo = lsTransferInfo.getContNo();
//        //String cmsId = lsTransferInfo.getCmsId();
//        //LSCont lsCont = contDao.findByContNo(contNo);
//        //Map<String, Object> map = new HashMap<>();
//        //String[] businumss = lsCont.getBusiNum().split(",");
//        //map.put("e_appl_no", Arrays.asList(businumss)); //电子投保单单号
//        /*LSUser lsUser = userDao.getUser(lsCont.getOperator());
//        String agentcode = "00000012345678";
//        String phoneNo = "13888888888";
//        if (lsUser != null) {
//            agentcode = lsUser.getAgentCode() == null ? "00000012345678" : lsUser.getAgentCode();
//            phoneNo = lsUser.getPhoneNo() == null ? "13888888888" : lsUser.getPhoneNo();
//        }*/
//        //map.put("isbs_rec_no", contNo);
//        //map.put("clerk_no", agentcode);   //agentcode
//        //map.put("phone_no", phoneNo);     //手机号
//        //map.put("isbs_notify_url", callBack);          //回调地址
//        //转码+切割参数
//        //map.put("isbs_res_bucket", resBucket);        //抽帧+分片桶名
//        //map.put("isbs_hls_time", "15");               //分片时间建个
//        //List<String> cms_hls_resolution = new ArrayList<>();
//        //cms_hls_resolution.add("600x480");           //分片分辨率
//        //map.put("isbs_hls_resolution", cms_hls_resolution);
//        /*List<String> cms_extract_time = new ArrayList<>();
//        List<LSPicture> pictures = pictureDao.findByContNoAndBusiType(contNo, "ScreenShoot");
//        String[] nodes = new String[2];
//        if(pictures != null && !pictures.isEmpty()){
//            //抽帧参数
//            for (LSPicture picture : pictures) {
//                cms_extract_time.add(picture.getTimeNode().split("\\.")[0]);
//            }
//            nodes[0] = "抽帧时点:"+cms_extract_time;
//            nodes[1] = "抽帧图片大小:600x480";
//            //map.put("isbs_extract_time", cms_extract_time);    //抽帧时点
//            //map.put("isbs_extract_size", "600x480");          //抽帧图片大小
//        }else {
//            cms_extract_time.add("1");
//            nodes[0] = "抽帧时点:"+cms_extract_time;
//            nodes[1] = "抽帧图片大小:600x480";
//            //map.put("isbs_extract_time", cms_extract_time);    //抽帧时点
//            //map.put("isbs_extract_size", "600x480");          //抽帧图片大小
//        }*/
//        //map.put("isbs_transcoding_status", UploadController.VideoTransCodingStatusEnum.TRANS_CODING); //转码状态
//        //logger.info("transfer updateIndex map : {}", map);
//        //String result = cmsService.updateIndex(cmsId, map);
//
//        // trans_type为1代表需要转码
//        RequestResult res = okhttpService.addVideo(null, callBack, "1",null,null,null);
//        logger.info("transfer updateIndex result : {}", res);
//        if (res.isSuccess()) {
//            lsTransferInfo.setStatus("G");
//            lsTransferInfo.setBatchNode(batchNode);
//            transferInfoDao.saveTransferInfo(lsTransferInfo);
//        } else {
//            lsTransferInfo.setStatus("K");
//            lsTransferInfo.setBatchNode(batchNode);
//            transferInfoDao.saveTransferInfo(lsTransferInfo);
//        }
//    }
//
//    @Transactional
//    public void transControl() {
//        LSTransferInfo infoList = transferInfoDao.findByStatus("E");
//        if (infoList != null) {
//            logger.info("transControl Business data not processed");
//            return;
//        }
//        LSTransferControl lsTransferControl = transferControlDao.findByEnable('C');
//        if (lsTransferControl != null) {
//            logger.info("transControl transfer control {}", lsTransferControl);
//            String orgCode = lsTransferControl.getTransferControlId().getOrgCode();
//            Date modifydate = lsTransferControl.getTransferControlId().getModifyDate();
//            logger.info("transControl transfer start orgcode {} modifydate {}", orgCode, modifydate);
//            //查询transinfo数据
//            List<LSTransferInfo> list1 = transferInfoDao.findByOrgCodeAndModifydateAndAndStatus(orgCode, modifydate, "A");
//            List<LSTransferInfo> list2 = transferInfoDao.findByOrgCodeAndModifydateAndAndStatus(orgCode, modifydate, "B");
//            List<LSTransferInfo> list3 = transferInfoDao.findByOrgCodeAndModifydateAndAndStatus(orgCode, modifydate, "D");
//            //如果存在A、B、D状态的transferinfo，则跳过这一天的数据
//            if ((list1 != null && !list1.isEmpty()) || (list2 != null && !list2.isEmpty()) || (list3 != null && !list3.isEmpty())) {
//                lsTransferControl.setEnable('G');
//                transferControlDao.saveTransControl(lsTransferControl);
//                logger.info("transControl transfercontrol G {}", lsTransferControl);
//                return;
//            }
//            //插入数据中
//            lsTransferControl.setEnable('E');
//            transferControlDao.saveTransControl(lsTransferControl);
//            //将transferinfo状态改为E
//            List<LSTransferInfo> transferInfos = transferInfoDao.findByOrgCodeAndModifydate(orgCode, modifydate);
//            for (LSTransferInfo transferInfo : transferInfos) {
//                transferInfo.setStatus("E");
//                transferInfoDao.saveTransferInfo(transferInfo);
//                logger.info("transControl save transferinfo {}", transferInfo);
//            }
//            //插入数据完毕
//            lsTransferControl.setEnable('I');
//            transferControlDao.saveTransControl(lsTransferControl);
//        } else {
//            logger.info("transControl not exists info");
//            return;
//        }
//    }
//
//    public static void main(String[] args) {
//        TranStart tranStart = new TranStart();
//        TransferInfoDao transferInfoDao = new TransferInfoDaoImpl();
//        LSTransferInfo lsTransferInfo = transferInfoDao.findByStatus("E");
//        try {
//            Thread thread = new Thread() {
//                @Override
//                public void run() {
//                    tranStart.update(lsTransferInfo);
//                }
//            };
//            thread.start();
//            //tranStart.transStart();
//            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//}
