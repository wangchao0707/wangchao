package com.sinosoft.easyrecord.util;

import com.sinosoft.easyrecord.dao.LDCodeDao;
import com.sinosoft.easyrecord.entity.LDCode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author lijunming
 * @date 2018/7/1 下午3:21
 */

public class RegetUserInfo {

    private LDCodeDao ldCodeDao;

    public void setLdCodeDao(LDCodeDao ldCodeDao) {
        this.ldCodeDao = ldCodeDao;
    }

    /**
     * @param regex 正则表达式字符串
     * @param str   要匹配的字符串
     * @return 如果str 符合 regex的正则表达式格式,返回true, 否则返回 false;
     */
    private  boolean match(String regex, String str) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }

    /*    ******************国寿个人客户关键信息录入校验规则开始*****************    */

    /**
     * 验证姓名
     * 中文姓名长度≥2个字符，≤200个字符，其中姓名间隔符“·”，不允许其他特殊符号
     * 英文姓名长度≥1个字符，≤200个字符，可包含字母、数字、括号、字符间支持一个空格、“.”、“•”“-”。
     */
    public  boolean isName(String name) {
        //由于英文姓名正则表达式验证长度比较麻烦，直接简单暴力验证
        if (name.length() > 200) {
            return false;
        }
        String regex = "^((?:[\u4e00-\u9fa5]+)(?:·[\\u4e00-\\u9fa5]+)*)|[a-zA-Z0-9()s.、·-]{1,}\\s?[a-zA-Z0-9().、·-]{1,}$";
        return match(regex, name);
    }

    /**
     * 验证性别
     * 选择项男性、女性、未知性别、未说明性别。
     */
    public  boolean isSex(String sex) {
        if (sex.equals("0") || sex.equals("1")) {
            return true;
        }
        return false;
    }

    /**
     * 验证出生日期格式
     *  YYYY-MM-DD;YYYYMMDD;YYYY/MM/DD;YYYY.MM.DD。  已匹配闰年
     */
    public  boolean isDate(Date date) {
        String regex = "^(((1[6-9]|[2-9]\\d)\\d{2})[-/.]?(0?[13578]|1[02])[-/.]?(0?[1-9]|[12]\\d|3[01]))|(((1[6-9]|[2-9]\\d)\\d{2})[-/.]?(0?[13456789]|1[012])[-/.]?(0?[1-9]|[12]\\d|30))|(((1[6-9]|[2-9]\\d)\\d{2})[-/.]?0?2[-/.]?(0?[1-9]|1\\d|2[0-8]))|(([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00))[-/.]?0?2[-/.]?29$";
        String dateStr=new SimpleDateFormat("yyyy-MM-dd").format(date);
        return match(regex, dateStr);
    }

    /**
     * 验证证件类型
     * 外国人永久居留证:11
     * 港澳居民往来内地通行证:  9
     * 身份证:4
     * 其他(个人): 13
     * 护照:  7
     * 台湾居民往来大陆通行证:W  8
     * 户口簿:   5
     * 出生医学证明:  14
     */
    public  boolean isIDType(String IDType) {
        boolean flag = true;
        switch (IDType) {
            case "4":
            case "5":
            case "7":
            case "8":
            case "9":
            case "11":
            case "13":
            case "14":
                break;
            default:
                flag = false;
        }
        return flag;
    }

    /**
     * 验证证件号码
     * 2、当证件类型为身份证、临时身份证、户口簿时，证件号码要符合身份证号码校验规则:
     * (1)证件号码长度为18位；
     * (2)证件号码中的前六位为地址码，按照《GB/T 2260 中华人民共和国行政区划代码》执行,系统校验前两位地址码；
     * (3)证件号码中的第七位至第十四位为出生日期码，按照《GB/T 7408 数据元和交换格式 信息交换 日期和时间表示法》执行；
     * (4)证件号码中的出生日期与系统录入的客户出生日期一致；
     * (5)证件号码的第十七位为性别校验位，奇数为男性，偶数为女性，与系统录入的客户性别一致；
     * (6)证件号码的第十八位为校验码，校验规则按照《GB 11643 公民身份号码》执行。
     */
    public    boolean  isIDNo(String IDNo,String sex,Date birthday,String address){
        try {
            if(IDNo.length()!=18){
                return  false;
            }
            int index=address.indexOf("省");
            if(index==-1){
                index=address.indexOf("市");
            }
            String city=address.substring(0,index);
            String validate=IDNo.substring(0,2);//待验证的地址码
            LDCode ldCode =ldCodeDao.findLDCodeByCodeName(city);//地址对应的地址
            if(ldCode==null){
                return  false;
            }
            String addressCode=ldCode.getCode();
            if(!addressCode.equals(validate)){
                return false;
            }
            String dateStr=IDNo.substring(6,14);
            Date str=new SimpleDateFormat("yyyyMMdd").parse(dateStr);
            if(str.getTime()!=birthday.getTime()){ //验证生日
                return  false;
            }
            String sexStr=IDNo.substring(16,17);//性别验证码
            Integer sexInt=Integer.parseInt(sexStr);
            if(sexInt%2==0){
                sexStr="1";
            }else{
                sexStr="0";
            }
            if(sexStr!=sex){//验证性别
                return  false;
            }
        }catch (Throwable tb){
            return  false;
        }
        boolean flag=isIDNoValidate(IDNo);//验证校验码
        return flag;
    }

    /**
     * 验证其他证件类型号码
     * 长度≥6个字符，≤25个字符，不存在空格、回车、特殊字符。
     */
    public boolean isIDNO(String isIDNo){
            String regex="^[A-Za-z0-9]{6,25}$";
            return match(regex,isIDNo);
    }
    /**
     * 3、当证件类型为出生医学证明时，证件号码要符合编号校验规则:
     * (1)证件号码长度为10位；
     * (2)证件号码由1个字母+9个数字组成；
     * (3)证件号码中的首字母对应出生年份，A对应2000年，B对应2001年，字母与年份的对应关系按26个字母顺序依次排列；
     * (4)证件号码中前两位数字为地址码，按照《GB/T 2260 中华人民共和国行政区划代码》执行,系统校验地址码；
     * (5)证件号码中后七位数字为出生医学证明顺序号
     */
    public    boolean isBirthdayNo(String birthdayNo,Date birthday,String address){
        String birthdayStr=new SimpleDateFormat("yyyy-MM-dd").format(birthday);
        String regex="^[A-Z]+\\d{9}$";
        if(match(regex,birthdayNo)==false){//验证证件号码由1个字母+9个数字组成
            return  false;
        }
        String first=birthdayNo.substring(0,1);
        char  cr=first.charAt(0);
        int year=2000+Integer.valueOf(cr)-65;
        int birthdayYear=Integer.parseInt(birthdayStr.substring(0,4));
        if(birthdayYear!=year) {//验证出生的年份和出生证明的是否匹配
            return false;
        }
        int index=address.indexOf("省");
        if(index==-1){
            index=address.indexOf("市");
        }
        String city=address.substring(0,index);
        String validate=birthdayNo.substring(1,3);//待验证的地址码
        LDCode ldCode =ldCodeDao.findLDCodeByCodeName(city);//地址对应的地址
        if(ldCode==null){
            return  false;
        }
        String addressCode=ldCode.getCode();
        if(!addressCode.equals(validate)){
            return false;
        }
        return true;
    }
    /**
     * 验证移动电话
     * 按国家代码+电话号码两段列出，，国家代码默认为0086，可更改，电话号码段长度≥8个字符，≤25个字符。
     * 3、当国家代码段为0086时，需符合各大运营商移动电话编码规则，移动电话号码只能为数字，号码长度为11位，且必须以“13、14、15、16、17、18、19”开头。
     */
    public    boolean isMobile(String mobile){
        String regex="^(0086\\d{8,25})|1[3456789]+\\d{9}$";
        return match(regex,mobile);
    }


    /**
     * 验证通讯地址
     * 地址按国家、省、市、县（区）、详细地址分段列出，国家默认为中国，可更改，省、市、县（区）三级为自动列出，可选择，详细地址需精确到门牌号(如：**省**市**县（区）**街道(镇)**路（村）详细地址)。详细地址长度在≥6个字符，≤200个字符。
     */
    public    boolean isAddress(String address){
        String regex="^([\u4e00-\u9fa5]{1,}省)?[\u4e00-\u9fa5]{1,}市[\u4e00-\u9fa5]{1,}[县区]+[\u4e00-\u9fa5]{1,}(街道|镇)[\u4e00-\u9fa5]{1,}[路村]+\\S*$";
        return match(regex,address);
    }


    /**
     * 身份证校验码计算方式
     * 将前面的身份证号码17位数分别乘以不同的系数。从第一位到第十七位的系数分别为：7－9－10－5－8－4－2－1－6－3－7－9－10－5－8－4－2。
     * 将这17位数字和系数相乘的结果相加。
     * 用加出来和除以11，余数就是正确的校验码
     */
    public  boolean  isIDNoValidate(String IDNo){
        String validate[]=new String []{"1","0","X","9","8","7","6","5","4","3","2"};//最后一位校验码数组
        int  num[]=new int[]{7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
        String yuan=IDNo.substring(17);//要认证的校验码
        int sum=0;
        for(int i=0;i< IDNo.length()-1;i++){
            sum+=Integer.parseInt(IDNo.substring(i,i+1))*num[i];
        }
        String  result=validate[sum%11];//法定的校验码
        if(result.equals(yuan)){
            return  true;
        }
        return false;
    }


}
