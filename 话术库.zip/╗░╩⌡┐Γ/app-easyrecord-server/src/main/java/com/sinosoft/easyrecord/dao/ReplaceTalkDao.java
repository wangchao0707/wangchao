package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSReplacetalk;

import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2018-06-26
 * Time: 10:19
 */
public interface ReplaceTalkDao {

    LSReplacetalk findByBusiNumAndRiskName(String busiNum,String riskName);

    LSReplacetalk findByBusiNumAndRiskCode(String busiNum,String riskCode);


    List<LSReplacetalk> findByBusiNum(String busiNum);

    //LSReplacetalk findByBusiNum(String busiNum);

    void saveReplaceTalk(LSReplacetalk lsReplacetalk);

    List<LSReplacetalk> findByRiskCodeAndBusiNum(String riskType,String busiNum);
}
