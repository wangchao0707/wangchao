package com.sinosoft.easyrecord.dao;

//import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSContStateRespository;
import com.sinosoft.easyrecord.entity.LsContState;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Optional;

@Component
public class ContStateDaoImpl4JPA implements ContStateDao {

    private static final Logger logger = LoggerFactory.getLogger(ContStateDaoImpl4JPA.class);

    private LSContStateRespository lsContStateRespository;

//    @PersistenceContext
//    private EntityManager entityManager;

    @Autowired
    public void setLsContStateRespository(LSContStateRespository lsContStateRespository) {
        this.lsContStateRespository = lsContStateRespository;
    }

    @Override
    public void save(LsContState lsContState) {
        logger.info("lsContStateRespository.saveAndFlush(lsContState: {})", lsContState);
        lsContStateRespository.saveAndFlush(lsContState);
        logger.info("lsContStateRespository.saveAndFlush(lsContState: {})", lsContState);
//        entityManager.flush();
    }

    @Override
    public LsContState getContState(String contNo) {
        Optional<LsContState> res = lsContStateRespository.findById(contNo);
        return res.orElse(null);
    }

}
