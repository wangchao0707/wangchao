package com.sinosoft.easyrecord.dao.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sinosoft.easyrecord.entity.LSPicture;

public interface LSPictureRepository extends JpaRepository<LSPicture, String> {

    @Query("select p from LSPicture p where p.contNo = ?1 order by timeNode")
    List<LSPicture> findByContNo(String contNo);


    LSPicture findByPicNameAndContNo(String picName, String contNo);

    List<LSPicture> findByContNoAndBusiType(String contNo, String busiType);

    @Query(value = "select * from LSPicture  where contNo = ?1 order by CAST(timenode AS SIGNED) ASC",nativeQuery = true)
    List<LSPicture> findPictureByContnoOrderByTimeNode(String contno);

    LSPicture findByPKIdAndContNo(String pkId,String contNo);

    LSPicture findByPicNo(String picNo);

}
