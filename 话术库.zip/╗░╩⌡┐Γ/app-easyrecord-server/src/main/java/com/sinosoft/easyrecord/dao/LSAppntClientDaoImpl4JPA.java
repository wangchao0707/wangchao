package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSAppntClientRepository;
import com.sinosoft.easyrecord.entity.LsappntClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LSAppntClientDaoImpl4JPA implements LSAppntClientDao {
    @Autowired
    private LSAppntClientRepository lsAppntClientRepository;

    public void save(LsappntClient lsappntClient){
        lsAppntClientRepository.saveAndFlush(lsappntClient);
    }
}
