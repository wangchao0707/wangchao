package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransbodyReq80007 implements Transbody, Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 2565211654649L;

    private CHANNELS CHANNELS;


    public CHANNELS getCHANNELS() {
        return CHANNELS;
    }

    public void setCHANNELS(CHANNELS cHANNELS) {
        CHANNELS = cHANNELS;
    }

    public static class CHANNELS {
        public String CHANNELCOUNT; //<!--数据条数-->
        public List<CHANNEL> CHANNEL = new ArrayList<TransbodyReq80007.CHANNEL>();
    }

    public static class CHANNEL {
        public String CHANNELCODE;//-- 渠道编码 -->
        public String CHANNELNAME;// 渠道名称 -->
    }

}
