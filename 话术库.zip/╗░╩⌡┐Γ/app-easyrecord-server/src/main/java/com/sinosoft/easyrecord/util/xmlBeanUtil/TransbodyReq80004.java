package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransbodyReq80004 implements Transbody, Serializable {


    /**
     *
     */
    private static final long serialVersionUID = 4125896325687415264L;
    private GENERATIONS GENERATIONS;

    public GENERATIONS getGENERATIONS() {
        return GENERATIONS;
    }

    public void setGENERATIONS(GENERATIONS gENERATIONS) {
        GENERATIONS = gENERATIONS;
    }

    public static class GENERATIONS {
        public String GENERATIONCOUNT;
        public List<GENERATION> GENERATION = new ArrayList<GENERATION>();
    }


    public static class GENERATION {
        public String AGENTCOM; //<!-- 经代公司编码 -->
        public String COMPANY;  //<!-- 保险公司代码 -->
        public String APPOINTSDATE;//<!-- 签约开始时间 -->
        public String APPOINTEDATE;//<!-- 签约结束时间 -->
        public String VALIDFLAG;//<!-- 激活状态 -->
    }
}
