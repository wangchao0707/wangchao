package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSTalkRepository;
import com.sinosoft.easyrecord.entity.LSTalk;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zf on 2017/7/27.
 */
@Component
public class TalkDaoImpl4JPA implements TalkDao {
    @Autowired
    private LSTalkRepository talkRepository;

    public LSTalkRepository getTalkRepository() {
        return talkRepository;
    }

    @Override
    public List<LSTalk> findTalkList(String comCode, String insurComCode, String riskType) {
        List<LSTalk> ls = talkRepository.findByComCodeAndInsurComCodeAndRiskTypeOrderByOrderNumAsc(comCode, insurComCode, riskType);
        return ls;
    }

    @Override
    public List<LSTalk> findByComCode(String comCode) {
        return talkRepository.findByComCode(comCode);
    }

    @Override
    public void deleteByComCode(String comCode) {
        talkRepository.deleteByComCode(comCode);
        talkRepository.flush();
    }

    @Override
    public void save(LSTalk lsTalk) {
        talkRepository.saveAndFlush(lsTalk);
    }

    @Override
    public List<LSTalk> findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(String comCode,
                                                                                            String insurComCode, String orgCode, String riskType) {
        return talkRepository.findByComCodeAndInsurComCodeAndOrgCodeAndRiskTypeOrderByOrderNumAsc(comCode, insurComCode, orgCode, riskType);
    }

    @Override
    public LSTalk findOneByPkId(String pkId) {
        return talkRepository.findByPkid(pkId);
    }

    @Override
    public LSTalk findTop1ByTalkPointCode(String talkPointCode) {
        return talkRepository.findTop1ByTalkPointCode(talkPointCode);
    }
}
