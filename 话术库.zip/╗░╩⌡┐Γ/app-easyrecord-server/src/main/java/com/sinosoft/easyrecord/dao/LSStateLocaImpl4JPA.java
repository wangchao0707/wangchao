package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSStateLocaRepository;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSStateLoca;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
@Service
public class LSStateLocaImpl4JPA implements  LSStateLocaDao {
    @Autowired
    private LSStateLocaRepository lsStateLocaRepository;

    private SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");

    @Override
    public void editStateLoca(LSStateLoca lsStateLoca) {
        lsStateLocaRepository.saveAndFlush(lsStateLoca);
    }

    @Override
    public List<LSStateLoca> findByIsSend(String isSend) {
        return lsStateLocaRepository.findTop100ByIsSend(isSend);
    }


    @Override
    public void saveStateLoca(LSCont lsCont, String stateName) {
        //保存保单状态变更轨迹记录
        LSStateLoca lsStateLoca=null;
        String busiNumArr[]=lsCont.getBusiNum().split(",");
        Date date=new Date();
        //如果有多个保单号则保存多条记录
        for (String busiNum:busiNumArr) {
            //如果保单状态变更记录存在，则修改保单状态，否则新增
            lsStateLoca=lsStateLocaRepository.findTop1ByBusiNum(lsCont.getBusiNum());
            if(lsStateLoca==null) {
                lsStateLoca=new LSStateLoca();
                lsStateLoca.setId(UUID.randomUUID().toString());
            }
            lsStateLoca.setBusiNum(busiNum);
            lsStateLoca.setStateName(stateName);
            lsStateLoca.setIsSend("N");//默认为没推送
            lsStateLoca.setMakeDate(date);
            lsStateLoca.setMakeTime(sdf.format(date));
            lsStateLoca.setContState(lsCont.getInteractive());
            lsStateLoca.setContNo(lsCont.getContNo());
            lsStateLocaRepository.saveAndFlush(lsStateLoca);
        }
    }
}
