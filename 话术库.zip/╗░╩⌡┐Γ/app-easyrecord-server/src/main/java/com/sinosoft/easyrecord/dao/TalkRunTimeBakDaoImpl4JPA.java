package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSTalkRunTimeBakRepository;
import com.sinosoft.easyrecord.entity.LSTalkRunTimeBak;

@Component
public class TalkRunTimeBakDaoImpl4JPA implements TalkRunTimeBakDao {

    @Autowired
    private LSTalkRunTimeBakRepository talkRunTimeBakRepository;

    public void setTalkRunTimeBakRepository(LSTalkRunTimeBakRepository talkRunTimeBakRepository) {
        this.talkRunTimeBakRepository = talkRunTimeBakRepository;
    }

    @Override
    public void saveTalkRunTimeBak(LSTalkRunTimeBak lsTalkRunTimeBak) {
        talkRunTimeBakRepository.saveAndFlush(lsTalkRunTimeBak);
    }

}
