package com.sinosoft.easyrecord.entity;

import org.springframework.context.annotation.Configuration;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
@Entity
@Table(name = "LSReplaceTalk")
public class LSReplacetalk  implements Serializable {
    @Id
    @Column(name = "Id")
    private String id;//唯一标识

    @Column(name="BusiNum")
    private String busiNum;

    @Column(name="AppntName")
    private String appntName;

    @Column(name="InsuredName")
    private String insuredName;

    @Column(name="ComName")
    private String  comName;

    @Column(name="UserName")
    private String userName;

    @Column(name="RiskName")
    private String riskName;

    @Column(name="IntersectionPayInty")
    private String  intersectionPayInty;

    @Column(name="IntersectionPrem")
    private String intersectionPrem;

    @Column(name="IntersectionPayEndYead")
    private String intersectionPayEndYead;

    @Column(name="IntersectionInsuYear")
    private String intersectionInsuYear;

    @Column(name="WholesalePrem")
    private String wholesalePrem;

    @Column(name="WholesaleInsuYear")
    private String wholesaleInsuYear;

    @Column(name="WholesaleHesitation")
    private String wholesaleHesitation;

    @Column(name = "IntersectionPayEndYearFlag")
    private String intersectionPayEndYearFlag;

    /**
     * 期交 保险期间 标识 Y:保多少年 | A:保到多少岁 |InsuYearFlag为A且InsuYear为105 表示终 身
     **/
    @Column(name = "IntersectionInsuYearFlag")
    private String intersectionInsuYearFlag;

    /**
     * 趸交 保险期间 标识 Y:保多少年 | A:保到多少岁 |InsuYearFlag为A且InsuYear为105 表示终 身
     **/
    @Column(name = "WholesaleInsuYearFlag")
    private String wholesaleInsuYearFlag;


    /**
     * Date:2019/06/21
     * Time:10:47
     * 新增投保人生日，被保人生日，投被保人关系
     */

    @Column(name = "appntBirthday")
    private String appntBirthday;

    @Column(name = "insuredBirthday")
    private String insuredBirthday;

    @Column(name = "insuredRelationship")
    private String insuredRelationship;

    //险种编号
    @Column(name = "riskcode")
    private String riskCode;

    public String getAppntBirthday() {
        return appntBirthday;
    }

    public void setAppntBirthday(String appntBirthday) {
        this.appntBirthday = appntBirthday;
    }

    public String getInsuredBirthday() {
        return insuredBirthday;
    }

    public void setInsuredBirthday(String insuredBirthday) {
        this.insuredBirthday = insuredBirthday;
    }

    public String getInsuredRelationship() {
        return insuredRelationship;
    }

    public void setInsuredRelationship(String insuredRelationship) {
        this.insuredRelationship = insuredRelationship;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAppntName() {
        return appntName;
    }

    public void setAppntName(String appntName) {
        this.appntName = appntName;
    }

    public String getInsuredName() {
        return insuredName;
    }

    public void setInsuredName(String insuredName) {
        this.insuredName = insuredName;
    }

    public String getComName() {
        return comName;
    }

    public void setComName(String comName) {
        this.comName = comName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRiskName() {
        return riskName;
    }

    public void setRiskName(String riskName) {
        this.riskName = riskName;
    }

    public String getIntersectionPayInty() {
        return intersectionPayInty;
    }

    public void setIntersectionPayInty(String intersectionPayInty) {
        this.intersectionPayInty = intersectionPayInty;
    }

    public String getIntersectionPrem() {
        return intersectionPrem;
    }

    public void setIntersectionPrem(String intersectionPrem) {
        this.intersectionPrem = intersectionPrem;
    }

    public String getIntersectionPayEndYead() {
        return intersectionPayEndYead;
    }

    public void setIntersectionPayEndYead(String intersectionPayEndYead) {
        this.intersectionPayEndYead = intersectionPayEndYead;
    }

    public String getIntersectionInsuYear() {
        return intersectionInsuYear;
    }

    public void setIntersectionInsuYear(String intersectionInsuYear) {
        this.intersectionInsuYear = intersectionInsuYear;
    }

    public String getWholesalePrem() {
        return wholesalePrem;
    }

    public void setWholesalePrem(String wholesalePrem) {
        this.wholesalePrem = wholesalePrem;
    }

    public String getWholesaleInsuYear() {
        return wholesaleInsuYear;
    }

    public void setWholesaleInsuYear(String wholesaleInsuYear) {
        this.wholesaleInsuYear = wholesaleInsuYear;
    }

    public String getWholesaleHesitation() {
        return wholesaleHesitation;
    }

    public void setWholesaleHesitation(String wholesaleHesitation) {
        this.wholesaleHesitation = wholesaleHesitation;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getIntersectionPayEndYearFlag() {
        return intersectionPayEndYearFlag;
    }

    public void setIntersectionPayEndYearFlag(String intersectionPayEndYearFlag) {
        this.intersectionPayEndYearFlag = intersectionPayEndYearFlag;
    }

    public String getIntersectionInsuYearFlag() {
        return intersectionInsuYearFlag;
    }

    public void setIntersectionInsuYearFlag(String intersectionInsuYearFlag) {
        this.intersectionInsuYearFlag = intersectionInsuYearFlag;
    }

    public String getWholesaleInsuYearFlag() {
        return wholesaleInsuYearFlag;
    }

    public void setWholesaleInsuYearFlag(String wholesaleInsuYearFlag) {
        this.wholesaleInsuYearFlag = wholesaleInsuYearFlag;
    }

    public String getRiskCode() {
        return riskCode;
    }

    public void setRiskCode(String riskCode) {
        this.riskCode = riskCode;
    }


    @Override
    public String toString() {
        return "LSReplacetalk{" +
                "id='" + id + '\'' +
                ", busiNum='" + busiNum + '\'' +
                ", appntName='" + appntName + '\'' +
                ", insuredName='" + insuredName + '\'' +
                ", comName='" + comName + '\'' +
                ", userName='" + userName + '\'' +
                ", riskName='" + riskName + '\'' +
                ", intersectionPayInty='" + intersectionPayInty + '\'' +
                ", intersectionPrem='" + intersectionPrem + '\'' +
                ", intersectionPayEndYead='" + intersectionPayEndYead + '\'' +
                ", intersectionInsuYear='" + intersectionInsuYear + '\'' +
                ", wholesalePrem='" + wholesalePrem + '\'' +
                ", wholesaleInsuYear='" + wholesaleInsuYear + '\'' +
                ", wholesaleHesitation='" + wholesaleHesitation + '\'' +
                ", intersectionPayEndYearFlag='" + intersectionPayEndYearFlag + '\'' +
                ", intersectionInsuYearFlag='" + intersectionInsuYearFlag + '\'' +
                ", wholesaleInsuYearFlag='" + wholesaleInsuYearFlag + '\'' +
                ", riskCode='" + riskCode + '\'' +
                '}';
    }
}
