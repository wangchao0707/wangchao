package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.ContDao;
import com.sinosoft.easyrecord.dao.ContTimeDao;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSContTime;
import com.sinosoft.easyrecord.entity.Task;
import com.sinosoft.easyrecord.util.FileTypeUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.zip.Zip64Mode;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.httpclient.HttpHost;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.URL;
import java.util.List;
import java.util.Random;

/**
 * 推送视频压缩包到中保信
 */
@Component
public class DownVideoAndUnzip {

    @Autowired
    ContDao contDao;
    @Autowired
    ContTimeDao contTimeDao;

    private static FileTypeUtil fileTypeUtil;
    private static Logger logger = LoggerFactory.getLogger(DownVideoAndUnzip.class);

    /**
     * 下载视频压缩文件并解压流程开始
     * @param contNo 流水号
     */
    public String startTask(String contNo,String localFileDir,String cloudUrl) throws IOException {
        String busiNumFileDir = localFileDir+contNo+"/";
        File file = new File(busiNumFileDir);
        if(!file.exists()){
            file.mkdir();
        }
        //根据流水号,关联查询所有双录视频地址
        LSContTime lsContTime = contTimeDao.findByContNo(contNo);
        //组合为全路径地址
        String zipUrl = lsContTime.getZipUrl();
        //解压到本地
        unZip(cloudUrl,zipUrl,busiNumFileDir);
        File[] files = file.listFiles();
        //删除非视频文件
        String videoFilePath = null;
        for(File f:files) {
            if (fileTypeUtil.getType(f.getPath())==3) {
                videoFilePath = f.getAbsolutePath();
            }
        }
        return videoFilePath;
    }

    public void deleteDir(String contNo,String localFileDir) throws IOException {
        String videoDir = localFileDir + contNo +"/";
        File file = new File(videoDir);
        if (file.exists()&&file.isDirectory()){
            FileUtils.deleteDirectory(file);
        }
    };

    public static void unZip(String cloudUrl, String zipFilePath, String saveFileDir) {
        valiZipFile(zipFilePath);
        ZipArchiveInputStream zais = null;
        try {
            URL url1 = new URL(cloudUrl+zipFilePath);
            logger.info("url1=>{}",url1);
            zais = new ZipArchiveInputStream(new BufferedInputStream((url1.openStream()), 2048));
            ArchiveEntry archiveEntry = null;

            while ((archiveEntry = zais.getNextEntry()) != null) {
                if (!archiveEntry.isDirectory()) {
                    File outFile = new File(saveFileDir, archiveEntry.getName()); // 把解压出来的文件写到指定路径
                    OutputStream os = new BufferedOutputStream(FileUtils.openOutputStream(outFile), 2048);
                    IOUtils.copy(zais, os);
                    IOUtils.closeQuietly(os);
                }
            }
            System.out.println("解压完成");
            //zais = null;
        } catch (IOException e) {
            System.out.println("zip解压报错");
            e.printStackTrace();
        } finally {
            if (zais != null) {
                try {
                    zais.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                IOUtils.closeQuietly(zais);
            }

        }
    }

    private static void valiZipFile(String filePath) {
        if (!"zip".equalsIgnoreCase(FilenameUtils.getExtension(filePath))) {
            throw new RuntimeException("文件后缀不为zip");
        }
    }

}
