package com.sinosoft.easyrecord.util;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.*;
import java.nio.charset.Charset;


/**
 * User: weihao
 * Date: 2018/5/17
 * Time: 10:20
 *  模拟http请求
 */

public class HttpUtil {

    private Logger logger = LoggerFactory.getLogger(HttpUtil.class);

    // 连接超时时间
//    @Value(value = "${message.http.connectTimeOut}")
    private int connectTimeOut = 200000;
    // 读取超时时间
//    @Value(value = "${message.http.readTimeOut}")
    private int readTimeOut = 200000;
    // 处理返回值的编码 默认UTF-8
//    @Value(value = "${message.http.charset}")
    private String charset = "UTF-8";

    //    @Value(value = "${message.http.url}")
    private String messageUrl = "http://localhost:8080/easyrecord/forword/sendMessage";



    /**
     * User: weihao
     * Date: 2018/5/17
     * Time: 11:32
     *  模拟发送 post 请求
     */
    public static String doPost(String url, String data) throws Exception {
        //构建POST请求   请求地址请更换为自己的。
        HttpPost post = new HttpPost(url);
        InputStream inputStream = null;
        String body = null;
        StringBuffer result = new StringBuffer();
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            // 构造消息头
            post.setHeader("Content-type", "application/json; charset=utf-8");
            post.setHeader("Connection", "Close");
            // 构建消息实体
            StringEntity entity = new StringEntity(data, Charset.forName("UTF-8"));
            entity.setContentEncoding("UTF-8");
            // 发送Json格式的数据请求
            entity.setContentType("application/json");
            post.setEntity(entity);
            //发送请求
            HttpResponse response = httpClient.execute(post);
            HttpEntity entityReaponse = response.getEntity();
            if (entityReaponse != null) {
                inputStream = entityReaponse.getContent();
                //转换为字节输入流
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, Consts.UTF_8));
                while ((body = br.readLine()) != null) {
                    result.append(body);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(inputStream != null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result.toString();
    }

    /**
     * User: wanglin
     * Date: 2020/5/30
     * Time: 11:32
     *  模拟向同方核心发送POST请求，请求头新加SOAPAction
     */
    public static String doPostTo(String url, String data) throws Exception {
        //构建POST请求   请求地址请更换为自己的。
        HttpPost post = new HttpPost(url);
        InputStream inputStream = null;
        String body = null;
        StringBuffer result = new StringBuffer();
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            // 构造消息头
            post.setHeader("Content-type", "application/json; charset=utf-8");
            post.setHeader("Connection", "Close");
            post.setHeader("SOAPAction","");
            // 构建消息实体
            StringEntity entity = new StringEntity(data, Charset.forName("UTF-8"));
            entity.setContentEncoding("UTF-8");
            // 发送Json格式的数据请求
            entity.setContentType("application/json");
            post.setEntity(entity);
            //发送请求
            HttpResponse response = httpClient.execute(post);
            HttpEntity entityReaponse = response.getEntity();
            if (entityReaponse != null) {
                inputStream = entityReaponse.getContent();
                //转换为字节输入流
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, Consts.UTF_8));
                while ((body = br.readLine()) != null) {
                    result.append(body);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(inputStream != null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return result.toString();
    }


    /**
     * get请求
     * @return
     */
    public String doGet(String url) {
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            //发送get请求
            HttpGet request = new HttpGet(url);
            HttpResponse response = httpClient.execute(request);

            /**请求发送成功，并得到响应**/
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                /**读取服务器返回过来的json字符串数据**/
                String strResult = EntityUtils.toString(response.getEntity());

                return strResult;
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
