package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;

/**
 * Created by wds on 2018-3-20.
 */
public class TransBodyReq81016 implements Transbody, Serializable {

    public String TYPE;//<!--操作类型    DELETE   OTHER-->
    public String ID;//<!--唯一标识-->
    public String BANKNETWORKCODE;//<!-- 银行网点编码 -->
    public String BANKNETWORKNAME;//<!-- 银行网点名称 -->
    public String PROPERSONCODE;//<!-- 客户经理编码 -->
    public String PROPERSONNAME;//<!-- 客户经理名称 -->

}
