//package com.sinosoft.easyrecord.test;
//
//import java.util.HashMap;
//import java.util.Map;
//
///**
// * Description:
// * User: weihao
// * Date: 2018-09-07
// * Time: 10:08
// */
//public class MapTest {
//
//    public static void main(String[] args) {
//        Map map = new HashMap();
//
//        map.put("1","1");
//        System.out.println(map.get("2"));
//    }
//
//}
