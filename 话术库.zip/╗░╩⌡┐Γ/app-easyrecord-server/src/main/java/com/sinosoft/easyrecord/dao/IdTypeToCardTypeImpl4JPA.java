package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.IdTypeToCustomerCardTypeRepository;
import com.sinosoft.easyrecord.entity.IdTypeToCustomerCardType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class IdTypeToCardTypeImpl4JPA implements IdTypeToCardTypeDao {

    @Autowired
    private IdTypeToCustomerCardTypeRepository idTypeToCustomerCardTypeRepository;

    @Override
    public IdTypeToCustomerCardType findByIdType(String idType) {
        return idTypeToCustomerCardTypeRepository.findByIdType(idType);
    }
}
