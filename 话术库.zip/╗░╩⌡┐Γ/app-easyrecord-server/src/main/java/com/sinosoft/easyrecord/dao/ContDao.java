package com.sinosoft.easyrecord.dao;


import com.sinosoft.easyrecord.entity.LSCont;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ContDao {

    //	LSCont getByBusiNumOrComCode(String code);
//
//	LSCont getByComCode(String comCode);
    //根据主键查询投保单信息
    LSCont findByContNo(String contNo);

    List<LSCont> findByClientContNO(String clientContNo);

    List<LSCont> findAll();

    //	//查询所有最后保存的保单
//	List<LSCont> findByLastOne(char lastOne);
    //获取投保单信息
    //LSCont getByContInfo(String busiNum, String comCode, String riskType);
    //保存所有投保单信息
    void save(LSCont cont);

    //根据ClientContNo查询最新contNo
    LSCont findByClientContNoAndLastOne(String clientContNo, char lastOne);

    //根据 busiNum 查询最新的保单
    LSCont findByComCodeAndInsurComCodeAndBusiNumAndLastOne(String comCode, String insurComCode, String busiNum, char lastOne);

    void delCont(LSCont lsCont);

    List<LSCont> findByLastOneAndInteractive(char lastOne, String interactive);

    List<LSCont.LSContPK> queryPKByLastOneAndInteractive(char lastOne, String interactive);

    void updateZipUrl(String zipurl, String contNo);

    void updateZipUrlTwo(String ZipUrlTwo, String contNo);

    //已上传列表 分页查询
    Page<LSCont> findByOperatorAndLastOneInAndSortTimeLessThanEqualOrderByMakeDateDescMakeTimeDesc(String operator, char[] lastOne, String sortTime, int pageNo);

    //根据busiNum(客户号)查询保单信息
    List<LSCont> findByOperatorAndLastOneInAndSortTimeLessThanEqualAndBusiNum(String operator, List lastOne, String sortTime, String busiNum);

    //获取当前用户上传总条数
    int countByOperatorAndLastOne(String operator, char lastOne);


    List<LSCont> findByInteractiveAndIssend(String interactive, int issend);

    List<String> findVideoIsNotSendCont();

    List<LSCont> findByBusiNumAndInteractive(String busiNum, String interactive);

    List<LSCont> findByBusiNum(String busiNum);


}
