package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSBank;

import java.util.List;

/**
 * Created by wds on 2018-3-17.
 */
public interface BankDao {

    void save(LSBank lsbank);

    void delete();

    List<LSBank> getBankList();

    LSBank findByBankCode(String bankCode);
}
