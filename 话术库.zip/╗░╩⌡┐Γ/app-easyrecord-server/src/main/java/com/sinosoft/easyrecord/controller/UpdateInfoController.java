package com.sinosoft.easyrecord.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Description:
 * User: weihao
 * Date: 2019-03-13
 * Time: 10:12
 * 接收迁移工具发送的视频id，并更新到视频表里面
 */
@RestController
@RequestMapping(value = "/update")
public class UpdateInfoController {

    private Logger logger = LoggerFactory.getLogger(UpdateInfoController.class);


    /**
     * 接收迁移工具发送信息
     **/
    @RequestMapping(value = "/info",method = RequestMethod.POST)
    @ResponseBody
    public Map info(@RequestBody Map<String,Object> reqMap){
        logger.info("update cont info reqMap {}",reqMap);

        Map<String,Object> resMap = new HashMap<>();
        // TODO: 2019/3/13 补全业务逻辑
        logger.info("update cont info resMap {}",resMap );
        return resMap;
    }

    /**
     *  首先收到 迁移工具传过来的 id
     *  然后更新 video 表 和 picture 将id 记录下
     *  然后 更新索引，触发转码 和切片
     *  需要有一个 表或者 记录状态 需要批处理
     *  批处理 包含 1.更新索引，2.获取m3u8的地址，3.获取抽帧图片地址，4.获取文件地址，5.推送信息给质检端
     *  添加排队机制
     *
     **/

}
