package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.EsVideoMainRepository;
import com.sinosoft.easyrecord.entity.EsVideoMain;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EsVideoMainDaoImpl implements EsVideoMainDao{

    @Autowired
    private EsVideoMainRepository esVideoMainRepository;

    @Override
    public String findUpLoadCountByDocCode(String docCode){
        EsVideoMain esVideoMain = esVideoMainRepository.findUpLoadCountByDocCode(docCode);
        return esVideoMain.getUpLoadCount();
    }
}
