package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.dao.ComConfigDao;
import com.sinosoft.easyrecord.entity.LDComConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CallRemoteAfcServiceUtilFactoryImpl implements CallRemoteAfcServiceUtilFactory {

    private ComConfigDao comConfigDao;

    @Autowired
    public void setComConfigDao(ComConfigDao comConfigDao) {
        this.comConfigDao = comConfigDao;
    }

    @Override
    public CallRemoteAfcServiceUtil getInstance(String comcode) {
        LDComConfig comConfig = comConfigDao.findByComCode(comcode);
        if (comConfig == null) {
            throw new IllegalArgumentException("not found LDComConfig [comcode: " + comcode + "]");
        }
        return new CallRemoteAfcServiceUtilImpl(comConfig);
    }
}
