package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSVersionRepository;
import com.sinosoft.easyrecord.entity.LSVersion;

@Component
public class VersionDaoImpl4JPA implements VersionDao {

    @Autowired
    private LSVersionRepository versionRepository;

    public void setVisionRepository(LSVersionRepository visionRepository) {
        this.versionRepository = visionRepository;
    }

    @Override
    public LSVersion findByIsNew(String isNew) {
        return versionRepository.findByIsNew(isNew);
    }

    @Override
    public void saveVision(LSVersion lsVision) {
        versionRepository.saveAndFlush(lsVision);
    }

    @Override
    public LSVersion findByIsNewAndComCode(String isNew, String comCode) {
        return versionRepository.findByIsNewAndComCode(isNew, comCode);
    }
}
