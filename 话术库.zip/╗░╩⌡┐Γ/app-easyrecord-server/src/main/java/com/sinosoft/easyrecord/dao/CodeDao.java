package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LDCode;
import com.sinosoft.easyrecord.entity.LDCode.LDCodePk;

import java.util.List;

public interface CodeDao {

    LDCode findCode(LDCodePk lCodePk);

    LDCode findByCodeRiskType(String codeRistType);

    LDCode findByCode(LDCodePk lCodePk);
    void  saveLdCode(LDCode ldCode);

    List<LDCode> findByCodeType(String codeType);

    List<LDCode> findAllByCodeTypeAndCodeRiskType(String CodeType,String codeName);
}
