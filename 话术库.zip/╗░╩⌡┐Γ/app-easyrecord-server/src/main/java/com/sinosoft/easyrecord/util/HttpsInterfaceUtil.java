package com.sinosoft.easyrecord.util;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.*;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.Map.Entry;


public class HttpsInterfaceUtil {
    private static Log log = LogFactory.getLog(HttpsInterfaceUtil.class);
    static org.apache.commons.logging.Log logger = org.apache.commons.logging.LogFactory
            .getLog(HttpsInterfaceUtil.class);

    public static boolean verify(Map<String, String> params, String key) {
        Map<String, String> newParams = paraFilter(params);
        String mysign = buildMysign(newParams, key);
        logger.debug("请求报文对应签名为 ：" + mysign);
        if (params.get("sign") == null) {
            return false;
        }
        String sign = params.get("sign");
        return mysign.equals(sign);
    }

    public static String buildMysign(Map<String, String> params, String key) {
        String prestr = createLinkString(params);
        prestr = prestr + key;
        String mysign = "";
        try {
            mysign = encryptSHA(prestr);
        } catch (Exception e) {
            logger.error("generate sign exception : ", e);
        }
        return mysign;
    }

    public static Map<String, String> paraFilter(Map<String, String> sArray) {

        Map<String, String> result = new HashMap<String, String>();
        if (sArray == null || sArray.size() <= 0) {
            return result;
        }
        for (String key : sArray.keySet()) {
            String value = sArray.get(key);
            if (value == null || value.equals("") || key.equalsIgnoreCase("sign")
                    || key.equalsIgnoreCase("sign_type")) {
                continue;
            }
            result.put(key, value);
        }
        return result;
    }

    public static String createLinkString(Map<String, String> params) {
        List<String> keys = new ArrayList<String>(params.keySet());
        Collections.sort(keys);
        String prestr = "";
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = params.get(key);
            if (i == keys.size() - 1) {
                prestr = prestr + key + "=" + value;
            } else {
                prestr = prestr + key + "=" + value + "&";
            }
        }
        return prestr;
    }

    public static String encryptSHA(String data) throws NoSuchAlgorithmException {
        MessageDigest alga = MessageDigest.getInstance("SHA-1");
        alga.update(data.getBytes());
        byte[] digesta = alga.digest();
        return new String(new Hex().encode(digesta));
    }
/**
    public static String executePostRequestWithResponse(String url, Map<String, String> params, boolean needProxy,
                                                        int msTimeOut) throws Exception {

        String responseBody = null;
        PostMethod postMethod = new PostMethod(url);

        NameValuePair[] data = new NameValuePair[params.size()];
        int i = 0;
        Iterator<Entry<String, String>> it = params.entrySet().iterator();
        while (it.hasNext()) {
            Entry<String, String> entry = it.next();
            data[i++] = new NameValuePair(entry.getKey(), entry.getValue());
        }
        if (msTimeOut > 0) {
            postMethod.getParams().setSoTimeout(msTimeOut);
        }
        postMethod.setRequestBody(data);
        HttpClient httpClient = new HttpClient(HttpClientManager.getInstance());

//		if (needProxy) {
//
//			/** 以下为NTLS服务协议验证中使，例如 同方全球 内部网络就要放开以下代码来代替以上 **/
//			String proxyUrl = "10.72.1.254";
//			String proxyPort = "8080";
//			String proxyUser = "FSHITD93";
//			String proxyPassword = "Abc123";
//			String domain = "AEGONTHTF.COM";
//			httpClient.getHostConfiguration().setProxy(proxyUrl, Integer.parseInt(proxyPort));
//			List authPrefs = new ArrayList(2);
//			authPrefs.add(AuthPolicy.NTLM);
//			httpClient.getParams().setParameter(HttpMethodParams.USER_AGENT,
//					"Mozilla/5.0 (Windows NT 5.1; rv:14.0) Gecko/20100101 Firefox/14.0.1");
//			httpClient.getParams().setParameter(AuthPolicy.AUTH_SCHEME_PRIORITY, authPrefs);
//			NTCredentials ntc = new NTCredentials(proxyUser, proxyPassword, proxyUrl, domain);
//			httpClient.getState().setProxyCredentials(AuthScope.ANY, ntc);
//		}

      /**  try {
            int statusCode = httpClient.executeMethod(postMethod);
            if (statusCode == HttpStatus.SC_OK || statusCode == HttpStatus.SC_PARTIAL_CONTENT) {
//				InputStream in = postMethod.getResponseBodyAsStream();

//				responseBody = StringUtil.getStrFromStream(in);
                responseBody = postMethod.getResponseBodyAsString();

            }
        } finally {
            postMethod.releaseConnection();
        }
        return responseBody;
    }*/

    /*public static String doPost(String url, Map<String, String> params, int msTimeOut) throws Exception{
        String responseBody = null;
        PostMethod postMethod = new PostMethod(url);
        NameValuePair[] data = new NameValuePair[params.size()];
        try {
            int i = 0;
            for (Entry<String, String> entry : params.entrySet()) {
                data[i++] = new NameValuePair(entry.getKey(), entry.getValue());
            }
            if (msTimeOut > 0) {
                postMethod.getParams().setSoTimeout(msTimeOut);
            }
            postMethod.setRequestBody(data);
            HttpClient httpClient = new HttpClient(HttpClientManager.getInstance());
//			HttpClient httpClient = new HttpClient();

            int statusCode = httpClient.executeMethod(postMethod);
            if (statusCode == HttpStatus.SC_OK || statusCode == HttpStatus.SC_PARTIAL_CONTENT) {
//				InputStream in = postMethod.getResponseBodyAsStream();
                responseBody = postMethod.getResponseBodyAsString();
            }
        }  finally {
            postMethod.releaseConnection();
        }
        return responseBody;
    }*/

    /**
     * 读取文件中的所有内容
     *
     * @param filePath
     * @return
     * @throws FileNotFoundException
     */
    public static String ReadFile(String filePath) throws Exception {

        File file = new File(filePath);
        BufferedReader reader = null;
        StringBuffer fileStr = new StringBuffer();
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                fileStr.append(tempString).append("\n");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        System.out.println(fileStr);
        return fileStr.toString();
    }

    /**
     * 把要写入的字符串写到文件里面
     *
     * @param str
     *            要写入的内容
     * @param destFilePath
     *            目标文件地址
     * @throws Exception
     */
    public static void writeToFile(String str, String destFilePath) throws Exception {
        File temp = new File(destFilePath);
        DataOutputStream outs = new DataOutputStream(new FileOutputStream(temp));
        outs.write(str.getBytes());
        outs.close();

    }

    /**
     * http请求发送xml报文
     */
    public static String doXmlPost(String url, String requestBody, String encode) throws Exception {

        String responseXml = null;
        log.info("==================request body is : " + requestBody);
        //参数Map值
        Map<String,String> params = new HashMap<String,String>();
        //默认规定xml文件存放在requestXML参数中
        //客户端对参数进行URL Encoder处理，服务端对参数进行URL Decoder处理，避免客户端和服务端的编码方式不一样导致中文乱码
        params.put("requestXML",URLEncoder.encode(requestBody, encode));
        String key = "3623010505";
//		key = "3623012201";
        String sign=HttpsInterfaceUtil.buildMysign(params,key);
        params.put("sign",sign);//签名，必填
        //执行请求
//        responseXml= HttpsInterfaceUtil.doPost(url, params, 180000);
        responseXml = URLDecoder.decode(responseXml);
        log.info("==================response body is : " + responseXml);

        return responseXml;

    }

    /**
     * http请求发送xml报文
     */
    public static String doXmlPost(String url, String requestBody, String signKey,String encode,int msTimeOut) throws Exception {

        String responseXml = null;
        log.info("==================request body is : " + requestBody);
        //参数Map值
        Map<String,String> params = new HashMap<String,String>();
        //默认规定xml文件存放在requestXML参数中
        //客户端对参数进行URL Encoder处理，服务端对参数进行URL Decoder处理，避免客户端和服务端的编码方式不一样导致中文乱码
        params.put("requestXML",URLEncoder.encode(requestBody, encode));
        //获取签名
        String sign=HttpsInterfaceUtil.buildMysign(params,signKey);
        params.put("sign",sign);//签名，必填
        //执行请求
//        responseXml= HttpsInterfaceUtil.doPost(url, params, msTimeOut);
        responseXml = URLDecoder.decode(responseXml);
        log.info("==================response body is : " + responseXml);

        return responseXml;

    }


   /* public static String doXmlPostWithoutSign(String url, String requestXml, String encode) throws Exception {
        HttpClient client = null;
        PostMethod method = null;
        String responseXml = null;
        try {
            client = new HttpClient(HttpClientManager.getInstance());
            method = new PostMethod(url);
            method.setRequestHeader("Content-Type", "application/xml; charset=" + encode);
            logger.info("======request body is :" + requestXml);
            method.setRequestEntity(new StringRequestEntity(requestXml, "application/xml", encode));
            if (HttpStatus.SC_OK == client.executeMethod(method)) {
                responseXml = method.getResponseBodyAsString();
            }
            logger.info("======response body is :" + responseXml);
        } finally {
            if (method != null) {
                method.releaseConnection();
            }
        }
        return responseXml;

    }*/

    /**
     * http请求发送Json报文
     * @throws UnsupportedEncodingException
     * @throws Exception
     */
   /* public static String sendJsonPost(String url, String requestBody, String encode) throws Exception {

        String responseXml = null;
        log.info("==================request body is : " + requestBody);
        //参数Map值
        Map<String,String> params = new HashMap<String,String>();
        //默认规定xml文件存放在requestXML参数中
        params.put("requestJOSN",requestBody);
        //客户端对参数进行URL Encoder处理，服务端对参数进行URL Decoder处理，避免客户端和服务端的编码方式不一样导致中文乱码
        for (Iterator iter = params.keySet().iterator(); iter.hasNext(); ) {
            String keyName = (String) iter.next();
            params.put(keyName, URLEncoder.encode(params.get(keyName),encode));
        }
        String key = (String) Constants.BANK_KEY.get("ILIS");
        String sign=HttpsInterfaceUtil.buildMysign(params,key);
        params.put("sign",sign);//签名，必填
        params.put("TransCode", Constants.ILIS_REQUEST_CODE_B00005);//transCode

        //执行请求
        responseXml= HttpsInterfaceUtil.executePostRequestWithResponse(url, params, false, 180000);
        responseXml = URLDecoder.decode(responseXml);
        log.info("==================response body is : " + responseXml);

        return responseXml;

    }*/












    public static String executeJsonPost(String url, Map<String, String> params,int msTimeOut) {
        log.info("--post url:[" + url + "]");

        String responseBody = null;
        PostMethod postMethod = new PostMethod(url);

        NameValuePair[] data = new NameValuePair[params.size()];
        int i = 0;
        Set<String> keys = params.keySet();
        Iterator<Entry<String, String>> it = params.entrySet().iterator();
        while (it.hasNext()) {
            Entry<String, String> entry = it.next();
            data[i++] = new NameValuePair(entry.getKey(), entry.getValue());
        }
        if (msTimeOut > 0) {
            postMethod.getParams().setSoTimeout(msTimeOut);
        }
        postMethod.setRequestBody(data);
        HttpClient httpClient = new HttpClient();

        try {
            int statusCode = httpClient.executeMethod(postMethod);
            log.info("----http status code:" + statusCode);
            if (statusCode == HttpStatus.SC_OK || statusCode == HttpStatus.SC_PARTIAL_CONTENT) {
                responseBody = postMethod.getResponseBodyAsString();
            }
        } catch (HttpException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            postMethod.releaseConnection();
        }
        return responseBody;
    }



    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        String requestXMLFile = "D:\\wallace\\XML\\request.xml";
        String responseXMLFile = "D:\\wallace\\XML\\response.xml";

        try {
            //获取请求报文
            String requestXML = HttpsInterfaceUtil.ReadFile(requestXMLFile);
            //获取url
            String url = "https://ilis-uat.aegonthtf.com/standard/httpsinterface.do?partner=WoNiu";
            //获取密钥
            String SignKey = "123456";
            String encode = "UTF-8";
            //执行请求，获取返回报文
            String responseXml = HttpsInterfaceUtil.doXmlPost(url, requestXML,SignKey, encode,10000);
            //将返回报文放到文件中显示
            System.out.println("请求响应结果：" + URLDecoder.decode(responseXml));
            HttpsInterfaceUtil.writeToFile(URLDecoder.decode(responseXml), responseXMLFile);

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
