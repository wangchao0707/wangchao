package com.sinosoft.easyrecord.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSUploadTimeRepository;
import com.sinosoft.easyrecord.entity.LSUploadTime;

@Component
public class UploadTimeDaoImpl4JPA implements UploadTimeDao {

    private LSUploadTimeRepository uploadTimeRepository;

    @Autowired
    public void setUploadTimeRepository(LSUploadTimeRepository uploadTimeRepository) {
        this.uploadTimeRepository = uploadTimeRepository;
    }

    @Override
    public void saveUploadTime(LSUploadTime lsUploadTime) {
        uploadTimeRepository.saveAndFlush(lsUploadTime);
    }

    @Override
    public LSUploadTime findBySerialNum(String serialNum) {
        return uploadTimeRepository.findBySerialNum(serialNum);
    }

}
