package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSFeedback;

public interface FeedbackDao {

    void saveFeedback(LSFeedback lsFeedback);
}
