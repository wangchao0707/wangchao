package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LDCode;
import com.sinosoft.easyrecord.entity.LDCode.LDCodePk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LDCodeRepository extends JpaRepository<LDCode, LDCodePk> {

    LDCode findByCodeRiskType(String codeRistType);

    LDCode findLDCodeByCodeName(String codeName);
    @Query(value = "select d from LDCode d where codeType = ?1")
    List<LDCode> findAllByCodeType(String CodeType);//通过codeTYpe查询

    @Query(value = "select d from LDCode d where codeType = ?1 and codeRiskType = ?2")
    List<LDCode> findAllByCodeTypeAndCodeRiskType(String CodeType,String codeRiskType);
}
