package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSDelFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by wh on 2018/3/2.
 */
public interface LSDelFileRespository extends JpaRepository<LSDelFile,String>{

    List<LSDelFile> findTop10ByIsDelPic(String isDelPic);


    List<LSDelFile> findTop10ByIsDelVideo(String isDelVideo);

    @Transactional
    @Modifying
    @Query(value = "update LSDelFile set IsDelPic = ?1 where PicId = ?2")
    void updateIsDelPicByPicId(String isDelPic,String picId);

    @Transactional
    @Modifying
    @Query(value = "update LSDelFile set IsDelVideo = ?1 where VideoId = ?2")
    void updateIsDelVideoByVideoId(String isDelVideo,String videoId);

}
