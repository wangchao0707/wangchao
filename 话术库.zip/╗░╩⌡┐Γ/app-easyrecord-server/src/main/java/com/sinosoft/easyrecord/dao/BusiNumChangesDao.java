package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSBusiNumChanges;

/**
 * Created by wh on 2018/1/5.
 */
public interface BusiNumChangesDao {

    void saveBusiNumChange(LSBusiNumChanges lsBusiNumChanges);

}
