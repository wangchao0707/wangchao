package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa4afc.LSOrganizationRepository;
import com.sinosoft.easyrecord.entity4afc.LSOrganization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * Created by WinterLee on 2017/7/19.
 */
@Component
public class OrganizationDaoImpl4JPA implements OrganizationDao {

    @Autowired
    private LSOrganizationRepository organizationRepository;

    public void setOrganizationRepository(LSOrganizationRepository organizationRepository) {
        this.organizationRepository = organizationRepository;
    }

    @Override
    // @Cacheable(value = "organization_list", key = "#comCode")
    public List<LSOrganization> getOrgList(String comCode) {
        return organizationRepository.findByComCodeOrderByOrgCodeDesc(comCode);
    }


    // @Cacheable(value = "organization", key = "#orgCode")
    public LSOrganization getOrganization(String orgCode) {
        Optional<LSOrganization> res = organizationRepository.findById(orgCode);
        return res.orElse(null);
    }


    @Override
    public void deleteByOrgCode(String comCode) {
        organizationRepository.deleteById(comCode);
        organizationRepository.flush();
    }

    @Override
    public void save(LSOrganization org) {
        organizationRepository.save(org);
    }


    @Override
    public LSOrganization findByOrgCode(String orgCode) {
        return getOrganization(orgCode);
    }

    @Override
    public List<LSOrganization> findAll(String comCode) {
        return organizationRepository.findByComCodeOrderByOrgCodeDesc(comCode);
    }

}
