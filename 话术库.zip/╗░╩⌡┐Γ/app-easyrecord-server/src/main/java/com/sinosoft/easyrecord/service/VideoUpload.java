package com.sinosoft.easyrecord.service;

import java.io.File;

/**
 * Created by Administrator on 2017/8/31.
 */
/*public interface VideoUpload {

    void uploadCloud(String contNo, File filePath);


    interface VideoUploadFactory {

        VideoUpload getInstance(String comcode);

    }

}*/
