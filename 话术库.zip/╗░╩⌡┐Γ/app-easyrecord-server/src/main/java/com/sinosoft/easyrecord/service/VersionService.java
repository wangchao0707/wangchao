package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.entity.LSVersion;
import com.sun.tools.ws.processor.model.Service;

import java.util.Map;

public interface VersionService {

    ServiceResult<LSVersion, String[]> saveVersion(String versionId, String type, String comCode);

    ServiceResult<String, String[]> checkVersion(String comCode, String eqInfor, String versionNum);

    RequestResult  updateMd5(Map reqMap);
}
