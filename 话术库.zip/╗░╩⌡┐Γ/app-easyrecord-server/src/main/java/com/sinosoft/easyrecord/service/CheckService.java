package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;

public interface CheckService {

    ServiceResult<String, String[]> checkBusiNum(String comCode, String busiNum, String agentCode, String riskType);

    ServiceResult<String, String[]> localCheckBusiNum(String clientContNo, String comCode, String busiNum, String insurComCode, String operator);

}
