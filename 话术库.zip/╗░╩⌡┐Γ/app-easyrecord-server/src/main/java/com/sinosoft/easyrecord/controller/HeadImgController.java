//package com.sinosoft.easyrecord.controller;
//
//import java.io.File;
//import java.util.Hashtable;
//
//
//import org.apache.commons.io.FilenameUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.sinosoft.almond.commons.transmit.data.ServiceResult;
//import com.sinosoft.almond.commons.transmit.vo.RequestResult;
//import com.sinosoft.easyrecord.service.HeadImgService;
//import com.sinosoft.easyrecord.sso.CurrentUser;
//import com.sinosoft.easyrecord.util.PicTest;
//import com.sinosoft.easyrecord.vo.HeadImgForm;
//
//@RestController
//@RequestMapping("api/user")
//public class HeadImgController {
//
//    final static private Logger logger = LoggerFactory.getLogger(HeadImgController.class);
//
//    @Autowired
//    private HeadImgService headImgService;
//    @Value("${save.configPath}")
//    private String configPath;
//
//    @RequestMapping(value = "/headImg", method = RequestMethod.POST)
//    @ResponseBody
//    public RequestResult uploadHeadImg(@RequestParam(value = "headImg") MultipartFile headImgFile) {
//        String userId = CurrentUser.getUser().getUserId();
//        System.out.println(userId);
//        String fileName = headImgFile.getOriginalFilename();
//        String ext = FilenameUtils.getExtension(fileName);
//        File dir = new File(configPath + "/upload/headImg/" + userId);
//        if (!dir.exists()) {
//            dir.mkdirs();
//        }
//        String newFileName = System.currentTimeMillis() + "." + ext;
//        File targetFile = new File(dir, newFileName);
//
//        // 保存
//        try {
//            headImgFile.transferTo(targetFile);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
////		//压缩图片
////		String newFileName2 = targetFile.getName().substring(0, targetFile.getName().lastIndexOf("."));
////		PicTest picTest = new PicTest(targetFile.getAbsolutePath(),dir.getAbsolutePath(),newFileName2,ext);
////		picTest.zoom(width, height);
//
//        String imgPath = targetFile.getAbsolutePath();
//        String headImg = "/public/upload/headImg/" + userId + "/" + newFileName;
//
//        HeadImgForm headImgForm = new HeadImgForm(userId, imgPath, headImg);
//        ServiceResult<String, String[]> validateRes = headImgForm.validate();
//
//        if (validateRes.isSuccess()) {
//            validateRes = headImgService.saveHeadImg(headImgForm); // userService.saveRegisterInfo(registerForm);
//        }
//        //删除本地图片
//        boolean del = targetFile.delete();
//        logger.info("del file {} success {}",targetFile.getAbsolutePath(),del);
//
//        if (!validateRes.isSuccess()) {
//            RequestResult res = new RequestResult(false);
//            res.setMessages(validateRes.getFailResult());
//            logger.info("headImgForm[{}] validate faild", headImgForm);
//            return res;
//        } else {
//            RequestResult res = new RequestResult(true);
//            Hashtable<String, String> data = new Hashtable<>(1);
//            data.put("headImg", validateRes.getSuccessResult());
//            res.setData(data);
//            logger.info("headImgForm[{}] success [{}]", validateRes.getSuccessResult());
//            return res;
//        }
//
//    }
//
//
//}
