package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSContRespository;
import com.sinosoft.easyrecord.entity.LSCont;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
public class ContDaoImpl4JPA implements ContDao {

    private static final Logger logger = LoggerFactory.getLogger(ContDaoImpl4JPA.class);

    @Autowired
    private LSContRespository contRespository;

    public void setContRespository(LSContRespository contRespository) {
        this.contRespository = contRespository;
    }


    @Override
    public void save(LSCont cont) {
        if (StringUtils.isEmpty(cont.getContNo())) {
            cont.setContNo(UUID.randomUUID().toString());
        }
        logger.info("contRespository.saveAndFlush(cont: {})", cont);
        contRespository.saveAndFlush(cont);
        logger.info("contRespository.saveAndFlush(cont: {})", cont);
    }

    @Override
    public LSCont findByContNo(String contNo) {
        Optional<LSCont> res = contRespository.findById(new LSCont.LSContPK(contNo));
        return res.orElse(null);
    }

    @Override
    public List<LSCont> findByClientContNO(String clientContNo) {
        return contRespository.findByClientContNo(clientContNo);
    }

    @Override
    public LSCont findByClientContNoAndLastOne(String clientContNo, char lastOne) {
        return contRespository.findByClientContNoAndLastOne(clientContNo, lastOne);
    }

    @Override
    public List<LSCont> findAll() {
        return contRespository.findAll();
    }

    @Override
    public LSCont findByComCodeAndInsurComCodeAndBusiNumAndLastOne(String comCode,
                                                                   String insurComCode, String busiNum, char lastOne) {
        return contRespository.findTop1ByComCodeAndInsurComCodeAndBusiNumAndLastOneOrderBySortTimeDesc(comCode, insurComCode, busiNum, lastOne);
    }

    @Override
    public void delCont(LSCont lsCont) {
        contRespository.delete(lsCont);
    }

    @Override
    public List<LSCont> findByLastOneAndInteractive(char lastOne, String interactive) {
        return contRespository.findByLastOneAndInteractiveOrderBySortTimeAsc(lastOne, interactive);
    }

    @Override
    public List<LSCont.LSContPK> queryPKByLastOneAndInteractive(char lastOne, String interactive) {
        return contRespository.queryPKByLastOneAndInteractiveOrderBySortTimeAsc(lastOne, interactive);
    }

    @Override
    public void updateZipUrl(String zipurl, String contNo) {
        contRespository.updateZipUrl(zipurl, contNo);
    }

    @Override
    public void updateZipUrlTwo(String ZipUrlTwo, String contNo) {
        contRespository.updateZipUrlTwo(ZipUrlTwo, contNo);
    }


    @Value(value = "${self.pageSize}")
    private int pageSize;

    @Override
    public Page<LSCont> findByOperatorAndLastOneInAndSortTimeLessThanEqualOrderByMakeDateDescMakeTimeDesc(String operator, char[] lastOne, String sortTime, int pageNo) {
        return contRespository.findByOperatorAndLastOneInAndSortTimeLessThanEqualOrderByModifyDateDescModifyTimeDesc(operator, lastOne, sortTime, new PageRequest(pageNo, pageSize));
    }


    @Override
    public List<LSCont> findByOperatorAndLastOneInAndSortTimeLessThanEqualAndBusiNum(String operator, List lastOne, String sortTime, String busiNum){
        return contRespository.findByOperatorAndLastOneInAndSortTimeLessThanEqualAndContNo(operator, lastOne, sortTime, busiNum);
    }

    @Override
    public int countByOperatorAndLastOne(String operator, char lastOne) {
        return contRespository.countByOperatorAndLastOne(operator, lastOne);
    }

    public List<LSCont> findByInteractiveAndIssend(String interactive,int issend){
        return contRespository.findByInteractiveAndIssend(interactive,issend);
    }

    @Override
    public List<String> findVideoIsNotSendCont() {
        return contRespository.findVideoIsNotSendCont();
    }

    @Override
    public List<LSCont> findByBusiNumAndInteractive(String busiNum, String interactive) {
        return contRespository.findByBusiNumAndInteractive(busiNum,interactive);
    }

    @Override
    public List<LSCont> findByBusiNum(String busiNum) {
        return contRespository.findByBusiNum(busiNum);
    }


}
