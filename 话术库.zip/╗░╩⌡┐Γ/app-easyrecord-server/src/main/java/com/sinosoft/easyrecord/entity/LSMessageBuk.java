package com.sinosoft.easyrecord.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "LSMessageBuk")
public class LSMessageBuk implements Serializable {

    @Id
    @Column(name = "id")
    private String id;
    @Column(name = "MessageNo")
    private String messageNo;

    @Column(name = "UserNo", nullable = false)
    private String userNo;

    @Column(name = "Title")
    private String title;
    @Lob
    @Basic(fetch=FetchType.LAZY)
    @Column(name = "Message")
    private String message;

    @Column(name = "Type")
    private String type;

    @Column(name = "MakeDate")
    private Date makeDate;

    @Column(name = "MakeTime")
    private String makeTime;

    @Column(name = "Source")
    private String source;

    @Column(name = "State")
    private char state;

    @Column(name = "ContNo")
    private String contNo;

    @Column(name = "BusiNum")
    private String busiNum;

    @Column(name = "Ocopertor")
    private String ocopertor;

    @Column(name = "IssueDate")
    private String issueDate;
    @Column(name = "ModifyDate")
    private Date modifyDate;
    @Column(name = "ModifyTime")
    private String modifyTime;


    public LSMessageBuk(String id, LSMessage lsMessage, Date modifyDate, String modifyTime) {
        super();
        this.id = id;
        this.messageNo = lsMessage.getMessageNo();
        this.userNo = lsMessage.getUserNo();
        this.title = lsMessage.getTitle();
        this.message = lsMessage.getMessage();
        this.type = lsMessage.getType();
        this.makeDate = lsMessage.getMakeDate();
        this.makeTime = lsMessage.getMakeTime();
        this.source = lsMessage.getSource();
        this.state = lsMessage.getState();
        this.contNo = lsMessage.getContNo();
        this.busiNum = lsMessage.getBusiNum();
        this.ocopertor = lsMessage.getOcopertor();
        this.issueDate = lsMessage.getIssueDate();
        this.modifyDate = modifyDate;
        this.modifyTime = modifyTime;
    }

    public LSMessageBuk() {
        super();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessageNo() {
        return messageNo;
    }

    public void setMessageNo(String messageNo) {
        this.messageNo = messageNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(Date makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public char getState() {
        return state;
    }

    public void setState(char state) {
        this.state = state;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getBusiNum() {
        return busiNum;
    }

    public void setBusiNum(String busiNum) {
        this.busiNum = busiNum;
    }

    public String getOcopertor() {
        return ocopertor;
    }

    public void setOcopertor(String ocopertor) {
        this.ocopertor = ocopertor;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }


}
