package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.vo.QueryMessageForm;
import com.sinosoft.easyrecord.vo.ReadMessageForm;

/**
 * Created by WinterLee on 2017/7/22.
 */
public interface MessageService {

    RequestResult getMessageList(QueryMessageForm messageQueryForm);

    ServiceResult<String, String[]> readMessage(ReadMessageForm readMessageForm);

    RequestResult findMessage();

    //查询具体保单 质检信息
    RequestResult findByContNo(String contNo);

    RequestResult findMessage(Integer pageNo, String sortTime);

}
