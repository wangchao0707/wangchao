package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.EsRuleMain;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EsRuleMainJpa extends JpaRepository<EsRuleMain,String> {

    List<EsRuleMain> findByChannel(String channel);

    List<EsRuleMain> findByChannelAndRiskTypeCodeIn(String channel,List<String> riskTypeCodeList);
}
