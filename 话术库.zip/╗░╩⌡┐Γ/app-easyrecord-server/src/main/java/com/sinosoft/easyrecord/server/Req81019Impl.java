package com.sinosoft.easyrecord.server;

import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;

/**
 * User: weihao
 * Date: 2019/1/16
 * Time: 9:01
 *  同步产品信息
 */

@Service
public class Req81019Impl implements Req81019 {
    private Logger logger = LoggerFactory.getLogger(Req81019Impl.class);

    private SimpleDateFormat dateSdf = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat timeSdf = new SimpleDateFormat("HH:mm:ss");


    @Transactional
    @Override
    public String getReq81019(String xml) {

        logger.info("Req81019 request xml {}", xml);
        //解析 xml 内容
        XStream xs1 = new XStream();
        xs1.aliasSystemAttribute(null, "class");
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq81019.class);
        xs1.alias("PRODUCTMANAGEMENT", TransbodyReq81019.class);
        // xs1.addImplicitCollection(TransbodyReq82001.class, "PRODUCTMANAGEMENT");//当多个时使用
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        Transhead head = tmp.getTranshead();

        return XmlResult.result(head, "000000", "操作成功");
    }


}
