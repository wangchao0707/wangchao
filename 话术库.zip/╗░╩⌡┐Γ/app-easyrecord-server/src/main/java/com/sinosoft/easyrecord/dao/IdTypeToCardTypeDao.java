package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.IdTypeToCustomerCardType;

public interface IdTypeToCardTypeDao {
    IdTypeToCustomerCardType findByIdType(String idType);
}
