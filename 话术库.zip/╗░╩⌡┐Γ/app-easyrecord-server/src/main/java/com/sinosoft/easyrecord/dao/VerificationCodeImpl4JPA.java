package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.service.impl.SimulateServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sinosoft.easyrecord.dao.jpa.LSVerificationCodeRepository;
import com.sinosoft.easyrecord.entity.LSVerificationCode;

import java.util.UUID;

@Component
public class VerificationCodeImpl4JPA implements VerificationCodeDao {

    private Logger logger = LoggerFactory.getLogger(VerificationCodeImpl4JPA.class);

    @Value(value = "${verification.environment}")
    private String environmentCode;

    @Autowired
    private LSVerificationCodeRepository verificationCodeRepository;

    public void setVerificationCodeRepository(LSVerificationCodeRepository verificationCodeRepository) {
        this.verificationCodeRepository = verificationCodeRepository;
    }

    @Override
    public void saveVerificationCode(LSVerificationCode lsVerificationCode) {
        verificationCodeRepository.saveAndFlush(lsVerificationCode);
    }

    @Override
    public LSVerificationCode findByPhoneNum(String phoneNum) {
        if("js".equals(environmentCode)){
            logger.info("environmentCode:{}",environmentCode);
            LSVerificationCode lsVerificationCode = new LSVerificationCode();
            lsVerificationCode.setId(UUID.randomUUID().toString().replaceAll("-", ""));
            lsVerificationCode.setPhoneNum(phoneNum);
            lsVerificationCode.setVerificationCode("1234");
            lsVerificationCode.setVerificationTime("2020-09-09 12:00:00");
            return lsVerificationCode;
        }else {
            logger.info("生产正常获取验证码");
            return verificationCodeRepository.findTop1ByPhoneNumOrderByVerificationTimeDesc(phoneNum);
        }
    }
}
