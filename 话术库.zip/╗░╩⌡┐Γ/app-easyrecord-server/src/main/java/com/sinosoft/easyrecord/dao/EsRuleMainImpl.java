package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.EsRuleMainJpa;
import com.sinosoft.easyrecord.entity.EsRuleMain;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


@Component

public class EsRuleMainImpl implements EsRuleMainDao {

    @Autowired
    private EsRuleMainJpa esRuleMainJpa;

    @Override
    public List<EsRuleMain> findByChannel(String channel) {
        return esRuleMainJpa.findByChannel(channel);
    }

    public void save(EsRuleMain esRuleMain){
        esRuleMainJpa.saveAndFlush(esRuleMain);
    }

    public List<EsRuleMain> findByChannelAndRiskTypeCodeIn(String channel,List<String> riskTypeCodeList){
        return esRuleMainJpa.findByChannelAndRiskTypeCodeIn(channel,riskTypeCodeList);
    }
}
