package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.dao.QueryDao;
import com.sinosoft.easyrecord.service.QueryService;
import com.sinosoft.easyrecord.utils.StringUtils;
import com.sinosoft.easyrecord.vo.QueryExitForm;
import com.sinosoft.easyrecord.vo.QueryExitVo;
import com.sinosoft.easyrecord.vo.QueryOrgForm;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Service
public class QueryServiceImpl implements QueryService {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(QueryServiceImpl.class);

    @Autowired
    private QueryDao queryDao;

    @Override
    public RequestResult status(QueryExitForm queryExitForm) {
        logger.info("开始调用接口!!!");
        String message = null;
        RequestResult requestResult = new RequestResult(false,message);
        //校验
        String type = queryExitForm.getType();
        if (StringUtils.isEmpty(type)){
            message = "type类型为空";
            requestResult.setMessage(message);
            return requestResult;
        }
        if (!"1".equals(type)){
            message = "type类型不是核心查询";
            requestResult.setMessage(message);
            return requestResult;
        }
        List<String> list = new ArrayList<String>();
        list = queryExitForm.getPolicyNo();
        if (null == list || list.size() == 0){
            message = "查询数据为null";
            requestResult.setMessage(message);
            return requestResult;
        }
        if (list.size() > 100){
            message = "投保单号超过100条";
            requestResult.setMessage(message);
            return requestResult;
        }
        List<QueryOrgForm> contList = new ArrayList<>();
        try{
             contList = queryDao.selectQueryStatus(list);
        }catch(Exception ex){
            logger.error("查询时出错！",ex);
            message = "查询数据异常";
            requestResult.setMessage(message);
            return requestResult;
        }
        long total = contList.size();
        requestResult.setSuccess(true);
        requestResult.setTotal(total);
        requestResult.setResult(contList);
        message= "查询完成";
        requestResult.setMessage(message);
        logger.info("查询完成");
        return requestResult;
    }

    @Override
    public RequestResult isExit(QueryExitForm queryExitForm) {
        logger.info("开始调用接口!!!");
        String message = null;
        RequestResult requestResult = new RequestResult(false,message);
        List<String> list = new ArrayList<String>();
        list = queryExitForm.getPolicyNo();
        if (null == list || list.size() == 0){
            message = "查询数据为null";
            requestResult.setMessage(message);
            return requestResult;
        }
        if (list.size() > 100){
            message = "投保单号超过100条";
            requestResult.setMessage(message);
            return requestResult;
        }
        List<String> data = new ArrayList<>();
        List<QueryExitVo> response = new ArrayList<>();
        try{
            data = queryDao.isExit(list);
            for(String l:list){
                QueryExitVo qeo = new QueryExitVo();
                boolean flag = data.contains(l);
                qeo.setExit(flag);
                qeo.setPolicyNo(l);
                response.add(qeo);
            }
        }catch(Exception ex){
            logger.error("查询时出错！",ex);
            message = "查询数据报错";
            requestResult.setSuccess(false);
            requestResult.setMessage(message);
            return requestResult;
        }
        requestResult.setSuccess(true);
        requestResult.setMessage("查询成功");
        requestResult.setResult(response);
        return requestResult;
    }
}


