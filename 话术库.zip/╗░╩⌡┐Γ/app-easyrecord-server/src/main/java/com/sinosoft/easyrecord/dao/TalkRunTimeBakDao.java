package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.entity.LSTalkRunTimeBak;

public interface TalkRunTimeBakDao {

    void saveTalkRunTimeBak(LSTalkRunTimeBak lsTalkRunTimeBak);

}
