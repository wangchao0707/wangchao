package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LSReplacetalk;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author  lijunming
 * @date   2018-6-21
 */
public interface LSReplaceTalkRepository extends JpaRepository<LSReplacetalk, String> {

    LSReplacetalk  findByBusiNumAndRiskName(String businum,String riskName);

    LSReplacetalk  findByBusiNumAndRiskCode(String businum,String riskCode);

    //LSReplacetalk  findByBusiNum(String businum);

    List<LSReplacetalk> findByBusiNum(String businum);

    List<LSReplacetalk> findByRiskCodeAndBusiNum(String riskType, String busiNum);
}
