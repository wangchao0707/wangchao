package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "LSVideo")
public class LSVideo implements Serializable {


    @Column(name = "VideoNo")
    private String videoNo;
    @Id
    @Column(name = "ContNo")
    private String contNo;
    @Column(name = "ClientContNo")
    private String clientContNo;
    @Column(name = "BeginDate")
    private Date beginDate;
    @Column(name = "BeginTime")
    private String beginTime;
    @Column(name = "TimeLength")
    private String timeLength;
    @Column(name = "VideoType")
    private String videoType;
    @Column(name = "VideoName")
    private String videoName;
    @Column(name = "URL")
    private String URL;
    @Column(name = "Operator")
    private String operator;
    @Column(name = "StorageType")
    private char storageType;
    @Column(name = "MakeDate")
    private Date makeDate;

    @Column(name = "MakeTime")
    private String makeTime;

    @Column(name = "ModifyDate")
    private Date modifyDate;

    @Column(name = "ModifyTime")
    private String modifyTime;

    @Column(name = "RequestId")
    private String requestId;

    @Column(name = "Mp3URL")
    private String mp3URL;

    @Column(name = "CloudFileId", unique = true)
    private String cloudFileId;

    @Column(name = "FileSize")
    private String fileSize;

    @Column(name = "StartTime")
    private String startTime;
    @Column(name = "EndTime")
    private String endTime;

    @Column(name = "IsCopy")
    private String isCopy;

    @Column(name = "CameraVersion")
    private String cameraVersion;

    @Column(name = "VideoUrl")
    private String videoUrl;






    public char getStorageType() {
        return storageType;
    }

    public void setStorageType(char storageType) {
        this.storageType = storageType;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getVideoNo() {
        return videoNo;
    }

    public void setVideoNo(String videoNo) {
        this.videoNo = videoNo;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getClientContNo() {
        return clientContNo;
    }

    public void setClientContNo(String clientContNo) {
        this.clientContNo = clientContNo;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getTimeLength() {
        return timeLength;
    }

    public void setTimeLength(String timeLength) {
        this.timeLength = timeLength;
    }

    public String getVideoType() {
        return videoType;
    }

    public void setVideoType(String videoType) {
        this.videoType = videoType;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String uRL) {
        URL = uRL;
    }

    public Date getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(Date makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getMp3URL() {
        return mp3URL;
    }

    public void setMp3URL(String mp3url) {
        mp3URL = mp3url;
    }

    public String getCloudFileId() {
        return cloudFileId;
    }

    public void setCloudFileId(String cloudFileId) {
        this.cloudFileId = cloudFileId;
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getIsCopy() {
        return isCopy;
    }

    public void setIsCopy(String isCopy) {
        this.isCopy = isCopy;
    }

    public String getCameraVersion() {
        return cameraVersion;
    }

    public void setCameraVersion(String cameraVersion) {
        this.cameraVersion = cameraVersion;
    }

    @Override
    public String toString() {
        return "LSVideo{" +
                "videoNo='" + videoNo + '\'' +
                ", contNo='" + contNo + '\'' +
                ", clientContNo='" + clientContNo + '\'' +
                ", beginDate=" + beginDate +
                ", beginTime='" + beginTime + '\'' +
                ", timeLength='" + timeLength + '\'' +
                ", videoType='" + videoType + '\'' +
                ", videoName='" + videoName + '\'' +
                ", URL='" + URL + '\'' +
                ", operator='" + operator + '\'' +
                ", storageType=" + storageType +
                ", makeDate=" + makeDate +
                ", makeTime='" + makeTime + '\'' +
                ", modifyDate=" + modifyDate +
                ", modifyTime='" + modifyTime + '\'' +
                ", requestId='" + requestId + '\'' +
                ", mp3URL='" + mp3URL + '\'' +
                ", cloudFileId='" + cloudFileId + '\'' +
                ", fileSize='" + fileSize + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", isCopy='" + isCopy + '\'' +
                ", cameraVersion='" + cameraVersion + '\'' +
                ", videoUrl='" + videoUrl + '\'' +
                '}';
    }
}
