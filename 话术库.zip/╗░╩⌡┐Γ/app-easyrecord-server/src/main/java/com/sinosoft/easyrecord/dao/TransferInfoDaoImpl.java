package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSTransferInfoRepository;
import com.sinosoft.easyrecord.entity.LSTransferInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * Description:
 * User: weihao
 * Date: 2019-02-21
 * Time: 19:40
 */
@Component
public class TransferInfoDaoImpl implements TransferInfoDao {

    @Autowired
    private LSTransferInfoRepository lsTransferInfoRepository;

    @Override
    public void saveTransferInfo(LSTransferInfo lsTransferInfo) {
        lsTransferInfoRepository.saveAndFlush(lsTransferInfo);
    }

    @Override
    public LSTransferInfo findByStatus(String status) {
        return lsTransferInfoRepository.findTop1ByStatusOrderByMakeDateDescMakeTimeDesc(status);
    }

    @Override
    public int findByStatusAndBatchNode(String status, String batchNode) {
        return lsTransferInfoRepository.countByStatusAndBatchNode(status,batchNode);
    }

    @Override
    public List<LSTransferInfo> findByOrgCodeAndModifydateAndAndStatus(String orgCode, Date modifyDate, String status) {
        return lsTransferInfoRepository.findByOrgCodeAndModifydateAndAndStatus(orgCode, modifyDate, status);
    }

    @Override
    public List<LSTransferInfo> findByOrgCodeAndModifydate(String orgCode, Date modifyDate) {
        return lsTransferInfoRepository.findByOrgCodeAndModifydate(orgCode, modifyDate);
    }

    @Override
    public LSTransferInfo findByContNo(String contNo) {
        return lsTransferInfoRepository.findByContNo(contNo);
    }

    @Override
    public LSTransferInfo findByStatusAndOrgCode(String status, String[] orgCode) {
        return lsTransferInfoRepository.findTop1ByStatusAndOrgCodeInOrderByMakeDateDescMakeTimeDesc(status, orgCode);
    }

    @Override
    public List<LSTransferInfo> find10ByStatusAndOrgCode(String status, String[] orgCode) {
        return lsTransferInfoRepository.findTop10ByStatusAndOrgCodeInOrderByMakeDateDescMakeTimeDesc(status, orgCode);
    }
}
