package com.sinosoft.easyrecord.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

@Entity
@Table(name = "LSComSignedOnRela")
public class LSComSignedOnRela implements Serializable {

    @EmbeddedId
    private LSComSignedOnRelaPK pk;

    @Column(name = "StartDate")
    private java.sql.Date startDate;

    @Column(name = "EndDate")
    private java.sql.Date endDate;

    @Column(name = "State")
    private char state;


    public LSComSignedOnRela() {
        this(new LSComSignedOnRelaPK());
    }

    public LSComSignedOnRela(LSComSignedOnRelaPK pk) {
        this.pk = pk;
    }

    public String getComCode() {
        return pk.getComCode();
    }

    public void setComCode(String comCode) {
        pk.setComCode(comCode);
    }

    public String getRelaComCode() {
        return pk.getRelaComCode();
    }

    public void setRelaComCode(String relaComCode) {
        pk.setRelaComCode(relaComCode);
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public char getState() {
        return state;
    }

    public void setState(char state) {
        this.state = state;
    }

    @Embeddable
    public static class LSComSignedOnRelaPK implements Serializable {

        @Column(name = "ComCode")
        private String comCode;
        @Column(name = "RelaComCode")
        private String relaComCode;

        public LSComSignedOnRelaPK() {
        }

        public LSComSignedOnRelaPK(String comCode, String relaComCode) {
            this.comCode = comCode;
            this.relaComCode = relaComCode;
        }

        public String getComCode() {
            return comCode;
        }

        public void setComCode(String comCode) {
            this.comCode = comCode;
        }

        public String getRelaComCode() {
            return relaComCode;
        }

        public void setRelaComCode(String relaComCode) {
            this.relaComCode = relaComCode;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            LSComSignedOnRelaPK that = (LSComSignedOnRelaPK) o;

            if (comCode != null ? !comCode.equals(that.comCode) : that.comCode != null) return false;
            return relaComCode != null ? relaComCode.equals(that.relaComCode) : that.relaComCode == null;
        }

        @Override
        public int hashCode() {
            int result = comCode != null ? comCode.hashCode() : 0;
            result = 31 * result + (relaComCode != null ? relaComCode.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            final StringBuffer sb = new StringBuffer("LSComSignedOnRelaPK{");
            sb.append("comCode='").append(comCode).append('\'');
            sb.append(", relaComCode='").append(relaComCode).append('\'');
            sb.append('}');
            return sb.toString();
        }

    }


}
