package com.sinosoft.easyrecord.server;

public interface CallRemoteAfcService<R, Q> {

    Q callService(R requestData, String comCode);

}
