package com.sinosoft.easyrecord.util;

import java.util.Iterator;

import javax.xml.namespace.QName;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.soap.SOAPHeader;
import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.context.MessageContext;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;

/**
 * axis2请求工具类
 * @author zhenglei
 *
 */
@SuppressWarnings("rawtypes")
public class Axis2Util { 
	
//	<?xml version='1.0' encoding='utf-8'?>  
//  <soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope">  
//      <soapenv:Header>  
//          <sean:Security xmlns:sean="http://sean.com">  
//              <sean:Token>  
//                  <sean:Username>root</sean:Username>  
//                  <sean:Password Type="PasswordText">123</sean:Password>  
//              </sean:Token>  
//          </sean:Security>  
//      </soapenv:Header>  
//      <soapenv:Body>  
//          <ns1:add xmlns:ns1="http://sean.com">  
//              <ns1:x>1</ns1:x>  
//              <ns1:y>1</ns1:y>  
//          </ns1:add>  
//      </soapenv:Body>  
//  </soapenv:Envelope>  
//     
	/**
	 * 添加请求头部信息用例
	 * @param _serviceClient
	 */
	public static void addHeaders(org.apache.axis2.client.ServiceClient _serviceClient){  
	    OMFactory omFactory = OMAbstractFactory.getOMFactory();  
	    OMNamespace omNS=omFactory.createOMNamespace("http://sean.com","sean");  
	      
	    OMElement head = omFactory.createOMElement("Security", omNS);  
	    OMElement token = omFactory.createOMElement("Token", omNS);  
	    head.addChild(token);  
	          
	    OMElement userName = omFactory.createOMElement("Username", omNS);  
	    userName.addChild(omFactory.createOMText(userName, "root"));  
	    token.addChild(userName);  
	          
	    OMElement password = omFactory.createOMElement("Password", omNS);  
	    password.addAttribute(omFactory.createOMAttribute("Type", null, "PasswordText"));  
	    password.addChild(omFactory.createOMText(password, "123"));  
	    token.addChild(password);  
	          
	    _serviceClient.addHeader(head);  
	} 
	
	/**
	 * 服务器获取header值
	 */
	public static void getHeaders(){
		SOAPHeader headers = MessageContext.getCurrentMessageContext().getEnvelope()
				.getHeader();
		Iterator it = headers.getChildElements();
		while (it.hasNext()) {
			System.out.println(0);
			OMElement omheader = (OMElement) it.next();
			if (omheader == null) {
				break;
			}
			System.out.println(omheader.getLocalName());
		}
	}
	
	/**
	 * 请求webservice
	 * @param wsdlUrl 地址
	 * @param targetNamespace  命名空间地址
	 * @param name 请求的方法名
	 * @param param 参数
	 * @param paramType 参数类型
	 * @return
	 * @throws AxisFault
	 */
	public static Object[] getResult(String wsdlUrl,String targetNamespace,String name,Object[] param,Class[] paramType) throws AxisFault{
		RPCServiceClient client = new RPCServiceClient();  
        Options options = client.getOptions();  
//        String address = "http://localhost:8080/afc/services/test?wsdl";  
        String address = wsdlUrl;  
        EndpointReference epf = new EndpointReference(address);  
        options.setProperty(HTTPConstants.SO_TIMEOUT, 300000);
        options.setTo(epf);  
          
//        QName qName = new QName("http://axis2.webservice.platform.sinosoft","getName");  
        QName qName = new QName(targetNamespace,name);  
//        return  client.invokeBlocking(qName, new Object[]{"张三"}, new Class[]{String.class});  
        
        //
      addHeaders(client);//添加头部信息
      //
        return  client.invokeBlocking(qName, param, paramType);  
	}
//	public static void main(String[] args) throws AxisFault {
////					String wsdlUrl = "http://localhost:8083/afc/services/EasyRecord?wsdl";
////		String wsdlUrl = "http://58.87.76.211:26666/TPEasyRecord/services/EasyRecord?wsdl";
//		String wsdlUrl = "http://58.87.84.230:26666/TPEasyRecord/services/EasyRecord?wsdl";
////		String wsdlUrl = "http://118.89.240.152:26666/TPEasyRecord/services/EasyRecord?wsdl";
////		String wsdlUrl = "http://10.2.100.79:8001/dir/wsdl?p=sa/65bd52bd76de381daf15736a37d13ab1";
////		String wsdlUrl = "http://localhost:8080/afc/services/EasyRecord?wsdl";
////		String targetNamespace = "tns";
////		String name = "say_hello";//easyScanInterface
////		String wsdlUrl = "http://10.2.100.21:8888/afc/services/EasyRecord?wsdl";
//		String targetNamespace = "http://infservice.webservice.platform.sinosoft";
//		String name = "easyRecord";
////		String wsdlUrl = "http://123.207.138.89:8081/afc2/services/easyScanInterface?wsdl";
////		String wsdlUrl = "http://123.207.138.89:8081/afc2/services/easyScanInterface?wsdl";
//		Class[] paramType= new Class[]{String.class};
//		Object[] param= new Object[]{
////				"你好",123
////				FileDow.outXmlString("注册接口.xml")
////				FileDow.outXmlString("80001.xml")
////				FileDow.outXmlString("800001接口报文核心查询.xml")
//
////				FileDow.outXmlString("800002接口报文核心承保单记录.xml")
////				FileDow.outXmlString("800001接口报文核心查询.xml")
////				FileDow.outXmlString("800003.xml")
////				FileDow.outXmlString("800002.xml")
////				FileDow.outXmlString("800005.xml")
////				FileDow.outXmlString("太平上传测试.xml")
//				FileDow.outXmlString("文件上传查询接口.xml")
////				FileDow.outXmlString("太平文件上传接口.xml")
////				FileDow.outXmlString("70001 (2)0.xml")
////				FileDow.outXmlString("800011.xml")
//
//			  };
//		Object[] result =Axis2Util.getResult(wsdlUrl, targetNamespace, name, param, paramType);
//		System.out.println(result[0]);
//	}
}
