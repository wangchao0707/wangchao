package com.sinosoft.easyrecord.server;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyRes;
import com.sinosoft.easyrecord.dao.ComSignedOnRelaBackupsDao;
import com.sinosoft.easyrecord.dao.ComSignedOnRelaDao;
import com.sinosoft.easyrecord.entity.LSComSignedOnRela;
import com.sinosoft.easyrecord.entity.LSComSignedOnRela.LSComSignedOnRelaPK;
import com.sinosoft.easyrecord.entity.LSComSignedOnRelaBackups;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transbody;
import com.sinosoft.easyrecord.util.xmlBeanUtil.TransbodyReq80004;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transdata;
import com.sinosoft.easyrecord.util.xmlBeanUtil.Transhead;
import com.thoughtworks.xstream.XStream;
/**
 * User: weihao
 * Date: 2018/5/14
 * Time: 17:48
 * 同步公司信息
 */
@Service("req80004")
public class Req80004Impl implements Req80004 {

    @Autowired
    private ComSignedOnRelaDao comSignedOnRelaDao;

    public void setComSignedOnRelaDao(ComSignedOnRelaDao comSignedOnRelaDao) {
        this.comSignedOnRelaDao = comSignedOnRelaDao;
    }

    @Autowired
    private ComSignedOnRelaBackupsDao comSignedOnRelaBackupsDao;

    public void setComSignedOnRelaBackupsDao(ComSignedOnRelaBackupsDao comSignedOnRelaBackupsDao) {
        this.comSignedOnRelaBackupsDao = comSignedOnRelaBackupsDao;
    }


    @Override
    public String req80004(String xml) {
        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransbodyReq80004.class);
        xs1.alias("GENERATIONS", TransbodyReq80004.GENERATIONS.class);
        xs1.alias("GENERATION", TransbodyReq80004.GENERATION.class);
        xs1.addImplicitCollection(TransbodyReq80004.GENERATIONS.class, "GENERATION");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        Transhead head = tmp.getTranshead();
        TransbodyReq80004 body = (TransbodyReq80004) tmp.getTransbody();

        TransbodyReq80004.GENERATIONS generations = body.getGENERATIONS();
        List<TransbodyReq80004.GENERATION> list = generations.GENERATION;
        for (TransbodyReq80004.GENERATION generation : list) {
            LSComSignedOnRelaPK pk = new LSComSignedOnRelaPK(generation.COMPANY, generation.AGENTCOM);
            //根据公司编码查询
            LSComSignedOnRela lsComSignedOnRela = comSignedOnRelaDao.find(pk);
            //备份数据
            if (lsComSignedOnRela != null) {
                LSComSignedOnRelaBackups backups = new LSComSignedOnRelaBackups();
                backups.setId(UUID.randomUUID().toString());
                backups.setComCode(lsComSignedOnRela.getComCode());
                backups.setRelaComCode(lsComSignedOnRela.getRelaComCode());
                backups.setStartDate(lsComSignedOnRela.getStartDate());
                backups.setEndDate(lsComSignedOnRela.getEndDate());
                backups.setState(lsComSignedOnRela.getState());
                Date date = new Date(System.currentTimeMillis());
                backups.setModifyDate(date);
                Long makeTime = date.getTime();
                Date d = new Date(makeTime);
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
                backups.setModifyTime(sdf.format(d));
                comSignedOnRelaBackupsDao.save(backups);
                //删除数据
                comSignedOnRelaDao.deleteByRelaComcode(lsComSignedOnRela);
            }

            //插入数据
            LSComSignedOnRela lsComSignedOnRela2 = new LSComSignedOnRela();
            lsComSignedOnRela2.setComCode(generation.COMPANY);
            lsComSignedOnRela2.setRelaComCode(generation.AGENTCOM);
            lsComSignedOnRela2.setStartDate(Date.valueOf(generation.APPOINTSDATE));
            lsComSignedOnRela2.setEndDate(Date.valueOf(generation.APPOINTEDATE));
            lsComSignedOnRela2.setState(generation.VALIDFLAG.charAt(0));
            comSignedOnRelaDao.save(lsComSignedOnRela2);

        }


        //返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        return xstream.toXML(td);
    }

}
