package com.sinosoft.easyrecord.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by wh on 2018/3/2.
 */
@Entity
@Table(name = "LSDelFile")
public class LSDelFile {

    @Id
    @Column(name = "Id")
    private String id;
    @Column(name = "ContNo")
    private String contNo;
    @Column(name = "IsDelPic")
    private String isDelPic;
    @Column(name = "PicId")
    private String picId;
    @Column(name = "IsDelVideo")
    private String isDelVideo;
    @Column(name = "VideoId")
    private String videoId;

    @Column(name = "picUrl")
    private String picUrl;
    @Column(name = "videoUrl")
    private String videoUrl;
    @Column(name = "fileId")
    private String fileId;

    //增加创建表和修改表的时间
    @Column(name ="makeDate")
    private String makeDate;
    @Column(name="makeTime")
    private String makeTime;
    @Column(name ="modifyDate")
    private String modifyDate;
    @Column(name = "modifyTime")
    private String modifyTime;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getIsDelPic() {
        return isDelPic;
    }

    public void setIsDelPic(String isDelPic) {
        this.isDelPic = isDelPic;
    }

    public String getPicId() {
        return picId;
    }

    public void setPicId(String picId) {
        this.picId = picId;
    }

    public String getIsDelVideo() {
        return isDelVideo;
    }

    public void setIsDelVideo(String isDelVideo) {
        this.isDelVideo = isDelVideo;
    }

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }


    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getFileId() {
        return fileId;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public String getMakeDate() {
        return makeDate;
    }

    public void setMakeDate(String makeDate) {
        this.makeDate = makeDate;
    }

    public String getMakeTime() {
        return makeTime;
    }

    public void setMakeTime(String makeTime) {
        this.makeTime = makeTime;
    }

    public String getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(String modifyDate) {
        this.modifyDate = modifyDate;
    }

    public String getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(String modifyTime) {
        this.modifyTime = modifyTime;
    }

}
