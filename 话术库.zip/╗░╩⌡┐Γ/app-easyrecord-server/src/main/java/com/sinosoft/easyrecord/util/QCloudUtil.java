package com.sinosoft.easyrecord.util;


/**
 * Date:2020/02/17
 * Time:10:58
 * create by zbl
 * 腾讯云操作工具
 */
public class QCloudUtil {

}
