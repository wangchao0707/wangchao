package com.sinosoft.easyrecord.server;

public interface Req80007 {

    public String getReq80007(String xml);

}
