package com.sinosoft.easyrecord.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LsRiskTypeNew")
public class LsRiskTypeNew {

    @Id
    @Column(name = "risktypeId")
    private String risktypeId;

    @Column(name = "contNo")
    private String contNo;

    @Column(name = "riskTypeCode")
    private String riskTypeCode;

    @Column(name = "riskTypeName")
    private String riskTypeName;

    @Column(name = "riskTypeType")
    private String riskTypeType;

    @Column(name = "isHealth")
    private String isHealth;

    @Column(name = "isDeath")
    private String isDeath;

    @Column(name = "isSale")
    private String isSale;

    @Column(name = "riskTime")
    public String riskTime;     //保险期间

    @Column(name = "price")
    public String price;       //保险单价

    @Column(name = "count")
    public String count;       //份数

    @Column(name = "paymentMethod")
    public String paymentMethod; //缴费方式

    @Column(name = "paymentTime")
    public String paymentTime;   //约定缴费时间

    @Column(name = "sumPrice")
    public String sumPrice;      //保险费


    public String getRiskTime() {
        return riskTime;
    }

    public void setRiskTime(String riskTime) {
        this.riskTime = riskTime;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(String paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getSumPrice() {
        return sumPrice;
    }

    public void setSumPrice(String sumPrice) {
        this.sumPrice = sumPrice;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getRiskTypeCode() {
        return riskTypeCode;
    }

    public void setRiskTypeCode(String riskTypeCode) {
        this.riskTypeCode = riskTypeCode;
    }

    public String getRiskTypeName() {
        return riskTypeName;
    }

    public void setRiskTypeName(String riskTypeName) {
        this.riskTypeName = riskTypeName;
    }

    public String getRiskTypeType() {
        return riskTypeType;
    }

    public void setRiskTypeType(String riskTypeType) {
        this.riskTypeType = riskTypeType;
    }

    public String getIsHealth() {
        return isHealth;
    }

    public void setIsHealth(String isHealth) {
        this.isHealth = isHealth;
    }

    public String getIsDeath() {
        return isDeath;
    }

    public void setIsDeath(String isDeath) {
        this.isDeath = isDeath;
    }

    public String getIsSale() {
        return isSale;
    }

    public void setIsSale(String isSale) {
        this.isSale = isSale;
    }

    public String getRisktypeId() {
        return risktypeId;
    }

    public void setRisktypeId(String risktypeId) {
        this.risktypeId = risktypeId;
    }

    @Override
    public String toString() {
        return "LsRiskTypeNew{" +
                "contNo='" + contNo + '\'' +
                ", riskTypeCode='" + riskTypeCode + '\'' +
                ", riskTypeName='" + riskTypeName + '\'' +
                ", riskTypeType='" + riskTypeType + '\'' +
                ", isHealth='" + isHealth + '\'' +
                ", isDeath='" + isDeath + '\'' +
                ", isSale='" + isSale + '\'' +
                ", riskTime='" + riskTime + '\'' +
                ", price='" + price + '\'' +
                ", count='" + count + '\'' +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", paymentTime='" + paymentTime + '\'' +
                ", sumPrice='" + sumPrice + '\'' +
                '}';
    }
}
