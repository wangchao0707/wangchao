package com.sinosoft.easyrecord.controller;

import java.text.SimpleDateFormat;
import java.util.*;

import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sinosoft.almond.commons.transmit.vo.RequestResult;

@RestController
public class TimeController {

    /**
     * User: weihao
     * Date: 2018/4/25
     * Time: 22:22
     *  获取系统当前时间
     */
    @RequestMapping("/time")
    public RequestResult getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式

        String time = sdf.format(new Date());
        RequestResult res = new RequestResult(true);
        Hashtable<String, String> data = new Hashtable<>(1);
        data.put("time", time);
        res.setData(data);
        return res;
    }

    @Autowired
    private VerificationCodeDao verificationCodeDao;

    @RequestMapping("/test")
    public String getTest() {
        LSVerificationCode lsVerificationCode = new LSVerificationCode();
        lsVerificationCode.setId(UUID.randomUUID().toString());
        lsVerificationCode.setPhoneNum("123");
        lsVerificationCode.setVerificationCode("123");
        verificationCodeDao.saveVerificationCode(lsVerificationCode);
        return "ok";
    }

    @Autowired
    private CodeDao codeDao;
    @RequestMapping("/pro")
    public String getPro() {
        List<LDCode> codes = codeDao.findAllByCodeTypeAndCodeRiskType("file_message", "440200");
        System.out.println(codes.get(0).getCodeName());
        return "OK";

    }
    @Autowired
    private TransferInfoDao transferInfoDao;
    @RequestMapping("/org")
    public String getOrg(){
        String orgCode = "110000,120000";
        String[] orgCodes = orgCode.split(",");
        LSTransferInfo lsTransferInfo = transferInfoDao.findByStatusAndOrgCode("R", orgCodes);
        System.out.println(lsTransferInfo);
        return "ok";
    }



}
