package com.sinosoft.easyrecord.util.xmlBeanUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class TransbodyReq80002 implements Transbody, Serializable {

    private static final long serialVersionUID = -5124637531596248279L;

    private ORGANIZATIONS ORGANIZATIONS;


    public ORGANIZATIONS getORGANIZATIONS() {
        return ORGANIZATIONS;
    }

    public void setORGANIZATIONS(ORGANIZATIONS oRGANIZATIONS) {
        ORGANIZATIONS = oRGANIZATIONS;
    }


    public static class ORGANIZATIONS {
        public String ORGANIZATIONCOUNT;//
        public List<ORGANIZATION> ORGANIZATION = new ArrayList<ORGANIZATION>();
    }

    public static class ORGANIZATION {
        public String COMPANY;//<!-- 公司编码-->
        public String COMCODE;//<!-- 机构编码 -->
        public String COMNAME;//<!-- 机构名称 -->
        public String UPCOMCODE; //<!-- 上级机构编码 -->
        public String UPCOMNAME; //<!-- 上级机构名称 -->
    }
}
