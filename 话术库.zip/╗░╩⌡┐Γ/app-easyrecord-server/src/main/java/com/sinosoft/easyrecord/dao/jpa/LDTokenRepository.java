package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.LDToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by WinterLee on 2017/7/18.
 */
public interface LDTokenRepository extends JpaRepository<LDToken, String> {

    LDToken findTop1ByRefreshTokenAndValid(String refreshToken, char valid);

    LDToken findTop1ByUserIdOrderByCreateTimeDesc(String userId);

    List<LDToken> findByUserId(String userId);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "update LDToken t set t.valid=?2 where t.accessToken=?1 ")
    int updateValidById(String accessToken, char valid);

}
