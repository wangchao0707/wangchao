package com.sinosoft.easyrecord.service.impl;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.almond.commons.transmit.vo.RequestResult;
import com.sinosoft.easyrecord.dao.CrashInformationDao;
import com.sinosoft.easyrecord.dao.OperationLogDao;
import com.sinosoft.easyrecord.entity.LSCrashInformation;
import com.sinosoft.easyrecord.service.CrashInformationService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class CrashInformationServiceImpl implements CrashInformationService {
    private static final Logger logger = LoggerFactory.getLogger(ComManagerImpl.class);

    @Autowired
    private CrashInformationDao crashInformationDao;

    public void setCrashInformationDao(CrashInformationDao crashInformationDao) {
        this.crashInformationDao = crashInformationDao;
    }

    @Autowired
    private OperationLogDao operationLogDao;

    public void setOperationLogDao(OperationLogDao operationLogDao) {
        this.operationLogDao = operationLogDao;
    }

    @Override
    public RequestResult saveCrashInformation(String crashInformation, String equipmentInformation) {
        logger.info("crashInformation {} equipmentInformation {}", crashInformation, equipmentInformation);
        String uuid = UUID.randomUUID().toString();
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String time = format.format(date);
        LSCrashInformation lsCrashInformation = new LSCrashInformation();
        lsCrashInformation.setId(uuid);
        lsCrashInformation.setUploadTime(time);
        lsCrashInformation.setCrashInformation(crashInformation);
        lsCrashInformation.setEquipmentInformation(equipmentInformation);
        crashInformationDao.save(lsCrashInformation);
        return new RequestResult(true);
    }


}
