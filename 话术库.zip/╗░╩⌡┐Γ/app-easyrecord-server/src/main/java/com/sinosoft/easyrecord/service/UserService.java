package com.sinosoft.easyrecord.service;

import com.sinosoft.almond.commons.transmit.data.ServiceResult;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.entity.LSVersion;
import com.sinosoft.easyrecord.vo.*;

/**
 * Created by WinterLee on 2017/7/15.
 */
public interface UserService {

    ServiceResult<LSUser, String[]> saveRegisterInfo(RegisterForm registerForm);

    ServiceResult<LSUser, String[]> saveRegisterInfoOutCheckVerCode(RegisterForm registerForm);

    ServiceResult<UserBasicInfo, String> getUserInfo(String userId);

    ServiceResult<UserInfo, String> basicInfo2UserInfo(UserBasicInfo basicInfo);

    ServiceResult<String, String[]> saveExtended(UserExtendedForm userExtendedForm);

    ServiceResult<String, String[]> updatePassword(String oldPassword, String newPassword, String randomCode);

    ServiceResult<String, String[]> foreignPassword(String phoneNo, String newPassword, String valicode, String randomCode);

    void saveDeviceInfor(String userId, String deviceInfor, String token);

    ServiceResult<String, String[]> getVerification(String phoneNum, String comCode);

    ServiceResult<String, String[]> getPhoneNumVerification(String phoneNum, String comCode);

    ServiceResult<String, String[]> foreignVerification(String phoneNum, String comCode);

    ServiceResult<String, String[]> loginVerification(String phoneNum, String comCode);

    ServiceResult<String, String[]> saveFeedback(FeedbackForm feedbackForm);

    ServiceResult<String, String[]> changePhoneNo(String password, String newPhoneNum, String valicode, String randomCode);

    LSUser saveUserByBank(PolicyCoreForm polcyForm);

    ServiceResult<LSVersion, String[]> userVerSion(String versionId, String type);

    LSUser findByPhoneNo(String phoneNo);

}
