package com.sinosoft.easyrecord.dao;

import com.sinosoft.easyrecord.dao.jpa.LSInsuredClientRepository;
import com.sinosoft.easyrecord.entity.LsinsuredClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LSInsuredClientDaoImpl4JPA implements LSInsuredClientDao {
    @Autowired
    private LSInsuredClientRepository lsInsuredClientRepository;

    public void save(LsinsuredClient lsinsuredClient){
        lsInsuredClientRepository.saveAndFlush(lsinsuredClient);
    }
}
