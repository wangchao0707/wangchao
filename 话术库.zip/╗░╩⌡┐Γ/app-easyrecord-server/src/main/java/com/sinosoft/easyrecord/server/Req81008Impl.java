package com.sinosoft.easyrecord.server;

import com.alibaba.fastjson.JSONArray;
import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.*;
import com.sinosoft.easyrecord.entity.LDCode.LDCodePk;
import com.sinosoft.easyrecord.util.HttpUtil;
import com.sinosoft.easyrecord.util.StringSortUtil;
import com.sinosoft.easyrecord.util.xmlBeanUtil.*;
import com.thoughtworks.xstream.XStream;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * User: weihao
 * Date: 2018/5/14
 * Time: 17:49
 * 同步质检消息 和实时话术
 */
@Service
public class Req81008Impl implements Req81008 {

    private Logger logger = LoggerFactory.getLogger(Req81008Impl.class);
    @Autowired
    private MessageDao messageDao;

    @Value(value = "${message.url}")
    private String messageUrl;
    @Autowired
    private CodeDao codeDao;
    @Autowired
    private TalkRunTimeBakDao talkRunTimeBakDao;

    @Autowired
    private ContDao contDao;
    @Autowired
    private MessageBukDao messageBukDao;

    @Autowired
    private AppntDao appntDao;

    @Autowired
    private TalkRunTimeDao talkRunTimeDao;

    @Autowired
    private UserDao userDao;
    @Autowired
    private BankNetWorkDao bankNetWorkDao;

    @Autowired
    private EsVideoMainDao esVideoMainDao;

    @Autowired
    private PictureDao pictureDao;

    @Value("${save.filePath}")
    private String filePath;

    @Transactional
    @Override
    public String getReq81008(String xml) {
        logger.info("req81008 start");
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

        XStream xs1 = new XStream();
        xs1.alias("TRANSDATA", Transdata.class);
        xs1.alias("TRANSBODY", Transbody.class, TransBodyReq81008.class);
        xs1.alias("QCFEEDBACKS", TransBodyReq81008.QCFEEDBACKS.class);
        xs1.alias("QCQUESTIONS", TransBodyReq81008.QCQUESTIONS.class);
        xs1.alias("QCFEEDBACK", TransBodyReq81008.QCFEEDBACK.class);
        xs1.alias("QCPOINTS", TransBodyReq81008.QCPOINTS.class);
        xs1.alias("VERBAL", TransBodyReq81008.VERBAL.class);
        xs1.addImplicitCollection(TransBodyReq81008.QCQUESTIONS.class, "QCFEEDBACK");
        xs1.addImplicitCollection(TransBodyReq81008.QCPOINTS.class, "VERBAL");
        Transdata tmp = (Transdata) xs1.fromXML(xml);
        TransBodyReq81008 body = (TransBodyReq81008) tmp.getTransbody();
        Transhead head = tmp.getTranshead();
        TransBodyReq81008.QCFEEDBACKS QCFEEDBACKS = body.getQCFEEDBACKS();
        // 获取基本信息
        String contNo = QCFEEDBACKS.BUSINESSNO;
        String agentCode = QCFEEDBACKS.AGENTID;
        String qcoperator = QCFEEDBACKS.QCOPERATOR;
        String busiNum = StringSortUtil.getArrayStringSort(QCFEEDBACKS.DOCCODE);
        String updateTime = QCFEEDBACKS.QCRECORDCOUNT;
        String comCode = head.getCOMPANY();
        String ISFLAG = QCFEEDBACKS.ISFLAG;
        String userId = null;
        LSUser lsUser = userDao.getByComInfo(comCode, agentCode);
        if (lsUser == null) {
            userId = QCFEEDBACKS.AGENTID;
        } else {
            userId = lsUser.getUserId();
        }

        List<TransBodyReq81008.QCFEEDBACK> list = QCFEEDBACKS.QCQUESTIONS.QCFEEDBACK;
        // 备份 删除
        // 根据业务流水号查询 保单 clientcontNo
        LSCont lsCont = contDao.findByContNo(contNo);
        LSAppnt lsAppnt = appntDao.findByContNo(contNo);
        String appntName = lsAppnt.getName();
        if (lsCont.getOrginContNo() != null) {
            LSCont lastCont = contDao.findByContNo(lsCont.getOrginContNo());
            List<LSMessage> lsMessages = null;
            if (lastCont != null) {
                lsMessages = messageDao.findByContNo(lastCont.getClientContNo());
            } else {
                lsMessages = messageDao.findByContNo(lsCont.getClientContNo());
            }

            if (lsMessages != null && lsMessages.size() != 0) {
                logger.info("messagebak start");
                for (LSMessage lsMessage : lsMessages) {
//                        LSMessageBuk lsMessageBuk = new LSMessageBuk(UUID.randomUUID().toString(), lsMessage,
//                                new Date(System.currentTimeMillis()), sdf.format(new java.util.Date()));
//                        messageBukDao.save(lsMessageBuk);
                    messageDao.del(lsMessage);
                    logger.info("businum {} del message title {}", busiNum, lsMessage.getTitle());
                }
            }
        }

        // 获取质检结果
        // 根据字典表 查询类型
        LDCode ldCode = codeDao.findByCode(new LDCodePk("message_type", ISFLAG));
        String riskType ="";
        String codeRiskType="";
        if(ldCode!=null){
            codeRiskType=ldCode.getCodeRiskType();
            riskType = ldCode.getCodeRiskType();
        }

        for (TransBodyReq81008.QCFEEDBACK back : list) {
            LSMessage lsMessage2 = new LSMessage();
            lsMessage2.setMessageNo(UUID.randomUUID().toString());
            lsMessage2.setUserNo(userId);
            lsMessage2.setTitle(back.ISSUETYPES);
            lsMessage2.setType(riskType);
            // 修改 保单 状态
            if (lsCont != null) {
                lsMessage2.setContNo(lsCont.getContNo());
                lsCont.setInteractive(codeRiskType);
                contDao.save(lsCont);
            } else {
                lsMessage2.setContNo("");
            }

            lsMessage2.setMessage(back.ISSUEDESC);

            lsMessage2.setBusiNum(busiNum);
            lsMessage2.setOcopertor(qcoperator);
            lsMessage2.setMakeDate(new Date(System.currentTimeMillis()));
            lsMessage2.setMakeTime(sdf.format(new java.util.Date()));
            lsMessage2.setIssueDate(back.ISSUEDATE);
            lsMessage2.setSource("core");
            /**
             * 添加内容 e店对接后初始 状态改为 H
             * 然后发送成功变成 F 失败为L
             **/
            if (riskType.equals("S")){
                lsMessage2.setState('F');
            } else {
                lsMessage2.setState('H');
            }
            messageDao.save(lsMessage2);

//            sendMessage(agentCode, busiNum, appntName, ldCode);

            //银保添加
            if ("Y".equals(lsCont.getOperation())) {
                String banknetWork = lsCont.getBanknetWork();
                List<LSBankNetWork> bankList = bankNetWorkDao.findAllByBankNetWorkCode(banknetWork);
                if (bankList != null && bankList.size() != 0) {
                    for (LSBankNetWork bankNetWork : bankList) {
                        String propersonCode = bankNetWork.getPropersonCode();
                        LSUser lsUserBank = userDao.findByAgentCode(propersonCode);
                        if (lsUserBank != null) {
                            lsMessage2.setMessageNo(UUID.randomUUID().toString());
                            //客户经理所属单 不在创建 客户经理银保消息
                            if (!userId.equals(lsUserBank.getUserId())) {
                                lsMessage2.setUserNo(lsUserBank.getUserId());
                                messageDao.save(lsMessage2);
                            }
                        }
                    }

                }

            }

        }
        // 备份实时话术
        // 删除实时话述
        List<LSTalkRunTime> talkRunTimes = talkRunTimeDao.findByBusiNumAndOperatorAndComCodeAndInsurComCode(
                StringSortUtil.getArrayStringSort(busiNum), userId, comCode, comCode);
        if (talkRunTimes != null && talkRunTimes.size() != 0) {
            for (LSTalkRunTime lsTalkRunTime : talkRunTimes) {
//                LSTalkRunTimeBak lsTalkRunTimeBak = new LSTalkRunTimeBak(UUID.randomUUID().toString(), lsTalkRunTime, new Date(System.currentTimeMillis()), sdf.format(new java.util.Date()));
//                logger.info("talkruntimebak {}", lsTalkRunTimeBak);
//                talkRunTimeBakDao.saveTalkRunTimeBak(lsTalkRunTimeBak);

                talkRunTimeDao.deleteTalkRunTime(lsTalkRunTime);
                logger.info("busiNum {} talkRunTime delete talk {}", StringSortUtil.getArrayStringSort(busiNum), lsTalkRunTime.getStep());
            }
        }

        String VERBALCOUNT = QCFEEDBACKS.QCPOINTS.VERBALCOUNT;
        if (!VERBALCOUNT.equals("0")) {


            List<TransBodyReq81008.VERBAL> verbals = QCFEEDBACKS.QCPOINTS.VERBAL;
            // 保存 实时 话述
            for (TransBodyReq81008.VERBAL verbal : verbals) {
                LSTalkRunTime lsTalkRunTime = new LSTalkRunTime();
                lsTalkRunTime.setId(UUID.randomUUID().toString());
                lsTalkRunTime.setBusiNum(busiNum);
                lsTalkRunTime.setComCode(comCode);
                lsTalkRunTime.setInsurComCode(verbal.COMPANY);
                lsTalkRunTime.setOperator(userId);
                lsTalkRunTime.setOrderNum(1);
                lsTalkRunTime.setOrgCode(lsCont.getOrgCode());
                lsTalkRunTime.setContNo(lsCont.getContNo());
                lsTalkRunTime.setPkId(verbal.DESCRIBEID);
                lsTalkRunTime.setRiskType(StringSortUtil.getArrayStringSort(verbal.RISKCODE));
                lsTalkRunTime.setType(verbal.RISKTYPE);
                lsTalkRunTime.setTalkPointCode(verbal.QCPOINTCODE);
                lsTalkRunTime.setStep(verbal.QCPOINT);
                lsTalkRunTime.setTaleConent(verbal.QCTRICK);
                lsTalkRunTime.setUpdateTime(updateTime);
                lsTalkRunTime.setIsFlag(riskType);
                //保存是否可读 和是否合并
//                LSTalk lsTalk=talkDao.findTop1ByTalkPointCode(verbal.QCPOINTCODE);
//                if(lsTalk!=null){
//                    lsTalkRunTime.setIsRead(lsTalk.getIsRead());
//                } else {
                //整改时将整改话术设置为可读
                if("322".equals(verbal.QCPOINTCODE)){
                    lsTalkRunTime.setIsRead("Y");
                }else{
                    lsTalkRunTime.setIsRead("N");
                }

//                }
                logger.info("lstalkruntime {}", lsTalkRunTime);
                talkRunTimeDao.saveTalkRunTime(lsTalkRunTime);

            }
        }

        // 返回xml
        Transdata td = new Transdata();
        TransbodyRes tr = new TransbodyRes();
        TransbodyRes.Transresult result = new TransbodyRes.Transresult();
        result.RETURNCODE = "000000";
        result.MESSAGE = "操作成功";

        tr.setTRANSRESULT(result);
        td.setTranshead(head);
        td.setTransbody(tr);
        XStream xstream = new XStream();
        xstream.aliasSystemAttribute(null, "class");
        xstream.alias("TRANSDATA", Transdata.class);
        xstream.alias("TRANSRESULT", TransbodyRes.Transresult.class);
        /*List<LSMessage> lsmessage =messageDao.findByBusinum(lsCont.getBusiNum());
        String upLoadCount = talkRunTimes.get(0).getUpdateTime();*/

        return xstream.toXML(td);


    }



    /**
     * 发送消息给 消息平台
     **/
//    private void sendMessage(String agentCode, String busiNum, String appntName, LDCode ldCode) {
//        //组织封装数据
//        JSONObject sendMap = new JSONObject();
//        sendMap.put("sendType", "1");
//        sendMap.put("sendTo", agentCode);
//        sendMap.put("dataSource", "sl");
//        sendMap.put("title", "质检消息");
//        sendMap.put("msgType", "sl01");
//        sendMap.put("topMsgType", "01");
//        if (ldCode.getCodeRiskType().equals("L")) {
//            sendMap.put("message", "亲爱的销售伙伴，您的客户" + appntName + "编号为" + busiNum + "投保单需要重新进行双录，请前往【全部订单】【问题件】模块进行操作。");
//        } else if (ldCode.getCodeRiskType().equals("R")) {
//            sendMap.put("message", "亲爱的销售伙伴，您的客户" + appntName + "编号为" + busiNum + "投保单录音录像文件质检不通过，请您及时联系客户。");
//        }
//        //把质检消息发送给e店
//        //多线程跑
//        Thread thread = new Thread() {
//            @Override
//            public void run() {
//                try {
//                    HttpUtil.doPost(messageUrl, sendMap.toString());
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        };
//        thread.start();
//
//    }
}
