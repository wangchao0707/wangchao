package com.sinosoft.easyrecord.server;


import com.sinosoft.easyrecord.dao.*;
import com.sinosoft.easyrecord.entity.LSCont;
import com.sinosoft.easyrecord.entity.LSStateLoca;
import com.sinosoft.easyrecord.entity.LSUser;
import com.sinosoft.easyrecord.service.PolicyService;
import com.sinosoft.easyrecord.util.AgeUtil;

import java.util.List;

public interface CoreInteractive {

    void uploadCloud(LSCont.LSContPK lsCont);
    //长时间收不到回调，主动去获取索引
    void updateVideo(LSCont.LSContPK lsCont);

    void dealOneUser(LSUser lsUser);

    void submitCont(LSCont lsCont);

    void submitCont(LSCont.LSContPK lsCont);

    void downCloud(LSCont.LSContPK lsCont);

//    void setUserDao(UserDao userDao);
//
//    void setAuthen(AuthenticationDao authen);
//
//    void setPolicyService(PolicyService policyService);
//
//    void setContTimeDao(ContTimeDao contTimeDao);
//
//    void setContStateDao(ContStateDao contStateDao);
//
    void  sendContState(List<LSStateLoca> lsStateLocaList,String comCode);
//
//    void setLsStateLocaDao(LSStateLocaDao lsStateLocaDao);
//
//    void setReplaceTalkDao(ReplaceTalkDao replaceTalkDao);

}
