package com.sinosoft.easyrecord.dao.jpa;

import com.sinosoft.easyrecord.entity.VideoIsSend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface VideoIsSendRepository extends JpaRepository<VideoIsSend,String> {

    VideoIsSend findByContNo(String contNo);
}
