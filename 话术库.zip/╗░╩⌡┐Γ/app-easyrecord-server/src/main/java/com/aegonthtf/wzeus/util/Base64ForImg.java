package com.aegonthtf.wzeus.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.codec.binary.Base64;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


@SuppressWarnings("restriction")
public class Base64ForImg {

    public static String GetImageStr(String imgFilePath) {// 将图片文件转化为字节数组字符串，并对其进行Base64编码处理
        byte[] data = null;

        // 读取图片字节数组
        try {
            InputStream in = new FileInputStream(imgFilePath);
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 对字节数组Base64编码
       //此方式返回的json没有换行符
      Base64 encoder = new Base64();
//      byte[] zipData = gZip(data);
      return encoder.encodeBase64String(data);// 返回Base64编码过的字节数组字符串
    }
    /**
	 * 64位编码解析字节数
	 * @param imgStr（64位编码）
	 * @return  字节数
	 */
	public static byte[] GenerateImage(String imgStr)
    {//对字节数组字符串进行Base64解码并生成图片
        if (imgStr == null) //图像数据为空
            return null;
        BASE64Decoder decoder = new BASE64Decoder();
        try 
        {
            //Base64解码
            byte[] b = decoder.decodeBuffer(imgStr);
            for(int i=0;i<b.length;++i)
            {
                if(b[i]<0)
                {//调整异常数据
                    b[i]+=256;
                }
            }
            
             return b;
            
        } 
        catch (Exception e) 
        {
        	e.printStackTrace();
            return null;
        }
    }
    /***
     * @description 压缩GZip
     * @param data 要压缩的二进制数据
     * @return
     */
    public static byte[] gZip(byte[] data) {
        byte[] b = null;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            GZIPOutputStream gzip = new GZIPOutputStream(bos);
            gzip.write(data);
            gzip.finish();
            gzip.close();
            b = bos.toByteArray();
            bos.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return b;
    }
   
    public static boolean GenerateImage(String imgStr, String imgFilePath) {// 对字节数组字符串进行Base64解码并生成图片
        if (imgStr == null) // 图像数据为空
            return false;
        BASE64Decoder decoder = new BASE64Decoder();
        try {
            // Base64解码
            byte[] bytes = decoder.decodeBuffer(imgStr);
            for (int i = 0; i < bytes.length; ++i) {
                if (bytes[i] < 0) {// 调整异常数据
                    bytes[i] += 256;
                }
            }
            File parentFile = new File(imgFilePath).getParentFile();
            if(!parentFile.exists()){
                parentFile.mkdirs();
            }
            // 生成jpeg图片
            OutputStream out = new FileOutputStream(imgFilePath);
            out.write(bytes);
            out.flush();
            out.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
  //base64字符串转化成图片    
    public static  byte[] GenerateImagebyte(String imgStr)    
    {   //对字节数组字符串进行Base64解码并生成图片    
        if (imgStr == null) //图像数据为空    
            return null;    
		Base64 base64 = new Base64();
        try     
        {    
            //Base64解码    
        	byte[] b = base64.decode(imgStr.getBytes());
            for(int i=0;i<b.length;++i)    
            {    
                if(b[i]<0)    
                {//调整异常数据    
                    b[i]+=256;    
                }    
            }     
            return b;    
        }     
        catch (Exception e)     
        {    
            return null;    
        }    
    }  
    
    public static String getBase64(String str) {
        byte[] b = null;
        String s = null;
        try {
            b = str.getBytes("utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        if (b != null) {
            s = new BASE64Encoder().encode(b);
        }
        return s;
    } 
}
