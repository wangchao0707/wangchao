package com.aegonthtf.wzeus.util;



import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DES encrypt
 * Created by liuchaoren on 2016/12/2.
 */
public class EncryptDESUtils {

    private static Logger logger = LoggerFactory
            .getLogger(EncryptDESUtils.class);

    /**
     * DES encrypt
     * @param data data
     * @param keyStr key
     * @return encrypted data
     */
    public static String encryptBasedDes(String data, String keyStr) {
        String encryptedData = null;

        try {
            SecureRandom sr = new SecureRandom();

            // create key factory，DESKeySpec object to SecretKey object
            DESKeySpec deskey = new DESKeySpec(keyStr.getBytes(Charset.forName("UTF-8")));
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey key = keyFactory.generateSecret(deskey);

            // encrypting data
            Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key, sr);
            byte[] result = cipher.doFinal(data.getBytes(Charset.forName("UTF-8")));
            encryptedData = URLEncoder.encode(new String(new Base64().encode(result)), "UTF-8");
        } catch (Exception e) {
            logger.error("encryptBasedDes exception: " + e.getMessage(), e);
        }

        return encryptedData;
    }

    /**
     * DES decrypt
     * @param cryptData encrypted data
     * @param keyStr key
     * @return decrypted data
     */
    public static String decryptBasedDes(String cryptData, String keyStr) {
        String decryptedData = null;

        try {
            // DES need SecureRandom
            SecureRandom sr = new SecureRandom();
            DESKeySpec deskey = new DESKeySpec(keyStr.getBytes(Charset.forName("UTF-8")));
            // create key factory，DESKeySpec object to SecretKey object
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey key = keyFactory.generateSecret(deskey);
            // decrypting data
            Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, key, sr);
            // decrypted data to base64 data
            byte[] data = new Base64().decode(URLDecoder.decode(cryptData, "UTF-8").getBytes(Charset.forName("UTF-8")));
            // base64 data to string
            decryptedData = new String(cipher.doFinal(data));
        } catch (Exception e) {
            logger.error("decryptBasedDes exception: " + e.getMessage(), e);
        }

        return decryptedData;
    }

}
